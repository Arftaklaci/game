"use strict"

var width, height, resize;

// edit below
var collator = "en";
var webUrl = "https://world-geography-games.com/africa.html";

var labels =
{
    website         : "World Geography Games",
    title           : "Countries of Africa",
    titleTwo        : "Countries \n    Africa",
    play            : "play",
    options         : "options",
    map             : "map",
    tapStart        : "Tap on the map to start",
    clickStart      : "Click on the map to start\nUse mouse wheel to zoom",
    incorrect       : "Incorrect. Try again!",
    score           : "Score: ",
    attempts        : "Attempts: ",
    attemptsEnd     : "Attempts",
    skip            : "Skip",
    skipped         : "Skipped",
    countries       : "Countries",
    sound           : "SOUND",
    carMulti        : " Central\n African\nRepublic",
    drCongoMulti    : "Democratic\nRepublic of\n the Congo",
    numOfCountries  : "Number of Countries",
    region1         : "Southern Africa",
    region2         : "Northern Africa",
    region3         : "Central Africa",
    region4         : "Western Africa",
    region5         : "Eastern Africa",
    westernSahara   : "",
    select          : "select",
    selectAtleast   : "Please select at least 5 countries",
    back            : "back",
    map             : "map",
    playAgain       : "Play Again",
    stop            : "Stop",
}

var countriesLabels = {

    botswana          : "Botswana",
    eswatini          : "Eswatini",
    lesotho           : "Lesotho",
    namibia           : "Namibia",
    southAfrica       : "South Africa",
	
    algeria           : "Algeria",
    egypt             : "Egypt",
    libya             : "Libya",
    morocco           : "Morocco",
    sudan             : "Sudan",
    tunisia           : "Tunisia",
	
    angola            : "Angola",
    cameroon          : "Cameroon",
    car               : "Central African Republic",
    chad              : "Chad",
    drCongo           : "Democratic Republic of the Congo",
    equatorialGuinea  : "Equatorial Guinea",
    gabon             : "Gabon",
    congo             : "Republic of the Congo",
    saoTomeAndPrincipe: "São Tomé and Príncipe",
	
    benin             : "Benin",
    burkinaFaso       : "Burkina Faso",
    capeVerde         : "Cape Verde",
    gambia            : "Gambia",
    ghana             : "Ghana",
    guinea            : "Guinea",
    guineaBissau      : "Guinea-Bissau",
    ivoryCoast        : "Ivory Coast",
    liberia           : "Liberia",
    mali              : "Mali",
    mauritania        : "Mauritania",
    niger             : "Niger",
    nigeria           : "Nigeria",
    senegal           : "Senegal",
    sierraLeone       : "Sierra Leone",
    togo              : "Togo",
	
    burundi           : "Burundi",
    comoros           : "Comoros",
    djibouti          : "Djibouti",
    eritrea           : "Eritrea",
    ethiopia          : "Ethiopia",
    kenya             : "Kenya",
    madagascar        : "Madagascar",
    malawi            : "Malawi",
    mauritius         : "Mauritius",
    mozambique        : "Mozambique",
    rwanda            : "Rwanda",
    seychelles        : "Seychelles",
    somalia           : "Somalia",
    southSudan        : "South Sudan",
    tanzania          : "Tanzania",
    uganda            : "Uganda",
    zambia            : "Zambia",
    zimbabwe          : "Zimbabwe"
}

// don't edit below

// number of attempts
var attempts = +0;
// number of skipped countries
var skips = +0;
// by default all countries are included
var questionsArray = Object.values(countriesLabels);
// always contains all countries
const questionsArrayStatic = questionsArray.slice();

// southern
var region1Array = [];
for (let x = 0; x < 5; x++) {
  region1Array.push(questionsArray[x]);
}
// northern
var region2Array = [];
for (let x = 5; x < 11; x++) {
  region2Array.push(questionsArray[x]);
}
// central 
var region3Array = [];
for (let x = 11; x < 20; x++) {
  region3Array.push(questionsArray[x]);
}
// western
var region4Array = [];
for (let x = 20; x < 36; x++) {
  region4Array.push(questionsArray[x]);
}
// eastern
var region5Array = [];
for (let x = 36; x < 54; x++) {
  region5Array.push(questionsArray[x]);
}

// toggle buttons, by default they are green (frame 0)
var btnRegion1Frame = 0;
var btnRegion2Frame = 0;
var btnRegion3Frame = 0;
var btnRegion4Frame = 0;
var btnRegion5Frame = 0;
var soundButtonFrame = 0;

var toggleButtonsFrames = [];
for (let x = 0; x < questionsArrayStatic.length; x++) {
  toggleButtonsFrames.push(+0);
}

// if true you can toggle regions, else you toggle countries on options
var regionsVisible = true;

function tweenObj(aScene, obj, fromN, toN) {
  obj.alpha = fromN;

  aScene.tweens.add({
      targets: [obj],
      alpha: { value: toN },
      ease: 'Linear',
      duration: 400,
  });
}

// resize
const DEFAULT_WIDTH = 1280
const DEFAULT_HEIGHT = 720
const MAX_WIDTH = DEFAULT_WIDTH * 1.5
const MAX_HEIGHT = DEFAULT_HEIGHT * 1.5
let SCALE_MODE = 'SMOOTH'

const config = {
    type: Phaser.AUTO,
    parent: 'geo-game',
    backgroundColor : 0x34C5EB,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,

    scale: 
    {
        mode: Phaser.Scale.NONE,
        parent: "geo-game",
    },
    scene: [Loading, Menu, UserInterface, GraphUI, Gameplay, Options, Graph]
}

window.addEventListener('load', () => {
    const game = new Phaser.Game(config)
  
    const resize = () => {
      const w = window.innerWidth
      const h = window.innerHeight
  
      let width = DEFAULT_WIDTH
      let height = DEFAULT_HEIGHT
      let maxWidth = MAX_WIDTH
      let maxHeight = MAX_HEIGHT
      let scaleMode = SCALE_MODE
  
      let scale = Math.min(w / width, h / height)
      let newWidth = Math.min(w / scale, maxWidth)
      let newHeight = Math.min(h / scale, maxHeight)
  
      let defaultRatio = DEFAULT_WIDTH / DEFAULT_HEIGHT
      let maxRatioWidth = MAX_WIDTH / DEFAULT_HEIGHT
      let maxRatioHeight = DEFAULT_WIDTH / MAX_HEIGHT
  
      // smooth scaling
      let smooth = 1
      if (scaleMode === 'SMOOTH') {
        const maxSmoothScale = 1.15
        const normalize = (value, min, max) => {
          return (value - min) / (max - min)
        }
        if (width / height < w / h) {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioWidth) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        } else {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioHeight) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        }
      }

      // resize the game
      game.scale.resize(newWidth * smooth, newHeight * smooth)
      // scale the width and height of the css
      game.canvas.style.width = newWidth * scale + 'px'
      game.canvas.style.height = newHeight * scale + 'px'
      // center the game with css margin
      game.canvas.style.marginTop = `${(h - newHeight * scale) / 2}px`
      game.canvas.style.marginLeft = `${(w - newWidth * scale) / 2}px`
    }

    window.addEventListener('resize', event => {
      resize()
    })
  
    resize()
  })
