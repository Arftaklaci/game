"use strict"
var width, height, resize;
var webUrl = "https://world-geography-games.com/world.html";

var labels = 
{
    website         : "World Geography Games",
    title           : "Mountains",
    titleTwo        : "Mountains",
    play            : "play",
    options         : "options",
    map             : "map",
    sound           : "SOUND",
    photos          : "PHOTOS",
    tapStart        : "Tap on the map to start",
    clickStart      : "Click on the map to start",
    incorrect       : "Incorrect. Try again!",
    score           : "Score: ",
    attempts        : "Attempts: ",
    attemptsEnd     : "Attempts",
    points          : "Points",
    back            : "back",
    playAgain       : "Play Again",
    stop            : "Stop",
    skip            : "Skip",
    skipped         : "Skipped",
}

// the order of labels below is important!
var credits = {
  credit1   : "Photo: Bjørn Christian Tørrissen 2016 (CC-BY-SA)",
  credit2   : "Photo: Nic McPhee 2006 (CC-BY-SA)",
  credit3   : "Photo: Rodrigo Menezes 2016 (CC-BY-SA)",
  credit4   : "Photo: Andrea Schieber 2019 (CC-BY-NC-SA)",
  credit5   : "Photo: Maria Ly 2008 (CC-BY)",
  credit6   : "Photo: Dion Hinchcliffe 2019 (CC-BY-SA)",
  credit7   : "Photo: Serouj Ourishian 2016 (CC-BY)",
  credit8   : "Photo: Esmée Winnubst 2017 (CC-BY)",
  credit9   : "Photo: Riadchikova 2017 (CC-BY-SA)",
  credit10  : "Photo: Ocrambo 2005 (Public Domain)",
  credit11  : "Photo: Xiquinhosilva 2018 (CC-BY)",
  credit12  : "Photo: Takashi Muramatsu (CC-BY)",
  credit13  : "Photo: Christian Stangl 2009 (CC-BY-SA)",
  credit14  : "Photo: Jean-Marie Hullot 2016 (CC-BY-SA)",
  credit15  : "Photo: Cristo Vlahos 2016 (CC-BY-SA)",
  credit16  : "Photo: Edgardo W. Olivera 2015 (CC-BY)",
  credit17  : "Photo: Zhangzhugang 2015 (CC-BY-SA)",
  credit18  : "Photo: Arfani Mujib 2015 (CC-BY-SA)",
  credit19  : "Photo: Jochen Spieker 2019 (CC-BY-SA)",
  credit20  : "Photo: Simon_sees 2018 (CC-BY)"
}

var creditsArray = Object.values(credits);

var subjects = {
  aconcagua:        "Aconcagua",
  denali:           "Denali / Mount McKinley",
  fitzRoy:          "Fitz Roy",
  gunungKinabalu:   "Gunung Kinabalu",
  k2:               "K2",
  mountArarat:      "Mount Ararat",
  montBlanc:        "Mont Blanc",
  mountCook:        "Aoraki / Mount Cook",
  mountElbrus:      "Mount Elbrus",
  mountEverest:     "Mount Everest",
  mountFuji:        "Mount Fuji",
  mountKailash:     "Mount Kailash",
  mountKilimanjaro: "Mount Kilimanjaro",
  mountLogan:       "Mount Logan",
  mountOlympus:     "Mount Olympus",
  mountSinai:       "Mount Sinai",
  mountTai:         "Mount Tai",
  puncakJaya:       "Puncak Jaya",
  tableMountain:    "Table Mountain",
  uluru:            "Uluru / Ayers Rock"
}

var countriesNames = ["Argentina", "Alaska","Argentina/Chile","Malaysia","China/Pakistan", "Turkey", "France/Italy", "New Zealand","Russia","China/Nepal","Japan", "China", "Tanzania", "Canada","Greece","Egypt","China","Indonesia","South Africa","Australia"];

var infoText = [
"Height: 6960 m", 
"Height: 6194 m",
"Height: 3359 m",
"Height: 4095 m",
"Height: 8611 m", 
"Height: 5137 m", 
"Height: 4810 m", 
"Height: 3754 m", 
"Height: 5642 m",
"Height: 8848 m", 
"Height: 3776 m", 
"Height: 6638 m", 
"Height: 5895 m", 
"Height: 5959 m", 
"Height: 2917 m", 
"Height: 2285 m", 
"Height: 1533 m", 
"Height: 4884 m", 
"Height: 1085 m", 
"Height: 863 m"];
// don't edit below


// sound is on by default
var soundButtonFrame = 0;
// show/hide photos
var showPhotos = true;
var photosButtonFrame = 0;
// number of attempts
var attempts = +0;
// skipped
var skips = +0;
// arrays
var questionsArray = Object.values(subjects);
var questionsArrayStatic = [...questionsArray];

// resize
const DEFAULT_WIDTH = 1280
const DEFAULT_HEIGHT = 720
const MAX_WIDTH = DEFAULT_WIDTH * 1.5
const MAX_HEIGHT = DEFAULT_HEIGHT * 1.5
let SCALE_MODE = 'SMOOTH'

const config = {
    type: Phaser.AUTO,
    parent: 'geo-game',
    backgroundColor : 0x34C5EB,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,

    scale: 
    {
        mode: Phaser.Scale.NONE,
        parent: "geo-game",
    },
    scene: [Loading, Menu, Options, UserInterface, GraphUI, Gameplay, Graph]
}

window.addEventListener('load', () => {
    const game = new Phaser.Game(config)
  
    resize = () => {
      const w = window.innerWidth
      const h = window.innerHeight
  
      let width = DEFAULT_WIDTH
      let height = DEFAULT_HEIGHT
      let maxWidth = MAX_WIDTH
      let maxHeight = MAX_HEIGHT
      let scaleMode = SCALE_MODE
  
      let scale = Math.min(w / width, h / height)
      let newWidth = Math.min(w / scale, maxWidth)
      let newHeight = Math.min(h / scale, maxHeight)
  
      let defaultRatio = DEFAULT_WIDTH / DEFAULT_HEIGHT
      let maxRatioWidth = MAX_WIDTH / DEFAULT_HEIGHT
      let maxRatioHeight = DEFAULT_WIDTH / MAX_HEIGHT
  
      // smooth scaling
      let smooth = 1
      if (scaleMode === 'SMOOTH') {
        const maxSmoothScale = 1.15
        const normalize = (value, min, max) => {
          return (value - min) / (max - min)
        }
        if (width / height < w / h) {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioWidth) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        } else {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioHeight) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        }
      }

      // resize the game
      game.scale.resize(newWidth * smooth, newHeight * smooth)
      // scale the width and height of the css
      game.canvas.style.width = newWidth * scale + 'px'
      game.canvas.style.height = newHeight * scale + 'px'
      // center the game with css margin
      game.canvas.style.marginTop = `${(h - newHeight * scale) / 2}px`
      game.canvas.style.marginLeft = `${(w - newWidth * scale) / 2}px`
    }

    window.addEventListener('resize', event => {
      resize()
    })
  
    resize()
  })
