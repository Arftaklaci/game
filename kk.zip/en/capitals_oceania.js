var game = new Phaser.Game(500, 800, Phaser.Canvas, null, null, true)

game.global = 
{
	orientated    : false,
    instructions  : true,
}

// edit below 
collator = "en"
website_url = "https://world-geography-games.com/australia.html";
website_label = "World Geography Games"
title_label = "Capitals of Oceania"
title_oneline = "Capitals of Oceania"
play_again_label = "Play again"
stop_label = "Stop"
score_label = "score: "
final_score = "Score"
next_label = "Next"
out_of_label = "out of"
play_label = "play"
options_label = "options"
select_atleast_label = "Select at least 5 capitals"
back_label = "back"
sound_label = "SOUND"
number_of_capitals_label = "NUMBER OF CAPITALS"
capitals_label = "CAPITALS"
select_label = "select"
library_label = "library"
oceaniaLabel = "Oceania"

countries = ["Samoa", "Australia", "Tuvalu", "Solomon Islands", "Marshall Islands", "Palau", "Tonga", "Micronesia", "Papua New Guinea", "Vanuatu", "Kiribati", "Fiji", "New Zealand", "Nauru"]

capitals = ["Apia", "Canberra", "Funafuti", "Honiara", "Majuro", "Ngerulmud", "Nuku'alofa", "Palikir", "Port Moresby", "Port Vila", "South Tarawa", "Suva", "Wellington", "Yaren"]

// ** DO NOT EDIT BELOW!
// create new array, order alphabetically
countriesAlphabet = countries.slice().sort(Intl.Collator(collator).compare);

var capitalsUsed = 14;

// frames that will be used (frames represent images)
frames = [];
for (let f = 0; f < capitalsUsed; f++) {
    frames.push(f);
}

// always contains all frames, get random capitals from this array
allFrames = frames.slice();

oceania = [0,1,2,3,4,5,6,7,8,9,10,11,12,13];

// toggle buttons used for countries, frame 0 or 1
toggleButtonFrames = [];

for (let i = 0; i < frames.length; i++) {
    // by default all buttons are on (frame 0)
    toggleButtonFrames.push(0);
}

// sound toggle button
soundFrame = 0;

// game states
game.state.add('boot', bootState);
game.state.add("Loading", loading);
game.state.add("menu", menuState);
game.state.add("options", optionsState);
game.state.add("library", libraryState);
game.state.add("level1", state1);
game.state.start("boot");