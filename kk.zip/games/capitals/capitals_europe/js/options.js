var mouseIsDown = false;
var distX = 0;

function mouseDown() {
    //set the mouseIsDown to true
    mouseIsDown = true;
    startX = game.input.y;
}

function mouseUp() {
    mouseIsDown = false;
}

var optionsState = {
    create: function () {

        mouseWheelScroll();

        game.input.onUp.add(mouseUp, this);
        game.input.onDown.add(mouseDown, this);

        // bg rectangle
        bg = game.add.image(0, 0, 'bg');

        // *** SELECT ANY COUNTRY IN ANY REGION

        // capitals in central and northern group
        central_and_eastern_group = game.add.group();
        central_and_eastern_group.visible = false;

        if (game.global.options_instructions === true) {
            if (game.device.desktop) {
                scroll_instruction = game.add.sprite(250, 400, 'scroll_desktop');
            } else {
                scroll_instruction = game.add.sprite(250, 400, 'scroll_mobile');
            }
            central_and_eastern_group.add(scroll_instruction);
        }

        // rectangle on top, if you scroll, capitals go behind it
        bg_top = game.add.image(0, 0, 'bg_top');
        bg_top.height = 150;

        // text_central_and_eastern = game.add.bitmapText(50, 110, 'os-blue-bold', central_and_eastern_label.toLocaleUpperCase(), 25);        
        text_central_and_eastern = game.add.text(50, 110,central_and_eastern_label.toLocaleUpperCase(), {font:"25px bold", fill:"#0099ff"});
        text_central_and_eastern.visible = false;

        // add all capitals to array and reorder items alphabetically
        cm_array = [];

        central_and_eastern_europe.forEach(function (f) {
            cm_array.push(capitals[f]);
        }, this);

        cm_array = cm_array.sort(Intl.Collator(collator).compare);

        var y_pos = 170;
        cm_array.forEach(function (country) {

            // write text
            write_text(50, y_pos, country, central_and_eastern_group);

            // get index
            let index = capitals.indexOf(country);

            // create a button for each country
            add_button(W - 120, y_pos - 5, index, toggle_capitals, central_and_eastern_group);

            y_pos += 50
        }, this)

        // capitals in western europe
        western_group = game.add.group();
        western_group.visible = false;

        // text_western_group = game.add.bitmapText(50, 110, 'os-blue-bold', western_label.toLocaleUpperCase(), 26, western_group);
        text_western_group = game.add.text(50, 110, western_label.toLocaleUpperCase(), {font:"26px bold", fill:"#0099ff"}, western_group);

        // add all capitals to array and reorder items alphabetically
        w_array = [];

        western_europe.forEach(function (fr) {
            w_array.push(capitals[fr]);
        }, this);

        w_array = w_array.sort(Intl.Collator(collator).compare);

        y_pos = 170;
        w_array.forEach(function (country) {

            // write text
            write_text(50, y_pos, country, western_group);

            // get index
            let index = capitals.indexOf(country);

            // create a button for each country
            add_button(W - 120, y_pos - 5, index, toggle_capitals, western_group);

            y_pos += 50
        }, this);

        // northern
        northern_group = game.add.group();
        northern_group.visible = false;

        // text_northern = game.add.bitmapText(50, 110, 'os-blue-bold', northern_label.toLocaleUpperCase(), 26, northern_group)
        text_northern = game.add.text(50, 110, northern_label.toLocaleUpperCase(), {font:"26px bold", fill:"#0099ff"}, northern_group);

        // add all capitals to array and reorder items alphabetically
        n_array = []

        northern_europe.forEach(function (fr) {
            n_array.push(capitals[fr])
        }, this)

        n_array = n_array.sort(Intl.Collator(collator).compare);

        y_pos = 170
        n_array.forEach(function (country) {

            // write text
            write_text(50, y_pos, country, northern_group)

            // get index
            let index = capitals.indexOf(country)

            // create a button for each country
            add_button(W - 120, y_pos - 5, index, toggle_capitals, northern_group)

            y_pos += 50
        }, this)

        // capitals in east asia
        microstates_group = game.add.group()
        microstates_group.visible = false

        // text_microstates = game.add.bitmapText(50, 110, 'os-blue-bold', microstates_label.toLocaleUpperCase(), 26, microstates_group)
        text_microstates = game.add.text(50, 110, microstates_label.toLocaleUpperCase(), {font:"26px bold", fill:"#0099ff"}, microstates_group);

        // add all capitals to array and reorder items alphabetically
        m_array = []

        microstates.forEach(function (fr) {
            m_array.push(capitals[fr])
        }, this)

        m_array = m_array.sort(Intl.Collator(collator).compare);

        y_pos = 170
        m_array.forEach(function (country) {

            // write text
            write_text(50, y_pos, country, microstates_group)

            // get index
            let index = capitals.indexOf(country)

            // create a button for each country
            add_button(W - 120, y_pos - 5, index, toggle_capitals, microstates_group)

            y_pos += 50
        }, this)


        // southern group
        southern_group = game.add.group()
        southern_group.visible = false

        // text_southern = game.add.bitmapText(50, 110, 'os-blue-bold', southern_label.toLocaleUpperCase(), 26, southern_group)
        text_southern = game.add.text(50, 110, southern_label.toLocaleUpperCase(), {font:"26px bold", fill:"#0099ff"}, southern_group);

        // add all capitals to array and reorder items alphabetically
        sm_array = []

        southern_europe.forEach(function (f) {
            sm_array.push(capitals[f])
        }, this)

        sm_array = sm_array.sort(Intl.Collator(collator).compare);

        y_pos = 170
        sm_array.forEach(function (country) {

            // write text
            write_text(50, y_pos, country, southern_group)

            // get index
            let index = capitals.indexOf(country)

            // create a button for each country
            add_button(W - 120, y_pos - 5, index, toggle_capitals, southern_group)

            y_pos += 50
        }, this)

        // text options
        // text_options = game.add.bitmapText(W - 40, 22, 'os-blue-extra-bold', options_label, 36)
        text_options = game.add.text(W-40, 22, options_label, {font:"36px extraBold", fill:"#0099ff"});

        text_options.anchor.setTo(1, 0)
        button_options = game.add.button(W - 55 - text_options.width, 18, 'button_options')
        button_options.anchor.setTo(1, 0)
        button_options.scale.x = .8
        button_options.scale.y = .8

        // button back
        button_back_small = game.add.button(20, 21, 'button_back')
        // text_back = game.add.bitmapText(55, 23, 'open_sans_bold', back_label, 26)
        text_back = game.add.text(55, 23, back_label, {font:"26px bold", fill:"#000000"});

        button_back_clickable = game.add.button(10, 20, 'button_invisible', go_back)
        button_back_clickable.width = 60 + text_back.width
        button_back_clickable.height = 40

        // ** BASIC OPTIONS(sound, number of flags, regions)
        regions_group = game.add.group()

        // select_atleast = game.add.bitmapText(W / 2, 670, 'os_red_bold', select_atleast_label, 24, regions_group)
        select_atleast = game.add.text(W/2, 670, select_atleast_label, {font:"24px bold", fill:"#f80007"}, regions_group);

        select_atleast.visible = false
        select_atleast.anchor.setTo(0.5, 0)

        // number of flags
        //text_number_of_flags = game.add.bitmapText(20, 240, 'os-blue-bold', number_of_flags_label, 27, regions_group)
        text_number_of_flags = game.add.text(20, 240, number_of_flags_label, {font:"27px bold", fill:"#0099ff"}, regions_group);

        // number_of_flags = game.add.bitmapText(350, 235, 'open_sans_bold', flags_used, 36, regions_group)
        number_of_flags = game.add.text(350, 235, flags_used, {font:"36px bold", fill:"#000000"}, regions_group);

        // flags
        // text_flags = game.add.bitmapText(20, 340, 'os-blue-bold', flags_label, 27, regions_group)
        text_flags = game.add.text(20, 340, flags_label, {font:"27px bold", fill:"#0099ff"}, regions_group);

        // regions text
        // south = game.add.bitmapText(20, 395, 'open_sans_bold', northern_label, 21, regions_group)
        south = game.add.text(20, 395, northern_label, {font:"21px bold", fill:"#000000"}, regions_group);

        // southern_txt = game.add.bitmapText(20, 445, 'open_sans_bold', southern_label, 21, regions_group)
        southern_txt = game.add.text(20, 445, southern_label, {font:"21px bold", fill:"#000000"}, regions_group);

        // central_and_eastern = game.add.bitmapText(20, 495, 'open_sans_bold', central_and_eastern_label, 21, regions_group)
        central_and_eastern = game.add.text(20, 495, central_and_eastern_label, {font:"21px bold", fill:"#000000"}, regions_group);

        // western = game.add.bitmapText(20, 545, 'open_sans_bold', western_label, 21, regions_group)
        western = game.add.text(20, 545,  western_label, {font:"21px bold", fill:"#000000"}, regions_group);

        // east = game.add.bitmapText(20, 595, 'open_sans_bold', microstates_label, 21, regions_group)
        east = game.add.text(20, 595,  microstates_label, {font:"21px bold", fill:"#000000"}, regions_group);

        // select links
        // select_south = game.add.bitmapText(W - 20, 395, 'open_sans_bold', select_label, 20, regions_group)
        select_south = game.add.text(W - 20, 395,  select_label, {font:"20px bold", fill:"#000000"}, regions_group);

        // select_southern = game.add.bitmapText(W - 20, 445, 'open_sans_bold', select_label, 20, regions_group);
        select_southern = game.add.text(W - 20, 445,  select_label, {font:"20px bold", fill:"#000000"}, regions_group);

        // select_central_and_eastern = game.add.bitmapText(W - 20, 495, 'open_sans_bold', select_label, 20, regions_group)
        select_central_and_eastern = game.add.text(W - 20, 495,  select_label, {font:"20px bold", fill:"#000000"}, regions_group);

        // select_western = game.add.bitmapText(W - 20, 545, 'open_sans_bold', select_label, 20, regions_group)
        select_western = game.add.text(W - 20, 545,  select_label, {font:"20px bold", fill:"#000000"}, regions_group);

        // select_east = game.add.bitmapText(W - 20, 595, 'open_sans_bold', select_label, 20, regions_group)
        select_east = game.add.text(W - 20, 595,   select_label, {font:"20px bold", fill:"#000000"}, regions_group);

        select_south.anchor.setTo(1, 0)
        select_southern.anchor.setTo(1, 0)
        select_central_and_eastern.anchor.setTo(1, 0)
        select_western.anchor.setTo(1, 0)
        select_east.anchor.setTo(1, 0)

        // underlines
        underline_1 = regions_group.create(select_south.x - select_south.width, select_south.y + 19, 'underline')
        underline_1.width = select_south.width

        underline_2 = regions_group.create(select_southern.x - select_southern.width, select_southern.y + 19, 'underline')
        underline_2.width = select_southern.width

        underline_3 = regions_group.create(select_central_and_eastern.x - select_central_and_eastern.width, select_central_and_eastern.y + 19, 'underline')
        underline_3.width = select_central_and_eastern.width

        underline_4 = regions_group.create(select_western.x - select_western.width, select_western.y + 19, 'underline')
        underline_4.width = select_western.width

        underline_5 = regions_group.create(select_east.x - select_east.width, select_east.y + 19, 'underline')
        underline_5.width = select_east.width

        // invisible clickable buttons (over select texts)
        btn_select_south = game.add.button(select_south.x + 10, select_south.y - 8, 'button_invisible', select_clicked, this)
        btn_select_south.width = 20 + select_south.width
        btn_select_south.height = 40

        btn_select_southern = game.add.button(select_southern.x + 10, select_southern.y - 8, 'button_invisible', select_clicked, this)
        btn_select_southern.width = 20 + select_southern.width
        btn_select_southern.height = 40

        btn_select_central_and_eastern = game.add.button(select_central_and_eastern.x + 10, select_central_and_eastern.y - 8, 'button_invisible', select_clicked, this)
        btn_select_central_and_eastern.width = 20 + select_central_and_eastern.width
        btn_select_central_and_eastern.height = 40

        btn_select_western = game.add.button(select_western.x + 10, select_western.y - 8, 'button_invisible', select_clicked, this)
        btn_select_western.width = 20 + select_western.width
        btn_select_western.height = 40

        btn_select_east = game.add.button(select_east.x + 10, select_east.y - 8, 'button_invisible', select_clicked, this)
        btn_select_east.width = 20 + select_east.width
        btn_select_east.height = 40

        btn_select_south.anchor.setTo(1, 0)
        btn_select_southern.anchor.setTo(1, 0)
        btn_select_central_and_eastern.anchor.setTo(1, 0)
        btn_select_western.anchor.setTo(1, 0)
        btn_select_east.anchor.setTo(1, 0)

        regions_group.add(btn_select_south)
        regions_group.add(btn_select_southern)
        regions_group.add(btn_select_western)
        regions_group.add(btn_select_central_and_eastern)
        regions_group.add(btn_select_east)

        select_south.anchor.setTo(1, 0)
        select_southern.anchor.setTo(1, 0)
        select_central_and_eastern.anchor.setTo(1, 0)
        select_western.anchor.setTo(1, 0)
        select_east.anchor.setTo(1, 0)

        // toggle buttons for regions
        toggle_northern = game.add.button(W - 35 - select_south.width, 390, 'button_toggle', toggle_regions, this, null, null, null, null, regions_group)
        toggle_northern.frame = northern_btn
        toggle_southern = game.add.button(W - 35 - select_south.width, 440, 'button_toggle', toggle_regions, this, null, null, null, null, regions_group)
        toggle_southern.frame = southern_btn
        toggle_central = game.add.button(W - 35 - select_south.width, 490, 'button_toggle', toggle_regions, this, null, null, null, null, regions_group)
        toggle_central.frame = central_btn
        toggle_western = game.add.button(W - 35 - select_south.width, 540, 'button_toggle', toggle_regions, this, null, null, null, null, regions_group)
        toggle_western.frame = western_btn
        toggle_microstates = game.add.button(W - 35 - select_south.width, 590, 'button_toggle', toggle_regions, this, null, null, null, null, regions_group)
        toggle_microstates.frame = microstates_btn

        toggle_northern.anchor.setTo(1, 0)
        toggle_southern.anchor.setTo(1, 0)
        toggle_central.anchor.setTo(1, 0)
        toggle_western.anchor.setTo(1, 0)
        toggle_microstates.anchor.setTo(1, 0)

        // sound
        // text_sound = game.add.bitmapText(20, 140, 'os-blue-bold', sound_label, 27, regions_group)
        text_sound = game.add.text(20, 140, sound_label, {font:"27px bold", fill:"#0099ff"}, regions_group);

        button_sound = game.add.button(W - 35 - select_south.width, 137, 'button_toggle', toggle_sound, this, null, null, null, null, regions_group)
        button_sound.frame = sound_frame
        button_sound.anchor.setTo(1, 0)
    },

    update: function () {
        if (mouseIsDown == true && central_and_eastern_group.visible) {
            //get the distance between the start and end point
            distX = Math.abs(game.input.y - startX);
            //if the distance is greater than 50 pixels
            if (distX > 50) {
                if (distX > 100) {
                    distX = 100
                }
                swipe_done();
            }
        }

        if (central_and_eastern_group.y < -320) {
            central_and_eastern_group.y = -320
        } else if (central_and_eastern_group.y > 0) {
            central_and_eastern_group.y = 0
        }
    }
}

function swipe_done() {
    //get the ending point
    var endX = game.input.y;

    if (endX < startX) {
        central_and_eastern_group.y -= distX / 6
    } else {
        central_and_eastern_group.y += distX / 6
    }
}

function write_text(x_pos, y_pos, this_text, this_group) {
    // country_text = game.add.bitmapText(x_pos, y_pos, 'open_sans_bold', this_text, 24, this_group)
    country_text = game.add.text(x_pos, y_pos, this_text, {font:"24px bold", fill:"#000000"}, this_group);
}

function add_button(x_pos, y_pos, number, callback, btn_group) {
    toggle_btn = game.add.button(x_pos, y_pos, 'button_toggle', callback, this, null, null, null, null, btn_group)
    toggle_btn.number = number
    toggle_btn.frame = toggle_button_frames[number]
}

function select_clicked(btn) {

    // hide sound button, number of flags, select at least text...
    regions_group.visible = false
    selecting_regions = false
    select_atleast.visible = false

    if (btn == btn_select_south) {
        northern_group.visible = true

        // switch each single button in this group
        northern_group.forEach(function (toggle_btn) {
            if (toggle_btn.number != null) {
                toggle_btn.frame = toggle_button_frames[toggle_btn.number]
            }
        }, this)
    } else if (btn == btn_select_southern) {
        southern_group.visible = true
        // switch each single button in this group
        southern_group.forEach(function (toggle_btn) {
            if (toggle_btn.number != null) {
                toggle_btn.frame = toggle_button_frames[toggle_btn.number]
            }
        }, this)
    } else if (btn == btn_select_central_and_eastern) {
        central_and_eastern_group.visible = true
        // switch each single button in this group
        central_and_eastern_group.forEach(function (toggle_btn) {
            if (toggle_btn.number != null) {
                toggle_btn.frame = toggle_button_frames[toggle_btn.number]
            }
        }, this)

        // show this text
        text_central_and_eastern.visible = true;

        // scroll instructions
        if (!game.device.desktop && game.global.options_instructions == true) {
            tween = game.add.tween(scroll_instruction).to({
                y: 300
            }, 700, "Linear", true, 0, 1, true)
            tween.onComplete.add(function () {
                scroll_instruction.visible = false
            }, this)

            game.global.options_instructions = false
        }
    } else if (btn == btn_select_western) {
        western_group.visible = true
        // switch each single button in this group
        western_group.forEach(function (toggle_btn) {
            if (toggle_btn.number != null) {
                toggle_btn.frame = toggle_button_frames[toggle_btn.number]
            }
        }, this)
    } else if (btn == btn_select_east) {
        microstates_group.visible = true
        // switch each single button in this group
        microstates_group.forEach(function (toggle_btn) {
            if (toggle_btn.number != null) {
                toggle_btn.frame = toggle_button_frames[toggle_btn.number]
            }
        }, this)
    }
}

function toggle_capitals(btn) {
    // remove this frame (flag)
    if (btn.frame == 0) {
        for (let i = 0; i < frames.length; i++) {
            if (btn.number == frames[i]) {
                frames.splice(i, 1)
            }
        }
    } else // add this frame to the array
    {
        for (let i = 0; i < frames.length; i++) {
            if (frames.includes(btn.number) == false) {
                frames.push(btn.number)
            }
        }
        // make sure it runs at least once
        if (frames.length == 0) {
            if (frames.includes(btn.number) == false) {
                frames.push(btn.number)
            }
        }
    }

    // update flags frames
    flags_used = frames.length

    // update number of flags
    number_of_flags.text = flags_used.toString()

    // save toggle button frame (0 or 1)
    toggle_button_frames[btn.number] = (toggle_button_frames[btn.number] == 0) ? 1 : 0

    // switch frame of the current button
    btn.frame = (btn.frame == 0) ? 1 : 0
}

function toggle_regions(btn) {
    if (btn == toggle_northern) {
        // save toggle buttonframe
        northern_btn = (northern_btn == 0) ? 1 : 0

        // exclude frames (flags)
        if (btn.frame == 0) {
            for (let j = 0; j < northern_europe.length; j++) {
                for (let i = 0; i < frames.length; i++) {
                    if (frames[i] === northern_europe[j]) {
                        // toggle buttons off
                        toggle_button_frames[frames[i]] = 1

                        // remove these frames
                        frames.splice(i, 1);
                    }
                }
            }
        } else // include frames (flags)
        {
            for (let j = 0; j < northern_europe.length; j++) {
                if (frames.includes(northern_europe[j]) == false) {
                    // toggle buttons on
                    toggle_button_frames[northern_europe[j]] = 0

                    // add these frames
                    frames.push(northern_europe[j])
                }
            }
        }
    } else if (btn == toggle_central) {

        central_btn = (central_btn === 0) ? 1 : 0

        // exclude
        if (btn.frame === 0) {
            for (let j = 0; j < central_and_eastern_europe.length; j++) {
                for (let i = 0; i < frames.length; i++) {
                    if (frames[i] === central_and_eastern_europe[j]) {

                        // toggle buttons off
                        toggle_button_frames[frames[i]] = 1
                        frames.splice(i, 1);
                    }
                }
            }
        } else // include
        {
            for (let j = 0; j < central_and_eastern_europe.length; j++) {
                if (frames.includes(central_and_eastern_europe[j]) == false) {
                    // toggle buttons on
                    toggle_button_frames[central_and_eastern_europe[j]] = 0

                    frames.push(central_and_eastern_europe[j])
                }
            }
        }
    } else if (btn == toggle_southern) {
        southern_btn = (southern_btn === 0) ? 1 : 0

        // exclude
        if (btn.frame == 0) {
            for (let j = 0; j < southern_europe.length; j++) {
                for (let i = 0; i < frames.length; i++) {
                    if (frames[i] === southern_europe[j]) {
                        // toggle buttons off
                        toggle_button_frames[frames[i]] = 1

                        // remove these frames
                        frames.splice(i, 1);
                    }
                }
            }
        } else // include
        {
            for (let j = 0; j < southern_europe.length; j++) {
                if (frames.includes(southern_europe[j]) == false) {
                    // toggle buttons on
                    toggle_button_frames[southern_europe[j]] = 0

                    // add these frames
                    frames.push(southern_europe[j])
                }
            }
        }
    } else if (btn == toggle_western) {
        western_btn = (western_btn == 0) ? 1 : 0

        // exclude
        if (btn.frame == 0) {

            for (let j = 0; j < western_europe.length; j++) {
                for (let i = 0; i < frames.length; i++) {
                    if (frames[i] === western_europe[j]) {
                        toggle_button_frames[frames[i]] = 1

                        frames.splice(i, 1);
                    }
                }
            }
        } else // include
        {
            for (j = 0; j < western_europe.length; j++) {
                if (frames.includes(western_europe[j]) == false) {
                    // toggle buttons on
                    toggle_button_frames[western_europe[j]] = 0

                    // add these frames
                    frames.push(western_europe[j])
                }
            }
        }
    } else if (btn == toggle_microstates) {
        microstates_btn = (microstates_btn == 0) ? 1 : 0

        // exclude
        if (btn.frame == 0) {
            for (let j = 0; j < microstates.length; j++) {
                for (let i = 0; i < frames.length; i++) {
                    if (frames[i] === microstates[j]) {
                        toggle_button_frames[frames[i]] = 1
                        frames.splice(i, 1);
                    }
                }
            }
        } else // include
        {
            for (let j = 0; j < microstates.length; j++) {
                if (frames.includes(microstates[j]) == false) {
                    // toggle buttons on
                    toggle_button_frames[microstates[j]] = 0

                    // add these frames
                    frames.push(microstates[j])
                }
            }
        }
    }

    // IMPORTANT switch button's frame
    btn.frame = (btn.frame == 0) ? 1 : 0;
    // update flags frames
    flags_used = frames.length;
    // update number of flags
    number_of_flags.text = flags_used.toString();

    // if all buttons switched off
    if (btn !== toggle_microstates && toggle_southern.frame === 1 && toggle_western.frame === 1 && toggle_central.frame === 1 && toggle_northern.frame === 1) {
        toggle_microstates.frame = 1;
    }
    else if (btn !== toggle_microstates && toggle_southern.frame === 0 && toggle_western.frame === 0 && toggle_central.frame === 0 && toggle_northern.frame === 0) {
        toggle_microstates.frame = 0;
    }
}

function go_back() {
    // go to menu
    if (selecting_regions == true) {
        if (frames.length >= 5) {
            game.state.start("menu")
        } else {
            select_atleast.visible = true
        }
    } else // go to basic options
    {
        regions_group.visible = true
        selecting_regions = true
        northern_group.visible = false
        southern_group.visible = false
        western_group.visible = false
        central_and_eastern_group.visible = false
        microstates_group.visible = false

        // hide this text
        text_central_and_eastern.visible = false;
    }
}
