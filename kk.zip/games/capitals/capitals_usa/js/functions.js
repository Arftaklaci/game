function stopGame() {
	window.location.href = website_url;
}

function mouseWheelScroll() {
    // mouse wheel on desktop
    if (game.global.instructions == true)
    {
        if (game.device.desktop) {
            mouseWheel = game.input.mouseWheel;
            mouseWheel.callback = scrollIt;

            scroll_instruction = game.add.sprite(400, 400, 'scroll_desktop');
        }
        else
        {
            scroll_instruction = game.add.sprite(370, 400, 'scroll_mobile');
            tween = game.add.tween(scroll_instruction).to({y: 300}, 500, "Linear", true, 0, 2, true);
            tween.onComplete.add(function(){
                scroll_instruction.visible = false;
            },this);
        }
        
        game.global.instructions = false;
    }
}

function scrollIt(event)
{
    var cState = game.state.getCurrentState().key;
    
    if (cState === "library") {
        if (mouseWheel.delta == 1 && capitalsGroup.y < 100){
            capitalsGroup.y += 50;
        }
        else if (mouseWheel.delta == -1 && capitalsGroup.y > -2250){
            capitalsGroup.y -= 50;
        }
    }
    else if (cState === "options") {

        if (southGroup.visible === true) {
            if (southGroup.visible) {

                if (mouseWheel.delta == 1 && southGroup.y < 0) {
                    southGroup.y += 50;
                } else if (mouseWheel.delta == -1 && southGroup.y > -320) {
                    southGroup.y -= 50;
                }
            }
        }
        else if (westernGroup.visible === true) {
            if (westernGroup.visible) {

                if (mouseWheel.delta == 1 && westernGroup.y < 0) {
                    westernGroup.y += 50;
                } else if (mouseWheel.delta == -1 && westernGroup.y > -320) {
                    westernGroup.y -= 50;
                }
            }
        }
    }
    
    if (scroll_instruction.visible)
    {
        scroll_instruction.visible = false;
    }
}

function goToMenu() {
    game.state.start("menu")
}

function shuffle(a) {
    for (let i = a.length - 1; i > 0; i--) 
    {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

function goFullscreen() {
    if (game.scale.isFullScreen)
    {
        game.scale.stopFullScreen()
    }
    else
    {
        game.scale.startFullScreen(false, false)
    }
}

function toggleSound() {
	game.sound.mute = ! game.sound.mute;
	button_sound.frame = game.sound.mute ? 1 : 0;
    
    // save sound frame
    sound_frame = button_sound.frame
}

function tweenObject(this_object) {
    game.add.tween(this_object).to({alpha: 1}, 600, "Linear", true)
}