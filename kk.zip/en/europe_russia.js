"use strict"
var width, height, resize;

// edit below
var collator = "en";
var webUrl = "https://world-geography-games.com/europe.html";

var labels =
{
    website         : "World Geography Games",
    title           : "Russia: Federal Subjects",
    titleTwo        : "Russia\nFederal Subjects",
    play            : "play",
    options         : "options",
    map             : "map",
    tapStart        : "Tap on the map to start",
    clickStart      : "Click on the map to start\nUse mouse wheel to zoom",
    incorrect       : "Incorrect. Try again!",
    score           : "Score: ",
    attempts        : "Attempts: ",
    attemptsEnd     : "Attempts",
    countries       : "Points",
    sound           : "SOUND",
	  numOfCountries  : "Number of Countries",
	  select          : "select",
    selectAtleast   : "Please select at least 5 countries",
    back            : "back",
    map             : "map",
    playAgain       : "Play Again",
    stop            : "Stop",
    skip            : "Skip",
    skipped         : "Skipped",

    // labels on the map
    mariElRepublic2              : "Mari El \nRepublic",
    northOssetiaAlaniaRepublic2  : "North Ossetia-Alania\nRepublic",
    // labels used in questions
    chukotkaAutonomousOkrug2     : "Chukotka AO",
    jewishAutonomousOblast2      : "Jewish AO",
    nenetsAutonomousOkrug2       : "Nenets AO",
    khantyMansiAutonomousOkrug2  : "Khanty-Mansi AO",
    yamaloNenetsAutonomousOkrug2 : "Yamalo-Nenets AO",
    crimeaRepublicDisputedArea2  : "Crimea Republic",
    sevastopolDisputedArea2      : "Sevastopol",

    region1         : "Southern",
    region2         : "Siberian",
    region3         : "Far Eastern ",
    region4         : "Northwestern",
    region5         : "Volga",
    region6         : "Central",
    region7         : "North Caucasian",
    region8         : "Ural",
}

var countriesLabels = {

  // southern
  adygheaRepublic             : "Adyghea Republic",
  astrakhanOblast             : "Astrakhan Oblast",
  crimeaRepublicDisputedArea  : "Crimea Republic (disputed area)",
  kalmykiaRepublic            : "Kalmykia Republic",
  krasnodarKrai               : "Krasnodar Krai",
  rostovOblast                : "Rostov Oblast",
  sevastopolDisputedArea      : "Sevastopol (disputed area)",
  volgogradOblast             : "Volgograd Oblast",
  // siberian
  altaiKrai                   : "Altai Krai",
  altaiRepublic               : "Altai Republic",
  irkutskOblast               : "Irkutsk Oblast",
  kemerovoOblast              : "Kemerovo Oblast",
  khakassiaRepublic           : "Khakassia Republic",
  krasnoyarskKrai             : "Krasnoyarsk Krai",
  novosibirskOblast           : "Novosibirsk Oblast",
  omskOblast                  : "Omsk Oblast",
  tomskOblast                 : "Tomsk Oblast",
  tuvaRepublic                : "Tuva Republic",
  // far eastern
  amurOblast                  : "Amur Oblast",
  buryatiaRepublic            : "Buryatia Republic",
  chukotkaAutonomousOkrug     : "Chukotka Autonomous Okrug",
  jewishAutonomousOblast      : "Jewish Autonomous Oblast",
  kamchatkaKrai               : "Kamchatka Krai",
  khabarovskKrai              : "Khabarovsk Krai",
  magadanOblast               : "Magadan Oblast",
  primorskyKrai               : "Primorsky Krai",
  sakhalinOblast              : "Sakhalin Oblast",
  sakhaRepublic               : "Sakha Republic",
  zabaykalskyKrai             : "Zabaykalsky Krai",
  // northwestern
  arkhangelskOblast           : "Arkhangelsk Oblast",
  kaliningradOblast           : "Kaliningrad Oblast",
  kareliaRepublic             : "Karelia Republic",
  komiRepublic                : "Komi Republic",
  leningradOblast             : "Leningrad Oblast",
  murmanskOblast              : "Murmansk Oblast",
  nenetsAutonomousOkrug       : "Nenets Autonomous Okrug",
  novgorodOblast              : "Novgorod Oblast",
  pskovOblast                 : "Pskov Oblast",
  saintPetersburg             : "Saint Petersburg",
  vologdaOblast               : "Vologda Oblast",
  // volga
  bashkortostanRepublic       : "Bashkortostan Republic",
  chuvashRepublic             : "Chuvash Republic",
  kirovOblast                 : "Kirov Oblast",
  mariElRepublic              : "Mari El Republic",
  mordoviaOblast              : "Mordovia Republic",
  nizhnyNovgorodOblast        : "Nizhny Novgorod Oblast",
  orenburgOblast              : "Orenburg Oblast",
  penzaOblast                 : "Penza Oblast",
  permKrai                    : "Perm Krai",
  samaraOblast                : "Samara Oblast",
  saratovOblast               : "Saratov Oblast",
  tatarstanRepublic           : "Tatarstan Republic",
  udmurtRepublic              : "Udmurt Republic",
  ulyanovskOblast             : "Ulyanovsk Oblast",
  // central
  belgorodOblast              : "Belgorod Oblast",
  bryanskOblast               : "Bryansk Oblast",
  ivanovoOblast               : "Ivanovo Oblast",
  kalugaOblast                : "Kaluga Oblast",
  kostromaOblast              : "Kostroma Oblast",
  kurskOblast                 : "Kursk Oblast",
  lipetskOblast               : "Lipetsk Oblast",
  moscow                      : "Moscow",
  moscowOblast                : "Moscow Oblast",
  oryolOblast                 : "Oryol Oblast",
  ryazanOblast                : "Ryazan Oblast",
  smolenskOblast              : "Smolensk Oblast",
  tambovOblast                : "Tambov Oblast",
  tulaOblast                  : "Tula Oblast",
  tverOblast                  : "Tver Oblast",
  vladimirOblast              : "Vladimir Oblast",
  voronezhOblast              : "Voronezh Oblast",
  yaroslavlOblast             : "Yaroslavl Oblast",
  // north caucasian
  chechenRepublic             : "Chechen Republic",
  dagestanRepublic            : "Dagestan Republic",
  ingushetiaRepublic          : "Ingushetia Republic",
  kabardinoBalkarRepublic     : "Kabardino-Balkar Republic",
  karachayCherkessRepublic    : "Karachay-Cherkess Republic",
  northOssetiaAlaniaRepublic  : "North Ossetia-Alania Republic",
  stavropolKrai               : "Stavropol Krai",
  // ural
  chelyabinskOblast           : "Chelyabinsk Oblast",
  khantyMansiAutonomousOkrug  : "Khanty-Mansi Autonomous Okrug",
  kurganOblast                : "Kurgan Oblast",
  sverdlovskOblast            : "Sverdlovsk Oblast",
  tyumenOblast                : "Tyumen Oblast",
  yamaloNenetsAutonomousOkrug : "Yamalo-Nenets Autonomous Okrug",
}

// don't edit below

// number of attempts
var attempts = +0;
// number of skipped countries
var skips = +0;
// by default all countries are included
var questionsArray = Object.values(countriesLabels);
// always contains all countries
const questionsArrayStatic = questionsArray.slice();

// southern
var region1Array = [];
for (let x = 0; x < 8; x++) {
  region1Array.push(questionsArray[x]);
}
// siberian
var region2Array = [];
for (let x = 8; x < 18; x++) {
  region2Array.push(questionsArray[x]);
}
// far eastern 
var region3Array = [];
for (let x = 18; x < 29; x++) {
  region3Array.push(questionsArray[x]);
}
// northwestern
var region4Array = [];
for (let x = 29; x < 40; x++) {
  region4Array.push(questionsArray[x]);
}
// volga
var region5Array = [];
for (let x = 40; x < 54; x++) {
  region5Array.push(questionsArray[x]);
}
// central
var region6Array = [];
for (let x = 54; x < 72; x++) {
  region6Array.push(questionsArray[x]);
}
// north caucasian
var region7Array = [];
for (let x = 72; x < 79; x++) {
  region7Array.push(questionsArray[x]);
}
// ural
var region8Array = [];
for (let x = 79; x < 85; x++) {
  region8Array.push(questionsArray[x]);
}

// toggle buttons, by default they are green (frame 0)
var btnRegion1Frame = 0;
var btnRegion2Frame = 0;
var btnRegion3Frame = 0;
var btnRegion4Frame = 0;
var btnRegion5Frame = 0;
var btnRegion6Frame = 0;
var btnRegion7Frame = 0;
var btnRegion8Frame = 0;
var soundButtonFrame = 0;

var toggleButtonsFrames = [];
for (let x = 0; x < questionsArrayStatic.length; x++) {
  toggleButtonsFrames.push(+0);
}

// if true you can toggle regions, else you toggle countries on options
var regionsVisible = true;

function tweenObj(aScene, obj, fromN, toN) {
  obj.alpha = fromN;

  aScene.tweens.add({
      targets: [obj],
      alpha: { value: toN },
      ease: 'Linear',
      duration: 400,
  });
}

// resize
const DEFAULT_WIDTH = 1280
const DEFAULT_HEIGHT = 720
const MAX_WIDTH = DEFAULT_WIDTH * 1.5
const MAX_HEIGHT = DEFAULT_HEIGHT * 1.5
let SCALE_MODE = 'SMOOTH'

const config = {
    type: Phaser.AUTO,
    parent: 'geo-game',
    backgroundColor : 0x34C5EB,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,

    scale: 
    {
        mode: Phaser.Scale.NONE,
        parent: "geo-game",
    },
    scene: [Loading, Menu, UserInterface, GraphUI, Gameplay, Options, Graph]
}

window.addEventListener('load', () => {
    const game = new Phaser.Game(config)
  
    const resize = () => {
      const w = window.innerWidth
      const h = window.innerHeight
  
      let width = DEFAULT_WIDTH
      let height = DEFAULT_HEIGHT
      let maxWidth = MAX_WIDTH
      let maxHeight = MAX_HEIGHT
      let scaleMode = SCALE_MODE
  
      let scale = Math.min(w / width, h / height)
      let newWidth = Math.min(w / scale, maxWidth)
      let newHeight = Math.min(h / scale, maxHeight)
  
      let defaultRatio = DEFAULT_WIDTH / DEFAULT_HEIGHT
      let maxRatioWidth = MAX_WIDTH / DEFAULT_HEIGHT
      let maxRatioHeight = DEFAULT_WIDTH / MAX_HEIGHT
  
      // smooth scaling
      let smooth = 1
      if (scaleMode === 'SMOOTH') {
        const maxSmoothScale = 1.15
        const normalize = (value, min, max) => {
          return (value - min) / (max - min)
        }
        if (width / height < w / h) {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioWidth) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        } else {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioHeight) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        }
      }

      // resize the game
      game.scale.resize(newWidth * smooth, newHeight * smooth)
      // scale the width and height of the css
      game.canvas.style.width = newWidth * scale + 'px'
      game.canvas.style.height = newHeight * scale + 'px'
      // center the game with css margin
      game.canvas.style.marginTop = `${(h - newHeight * scale) / 2}px`
      game.canvas.style.marginLeft = `${(w - newWidth * scale) / 2}px`
    }

    window.addEventListener('resize', event => {
      resize()
    })
  
    resize()
  })
