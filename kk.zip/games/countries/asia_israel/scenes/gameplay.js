"use strict"
var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        });
    }
    
    create() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;
        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;
       camera.zoom = 1.4;

       if (this.sys.game.device.os.desktop) {
            // min max zoom
            this.minZoom = 1;  
            this.maxZoom = 1.5;
            camera.zoom = 1.4;
        }
        else {
            this.minZoom = 1;
            this.maxZoom = 1.8;
        }
        // display countries in this scene
        this.displayMap(this);
        // get countries (sprites) array from the container
        this.countriesArray = this.mapContainer.getAll();
        // for each subject (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {
            /* development phase - enable drag to position countries
            this.countriesArray[i].setInteractive()
            this.input.setDraggable(this.countriesArray[i]);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {
                gameObject.x = dragX;
                gameObject.y = dragY;
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });
            */
           
            let subject = this.countriesArray[i];
            // make countries sprites interactive
            subject.setInteractive({ 
                useHandCursor: true,             
                pixelPerfect: true,
                alphaTolerance: 255
             });
             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over subject
                subject.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                       subject.setTintFill(0xFFFFFF);
                    }
                },this);
                subject.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        subject.clearTint();
                    }
                },this);
            }
            subject.on('pointerdown', () => {
                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });
            subject.on('pointerup', () => {
                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);
                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    subject.xPos = camera.x;
                    subject.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false) {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === subject.name) {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this subject
                            subject.disableInteractive();
                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }
                            // create the subject label
                            this.showLabels(subject);
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // else don't tap, drag the map
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();
        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false) {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();
                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip, ui.buttonSound],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                let dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {
                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        let drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }
                }).on('pinch', dragScale => {
                    let scaleFactor = dragScale.scaleFactor;
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                }, this);
                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }
        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 30, align: "center", color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 30, align: "center", color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });
        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                camera.zoom *= 0.9;
            }
        }
        // limit zoom
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.mapContainer.setSize(width, height);
        this.mapContainer.x = 0;
        this.mapContainer.y = 0;

        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2, height/2);
        }
    }

    getQuestion() {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;
        this.questionsArray.shift();

        if (ui.questionText.text === subjects.yorkshire) {
            ui.questionText.setFontSize(32);
        }
        else {
            ui.questionText.setFontSize(34);
        }

        // tween
        this.tweens.add({
           targets: [ui.questionText],
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;
        // play sound
        this.gameOverSound.play();
        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        ui.buttonSound.destroy();
        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {
        // tween camera
        if (camera.zoom > this.minZoom) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: this.minZoom,
                x: 0, 
                y: 0,
                duration: 1500,
                onComplete: () => {
                    
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }
        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: 0,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showLabels(subject) {
        // create white rectangle
        subject.rect = this.add.sprite(subject.x, subject.y, "rectangle");
        // subject name
        subject.txt = this.add.text(subject.x, subject.y, subject.name, { fontFamily: "bold", fontSize: 28, align: "center", color: '#000000' });
        subject.txt.setOrigin(.5,.5);
        
        // position text
        if (subject.labelX) {
            subject.txt.x = subject.labelX;
            subject.txt.y = subject.labelY;
            subject.rect.x = subject.labelX;
            subject.rect.y = subject.labelY;
        }
        subject.rect.displayWidth = subject.txt.width + 4;
        subject.rect.displayHeight = subject.txt.height + 2;
    }

    displayMap(aScene) {
        this.map = this.add.image(width/2, height/2, 'map');
        this.map.alpha = .5;

        // interactive sprites
        aScene.haDarom = aScene.add.sprite(width/2 - 11.2, height/2 + 197.8, "texture", "haDarom.png");
        aScene.haifa = aScene.add.sprite(width/2 + 18.2, height/2 - 186.3, "texture", "haifa.png");
        aScene.haMerkaz = aScene.add.sprite(width/2 - 12.5, height/2 - 78.3, "texture", "haMerkaz.png");
        aScene.haTzafon = aScene.add.sprite(width/2 + 87, height/2 - 231, "texture", "haTzafon.png");
        aScene.jerusalem = aScene.add.sprite(width/2 + 15.5, height/2 - 9.6, "texture", "jerusalem.png");
        aScene.telAviv = aScene.add.sprite(width/2 - 22.4, height/2 - 79.7, "texture", "telAviv.png");

        // reposition labels
        aScene.haMerkaz.labelX = aScene.haMerkaz.x + 10;
        aScene.haMerkaz.labelY = aScene.haMerkaz.y - 40;
        aScene.telAviv.labelX = aScene.telAviv.x - 35;
        aScene.telAviv.labelY = aScene.telAviv.y;
        aScene.jerusalem.labelX = aScene.jerusalem.x + 25;
        aScene.jerusalem.labelY = aScene.jerusalem.y;
        aScene.haTzafon.labelX = aScene.haTzafon.x - 20;
        aScene.haTzafon.labelY = aScene.haTzafon.y - 20;
        aScene.haifa.labelX = aScene.haifa.x - 20;
        aScene.haifa.labelY = aScene.haifa.y - 20;

        // names
        aScene.haDarom.name = subjects.haDarom;
        aScene.haifa.name = subjects.haifa;
        aScene.haMerkaz.name = subjects.haMerkaz;
        aScene.haTzafon.name = subjects.haTzafon;
        aScene.jerusalem.name = subjects.jerusalem;
        aScene.telAviv.name = subjects.telAviv;

        // create container and put countries into it
        aScene.mapContainer = aScene.add.container(0, 0, [aScene.haDarom, aScene.haifa, aScene.haMerkaz, aScene.haTzafon, aScene.jerusalem, aScene.telAviv]);

        aScene.mapContainer.setSize(width, height);
        aScene.mapContainer.x = 0;
        aScene.mapContainer.y = 0;
     }
}