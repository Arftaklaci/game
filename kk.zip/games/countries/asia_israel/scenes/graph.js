"use strict"

class Graph extends Phaser.Scene {
    constructor() {
        super({
            key: "graph"
        })
    }

    create() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        // gameplay scene
        let gameplay = this.scene.get("gameplay");
        gameplay.displayMap(this);

        this.txtDisputed = this.add.text(this.haTzafon.x + 35, this.haTzafon.y + 45, labels.disputed, { fontFamily: "semiBold", fontSize: 18, align: "center", color: '#000000' });
        this.line = this.add.image(this.haTzafon.x+55, this.haTzafon.y+20, 'line');
        this.line.angle = -25;
        
        // show labels
        this.showLabels();
        // user interface
        this.ui = this.scene.get("graphUI");
        // launch user interface 
        this.scene.launch("graphUI");
        this.scene.moveAbove("graph", "graphUI");
       // camera
       camera = this.cameras.main;
       camera.zoom = 1.4;

       if (this.sys.game.device.os.desktop) {
            // min max zoom
            this.minZoom = 1;  
            this.maxZoom = 1.5;
            camera.zoom = 1.4;
        }
        else {
            this.minZoom = 1;
            this.maxZoom = 1.8;
        }
        // enable drag and pinch to zoom
        var dragScale = this.plugins.get('rexpinchplugin').add(this);
        dragScale.on('drag1', dragScale => {
                var drag1Vector = dragScale.drag1Vector;
                camera.scrollX -= drag1Vector.x / camera.zoom;
                camera.scrollY -= drag1Vector.y / camera.zoom;
        }).on('pinch', dragScale => {
            var scaleFactor = dragScale.scaleFactor;
            
            // camera zoom
            camera.zoom *= scaleFactor;
        }, this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);

            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
            //this.upKeyDown = cursorKeys.up.isDown;
            //this.downKeyDown = cursorKeys.down.isDown;
        }

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on("resize", (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }
    
    update() {
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop) {
            if (this.cursorKeys.up.isDown) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown) {
                
                camera.zoom *= 0.9;
            }
        }
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    showLabels(subject) {
        
        this.subjectsArray = this.mapContainer.getAll();

        for (let i = 0; i < this.subjectsArray.length; i++) {
            let subject = this.subjectsArray[i];

            // create white rectangle
            subject.rect = this.add.image(subject.x, subject.y, "rectangle");
            // text
            subject.txt = this.add.text(subject.x, subject.y, subject.name, { fontFamily: "bold", fontSize: 18, align: "center", color: '#000000' });
            subject.txt.setOrigin(.5,.5);
            
            // position text
            if (subject.labelX) {
                subject.txt.x = subject.labelX;
                subject.txt.y = subject.labelY;
                subject.rect.x = subject.labelX;
                subject.rect.y = subject.labelY;
            }
            // rectangle width/height
            subject.rect.displayWidth = subject.txt.width + 4;
            subject.rect.displayHeight = subject.txt.height;
        }
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;

        this.mapContainer.setSize(width, height);
        this.mapContainer.x = 0;
        this.mapContainer.y = 0;
    }
}
