"use strict"
var width, height, resize;

// edit below
var collator = "en";
var webUrl = "https://world-geography-games.com/asia.html";

var labels =
{
    website         : "World Geography Games",
    title           : "VIETNAM\nProvinces and Municipalities",
    titleTwo        : "\nVietnam",
    play            : "play",
    options         : "options",
    map             : "map",
    tapStart        : "Tap on the map to start",
    clickStart      : "Click on the map to start \nUse mouse wheel to zoom",
    incorrect       : "Incorrect. Try again!",
    score           : "Score: ",
    attempts        : "Attempts: ",
    attemptsEnd     : "Attempts",
    countries       : "Provinces",
    sound           : "SOUND",
	  numOfCountries  : "Number of Provinces",
	  select          : "select",
    selectAtleast   : "Please select at least 5 provinces",
    back            : "back",
    map             : "map",
    playAgain       : "Play Again",
    stop            : "Stop",
    skip            : "Skip",
    skipped         : "Skipped",

    region1         : "Northwest",
    region2         : "Northeast",
    region3         : "Red River Delta",
    region4         : "North Central Coast",
    region5         : "Central Highlands",
    region6         : "South Central Coast",
    region7         : "Southeast",
    region8         : "Mekong Delta",
}

var countriesLabels = {
  // Northwest:
  dienBien:     "Điện Biên",
  hoaBinh:      "Hòa Bình",
  laiChau:      "Lai Châu",
  laoCai:       "Lào Cai",
  sonLa:        "Sơn La",
  yenBai:       "Yên Bái",
  // Northeast:
  bacGiang:     "Bắc Giang",
  bacKan:       "Bắc Kạn",
  caoBang:      "Cao Bằng",
  haGiang:      "Hà Giang",
  langSon:      "Lạng Sơn",
  phuTho:       "Phú Thọ",
  quangNinh:    "Quảng Ninh",
  thaiNguyen:   "Thái Nguyên",
  tuyenQuang:   "Tuyên Quang",
  // Red River Delta:
  haNoi:        "Hà Nội",
  haiPhong:     "Hải Phòng",
  bacNinh:      "Bắc Ninh",
  haNam:        "Hà Nam",
  haiDuong:     "Hải Dương",
  hungYen:      "Hưng Yên",
  namDinh:      "Nam Định",
  ninhBinh:     "Ninh Bình",
  thaiBinh:     "Thái Bình",
  vinhPhuc:     "Vĩnh Phúc",
  // North Central Coast:
  haTinh:       "Hà Tĩnh",
  ngheAn:       "Nghệ An",
  quangBinh:    "Quảng Bình",
  quangTri:     "Quảng Trị",
  thanhHoa:     "Thanh Hóa",
  thuaThienHue: "Thừa Thiên Huế",
  // Central Highlands:
  dakLak:       "Đắk Lắk",
  dakNong:      "Đắk Nông",
  giaLai:       "Gia Lai",
  konTum:       "Kon Tum",
  lamDong:      "Lâm Đồng",
  //South Central Coast:
  daNang:       "Đà Nẵng",
  binhDinh:     "Bình Định",
  binhThuan:    "Bình Thuận",
  khanhHoa:     "Khánh Hòa",
  ninhThuan:    "Ninh Thuận",
  phuYen:       "Phú Yên",
  quangNam:     "Quảng Nam",
  quangNgai:    "Quảng Ngãi",
  // Southeast:
  hoChiMinhCity:"Hồ Chí Minh City",
  baRiaVungTau: "Bà Rịa–Vũng Tàu",
  binhDuong:    "Bình Dương",
  binhPhuoc:    "Bình Phước",
  dongNai:      "Đồng Nai",
  tayNinh:      "Tây Ninh",
  // Mekong Delta:
  canTho:       "Cần Thơ",
  anGiang:      "An Giang",
  bacLieu:      "Bạc Liêu",
  benTre:       "Bến Tre",
  caMau:        "Cà Mau",
  dongThap:     "Đồng Tháp",
  hauGiang:     "Hậu Giang",
  kienGiang:    "Kiên Giang",
  longAn:       "Long An",
  socTrang:     "Sóc Trăng",
  tienGiang:    "Tiền Giang",
  traVinh:      "Trà Vinh",
  vinhLong:     "Vĩnh Long"
}

// don't edit below
var attempts = +0;
var skips = +0;
var questionsArray = Object.values(countriesLabels);
const questionsArrayStatic = questionsArray.slice();

// Northwest
var region1Array = [];
for (let x = 0; x < 6; x++) {
  region1Array.push(questionsArray[x]);
}
// Northeast
var region2Array = [];
for (let x = 6; x < 15; x++) {
  region2Array.push(questionsArray[x]);
}
// Red River Delta
var region3Array = [];
for (let x = 15; x < 25; x++) {
  region3Array.push(questionsArray[x]);
}
// North Central Coast
var region4Array = [];
for (let x = 25; x < 31; x++) {
  region4Array.push(questionsArray[x]);
}
// Central Highlands
var region5Array = [];
for (let x = 31; x < 36; x++) {
  region5Array.push(questionsArray[x]);
}
// South Central Coast
var region6Array = [];
for (let x = 36; x < 44; x++) {
  region6Array.push(questionsArray[x]);
}
// Southeast
var region7Array = [];
for (let x = 44; x < 50; x++) {
  region7Array.push(questionsArray[x]);
}
// Mekong Delta
var region8Array = [];
for (let x = 50; x < 63; x++) {
  region8Array.push(questionsArray[x]);
}



// toggle buttons, by default they are green (frame 0)
var btnRegion1Frame = 0;
var btnRegion2Frame = 0;
var btnRegion3Frame = 0;
var btnRegion4Frame = 0;
var btnRegion5Frame = 0;
var btnRegion6Frame = 0;
var btnRegion7Frame = 0;
var btnRegion8Frame = 0;
var soundButtonFrame = 0;

var toggleButtonsFrames = [];
for (let x = 0; x < questionsArrayStatic.length; x++) {
  toggleButtonsFrames.push(+0);
}

// either regions or provinces are visible
var regionsVisible = true;

function tweenObj(aScene, obj, fromN, toN) {
  obj.alpha = fromN;

  aScene.tweens.add({
      targets: [obj],
      alpha: { value: toN },
      ease: 'Linear',
      duration: 400,
  });
}

// resize
const DEFAULT_WIDTH = 720
const DEFAULT_HEIGHT = 1280
const MAX_WIDTH = DEFAULT_WIDTH * 1.5
const MAX_HEIGHT = DEFAULT_HEIGHT * 1.5
let SCALE_MODE = 'SMOOTH'

const config = {
    type: Phaser.AUTO,
    parent: 'geo-game',
    backgroundColor : 0x34C5EB,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,

    scale: 
    {
        mode: Phaser.Scale.NONE,
        parent: "geo-game",
    },
    scene: [Loading, Menu, UserInterface, GraphUI, Gameplay, Options, Graph]
}

window.addEventListener('load', () => {
    const game = new Phaser.Game(config)
  
    const resize = () => {
      const w = window.innerWidth
      const h = window.innerHeight
  
      let width = DEFAULT_WIDTH
      let height = DEFAULT_HEIGHT
      let maxWidth = MAX_WIDTH
      let maxHeight = MAX_HEIGHT
      let scaleMode = SCALE_MODE
  
      let scale = Math.min(w / width, h / height)
      let newWidth = Math.min(w / scale, maxWidth)
      let newHeight = Math.min(h / scale, maxHeight)
  
      let defaultRatio = DEFAULT_WIDTH / DEFAULT_HEIGHT
      let maxRatioWidth = MAX_WIDTH / DEFAULT_HEIGHT
      let maxRatioHeight = DEFAULT_WIDTH / MAX_HEIGHT
  
      // smooth scaling
      let smooth = 1
      if (scaleMode === 'SMOOTH') {
        const maxSmoothScale = 1.15
        const normalize = (value, min, max) => {
          return (value - min) / (max - min)
        }
        if (width / height < w / h) {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioWidth) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        } else {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioHeight) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        }
      }

      // resize the game
      game.scale.resize(newWidth * smooth, newHeight * smooth)
      // scale the width and height of the css
      game.canvas.style.width = newWidth * scale + 'px'
      game.canvas.style.height = newHeight * scale + 'px'
      // center the game with css margin
      game.canvas.style.marginTop = `${(h - newHeight * scale) / 2}px`
      game.canvas.style.marginLeft = `${(w - newWidth * scale) / 2}px`
    }

    window.addEventListener('resize', event => {
      resize()
    })
  
    resize()
  })
