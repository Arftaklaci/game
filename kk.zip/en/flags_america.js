var game = new Phaser.Game(500, 800, Phaser.Canvas, null, null, true)

game.global = 
{
	orientated             : false,
    library_instructions   : true,
    options_instructions   : true,
}

// edit below to change a language
collator = 'en'
var webURL = "https://world-geography-games.com/americas.html";
var websiteName = "World Geography Games";

title_label = "  Flags of\n America"
title_oneline = "Flags of America"
play_again_label = "Play again"
stop_label = "Stop"
score_label = "Score: "
next_label = "Next"
out_of_label = "out of"
play_label = "play"
options_label = "options"
select_atleast_label = "Select at least 5 flags"
back_label = "back"
sound_label = "SOUND"
number_of_flags_label = "NUMBER OF FLAGS"
flags_label = "FLAGS"
select_label = "select"
library_label = "library"

south_label = "South America"
central_label = "Central America"
caribbean_label = "Caribbean"
canada_us_label = "Canada, US & Mexico"

countries = ["Antigua and Barbuda", "Argentina", "Bahamas", "Barbados", "Belize", "Bolivia", "Brazil", "Canada", "Chile", "Colombia", "Costa Rica", "Cuba", "Dominica", "Dominican Republic", "Ecuador", "El Salvador", "Grenada", "Guatemala", "Guyana", "Haiti", "Honduras", "Jamaica", "Mexico", "Nicaragua", "Panama", "Paraguay", "Peru", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and Grenadines", "Suriname", "Trinidad and Tobago", "United States", "Uruguay", "Venezuela"]

// ** DO NOT EDIT BELOW!

// create new array, don't change the first one, order alphabetically
countries_alphabet = countries.slice().sort(Intl.Collator(collator).compare);

// number of flags
flags_used = 35

// frames that will be used
frames = []
for (var f = 0; f < flags_used; f++)
{
    frames.push(f)
}

// always contains all frames, get random flags from this array
all_frames = frames.slice()

// regions
canada_us_mexico = [7,22,32]
central_america = [4,10,15,17,20,23,24]
south_america = [1,5,6,8,9,14,18,25,26,30,33,34]
caribbean = [0,2,3,11,12,13,16,19,21,27,28,29,31]

// toggle buttons used for regions, possible frame 0 or 1
south_btn = 0
northern_btn = 0
central_btn = 0
caribbean_btn = 0

// toggle buttons used for countries, possible frame 0 or 1
toggle_button_frames = []

for (var i = 0; i < frames.length; i++)
{
    // by default all buttons are on (frame 0)
    toggle_button_frames.push(0)
}

// sound toggle button
sound_frame = 0

// selecting regions or countries in options (back button depends on this)
selecting_regions = true

// countries have lookalikes
have_lookalikes = 
[1,9,14,15,17,20,23,34];

// lookalikes
lookalikes = [
[17],[14,34],[9,34],[23,20],[1],[15,23],[15,20],[9,14]
];

// game states
game.state.add('boot', bootState);
game.state.add("Loading", loading);
game.state.add("menu", menuState);
game.state.add("options", optionsState);
game.state.add("library", libraryState);
game.state.add("level1", state1);
game.state.start("boot");

