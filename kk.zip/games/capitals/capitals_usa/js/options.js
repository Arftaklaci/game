var mouseIsDown = false;
var distX = 0;

function mouseDown() {
    //set the mouseIsDown to true
    mouseIsDown = true;
    startX = game.input.y;
}

function mouseUp() {
    mouseIsDown = false;
}

var optionsState = {
    create: function () {
        mouseWheelScroll();
        game.input.onUp.add(mouseUp, this);
        game.input.onDown.add(mouseDown, this);

        // bg rectangle
        bg = game.add.image(0, 0, 'bg');

        // west
        westernGroup = game.add.group();
        westernGroup.visible = false;
        // south group
        southGroup = game.add.group();
        southGroup.visible = false;
        // rectangle on top, hide capitals
        bgTop = game.add.image(0, 0, 'bg_top');
        bgTop.height = 150;

        // south
        textSouth = game.add.text(50, 110, southLabel.toLocaleUpperCase(), {font:"26px bold", fill:"#0099ff"});
        textSouth.visible = false;
        // add all capitals to array and reorder items alphabetically
        array4 = [];

        south.forEach(function (fr) {
            array4.push(capitals[fr]);
        }, this)
        array4 = array4.sort(Intl.Collator(collator).compare);

        yPos = 170
        array4.forEach(function (country) {
            // write text
            writeText(50, yPos, country, southGroup);
            // get index
            let index = capitals.indexOf(country);
            // create a button for each country
            addButton(W - 120, yPos - 5, index, toggleCapitals, southGroup);

            yPos += 50;
        }, this)
       
        // western
        textWesternGroup = game.add.text(50, 110, westernLabel.toLocaleUpperCase(), {font:"26px bold", fill:"#0099ff"});
        textWesternGroup.visible = false;

        // add all capitals to array and reorder items alphabetically
        array2 = [];

        west.forEach(function (fr) {
            array2.push(capitals[fr]);
        }, this);
        array2 = array2.sort(Intl.Collator(collator).compare);

        yPos = 170;
        array2.forEach(function (country) {
            // write text
            writeText(50, yPos, country, westernGroup);
            // get index
            let index = capitals.indexOf(country);
            // create a button for each country
            addButton(W - 120, yPos - 5, index, toggleCapitals, westernGroup);

            yPos += 50
        }, this);

        // midwest group
        midwestGroup = game.add.group();
        midwestGroup.visible = false;

        if (game.global.instructions === true) {
            if (game.device.desktop) {
                scroll_instruction = game.add.sprite(250, 400, 'scroll_desktop');
            } else {
                scroll_instruction = game.add.sprite(250, 400, 'scroll_mobile');
            }
            midwestGroup.add(scroll_instruction);
        }

        txtMidwest = game.add.text(50, 110, midwestLabel.toLocaleUpperCase(), {font:"25px bold", fill:"#0099ff"}, midwestGroup);

        // add all capitals to array and reorder items alphabetically
        array1 = [];

        midwest.forEach(function (f) {
            array1.push(capitals[f]);
        }, this);

        array1 = array1.sort(Intl.Collator(collator).compare);

        var yPos = 170;
        array1.forEach(function (country) {
            // write text
            writeText(50, yPos, country, midwestGroup);
            // get index
            let index = capitals.indexOf(country);
            // create a button for each country
            addButton(W - 120, yPos - 5, index, toggleCapitals, midwestGroup);

            yPos += 50
        }, this)

        // northeast
        northernGroup = game.add.group();
        northernGroup.visible = false;

        text_northern = game.add.text(50, 110, northernLabel.toLocaleUpperCase(), {font:"26px bold", fill:"#0099ff"}, northernGroup);

        // add all capitals to array and reorder items alphabetically
        array3 = [];

        northeast.forEach(function (fr) {
            array3.push(capitals[fr]);
        }, this)

        array3 = array3.sort(Intl.Collator(collator).compare);

        yPos = 170;
        array3.forEach(function (country) {
            // write text
            writeText(50, yPos, country, northernGroup);
            // get index
            let index = capitals.indexOf(country);
            // create a button for each country
            addButton(W - 120, yPos - 5, index, toggleCapitals, northernGroup);

            yPos += 50;
        }, this);

        // text options
        textOptions = game.add.text(W - 40, 22, options_label, {font:"36px extraBold", fill:"#0099ff"});

        textOptions.anchor.setTo(1, 0)
        buttonOptions = game.add.button(W - 55 - textOptions.width, 18, 'button_options')
        buttonOptions.anchor.setTo(1, 0)
        buttonOptions.scale.x = .8
        buttonOptions.scale.y = .8

        // button back
        buttonBackSmall = game.add.button(20, 21, 'button_back')
        textBack = game.add.text(55, 23, back_label, {font:"26px bold", fill:"#000000"});

        buttonBackClickable = game.add.button(10, 20, 'button_invisible', goBack)
        buttonBackClickable.width = 60 + textBack.width
        buttonBackClickable.height = 40

        // ** BASIC OPTIONS(sound, number of capitals, regions)
        regionsGroup = game.add.group()

        selectAtleast = game.add.text(W/2, 670, select_atleast_label, {font:"24px bold", fill:"#f80007"}, regionsGroup);

        selectAtleast.visible = false
        selectAtleast.anchor.setTo(0.5, 0)

        // number of capitals
        textNumberOfCapitals = game.add.text(20, 240, number_of_capitals_label, {font:"27px bold", fill:"#0099ff"}, regionsGroup);

        numberOfCapitals = game.add.text(350, 235, capitalsUsed, {font:"36px bold", fill:"#000000"}, regionsGroup);

        // capitals
        textCapitals = game.add.text(20, 340, capitals_label, {font:"27px bold", fill:"#0099ff"}, regionsGroup);
        // regions text
        northernTxt = game.add.text(20, 395, northernLabel, {font:"21px bold", fill:"#000000"}, regionsGroup);

        midwestTxt = game.add.text(20, 445, midwestLabel, {font:"21px bold", fill:"#000000"}, regionsGroup);

        westernTxt = game.add.text(20, 495, westernLabel, {font:"21px bold", fill:"#000000"}, regionsGroup);

        southTxt = game.add.text(20, 545, southLabel, {font:"21px bold", fill:"#000000"}, regionsGroup);

        // select links
        select_south = game.add.text(W-20, 395, select_label, {font:"20px bold", fill:"#000000"}, regionsGroup);
        selectMidwest = game.add.text(W-20, 445, select_label, {font:"20px bold", fill:"#000000"}, regionsGroup);
        select_western = game.add.text(W-20, 495, select_label, {font:"20px bold", fill:"#000000"}, regionsGroup);
        select_east = game.add.text(W-20, 545, select_label, {font:"20px bold", fill:"#000000"}, regionsGroup);

        select_south.anchor.setTo(1, 0)
        selectMidwest.anchor.setTo(1, 0)
        select_western.anchor.setTo(1, 0)
        select_east.anchor.setTo(1, 0)

        // underlines
        underline1 = regionsGroup.create(select_south.x - select_south.width, select_south.y + 19, 'underline')
        underline1.width = select_south.width
        underline3 = regionsGroup.create(selectMidwest.x - selectMidwest.width, selectMidwest.y + 19, 'underline')
        underline3.width = selectMidwest.width
        underline4 = regionsGroup.create(select_western.x - select_western.width, select_western.y + 19, 'underline')
        underline4.width = select_western.width
        underline5 = regionsGroup.create(select_east.x - select_east.width, select_east.y + 19, 'underline')
        underline5.width = select_east.width

        // invisible clickable buttons (over select texts)
        btnSelectNorthern = game.add.button(select_south.x + 10, select_south.y - 8, 'button_invisible', selectClicked, this)
        btnSelectNorthern.width = 20 + select_south.width
        btnSelectNorthern.height = 40

        btnSelectMidwest = game.add.button(selectMidwest.x + 10, selectMidwest.y - 8, 'button_invisible', selectClicked, this)
        btnSelectMidwest.width = 20 + selectMidwest.width
        btnSelectMidwest.height = 40

        btnSelectWestern = game.add.button(select_western.x + 10, select_western.y - 8, 'button_invisible', selectClicked, this)
        btnSelectWestern.width = 20 + select_western.width
        btnSelectWestern.height = 40

        btnSelectSouth = game.add.button(select_east.x + 10, select_east.y - 8, 'button_invisible', selectClicked, this)
        btnSelectSouth.width = 20 + select_east.width
        btnSelectSouth.height = 40

        btnSelectNorthern.anchor.setTo(1, 0)
        btnSelectMidwest.anchor.setTo(1, 0)
        btnSelectWestern.anchor.setTo(1, 0)
        btnSelectSouth.anchor.setTo(1, 0)
        regionsGroup.add(btnSelectNorthern)
        regionsGroup.add(btnSelectWestern)
        regionsGroup.add(btnSelectMidwest)
        regionsGroup.add(btnSelectSouth)
        select_south.anchor.setTo(1, 0)
        selectMidwest.anchor.setTo(1, 0)
        select_western.anchor.setTo(1, 0)
        select_east.anchor.setTo(1, 0)

        // toggle buttons for regions
        toggle_northern = game.add.button(W - 35 - select_south.width, 390, 'button_toggle', toggleRegions, this, null, null, null, null, regionsGroup);
        toggle_northern.frame = northernBtn;
        toggleMidwest = game.add.button(W - 35 - select_south.width, 440, 'button_toggle', toggleRegions, this, null, null, null, null, regionsGroup);
        toggleMidwest.frame = midwestBtn;
        toggle_western = game.add.button(W - 35 - select_south.width, 490, 'button_toggle', toggleRegions, this, null, null, null, null, regionsGroup);
        toggle_western.frame = westernBtn;
        toggleSouth = game.add.button(W - 35 - select_south.width, 540, 'button_toggle', toggleRegions, this, null, null, null, null, regionsGroup);
        toggleSouth.frame = southBtn;

        toggle_northern.anchor.setTo(1, 0);
        toggleMidwest.anchor.setTo(1, 0);
        toggle_western.anchor.setTo(1, 0);
        toggleSouth.anchor.setTo(1, 0);
        // sound
        text_sound = game.add.text(20, 140, sound_label, {font:"27px bold", fill:"#0099ff"}, regionsGroup);

        button_sound = game.add.button(W - 35 - select_south.width, 137, 'button_toggle', toggleSound, this, null, null, null, null, regionsGroup);
        button_sound.frame = soundFrame;
        button_sound.anchor.setTo(1, 0);
    },

    update: function () {
        if (mouseIsDown === true && (southGroup.visible === true ||     westernGroup.visible === true)) {
            //get the distance between the start and end point
            distX = Math.abs(game.input.y - startX);
            //if the distance is greater than 50 pixels
            if (distX > 50) {
                if (distX > 100) {
                    distX = 100
                }
                swipeDone();
            }
        }

        if (southGroup.y < -220) {
            southGroup.y = -220;
        } 
        else if (southGroup.y > 0) {
            southGroup.y = 0;
        }
        if (westernGroup.y < -100) {
            westernGroup.y = -100;
        } 
        else if (westernGroup.y > 0) {
            westernGroup.y = 0;
        }
    }
}

function swipeDone() {
    //get the ending point
    var endX = game.input.y;

    if (southGroup.visible === true) {
        if (endX < startX) {
            southGroup.y -= distX / 6
        } else {
            southGroup.y += distX / 6
        }
    }
    else if (westernGroup.visible === true) {
        if (endX < startX) {
            westernGroup.y -= distX / 6
        } else {
            westernGroup.y += distX / 6
        }
    }
}

function writeText(x_pos, yPos, this_text, this_group) {
    country_text = game.add.text(x_pos, yPos, this_text, {font:"24px bold", fill:"#000000"}, this_group);
}

function addButton(x_pos, yPos, number, callback, btn_group) {
    toggle_btn = game.add.button(x_pos, yPos, 'button_toggle', callback, this, null, null, null, null, btn_group)
    toggle_btn.number = number
    toggle_btn.frame = toggleButtonFrames[number]
}

function selectClicked(btn) {

    // hide sound button, number of capitals, select at least text...
    regionsGroup.visible = false
    selectingRegions = false
    selectAtleast.visible = false

    if (btn === btnSelectNorthern) {
        northernGroup.visible = true

        // switch each single button in this group
        northernGroup.forEach(function (toggle_btn) {
            if (toggle_btn.number != null) {
                toggle_btn.frame = toggleButtonFrames[toggle_btn.number]
            }
        }, this)
    } else if (btn === btnSelectMidwest) {
        midwestGroup.visible = true
        // switch each single button in this group
        midwestGroup.forEach(function (toggle_btn) {
            if (toggle_btn.number != null) {
                toggle_btn.frame = toggleButtonFrames[toggle_btn.number]
            }
        }, this)

        // scroll instructions
        if (!game.device.desktop && game.global.instructions === true) {
            tween = game.add.tween(scroll_instruction).to({
                y: 300
            }, 700, "Linear", true, 0, 1, true)
            tween.onComplete.add(function () {
                scroll_instruction.visible = false
            }, this)

            game.global.instructions = false
        }
    } else if (btn === btnSelectWestern) {
        westernGroup.visible = true
        // show this text
        textWesternGroup.visible = true;

        // switch each single button in this group
        westernGroup.forEach(function (toggle_btn) {
            if (toggle_btn.number != null) {
                toggle_btn.frame = toggleButtonFrames[toggle_btn.number]
            }
        }, this)
    } else if (btn === btnSelectSouth) {
        southGroup.visible = true;
        // show this text
        textSouth.visible = true;

        // switch each single button in this group
        southGroup.forEach(function (toggle_btn) {
            if (toggle_btn.number != null) {
                toggle_btn.frame = toggleButtonFrames[toggle_btn.number]
            }
        }, this)
    }
}

function toggleCapitals(btn) {
    // remove this frame (map)
    if (btn.frame == 0) {
        for (let i = 0; i < frames.length; i++) {
            if (btn.number == frames[i]) {
                frames.splice(i, 1)
            }
        }
    } else // add this frame to the array
    {
        for (let i = 0; i < frames.length; i++) {
            if (frames.includes(btn.number) == false) {
                frames.push(btn.number)
            }
        }
        // make sure it runs at least once
        if (frames.length == 0) {
            if (frames.includes(btn.number) == false) {
                frames.push(btn.number)
            }
        }
    }

    // update capitals frames
    capitalsUsed = frames.length

    // update number of capitals
    numberOfCapitals.text = capitalsUsed.toString()

    // save toggle button frame (0 or 1)
    toggleButtonFrames[btn.number] = (toggleButtonFrames[btn.number] == 0) ? 1 : 0

    // switch frame of the current button
    btn.frame = (btn.frame == 0) ? 1 : 0
}

function toggleRegions(btn) {
    if (btn == toggle_northern) {
        // save toggle buttonframe
        northernBtn = (northernBtn == 0) ? 1 : 0

        // exclude frames (capitals)
        if (btn.frame == 0) {
            for (let j = 0; j < northeast.length; j++) {
                for (let i = 0; i < frames.length; i++) {
                    if (frames[i] === northeast[j]) {
                        // toggle buttons off
                        toggleButtonFrames[frames[i]] = 1

                        // remove these frames
                        frames.splice(i, 1);
                    }
                }
            }
        } else // include frames (capitals)
        {
            for (let j = 0; j < northeast.length; j++) {
                if (frames.includes(northeast[j]) == false) {
                    // toggle buttons on
                    toggleButtonFrames[northeast[j]] = 0

                    // add these frames
                    frames.push(northeast[j])
                }
            }
        }
    } else if (btn == toggleMidwest) {

        midwestBtn = (midwestBtn === 0) ? 1 : 0

        // exclude
        if (btn.frame === 0) {
            for (let j = 0; j < midwest.length; j++) {
                for (let i = 0; i < frames.length; i++) {
                    if (frames[i] === midwest[j]) {

                        // toggle buttons off
                        toggleButtonFrames[frames[i]] = 1
                        frames.splice(i, 1);
                    }
                }
            }
        } else // include
        {
            for (let j = 0; j < midwest.length; j++) {
                if (frames.includes(midwest[j]) == false) {
                    // toggle buttons on
                    toggleButtonFrames[midwest[j]] = 0

                    frames.push(midwest[j])
                }
            }
        }
    } else if (btn == toggle_western) {
        westernBtn = (westernBtn == 0) ? 1 : 0

        // exclude
        if (btn.frame == 0) {

            for (let j = 0; j < west.length; j++) {
                for (let i = 0; i < frames.length; i++) {
                    if (frames[i] === west[j]) {
                        toggleButtonFrames[frames[i]] = 1

                        frames.splice(i, 1);
                    }
                }
            }
        } else // include
        {
            for (j = 0; j < west.length; j++) {
                if (frames.includes(west[j]) == false) {
                    // toggle buttons on
                    toggleButtonFrames[west[j]] = 0

                    // add these frames
                    frames.push(west[j])
                }
            }
        }
    } else if (btn == toggleSouth) {
        southBtn = (southBtn == 0) ? 1 : 0

        // exclude
        if (btn.frame == 0) {
            for (let j = 0; j < south.length; j++) {
                for (let i = 0; i < frames.length; i++) {
                    if (frames[i] === south[j]) {
                        toggleButtonFrames[frames[i]] = 1
                        frames.splice(i, 1);
                    }
                }
            }
        } else // include
        {
            for (let j = 0; j < south.length; j++) {
                if (frames.includes(south[j]) == false) {
                    // toggle buttons on
                    toggleButtonFrames[south[j]] = 0

                    // add these frames
                    frames.push(south[j])
                }
            }
        }
    }

    // IMPORTANT switch button's frame
    btn.frame = (btn.frame == 0) ? 1 : 0;
    // update capitals frames
    capitalsUsed = frames.length;
    // update number of capitals
    numberOfCapitals.text = capitalsUsed.toString();
}

function goBack() {
    // go to menu
    if (selectingRegions == true) {
        if (frames.length >= 5) {
            game.state.start("menu")
        } 
        else {
            selectAtleast.visible = true;
        }
    } 
    else // go to basic options
    {
        regionsGroup.visible = true;
        selectingRegions = true;
        northernGroup.visible = false;
        westernGroup.visible = false;
        midwestGroup.visible = false;
        southGroup.visible = false;

        // hide text
        textWesternGroup.visible = false;
        textSouth.visible = false;
    }
}
