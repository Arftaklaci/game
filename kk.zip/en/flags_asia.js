var game = new Phaser.Game(500, 800, Phaser.Canvas, null, null, true)

game.global = 
{
	orientated             : false,
    library_instructions   : true,
    options_instructions   : true,
}

// edit below to change a language
collator = 'en'
var webURL = "https://world-geography-games.com/asia.html";
var websiteName = "World Geography Games";

title_label = "Flags of\n    Asia"
title_oneline = "Flags of Asia"
play_again_label = "Play again"
stop_label = "Stop"
score_label = "Score: "
next_label = "Next"
out_of_label = "out of"
play_label = "play"
options_label = "options"
select_atleast_label = "Select at least 5 flags"
back_label = "back"
sound_label = "SOUND"
number_of_flags_label = "NUMBER OF FLAGS"
flags_label = "FLAGS"
select_label = "select"
library_label = "library"

south_label = "South Asia"
central_and_northern_label = "Central and Northern Asia"
east_label = "East Asia"
western_label = "Western Asia"
southeast_label = "Southeast Asia"

countries = ["Afghanistan", "Armenia", "Azerbaijan", "Bahrain", "Bangladesh", "Bhutan", "Brunei", "Cambodia", "China", "East Timor", "Georgia", "India", "Indonesia", "Iran", "Iraq", "Israel", "Japan", "Jordan", "Kazakhstan", "Kuwait", "Kyrgyzstan", "Laos", "Lebanon", "Malaysia", "Maldives", "Mongolia", "Myanmar", "Nepal", "North Korea", "Oman", "Pakistan", "State of Palestine", "Philippines", "Qatar", "Russia", "Saudi Arabia", "Singapore", "South Korea", "Sri Lanka", "Syria", "Taiwan", "Tajikistan", "Thailand", "Turkey", "Turkmenistan", "UAE", "Uzbekistan", "Vietnam", "Yemen"]


// ** DO NOT EDIT BELOW!

// create new array, don't change the first one, order alphabetically
countries_alphabet = countries.slice().sort(Intl.Collator(collator).compare);

// how many flags selected
flags_used = 49

// frames that will be used (frames represent flags)
frames = []
for (var f = 0; f < flags_used; f++)
{
    frames.push(f)
}

// always contains all frames, get random flags from this array
all_frames = frames.slice()

// regions
southeast_asia =[6,7,9,12,21,23,26,32,36,42,47]
western_asia = [1,2,3,10,13,14,15,17,19,22,29,31,33,35,39,43,45,48]
south_asia = [0,4,5,11,24,27,30,38]
east_asia = [8,16,25,28,37,40]
central_and_northern_asia = [18,20,34,41,44,46]

// toggle buttons used for regions, possible frame 0 or 1
south_btn = 0
southeast_btn = 0
central_btn = 0
western_btn = 0
east_btn = 0

// toggle buttons used for countries, possible frame 0 or 1
toggle_button_frames = []

for (var i = 0; i < frames.length; i++)
{
    // by default all buttons are on (frame 0)
    toggle_button_frames.push(0)
}

// sound toggle button
sound_frame = 0

// selecting regions or countries in options (back button depends on this)
selecting_regions = true

// countries have lookalikes
have_lookalikes = 
[34,41,44,8,28,40,30,12,36,47,1,3,13,14,17,19,31,33,39,43,45,48];

// lookalikes
lookalikes = [
[1],[13],[30],[47],[21,40],[21,28],[44],[28,40],[43],[8],[34],[33],[41],[39,48],[19,31,45],[17,31,45],[17,19,45],[3],[14,48],[36],[17,19,31],[14,39]
];

// game states
game.state.add('boot', bootState);
game.state.add("Loading", loading);
game.state.add("menu", menuState);
game.state.add("options", optionsState);
game.state.add("library", libraryState);
game.state.add("level1", state1);
game.state.start("boot");

