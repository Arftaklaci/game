var state1 = {

create: function(){
    init();
    createSounds();

    bg = game.add.image(0, 0, 'bg');

    // text - score and attempts
    score_text = game.add.text(W/2, 13,  "score: 0", {font:"26px bold", fill:"#000000"});
    score_text.anchor.setTo(0.5,0);

    question_number_text = game.add.text(W-40, 13, "1/" + capitalsUsed, {font:"26px bold", fill:"#000000"});
    question_number_text.anchor.setTo(1,0);

    // button back
    button_back_small = game.add.button(34, 13, 'button_back', goToMenu)
    text_back = game.add.text(50, 15, back_label, {font:"26px bold", fill:"#000000"});

    button_back_clickable = game.add.button(20, 10, 'button_invisible', goToMenu)
    button_back_clickable.width = 60
    button_back_clickable.height = 35
    text_back.visible = false

    // clone array and shuffle it
    frames_shuffle = frames.slice(0);
    frames_shuffle = shuffle(frames_shuffle);

    // question mark country name
    question_mark = game.add.sprite(200, 306, "question");
    question_mark.scale.x = .9;
    question_mark.scale.y = .9;
    question_mark.anchor.setTo(1,0);

    country_name = game.add.text(W/2 + 25, 313, "", {font:"30px bold", fill:"#000000"});
    country_name.anchor.setTo(0.5,0)

    // show a capital and possible answers
    guessThisCapital();

    // button next
    button_next = game.add.button(W/2, 695, 'button_next', nextCapital);
    button_next.anchor.setTo(0.5, 0);
    button_next.alpha = 0;
    button_next.inputEnabled = false;

    next_text = game.add.text(W/2, button_next.y + 13, next_label, {font:"28px semiBold", fill:"#000000"});
    next_text.anchor.setTo(0.5,0);
    next_text.alpha = 0;

    // create "wrong" button
    button_wrong = game.add.sprite(400, 300, 'button_wrong');
    button_wrong.visible = false;

    // REQUIRED
    tween_world = game.add.tween(game.world).to({alpha: 1}, 250, "Linear", true);    
},

update: function()
{
    if (play_animation == true)
    {
        counter++

        if (counter >= 85)
        {
            // random frame and position
            randomF = game.rnd.integerInRange(0,2);
            randomX = game.rnd.integerInRange(0,5);

            a = anims.create(1000, 3000, 'boats');
            a.frame = randomF;
            a.anchor.setTo(0.5,0.5);

            if (randomX === 0) {
                a.x = -90;
                a.vx = 2.6;
                a.y = 750;
                a.scale.x = -1;
            }else if (randomX === 1 || randomX === 2) {
                a.x = 590;
                a.vx = -2.4;

                if (randomX === 1) {
                    a.y = 70;
                }else {
                    a.y = 635;
                }
            }
            else if (randomX === 3) {
                a.x = -90;
                a.y = 190;
                a.vx = 2.4;
                a.scale.x = -1;
            }
            else if (randomX === 4) {
                a.y = 280;
                a.x = 590;
                a.vx = -2.6;
            }
            else if (randomX === 5) {
                a.y = 460;
                a.x = -90;
                a.scale.x = -1;
                a.vx = 2.6;
            }

            counter = 0;
        }

        anims.forEach(function(obj){
            obj.x += obj.vx;

            if (obj.x > 1000 || obj.x < -1000) {
                obj.destroy();
                obj = null;
            }
        },this);
    }
}
};

function guessThisCapital() {
    // update question number
    question_number += 1
    question_number_text.text = question_number + "/" + capitalsUsed

    // choose the first frame from the array
    frame_number = frames_shuffle[0];

    capital = game.add.sprite(W/2, 55, 'capitals');
    capital.frame = frame_number;
    capital.anchor.setTo(0.5, 0);
    // choose the capital from array
    country_to_guess = capitals[frame_number];
    // get correct answer, so we can use it later
    correct_answer = country_to_guess;
    // display country name
    country_name.text = countries[frame_number];
    question_mark.x = country_name.x - country_name.width/2 - 10;
    // get correct answer, so we can use it later
    correct_answer = country_to_guess;
 
    // get random capitals
    let random1 = getRandomWithoutRepeating(allFrames, [frame_number])
    let random2 = getRandomWithoutRepeating(allFrames, [frame_number, random1])
    let random3 = getRandomWithoutRepeating(allFrames, [frame_number, random1, random2])

    // 4 capitals
    array_4_capitals = [correct_answer, capitals[random1], capitals[random2], capitals[random3]]

    // random positions for 4 names
    label_positions = [[W/2, 390], [W/2, 466], [W/2, 542], [W/2, 618]]
    shuffle(label_positions)
    
    // group contains buttons and labels, used to destroy those objects
    buttons = game.add.group()

    for (let i = 0; i < 4; i++)
    {
        // make a button
        button_c = game.add.button(W/2, label_positions[i][1], 'button_capital', tapCountry, this)
        button_c.anchor.setTo(0.5, 0)

        // display text
        button_c.capital_name = game.add.text(W/2, button_c.y + 12, array_4_capitals[i], {font:"28px semiBold", fill:"#000000"});
        button_c.capital_name.anchor.setTo(0.5, 0)

        // attach a country name to button
        button_c.name = button_c.capital_name.text
        // add buttons and texts to the group
        buttons.add(button_c)
        buttons.add(button_c.capital_name)
    }

    // remove the first number from frames, so we don't choose the same again
    frames_shuffle.shift()
}

function getRandomWithoutRepeating(all_possible_frames, excluded_frames)
{
    var rand = null;

    while(rand === null || excluded_frames.includes(rand)){
         rand = Math.round(Math.random() * (all_possible_frames.length - 1))
    }
    return rand;
}

function tapCountry(btn)
{
    if (can_tap == true)
    {
        can_tap = false

        // correct
        if (btn.name == correct_answer)
        {
            correct_sound.play()
            score += 1
            btn.frame = 1

            // change text color to white
            btn.capital_name.destroy()

            btn.capital_name = game.add.text(W/2, button_c.y + 15, correct_answer, {font:"27px bold", fill:"#FFFFFF"});
            btn.capital_name.y = btn.y + 12
            btn.capital_name.anchor.setTo(0.5, 0)

            // show next button, or game over if no more capitals available
            showNextButton();
        }
        else    // wrong
        {
            wrong_sound.play()

            // mark it wrong
            button_wrong.x = 400
            button_wrong.y = btn.y
            button_wrong.visible = true
            button_wrong.bringToTop()

            // find the correct answer (button), mark it green
            buttons.forEach(function(onebutton){

                if (onebutton.name == correct_answer)
                {
                    onebutton.frame = 1
                    // change text color to white
                    onebutton.capital_name.destroy()

                    onebutton.capital_name = game.add.text(W/2, button_c.y + 15, correct_answer, {font:"27px bold", fill:"#FFFFFF"});
                    onebutton.capital_name.y = onebutton.y + 12
                    onebutton.capital_name.anchor.setTo(0.5, 0)

                    // show next button, or game over
                    showNextButton()
                }
            },this)
        }
    }
    // update score
    score_text.text = score_label + score
}

function showNextButton()
{
    if (question_number < capitalsUsed)
    {
        button_next.inputEnabled = true
        button_next.input.useHandCursor = true

        tweenObject(next_text)
        tweenObject(button_next)
    }
    else
    {
        // no more capitals, show play again button and a result
        game.time.events.add(2000, function()
        {
            // hide buttons and background
            buttons.forEach(function(onebutton){
                    // change text color to white
                    onebutton.capital_name.destroy()
            },this)
            buttons.removeAll(true)
            buttons.destroy()
            button_wrong.destroy()
            question_number_text.destroy()
            button_back_small.destroy()
            button_back_clickable.destroy()
            text_back.destroy()
            capital.destroy()

            // remove white bg
            bg.destroy();

            // make a white  circle
            var graphics2 = game.add.graphics(0, 0);
            graphics2.beginFill(0xffffff, 1);
            graphics2.drawCircle(W/2, H/2, 480);
            // green circle
            var graphics3 = game.add.graphics(0, 0);
            graphics3.beginFill(0x009b2e, 1);
            graphics3.drawCircle(W/2 - 120, H/2 - 50, 100);
            // yellow circle
            var graphics4 = game.add.graphics(0, 0)
            graphics4.beginFill(0xffb900, 1)
            graphics4.drawCircle(W/2 + 120, H/2 - 50, 100)
            // destroy previous score texts
            score_text.destroy()
            // new score label
            score_text1 = game.add.text(W/2, H/2 - 150, final_score, {font:"55px bold", fill:"#0099ff"});
            score_text1.anchor.setTo(0.5,0.5)
            // out of
            out_of = game.add.text(W/2, H/2-45, out_of_label, {font:"26px semiBold", fill:"#000000"});
            out_of.anchor.setTo(0.5,0.5)

            user_score = game.add.text(W/2-120, H/2-43, score.toString(), {font:"46px extraBold", fill:"#000000"});
            user_score.anchor.setTo(0.5,0.5)

            max_possible_score = game.add.text(W/2 + 120, H/2 - 43, capitalsUsed.toString(), {font:"46px extraBold", fill:"#000000"});
            max_possible_score.anchor.setTo(0.5,0.5)

            // play again button
            button_play_again = game.add.button(W/2, H/2 + 55, 'button_capital', function(){
                game.state.start("menu")
            }, this)
            button_play_again.scale.x = .7
            button_play_again.anchor.setTo(0.5, 0.5)

            replay_text = game.add.text(W/2, H/2 + 55, play_again_label.toString(), {font:"29px semiBold", fill:"#000000"});
            replay_text.anchor.setTo(0.5, 0.5)
            // stop button
            button_stop = game.add.button(W/2, H/2 + 130, 'button_capital', stopGame, this)
            button_stop.scale.x = .7
            button_stop.anchor.setTo(0.5, 0.5)
            // stop text
            text_stop = game.add.text(W/2, H/2 + 130, stop_label, {font:"29px semiBold", fill:"#000000"});
            text_stop.anchor.setTo(0.5, 0.5)
            // animation at the end
            anims = game.add.group()
            counter = 0
            play_animation = true
        },this)
    }
}

function nextCapital(){
    // hide next button
    button_next.inputEnabled = false
    game.add.tween(button_next).to({alpha: 0}, 400, "Linear", true)
    game.add.tween(next_text).to({alpha: 0}, 400, "Linear", true)
    button_wrong.visible = false

    // destroy previous capital and buttons
    capital.destroy()

    buttons.forEach(function(onebutton){
            // change text color to white
            onebutton.capital_name.destroy()
    },this)
    buttons.removeAll(true)

    // new capital
    guessThisCapital();
    can_tap = true;
}