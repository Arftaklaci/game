var game = new Phaser.Game(960, 640, Phaser.AUTO, null);

game.global = 
{
	orientated : false,
	first_time : true,
}

language = "english"

// game states
game.state.add('boot', bootState);
game.state.add("Loading", loading);
game.state.add("level1", state1);

// start boot state
game.state.start("boot");

// use \n for a line break
if (language == "english")
{
    title_label = "Earth"
	website = "World Geography Games"
    webURL = "https://world-geography-games.com/world.html"
    solution_label = "Solution"
    score_label = "Score"
    attempts_label = "Attempts"
    stop_label = "Stop"
    play_again_label = "Play again"
    click_to_play_label = "Click on the map to start"
    tap_to_play_label = "Tap on the map to start"
    
    crust_label = "Crust"
    upper_mantle_label = "Upper mantle"
    mantle_label = "Mantle"
    outer_core_label = "Outer core"
    inner_core_label = "Inner core"
    
    crust_info_label = "The Earths crust is made up of solid \nrock. The surface is broken into shifting \nplates that float on the denser material \nof the mantle."
    
    upper_mantle_info_label = "The upper part of the mantle is a transition \nzone of molten magma and semi-solid rock. \nTemperature: around 2700°F (1500°C)."
    
    mantle_info_label = "The mantle is the source of plate tectonics, \nvolcanism and earthquakes. \nTemperature: around 5500°F (3000°C)."
    
    outer_core_info_label = "The outer core is made up of liquid iron \nand nickel. This layer controls the Earths \nmagnetic field. Temperature: around \n8000°F (4500°C)."
    
    inner_core_info_label = "The inner core of the Earth is a solid ball of \niron and nickel. The pressure is extremely \nhigh. Temperature: 10,000°F (6000°C)."
}
else if (language == "bosanski")
{
    title_label = "Earth"
    score_label = "Rezultat"
    attempts_label = "Pokušaji"
    solution_label = "Rješenje"
    stop_label = "Stop"
    play_again_label = "Igraj ponovo"
    click_to_play_label = "Kliknite mapu da počnete"
    tap_to_play_label = "Pritisnite mapu da počnete"
    
    crust_label = "Kora"
    upper_mantle_label = "Gornji omotač"
    mantle_label = "Omotač"
    outer_core_label = "Vanjsko jezgro"
    inner_core_label = "Unutrašnje jezgro"
    
    crust_info_label = "Zemljina kora je površinski dio Zemlje, \nsastoji se od nepomičnih stijena, a \nzajedno s gornjim dijelom omotača \nsačinjava litosferu."
    
    upper_mantle_info_label = "Gornji dio omotača je prijelazna zona \nrastopljene magme i polučvrstih stijena. \nTemperatura: oko 1500 C (2700 F)."
    
    mantle_info_label = "Omotač je izvor kontinentalnog drifta, \nvulkanizma i zemljotresa. \nTemperatura: oko 3000 C (5432 F)."
    
    outer_core_info_label = "Spoljno jezgro se sastoji od tečnog gvožđa i \nnikla, te kontrolira Zemljino magnetno polje. \nTemperatura: 4000 C - 5000 C (7200 F - 9000 F)."
    
    inner_core_info_label = "Unutrašnje jezgro Zemlje je čvrsta kugla \nsastavljena od željeza i nikla. Pritisak je vrlo \nvisok, a temperatura oko 6000 C."
}