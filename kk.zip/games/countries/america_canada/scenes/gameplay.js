"use strict"
var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        });
    }
    
    create() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;
        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;
       camera.zoom = 1.3;
        // min max zoom
        this.minZoom = 1;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.8;
        }
        else {
            this.maxZoom = 2.1;
        }
        // display countries in this scene
        this.displayCanada(this);
        // get countries (sprites) array from the container
        this.countriesArray = this.canadaContainer.getAll();
        // for each country (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {
            /* development phase - enable drag to position countries
            this.countriesArray[i].setInteractive()
            this.input.setDraggable(this.countriesArray[i]);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {
                gameObject.x = dragX;
                gameObject.y = dragY;
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });
            */
            let country = this.countriesArray[i];
            // make countries sprites interactive
            country.setInteractive({ 
                useHandCursor: true,             
                pixelPerfect: true,
                alphaTolerance: 255
             });
             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over country
                country.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                        country.setTintFill(0xFFFFFF);
                    }
                },this);
                country.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        country.clearTint();
                    }
                },this);
            }
            country.on('pointerdown', () => {
                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });
            country.on('pointerup', () => {
                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);
                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    country.xPos = camera.x;
                    country.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false) {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === country.name) {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this country
                            country.disableInteractive();
                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }
                            // create the country label
                            this.showLabels(country);
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // else don't tap, drag the map
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();
        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false) {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();
                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip, ui.buttonSound],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                let dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {

                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        let drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }
                }).on('pinch', dragScale => {
                    let scaleFactor = dragScale.scaleFactor;
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                }, this);
                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }
        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 34, color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 34, color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });
        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                camera.zoom *= 0.9;
            }
        }
        // limit zoom
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.canadaContainer.setSize(width, height);
        this.canadaContainer.x = 0;
        this.canadaContainer.y = 0;

        this.borders.setPosition(width/2 + 8.5, height/2 + 69);
        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2, height/2);
        }
    }

    getQuestion() {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;
        this.questionsArray.shift();

        if (ui.questionText.text === countriesLabels.newfoundland || ui.questionText.text === countriesLabels.princeEdwardIsland || ui.questionText.text === countriesLabels.northwestTerritories) {
            ui.questionText.setFontSize(29);
        }
        else {
            ui.questionText.setFontSize(32);
        }
        
        // tween
        this.tweens.add({
           targets: [ui.questionText],
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;
        // play sound
        this.gameOverSound.play();
        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        ui.buttonSound.destroy();
        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {
        // tween camera
        if (camera.zoom > this.minZoom) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: this.minZoom,
                x: 0, 
                y: 0,
                duration: 2000,
                onComplete: () => {
                    
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }
        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: 0,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showLabels(country) {
            if (country.name === countriesLabels.princeEdwardIsland) {
                let line = this.add.image(country.lineX, country.lineY, "linePrinceEdward");
                line.setOrigin(0,0.5);
                this.canadaContainer.add(line);
            }
            else if (country.name === countriesLabels.novaScotia) {
                let line = this.add.image(country.lineX, country.lineY, "lineNovaScotia");
                line.setOrigin(0,0.5);
                this.canadaContainer.add(line);
            }
            else if (country.name === countriesLabels.newBrunswick) {
                let line = this.add.image(country.lineX, country.lineY, "lineNewBrunswick");
                line.setOrigin(.5,.5);
                this.canadaContainer.add(line);
            }

            // country name
            country.txt = this.add.text(country.x, country.y, country.name, { fontFamily: "bold", fontSize: 14, color: '#000000' });
            country.txt.setOrigin(.5,.5);
            this.canadaContainer.add(country.txt);
            // position text
            if (country.labelX) {
                country.txt.x = country.labelX;
                country.txt.y = country.labelY;
            }
            // create white rectangle
            country.rect = this.add.sprite(country.txt.x, country.txt.y, "rectangle");
            country.rect.displayWidth = country.txt.width + 4;
            country.rect.displayHeight = country.txt.height;
            this.canadaContainer.add(country.rect);
            // set different origin for certain text and rectangles
            if (country.name === countriesLabels.princeEdwardIsland || country.name === countriesLabels.novaScotia) {
                country.rect.setOrigin(0, 0.5);
                country.txt.setOrigin(0, 0.5);
                country.txt.x += 2;
            }
            // bring to top text field
            this.canadaContainer.bringToTop(country.txt);
    }
    
    displayCanada(aScene) {
        // extra
        aScene.borders = aScene.add.image(width/2 + 8.5, height/2 + 69, 'borders')
        // interactive sprites
        aScene.nunavut = aScene.add.sprite(width/2 + 37, height/2 - 60, "nunavut");
        aScene.northwestTerritories = aScene.add.sprite(width/2 - 110, height/2 - 76, "northwestTerritories");
        aScene.yukon = aScene.add.sprite(width/2 - 215, height/2 - 45, "yukon");
        aScene.britishColumbia = aScene.add.sprite(width/2 - 214, height/2 + 86.5, "britishColumbia");
        aScene.alberta = aScene.add.sprite(width/2 - 133, height/2 + 118.5, "alberta");
        aScene.manitoba = aScene.add.sprite(width/2 - 8, height/2 + 139, "manitoba");
        aScene.saskatchewan = aScene.add.sprite(width/2 - 82, height/2 + 133, "saskatchewan");
        aScene.ontario = aScene.add.sprite(width/2 + 72.5, height/2 + 203.5, "ontario");
        aScene.quebec = aScene.add.sprite(width/2 + 184, height/2 + 140, "quebec");
        aScene.newfoundland = aScene.add.sprite(width/2 + 301.5, height/2 + 117, "newfoundlandAndLabrador");
        aScene.novaScotia = aScene.add.sprite(width/2 + 291, height/2 + 220, "novaScotia");
        aScene.newBrunswick = aScene.add.sprite(width/2 + 231, height/2 + 232, "newBrunswick");
        aScene.princeEdwardIsland = aScene.add.sprite(width/2 + 336, height/2 + 192, "princeEdwardIsland");
        // reposition labels
        aScene.yukon.labelX = aScene.yukon.x - 10;
        aScene.yukon.labelY = aScene.yukon.y + 15;
        aScene.britishColumbia.labelX = aScene.britishColumbia.x - 20;
        aScene.britishColumbia.labelY = aScene.britishColumbia.y;
        aScene.saskatchewan.labelX = aScene.saskatchewan.x;
        aScene.saskatchewan.labelY = aScene.saskatchewan.y + 20;
        aScene.manitoba.labelX = aScene.manitoba.x;
        aScene.manitoba.labelY = aScene.manitoba.y - 25;
        aScene.ontario.labelX = aScene.ontario.x - 25;
        aScene.ontario.labelY = aScene.ontario.y - 25;
        aScene.quebec.labelX = aScene.quebec.x - 30;
        aScene.quebec.labelY = aScene.quebec.y + 15;
        aScene.alberta.labelX = aScene.alberta.x - 5;
        aScene.alberta.labelY = aScene.alberta.y;
        aScene.northwestTerritories.labelX = aScene.northwestTerritories.x;
        aScene.northwestTerritories.labelY = aScene.northwestTerritories.y + 90;
        aScene.newBrunswick.labelX = aScene.newBrunswick.x - 10;
        aScene.newBrunswick.labelY = aScene.newBrunswick.y + 30;
        aScene.novaScotia.labelX = aScene.novaScotia.x + 25;
        aScene.novaScotia.labelY = aScene.novaScotia.y;
        aScene.princeEdwardIsland.labelX = aScene.princeEdwardIsland.x - 40;
        aScene.princeEdwardIsland.labelY = aScene.princeEdwardIsland.y - 10;
        // white lines
        aScene.newBrunswick.hasLine = true;
        aScene.novaScotia.hasLine = true;
        aScene.princeEdwardIsland.hasLine = true;
        aScene.newBrunswick.lineX = aScene.newBrunswick.x - 10;
        aScene.newBrunswick.lineY = aScene.newBrunswick.y + 5;
        aScene.novaScotia.lineX = aScene.novaScotia.x - 45;
        aScene.novaScotia.lineY = aScene.novaScotia.y;
        aScene.princeEdwardIsland.lineX = aScene.princeEdwardIsland.x - 95;
        aScene.princeEdwardIsland.lineY = aScene.princeEdwardIsland.y;
        // names
        aScene.nunavut.name = countriesLabels.nunavut;
        aScene.northwestTerritories.name = countriesLabels.northwestTerritories;
        aScene.yukon.name = countriesLabels.yukon;
        aScene.britishColumbia.name = countriesLabels.britishColumbia;
        aScene.alberta.name = countriesLabels.alberta;
        aScene.manitoba.name = countriesLabels.manitoba;
        aScene.ontario.name = countriesLabels.ontario;
        aScene.quebec.name = countriesLabels.quebec;
        aScene.newfoundland.name = countriesLabels.newfoundland;
        aScene.princeEdwardIsland.name = countriesLabels.princeEdwardIsland;
        aScene.newBrunswick.name = countriesLabels.newBrunswick;
        aScene.novaScotia.name = countriesLabels.novaScotia;
        aScene.saskatchewan.name = countriesLabels.saskatchewan;
        // create container and put countries into it
        aScene.canadaContainer = aScene.add.container(0, 0, [ aScene.nunavut, aScene.northwestTerritories, aScene.yukon, aScene.britishColumbia, aScene.alberta, aScene.saskatchewan, aScene.ontario, aScene.manitoba, aScene.quebec, aScene.newfoundland, aScene.newBrunswick, aScene.novaScotia, aScene.princeEdwardIsland ]);
        
        aScene.canadaContainer.setSize(width, height);
        aScene.canadaContainer.x = 0;
        aScene.canadaContainer.y = 0;     
     }
}