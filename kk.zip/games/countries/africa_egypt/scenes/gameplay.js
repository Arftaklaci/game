"use strict"
var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        });
    }
    
    create() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;
        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;
       camera.scrollX = -50;

        // min max zoom
        this.minZoom = .25;  
        this.maxZoom = 1.6;
        camera.zoom = .25;

        // display countries in this scene
        this.displayMap(this);
        // get countries (sprites) array from the container
        this.countriesArray = this.mapContainer.getAll();
        // for each subject (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {
            /* development phase 
            this.countriesArray[i].setInteractive()
            this.input.setDraggable(this.countriesArray[i]);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {
                gameObject.x = dragX;
                gameObject.y = dragY;
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });
            */
            
            let subject = this.countriesArray[i];

            //interactive
            subject.setInteractive({ 
                useHandCursor: true,             
                pixelPerfect: true,
                alphaTolerance: 255
                });

             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over subject
                subject.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                       subject.setTintFill(0xFFFFFF);
                    }
                },this);
                subject.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        subject.clearTint();
                    }
                },this);
            }
            subject.on('pointerdown', () => {
                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });
            subject.on('pointerup', () => {
                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);
                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    subject.xPos = camera.x;
                    subject.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false) {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === subject.name) {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this subject
                            subject.disableInteractive();
                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }
                            // create the subject label
                            this.showLabels(subject);
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // else don't tap, drag the map
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();
        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false) {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();
                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip, ui.buttonSound],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                let dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {
                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        let drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }
                }).on('pinch', dragScale => {
                    let scaleFactor = dragScale.scaleFactor;
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                }, this);
                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }
        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 70, align: "center", color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 70, align: "center", color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });
        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                camera.zoom *= 0.9;
            }
        }
        // limit zoom
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.mapContainer.setSize(width, height);
        this.mapContainer.x = 0;
        this.mapContainer.y = 0;

        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2, height/2);
        }
    }

    getQuestion() {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;
        this.questionsArray.shift();

       	
		 if (ui.questionText.text === countriesLabels.redSea) {
            ui.questionText.setFontSize(30);
        }
        else {
            ui.questionText.setFontSize(34);
        }


        // tween
        this.tweens.add({
           targets: [ui.questionText],
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;
        // play sound
        this.gameOverSound.play();
        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        ui.buttonSound.destroy();
        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {
        // tween camera
        if (camera.zoom > this.minZoom) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: this.minZoom,
                x: 0, 
                y: 0,
                duration: 1500,
                onComplete: () => {
                    
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }
        this.tweens.add({
            targets: [camera],
            scrollX: -50,
            scrollY: 0,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showLabels(subject) {
        if (subject.name === subjects.portSaid) {
            let line = this.add.image(subject.x+50, subject.y+10, "texture", "linePortSaid.png");
            line.setOrigin(1,1);
            this.mapContainer.add(line);
        }
        else if (subject.name === subjects.sharqia) {
            let line = this.add.image(subject.x+40, subject.y-75, "texture", "lineDamietta.png");
            line.setOrigin(0,1);
            this.mapContainer.add(line);
        }
        else if (subject.name === subjects.damietta) {
            let line = this.add.image(subject.x-40, subject.y, "texture", "lineDamietta.png");
            line.setOrigin(0,1);
            this.mapContainer.add(line);
        }
        else if (subject.name === subjects.luxor) {
            let line = this.add.image(subject.x+10, subject.y, "texture", "lineLuxor.png");
            line.setOrigin(1,0.5);
            this.mapContainer.add(line);
        }
        else if (subject.name === subjects.dakahlia) {
            let line = this.add.image(subject.x-50, subject.y-30, "texture", "lineDakahlia.png");
            line.setOrigin(0,1);
            this.mapContainer.add(line);
        }
        else if (subject.name === subjects.kafrElSheikh) {
            let line = this.add.image(subject.x, subject.y, "texture", "lineKafrElSheik.png");
            line.setOrigin(0,1);
            this.mapContainer.add(line);
        }

        subject.rect = this.add.sprite(subject.x, subject.y, "rectangle");
        // subject name
        subject.txt = this.add.text(subject.x, subject.y, subject.name, { fontFamily: "bold", fontSize: 36, align: "center", color: '#000000' });
        subject.txt.setOrigin(.5,.5);
        
        // position text
        if (subject.labelX) {
            subject.txt.x = subject.labelX;
            subject.txt.y = subject.labelY;
            subject.rect.x = subject.labelX;
            subject.rect.y = subject.labelY;
        }
        subject.rect.displayWidth = subject.txt.width + 4;
        subject.rect.displayHeight = subject.txt.height + 2;
    }

    displayMap(aScene) {
        // interactive sprites
        aScene.matrouh = aScene.add.sprite(width/2 - 719, height/2 - 714.5, "matrouh");
        aScene.redSea = aScene.add.sprite(width/2 + 703, height/2 + 324, "redSea");
        aScene.newValley = aScene.add.sprite(width/2 - 393, height/2 + 495.5, "newValley");

        aScene.aswan = aScene.add.sprite(width/2 + 350, height/2 + 794, "texture", "aswan.png");
        aScene.luxor = aScene.add.sprite(width/2 + 429, height/2 + 285, "texture", "luxor.png");
        aScene.qena = aScene.add.sprite(width/2 + 386, height/2 + 277.5, "texture", "qena.png");
        aScene.asyut = aScene.add.sprite(width/2 + 95, height/2 - 104.5, "texture", "asyut.png");
        aScene.sohag = aScene.add.sprite(width/2 + 242.5, height/2 + 69, "texture", "sohag.png");
        aScene.giza = aScene.add.sprite(width/2 - 314, height/2 - 549.5, "texture", "giza.png");
        aScene.minya = aScene.add.sprite(width/2 - 202.5, height/2 - 346, "texture", "minya.png");
        aScene.beniSuef = aScene.add.sprite(width/2 - 46, height/2 - 563, "texture", "beniSuef.png");
        aScene.faiyum = aScene.add.sprite(width/2 - 55.5, height/2 - 635.5, "texture", "faiyum.png");
        aScene.cairo = aScene.add.sprite(width/2 + 193.5, height/2 - 694.5, "texture", "cairo.png");
        aScene.suez = aScene.add.sprite(width/2 + 368, height/2 - 699.5, "texture", "suez.png");
        aScene.monufia = aScene.add.sprite(width/2 + 70.5, height/2 - 914, "texture", "monufia.png");
        aScene.gharbia = aScene.add.sprite(width/2 + 73, height/2 - 1011, "texture", "gharbia.png");
        aScene.kafrElSheikh = aScene.add.sprite(width/2 + 30, height/2 - 1122, "texture", "kafrElSheikh.png");
        aScene.alexandria = aScene.add.sprite(width/2 - 196.5, height/2 - 1006, "texture", "alexandria.png");
        aScene.beheira = aScene.add.sprite(width/2 - 106, height/2 - 971.5, "texture", "beheira.png");
        aScene.sharqia = aScene.add.sprite(width/2 + 229, height/2 - 961, "texture", "sharqia.png");
        aScene.dakahlia = aScene.add.sprite(width/2 + 204.5, height/2 - 1060.5, "texture", "dakahlia.png");
        aScene.damietta = aScene.add.sprite(width/2 + 254, height/2 - 1135.5, "texture", "damietta.png");
        aScene.portSaid = aScene.add.sprite(width/2 + 378, height/2 - 1081, "texture", "portSaid.png");
        aScene.ismailia = aScene.add.sprite(width/2 + 350, height/2 - 963, "texture", "ismailia.png");
        aScene.qalyubia = aScene.add.sprite(width/2 + 135, height/2 - 888, "texture", "qalyubia.png");
        aScene.northSinai = aScene.add.sprite(width/2 + 680, height/2 - 899, "texture", "northSinai.png");
        aScene.southSinai = aScene.add.sprite(width/2 + 684.5, height/2 - 504, "texture", "southSinai.png");

        // reposition labels
        aScene.monufia.labelX = aScene.monufia.x;
        aScene.monufia.labelY = aScene.monufia.y - 15;
        aScene.qalyubia.labelX = aScene.qalyubia.x;
        aScene.qalyubia.labelY = aScene.qalyubia.y + 20;

        aScene.aswan.labelX = aScene.aswan.x + 110;
        aScene.aswan.labelY = aScene.aswan.y + 15;
        aScene.qena.labelX = aScene.qena.x;
        aScene.qena.labelY = aScene.qena.y - 90;
        aScene.alexandria.labelX = aScene.alexandria.x - 30;
        aScene.alexandria.labelY = aScene.alexandria.y - 20;
        aScene.beheira.labelX = aScene.beheira.x;
        aScene.beheira.labelY = aScene.beheira.y + 85;
        aScene.luxor.labelX = aScene.luxor.x - 120;
        aScene.luxor.labelY = aScene.luxor.y;
        aScene.minya.labelX = aScene.minya.x + 65;
        aScene.minya.labelY = aScene.minya.y;
        aScene.beniSuef.labelX = aScene.beniSuef.x;
        aScene.beniSuef.labelY = aScene.beniSuef.y + 40;
        aScene.faiyum.labelX = aScene.faiyum.x + 20;
        aScene.faiyum.labelY = aScene.faiyum.y + 10;
        aScene.suez.labelX = aScene.suez.x - 20;
        aScene.suez.labelY = aScene.suez.y;
        aScene.giza.labelX = aScene.giza.x - 10;
        aScene.giza.labelY = aScene.giza.y + 40;

        aScene.kafrElSheikh.labelX = aScene.kafrElSheikh.x - 30;
        aScene.kafrElSheikh.labelY = aScene.kafrElSheikh.y - 130;
        aScene.dakahlia.labelX = aScene.dakahlia.x - 40;
        aScene.dakahlia.labelY = aScene.dakahlia.y - 270;
        aScene.ismailia.labelX = aScene.ismailia.x;
        aScene.ismailia.labelY = aScene.ismailia.y + 30;

        aScene.sharqia.labelX = aScene.sharqia.x + 230;
        aScene.sharqia.labelY = aScene.sharqia.y - 225;
        aScene.damietta.labelX = aScene.damietta.x + 165;
        aScene.damietta.labelY = aScene.damietta.y - 150;
        aScene.portSaid.labelX = aScene.portSaid.x + 120;
        aScene.portSaid.labelY = aScene.portSaid.y - 35;

        // names
        aScene.matrouh.name = subjects.matrouh;
        aScene.redSea.name = subjects.redSea;
        aScene.newValley.name = subjects.newValley;
        aScene.aswan.name = subjects.aswan;
        aScene.luxor.name = subjects.luxor;
        aScene.qena.name = subjects.qena;
        aScene.asyut.name = subjects.asyut;
        aScene.sohag.name = subjects.sohag;
        aScene.giza.name = subjects.giza;
        aScene.minya.name = subjects.minya;
        aScene.beniSuef.name = subjects.beniSuef;
        aScene.faiyum.name = subjects.faiyum;
        aScene.cairo.name = subjects.cairo;
        aScene.suez.name = subjects.suez;
        aScene.qalyubia.name = subjects.qalyubia;
        aScene.monufia.name = subjects.monufia;
        aScene.gharbia.name = subjects.gharbia;
        aScene.kafrElSheikh.name = subjects.kafrElSheikh;
        aScene.alexandria.name = subjects.alexandria;
        aScene.beheira.name = subjects.beheira;
        aScene.sharqia.name = subjects.sharqia;
        aScene.dakahlia.name = subjects.dakahlia;
        aScene.damietta.name = subjects.damietta;
        aScene.portSaid.name = subjects.portSaid;
        aScene.ismailia.name = subjects.ismailia;
        aScene.northSinai.name = subjects.northSinai;
        aScene.southSinai.name = subjects.southSinai;
        // create container and put countries into it
        aScene.mapContainer = aScene.add.container(0, 0, [aScene.matrouh, aScene.redSea, aScene.newValley, aScene.aswan, aScene.qena, aScene.asyut, aScene.sohag, aScene.luxor, aScene.giza, aScene.minya, aScene.beniSuef,  ]);
        aScene.mapContainer = aScene.add.container(0, 0, [aScene.matrouh, aScene.redSea, aScene.newValley, aScene.aswan, aScene.qena, aScene.asyut, aScene.sohag, aScene.luxor, aScene.giza, aScene.minya, aScene.beniSuef, aScene.faiyum, aScene.cairo, aScene.suez, aScene.kafrElSheikh, aScene.gharbia, aScene.qalyubia, aScene.monufia, aScene.alexandria, aScene.beheira, aScene.sharqia, aScene.dakahlia, aScene.damietta, aScene.portSaid, aScene.ismailia, aScene.northSinai, aScene.southSinai]);

        // rivers and disputed area (these aren't interactive sprites)
        aScene.rivers = aScene.add.image(width/2+219, height/2+101, "rivers");
        aScene.disputedArea = aScene.add.image(width/2+968, height/2+1095, "disputedArea");

        aScene.mapContainer.setSize(width, height);
        aScene.mapContainer.x = 0;
        aScene.mapContainer.y = 0;
     }
}