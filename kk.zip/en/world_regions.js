"use strict"
var width, height, resize;
var webUrl = "https://world-geography-games.com/world.html";

var labels = 
{
    website         : "World Geography Games",
    title           : "Regions",
    titleTwo        : "Regions",
    play            : "play",
    options         : "options",
    map             : "map",
    sound           : "SOUND",
    photos          : "PHOTOS",
    tapStart        : "Tap on the map to start",
    clickStart      : "Click on the map to start",
    incorrect       : "Incorrect. Try again!",
    score           : "Score: ",
    attempts        : "Attempts: ",
    attemptsEnd     : "Attempts",
    points          : "Points",
    back            : "back",
    playAgain       : "Play Again",
    stop            : "Stop",
    skip            : "Skip",
    skipped         : "Skipped",
}

// the order of labels below is important!
var credits = {
  credit1   : "Photo: Neil Palmer 2011 (CC-BY-SA)",
  credit2   : "Photo: Thomas Hackl 2018 (CC-BY-NC)",
  credit3   : "Photo: Mohammad Tauheed 2018 (CC-BY-NC)",
  credit4   : "Photo: Paula Funnell 2017 (CC-BY-NC-SA)",
  credit5   : "Photo: PanaTomix 2018 (CC-BY-NC)",
  credit6   : "Photo: Ahtziri Gonzalez/CIFOR 2018 (CC-BY-NC-SA)",
  credit7   : "Photo: Bart Everson 2018  (CC-BY)",
  credit8   : "Photo: Christian Collins 2017 (CC-BY-SA)",
  credit9   : "Photo: Nina R 2020 (CC-BY)",
  credit10  : "Photo: Rajarshi Mitra 2018 (CC-BY)",
  credit11  : "Photo: Ogust1 2014 (CC-BY-NC)",
  credit12  : "Photo: Martha de Jong-Lantink 2018 (CC-BY-NC-SA)",
  credit13  : "Photo: Pablo Marx 2016 (CC-BY-NC-SA)",
  credit14  : "Photo: Ahmed Helal 2019 (CC-BY)",
  credit15  : "Photo: Ashok Boghani 2017 (CC-BY-NC)",
  credit16  : "Photo: Claudia Cota 2016 (CC-BY-NC-SA)",
  credit17  : "Photo: Eric Tessmer 2017 (CC-BY)",
  credit18  : "Photo: Arlid Andersen 2019 (CC-BY-SA)",
  credit19  : "Photo: Anatoly_l 2019 (CC-BY-SA)",
  credit20  : "Photo: LisArt 2016 (CC-BY-NC-SA)"
}
var creditsArray = Object.values(credits);

var subjects = {
  amazonBasin:   "Amazon Basin",
  balkans:       "Balkans",
  bengal:        "Bengal",
  caribbean:     "Caribbean",
  caucasus:      "Caucasus",
  congoBasin:    "Congo Basin",
  deepSouth:     "Deep South",
  greatPlains:   "Great Plains",
  hornOfAfrica:  "Horn of Africa",
  kashmir:       "Kashmir",
  maghreb:       "Maghreb",
  melanesia:     "Melanesia",
  micronesia:    "Micronesia",
  middleEast:    "Middle East",
  nunavut:       "Nunavut",
  patagonia:     "Patagonia",
  polynesia:     "Polynesia",
  scandinavia:   "Scandinavia",
  siberia:       "Siberia",
  sundaland:     "Sundaland",
}

var countriesNames = [", South America", ", Europe", ", Bangladesh/India", ", Americas", ", Eurasia", ", Africa", ", USA", ", USA", "", ", Asia", ", North Africa", ", Oceania", ", Oceania", "", ", Canada", ", Argentina/Chile", ", Oceania", ", Northern Europe", ", Russia", ", Southeast Asia"];

var infoText = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""];

// don't edit below

// sound is on by default
var soundButtonFrame = 0;
// show photos by default
var showPhotos = true;
var photosButtonFrame = 0;
// number of attempts
var attempts = +0;
// number of skipped countries
var skips = +0;
// make array
var questionsArray = Object.values(subjects);
var questionsArrayStatic = [...questionsArray];

// resize
const DEFAULT_WIDTH = 1280
const DEFAULT_HEIGHT = 720
const MAX_WIDTH = DEFAULT_WIDTH * 1.5
const MAX_HEIGHT = DEFAULT_HEIGHT * 1.5
let SCALE_MODE = 'SMOOTH'

const config = {
    type: Phaser.AUTO,
    parent: 'geo-game',
    backgroundColor : 0x34C5EB,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,

    scale: 
    {
        mode: Phaser.Scale.NONE,
        parent: "geo-game",
    },
    scene: [Loading, Menu, Options, UserInterface, GraphUI, Gameplay, Graph]
}

window.addEventListener('load', () => {
    const game = new Phaser.Game(config)
  
    resize = () => {
      const w = window.innerWidth
      const h = window.innerHeight
  
      let width = DEFAULT_WIDTH
      let height = DEFAULT_HEIGHT
      let maxWidth = MAX_WIDTH
      let maxHeight = MAX_HEIGHT
      let scaleMode = SCALE_MODE
  
      let scale = Math.min(w / width, h / height)
      let newWidth = Math.min(w / scale, maxWidth)
      let newHeight = Math.min(h / scale, maxHeight)
  
      let defaultRatio = DEFAULT_WIDTH / DEFAULT_HEIGHT
      let maxRatioWidth = MAX_WIDTH / DEFAULT_HEIGHT
      let maxRatioHeight = DEFAULT_WIDTH / MAX_HEIGHT
  
      // smooth scaling
      let smooth = 1
      if (scaleMode === 'SMOOTH') {
        const maxSmoothScale = 1.15
        const normalize = (value, min, max) => {
          return (value - min) / (max - min)
        }
        if (width / height < w / h) {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioWidth) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        } else {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioHeight) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        }
      }

      // resize the game
      game.scale.resize(newWidth * smooth, newHeight * smooth)
      // scale the width and height of the css
      game.canvas.style.width = newWidth * scale + 'px'
      game.canvas.style.height = newHeight * scale + 'px'
      // center the game with css margin
      game.canvas.style.marginTop = `${(h - newHeight * scale) / 2}px`
      game.canvas.style.marginLeft = `${(w - newWidth * scale) / 2}px`
    }

    window.addEventListener('resize', event => {
      resize()
    })
  
    resize()
  })
