var mouseIsDown = false;
var distX = 0;

function mouseDown(){
    //set the mouseIsDown to true
    mouseIsDown = true;
    startX = game.input.y;
}

function mouseUp(){
       mouseIsDown = false;
}

var optionsState =
{
create: function()
{
    game.input.onUp.add(mouseUp, this);
    game.input.onDown.add(mouseDown, this);

    // bg blue rectangle
    bg = game.add.image(0, 0, 'bg');
    // text options
    text_options = game.add.text(W - 20, 20, options_label, {font:"36px bold", fill:"#ffffff"});
    text_options.anchor.setTo(1,0);
    button_options = game.add.button(W - 35 - text_options.width, 18, 'button_options');
    button_options.anchor.setTo(1,0);
    button_options.scale.x = .8;
    button_options.scale.y = .8;

    // button back
    button_back_small = game.add.button(20, 21, 'button_back');
    text_back = game.add.text(55, 23, back_label, {font:"26px bold", fill:"#000000"});
    button_back_clickable = game.add.button(10, 20, 'button_invisible', go_back);
    button_back_clickable.width = 60 + text_back.width;
    button_back_clickable.height = 40;

    // ** BASIC OPTIONS(sound, number of flags, regions)
    regions_group = game.add.group();

    // number of flags
    text_number_of_flags = game.add.text(30, 230, number_of_flags_label, {font:"27px bold", fill:"#000000"}, regions_group);
    // radio buttons
    radio10 = game.add.button(25, 280, 'button_radio', radioButtonClicked);
    radio10.value = 10;
    text10 = game.add.text(68, 290, "10", {font:"20px semiBold", fill:"#000000"});

    radio25 = game.add.button(120, 280, 'button_radio', radioButtonClicked);
    radio25.value = 25;
    text25 = game.add.text(163, 290, "25", {font:"20px semiBold", fill:"#000000"});

    radio50 = game.add.button(215, 280, 'button_radio', radioButtonClicked);
    radio50.value = 50;
    text50 = game.add.text(258, 290, "50", {font:"20px semiBold", fill:"#000000"});

    radio100 = game.add.button(310, 280, 'button_radio', radioButtonClicked);
    radio100.value = 100;
    text100 = game.add.text(353, 290, "100", {font:"20px semiBold", fill:"#000000"});

    radio197 = game.add.button(405, 280, 'button_radio', radioButtonClicked);
    radio197.value = 197;
    text197 = game.add.text(448, 290, "197", {font:"20px semiBold", fill:"#000000"});

    // selected
    if (capitalsUsed === 10) {
        radio10.frame = 1;
    }
    else if (capitalsUsed === 25) {
        radio25.frame = 1;
    }
    else if (capitalsUsed === 50) {
        radio50.frame = 1;
    }
    else if (capitalsUsed === 100) {
        radio100.frame = 1;
    }
    else if (capitalsUsed === 197) {
        radio197.frame = 1;
    }

    // flags
    text_flags = game.add.text(30, 370, flags_label, {font:"27px bold", fill:"#000000"}, regions_group);
    // regions text
    europe_txt = game.add.text(30, 525, europe_label, {font:"21px bold", fill:"#000000"}, regions_group);
    africa_txt = game.add.text(30, 425, africa_label, {font:"21px bold", fill:"#000000"}, regions_group);
    north_america_txt = game.add.text(30, 575, north_america_label, {font:"21px bold", fill:"#000000"}, regions_group);
    asia_txt = game.add.text(30, 475, asia_label, {font:"21px bold", fill:"#000000"}, regions_group);
    oceania_txt = game.add.text(30, 625, oceania_label, {font:"21px bold", fill:"#000000"}, regions_group);
    south_america_text = game.add.text(30, 675, south_america_label, {font:"21px bold", fill:"#000000"}, regions_group);

    // toggle buttons for regions
    toggle_europe = game.add.button(W - 30, 520, 'button_toggle', toggle_regions, this, null,null,null,null, regions_group)
    toggle_europe.frame = europe_btn
    toggle_africa = game.add.button(W - 30, 420, 'button_toggle', toggle_regions, this, null,null,null,null, regions_group)
    toggle_africa.frame = africa_btn
    toggle_north_america = game.add.button(W - 30, 570, 'button_toggle', toggle_regions, this, null,null,null,null, regions_group)
    toggle_north_america.frame = north_america_btn
    toggle_asia = game.add.button(W - 30, 470, 'button_toggle', toggle_regions, this, null,null,null,null, regions_group)
    toggle_asia.frame = asia_btn
    toggle_oceania = game.add.button(W - 30, 620, 'button_toggle', toggle_regions, this, null,null,null,null, regions_group)
    toggle_oceania.frame = oceania_btn

    toggle_south_america = game.add.button(W - 30,670, 'button_toggle', toggle_regions, this, null,null,null,null, regions_group)
    toggle_south_america.frame = south_america_btn

    toggle_europe.anchor.setTo(1,0)
    toggle_africa.anchor.setTo(1,0)
    toggle_north_america.anchor.setTo(1,0)
    toggle_asia.anchor.setTo(1,0)
    toggle_oceania.anchor.setTo(1,0)
    toggle_south_america.anchor.setTo(1,0)
    // short of flags
    shortOfFlags = game.add.text(W/2, 330, short_label, {font:"24px bold", fill:"#f80007"}, regions_group);
    shortOfFlags.visible = false;
    shortOfFlags.anchor.setTo(0.5,0);
    // sound
    text_sound = game.add.text(30, 140, sound_label, {font:"27px bold", fill:"#000000"}, regions_group);
    button_sound = game.add.button(W - 30, 137, 'button_toggle', toggle_sound, this, null, null, null, null, regions_group)
    button_sound.frame = sound_frame
    button_sound.anchor.setTo(1,0)
},
}

function radioButtonClicked(btn) {
    if (btn.value <= slider_array.length) {
        //min = Math.round((flag_counter.x - bounds.x) / 2);
        frames.length = 0;
        
        shuffle(slider_array);
        for (let f = 0; f < btn.value; f++){
            frames.push(slider_array[f]);
        }
    
        capitalsUsed = frames.length;
        shortOfFlags.visible = false;
        button_back_small.alpha = 1;
        text_back.alpha = 1;
        // on/off
        radio10.frame = 0;
        radio25.frame = 0;
        radio50.frame = 0;
        radio100.frame = 0;
        radio197.frame = 0;
        btn.frame = 1;
    }
    else {
        shortOfFlags.visible = true;
    }
}

function swipe_done() {
    //get the ending point
    var endX = game.input.y;
    if (endX < startX) {
        asia_group.y -= distX / 6
    }
    else{
        asia_group.y += distX / 6
    }
}

function toggle_regions(btn)
{
    if (btn == toggle_europe){
        // save toggle buttonframe
        europe_btn = (europe_btn == 0) ? 1 : 0

        // exclude frames (flags)
        if (btn.frame == 0) {
            for(let j = 0; j < europe.length; j++)
            {
                for(let i = 0; i < slider_array.length; i++)
                {
                   if (slider_array[i] === europe[j])
                   {
                        // remove these frames
                        slider_array.splice(i, 1);
                   }
                }
            }
        }
        else    // include frames (flags)
        {
            for(let j = 0; j < europe.length; j++)
            {
                if (slider_array.includes(europe[j]) == false)
                {
                    // add these frames
                    slider_array.push(europe[j])
                }
            }
        }
    }
    else if (btn == toggle_north_america){

        north_america_btn = (north_america_btn == 0) ? 1 : 0

        // exclude
        if (btn.frame == 0) {
            for(let j = 0; j < north_america.length; j++)
            {
                for(let i = 0; i < slider_array.length; i++)
                {
                   if (slider_array[i] === north_america[j])
                   {
                        slider_array.splice(i, 1);
                   }
                }
            }
        }
        else    // include
        {
            for(let j = 0; j < north_america.length; j++)
            {
                if (slider_array.includes(north_america[j]) == false)
                {
                    slider_array.push(north_america[j])
                }
            }
        }
    }
    else if (btn == toggle_south_america){

        south_america_btn = (south_america_btn == 0) ? 1 : 0

        // exclude
        if (btn.frame == 0) {
            for(let j = 0; j < south_america.length; j++)
            {
                for(let i = 0; i < slider_array.length; i++)
                {
                   if (slider_array[i] === south_america[j])
                   {
                    slider_array.splice(i, 1);
                   }
                }
            }
        }
        else    // include
        {
            for(let j = 0; j < south_america.length; j++)
            {
                if (slider_array.includes(south_america[j]) == false)
                {
                    slider_array.push(south_america[j])
                }
            }
        }
    }
    else if (btn == toggle_africa){
        africa_btn = (africa_btn == 0) ? 1 : 0

        // exclude
        if (btn.frame == 0) {
            for(let j = 0; j < africa.length; j++)
            {
                for(let i = 0; i < slider_array.length; i++)
                {
                   if (slider_array[i] === africa[j])
                   {
                        // remove these frames
                        slider_array.splice(i, 1);
                   }
                }
            }
        }
        else    // include
        {
            for(let j = 0; j < africa.length; j++)
            {
                if (slider_array.includes(africa[j]) == false)
                {
                    // add these frames
                    slider_array.push(africa[j])
                }
            }
        }
    }
    else if (btn == toggle_asia){
        asia_btn = (asia_btn == 0) ? 1 : 0

        // exclude
        if (btn.frame == 0) {
            for(let j = 0; j < asia.length; j++)
            {
                for(let i = 0; i < slider_array.length; i++)
                {
                   if (slider_array[i] === asia[j])
                   {
                        slider_array.splice(i, 1);
                   }
                }
            }
        }
        else    // include
        {
            for(j = 0; j < asia.length; j++)
            {
                if (slider_array.includes(asia[j]) == false)
                {
                    // add these frames
                    slider_array.push(asia[j])
                }
            }
        }
    }
    else if (btn == toggle_oceania) {
        oceania_btn = (oceania_btn == 0) ? 1 : 0

        // exclude
        if (btn.frame == 0) {
            for(let j = 0; j < oceania.length; j++)
            {
                for(let i = 0; i < slider_array.length; i++)
                {
                   if (slider_array[i] === oceania[j])
                   {
                    slider_array.splice(i, 1);
                   }
                }
            }
        }
        else    // include
        {
            for(let j = 0; j < oceania.length; j++)
            {
                if (slider_array.includes(oceania[j]) == false)
                {
                    // add these frames
                    slider_array.push(oceania[j])
                }
            }
        }
    }

    // IMPORTANT switch button's frame
    btn.frame = (btn.frame == 0) ? 1 : 0

    if (capitalsUsed <= slider_array.length) {
        min = capitalsUsed;
        frames.length = 0;
        
        shuffle(slider_array);
        for (let f = 0; f < min; f++){
            frames.push(slider_array[f]);
        }

        shortOfFlags.visible = false;
        button_back_small.alpha = 1;
        text_back.alpha = 1;
    }
    else {
        shortOfFlags.visible = true;
        button_back_small.alpha = 0.3;
        text_back.alpha = 0.3;
    }
}

function go_back() {
    // go to menu
    if (button_back_small.alpha === 1)
    {
        if (frames.length >= 5) {
            game.state.start("menu");
        }
    }
}
