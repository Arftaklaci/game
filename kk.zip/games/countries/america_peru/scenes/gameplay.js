"use strict"
var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        });
    }
    
    create() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;
        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;
       camera.zoom = .8;
       camera.scrollX = -55;
       
        // min max zoom
        this.minZoom = .7;
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.5;
        }
        else {
            this.maxZoom = 1.8;
        }
        // display countries in this scene
        this.displayMap(this);
        // get countries (sprites) array from the container
        this.countriesArray = this.mapContainer.getAll();
        // for each subject (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {
            /*
            this.countriesArray[i].setInteractive()
            this.input.setDraggable(this.countriesArray[i]);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {
                gameObject.x = dragX;
                gameObject.y = dragY;
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });
            */
            
            let subject = this.countriesArray[i];
            // make countries sprites interactive
            subject.setInteractive({ 
                useHandCursor: true,             
                pixelPerfect: true,
                alphaTolerance: 255
             });
             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over subject
                subject.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                        if (subject.isSprite) {
                            subject.setFrame(1);
                        }
                        else {
                            subject.setTintFill(0xFFFFFF);
                        }
                    }
                },this);
                subject.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        if (subject.isSprite) {
                            subject.setFrame(0);
                        }
                        else {
                            subject.clearTint();
                        }
                    }
                },this);
            }
            subject.on('pointerdown', () => {
                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });
            subject.on('pointerup', () => {
                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);
                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    subject.xPos = camera.x;
                    subject.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false) {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === subject.name) {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this subject
                            subject.disableInteractive();
                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }
                            // create the subject label
                            this.showLabels(subject);
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // else don't tap, drag the map
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();
        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false) {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();
                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip, ui.buttonSound],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                let dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {
                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        let drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }
                }).on('pinch', dragScale => {
                    let scaleFactor = dragScale.scaleFactor;
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                }, this);
                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }
        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2 - 55, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 50, align: "center", color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2 - 55, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 50, align: "center", color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });
        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                camera.zoom *= 0.9;
            }
        }
        // limit zoom
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.mapContainer.setSize(width, height);
        this.mapContainer.x = 0;
        this.mapContainer.y = 0;

        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2-55, height/2);
        }
    }

    getQuestion() {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;
        this.questionsArray.shift();

        // tween
        this.tweens.add({
           targets: [ui.questionText],
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;
        // play sound
        this.gameOverSound.play();
        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        ui.buttonSound.destroy();
        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {
        // tween camera
        if (camera.zoom > this.minZoom) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: this.minZoom,
                x: 0, 
                y: 0,
                duration: 1500,
                onComplete: () => {
                    
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }
        this.tweens.add({
            targets: [camera],
            scrollX: -55,
            scrollY: 0,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showLabels(subject) {
        // create white rectangle
        subject.rect = this.add.sprite(subject.x, subject.y, "rectangle");
        // subject name
        subject.txt = this.add.text(subject.x, subject.y, subject.name, { fontFamily: "bold", fontSize: 28, align: "center", color: '#000000' });
        subject.txt.setOrigin(.5,.5);
        
        // position text
        if (subject.labelX) {
            subject.txt.x = subject.labelX;
            subject.txt.y = subject.labelY;
            subject.rect.x = subject.labelX;
            subject.rect.y = subject.labelY;
        }
        subject.rect.displayWidth = subject.txt.width + 4;
        subject.rect.displayHeight = subject.txt.height + 2;
    }

    displayMap(aScene) {
        aScene.map = aScene.add.image(width/2, height/2, "map");
        aScene.map.alpha = .4;

        aScene.amazonas = aScene.add.sprite(width/2 - 290.1, height/2 - 264.3, "texture", "amazonas.png");
        aScene.loreto = aScene.add.sprite(width/2 + 29.7, height/2 - 316.3, "texture", "loreto.png");
        aScene.ancash = aScene.add.sprite(width/2 - 267.5, height/2 + 76.3, "texture", "ancash.png");
        aScene.apurimac = aScene.add.sprite(width/2 + 96.9, height/2 + 435.2, "texture", "apurimac.png");
        aScene.arequipa = aScene.add.sprite(width/2 + 95.5, height/2 + 589.5, "texture", "arequipa.png");
        aScene.ayacucho = aScene.add.sprite(width/2 + 18.5, height/2 + 425.3, "texture", "ayacucho.png");
        aScene.cajamarca = aScene.add.sprite(width/2 - 340.3, height/2 - 171.9, "texture", "cajamarca.png");
        aScene.callao = aScene.add.sprite(width/2 - 229.7, height/2 + 274, "texture", "callao.png");
        aScene.cuzco = aScene.add.sprite(width/2 + 158.4, height/2 + 380.5, "texture", "cuzco.png");
        aScene.huancavelica = aScene.add.sprite(width/2 - 61.6, height/2 + 359.6, "texture", "huancavelica.png");
        aScene.huanuco = aScene.add.sprite(width/2 - 127.5, height/2 + 77.6, "texture", "huanuco.png");
        aScene.ica = aScene.add.sprite(width/2 - 100.9, height/2 + 450.5, "texture", "ica.png");
        aScene.junin = aScene.add.sprite(width/2 - 56, height/2 + 254.1, "texture", "junin.png");
        aScene.laLibertad = aScene.add.sprite(width/2 - 312.8, height/2 - 33.2, "texture", "laLibertad.png");
        aScene.limaProvince = aScene.add.sprite(width/2 - 211.5, height/2 + 278, "texture", "limaProvince.png");
        aScene.limaRegion = aScene.add.sprite(width/2 - 187.8, height/2 + 264, "texture", "limaRegion.png");
        aScene.madreDeDios = aScene.add.sprite(width/2 + 283.2, height/2 + 256.8, "texture", "madreDeDios.png");
        aScene.puno = aScene.add.sprite(width/2 + 322.4, height/2 + 527.6, "texture", "puno.png");
        aScene.lambayeque = aScene.add.sprite(width/2 - 440.2, height/2 - 158, "texture", "lambayeque.png");
        aScene.moquegua = aScene.add.sprite(width/2 + 259.4, height/2 + 659.3, "texture", "moquegua.png");
        aScene.pasco = aScene.add.sprite(width/2 - 95.1, height/2 + 153.3, "texture", "pasco.png");
        aScene.piura = aScene.add.sprite(width/2 - 473.8, height/2 - 244.9, "texture", "piura.png");
        aScene.sanMartin = aScene.add.sprite(width/2 - 183.8, height/2 - 104.8, "texture", "sanMartin.png");
        aScene.tacna = aScene.add.sprite(width/2 + 289, height/2 + 715.6, "texture", "tacna.png");
        aScene.tumbes = aScene.add.sprite(width/2 - 497.6, height/2 - 355.6, "texture", "tumbes.png");
        aScene.ucayali = aScene.add.sprite(width/2 + 77.2, height/2 + 76, "texture", "ucayali.png");

        // labels
        //aScene.lambayeque.labelX = aScene.lambayeque.x - 45;
        //aScene.lambayeque.labelY = aScene.lambayeque.y + 20;
        aScene.cajamarca.labelX = aScene.cajamarca.x - 5;
        aScene.cajamarca.labelY = aScene.cajamarca.y + 50;
        aScene.amazonas.labelX = aScene.amazonas.x - 10;
        aScene.amazonas.labelY = aScene.amazonas.y - 40;
        aScene.sanMartin.labelX = aScene.sanMartin.x + 20;
        aScene.sanMartin.labelY = aScene.sanMartin.y - 45;
        aScene.loreto.labelX = aScene.loreto.x - 60;
        aScene.loreto.labelY = aScene.loreto.y;
        aScene.huanuco.labelX = aScene.huanuco.x - 10;
        aScene.huanuco.labelY = aScene.huanuco.y + 17;
        aScene.ucayali.labelX = aScene.ucayali.x;
        aScene.ucayali.labelY = aScene.ucayali.y + 35;
        aScene.puno.labelX = aScene.puno.x - 5;
        aScene.puno.labelY = aScene.puno.y - 35;
        aScene.tacna.labelX = aScene.tacna.x + 5;
        aScene.tacna.labelY = aScene.tacna.y + 5;
        aScene.arequipa.labelX = aScene.arequipa.x + 35;
        aScene.arequipa.labelY = aScene.arequipa.y - 10;
        aScene.junin.labelX = aScene.junin.x;
        aScene.junin.labelY = aScene.junin.y - 10;
        aScene.ayacucho.labelX = aScene.ayacucho.x - 25;
        aScene.ayacucho.labelY = aScene.ayacucho.y + 40;
        aScene.ica.labelX = aScene.ica.x - 15;
        aScene.ica.labelY = aScene.ica.y + 5;
        aScene.apurimac.labelX = aScene.apurimac.x + 10;
        aScene.apurimac.labelY = aScene.apurimac.y;
        aScene.limaProvince.labelX = aScene.limaProvince.x;
        aScene.limaProvince.labelY = aScene.limaProvince.y + 40;
        aScene.limaRegion.labelX = aScene.limaRegion.x - 70;
        aScene.limaRegion.labelY = aScene.limaRegion.y - 70;
        aScene.callao.labelX = aScene.callao.x - 40;
        aScene.callao.labelY = aScene.callao.y - 10;
        aScene.pasco.labelX = aScene.pasco.x + 25;
        aScene.pasco.labelY = aScene.pasco.y - 5;
        aScene.madreDeDios.labelX = aScene.madreDeDios.x;
        aScene.madreDeDios.labelY = aScene.madreDeDios.y + 15;
        // names
        aScene.amazonas.name = subjects.amazonas;
        aScene.loreto.name = subjects.loreto;
        aScene.ancash.name = subjects.ancash;
        aScene.apurimac.name = subjects.apurimac;
        aScene.arequipa.name = subjects.arequipa;
        aScene.ayacucho.name = subjects.ayacucho;
        aScene.cajamarca.name = subjects.cajamarca;
        aScene.callao.name = subjects.callao;
        aScene.cuzco.name = subjects.cuzco;
        aScene.huancavelica.name = subjects.huancavelica;
        aScene.huanuco.name = subjects.huanuco;
        aScene.ica.name = subjects.ica;
        aScene.junin.name = subjects.junin;
        aScene.laLibertad.name = subjects.laLibertad;
        aScene.lambayeque.name = subjects.lambayeque;
        aScene.limaProvince.name = subjects.limaProvince;
        aScene.limaRegion.name = subjects.limaRegion;
        aScene.loreto.name = subjects.loreto;
        aScene.madreDeDios.name = subjects.madreDeDios;
        aScene.moquegua.name = subjects.moquegua;
        aScene.pasco.name = subjects.pasco;
        aScene.piura.name = subjects.piura;
        aScene.puno.name = subjects.puno;
        aScene.sanMartin.name = subjects.sanMartin;
        aScene.tacna.name = subjects.tacna;
        aScene.tumbes.name = subjects.tumbes;
        aScene.ucayali.name = subjects.ucayali;
  
        // create container
        aScene.mapContainer = aScene.add.container(0, 0, [aScene.amazonas, aScene.loreto, aScene.ancash, aScene.limaRegion,aScene.apurimac, aScene.arequipa, aScene.ayacucho, aScene.cajamarca,  aScene.cuzco, aScene.huancavelica, aScene.huanuco, aScene.ica, aScene.junin, aScene.laLibertad, aScene.lambayeque, aScene.limaProvince, aScene.loreto, aScene.madreDeDios, aScene.moquegua, aScene.pasco, aScene.piura, aScene.puno, aScene.callao, aScene.sanMartin, aScene.tacna, aScene.tumbes, aScene.ucayali]);

        // extra lake
        aScene.extraLake = aScene.add.sprite(width/2 + 368.7, height/2 + 588.3, "texture", "extraLake.png");

        aScene.mapContainer.setSize(width, height);
        aScene.mapContainer.x = 0;
        aScene.mapContainer.y = 0;
     }
}