"use strict"

var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        })
    }

    create() {

        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;

        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;
       camera.zoom = 0.38;

        // min max zoom
        this.minZoom = 0.38;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.7;
        }
        else {
            this.maxZoom = 2;
        }

        // display countries in this scene
        this.displayJapan(this);
       
        // get countries (sprites) array from the container
        this.countriesArray = this.japanContainer.getAll();
        // for each country (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {

            let country = this.countriesArray[i];

            /* enable drag to position countries
            country.setInteractive()
            this.input.setDraggable(country);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {

                gameObject.x = dragX;
                gameObject.y = dragY;
        
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });
            */
            
            // make countries sprites interactive
            if (country.name === countriesLabels.okinawa) {
                country.setInteractive({           
                useHandCursor: true,             
                pixelPerfect: false,
                });
            }
            else {
                country.setInteractive({ 
                    useHandCursor: true,             
                    pixelPerfect: true,
                    alphaTolerance: 255
                    });
            }

             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over country
                country.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                        if (country.isSpritesheet === true) {
                            country.setFrame(1);
                        }
                        else {
                            country.setTintFill(0xFFFFFF);
                        }
                    }
                },this);

                country.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        if (country.isSpritesheet === true) {
                            country.setFrame(0);
                        }
                        else {
                            country.clearTint();
                        }
                    }
                },this);
            }

            country.on('pointerdown', () => {

                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });

            country.on('pointerup', () => {

                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);

                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    country.xPos = camera.x;
                    country.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false)
                    {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === country.name || (ui.questionText.text === labels.mariElRepublic2 && country.name === countriesLabels.mariElRepublic) || (ui.questionText.text === labels.northOssetiaAlaniaRepublic2 && country.name === countriesLabels.northOssetiaAlaniaRepublic) || (ui.questionText.text === labels.chukotkaAutonomousOkrug2 && country.name === countriesLabels.chukotkaAutonomousOkrug) || (ui.questionText.text === labels.jewishAutonomousOblast2 && country.name === countriesLabels.jewishAutonomousOblast) || (ui.questionText.text === labels.nenetsAutonomousOkrug2 && country.name === countriesLabels.nenetsAutonomousOkrug) || (ui.questionText.text === labels.khantyMansiAutonomousOkrug2 && country.name === countriesLabels.khantyMansiAutonomousOkrug) || (ui.questionText.text === labels.yamaloNenetsAutonomousOkrug2 && country.name === countriesLabels.yamaloNenetsAutonomousOkrug) || (ui.questionText.text === labels.crimeaRepublicDisputedArea2 && country.name === countriesLabels.crimeaRepublicDisputedArea) || (ui.questionText.text === labels.sevastopolDisputedArea2 && country.name === countriesLabels.sevastopolDisputedArea))
                        {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this country
                            country.disableInteractive();

                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }

                            // create the country label
                            this.showLabels(country);
    
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
    
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // drag
                else {
                    // console.log("don't tap, drag the map");
                }
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();

        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false)
            {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();

                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                var dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {

                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        var drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }

                }).on('pinch', dragScale => {
                    var scaleFactor = dragScale.scaleFactor;
                    
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                    
                }, this);

                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }

        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 65, color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 65, color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                
                camera.zoom *= 0.9;
            }
        }
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.japanContainer.setSize(width, height);
        this.japanContainer.x = 0;
        this.japanContainer.y = 0; 
        this.line.setPosition(this.okinawa.x - 145, this.okinawa.y - 70);
        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2, height/2);
        }
    }

    getQuestion()
    {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;

        // use short labels for these regions
        if (ui.questionText.text === countriesLabels.chukotkaAutonomousOkrug) {
            ui.questionText.text = labels.chukotkaAutonomousOkrug2;
        }
        else if (ui.questionText.text === countriesLabels.jewishAutonomousOblast) {
            ui.questionText.text = labels.jewishAutonomousOblast2;
        }
        else if (ui.questionText.text === countriesLabels.nenetsAutonomousOkrug) {
            ui.questionText.text = labels.nenetsAutonomousOkrug2;
        }
        else if (ui.questionText.text === countriesLabels.khantyMansiAutonomousOkrug) {
            ui.questionText.text = labels.khantyMansiAutonomousOkrug2;
        }
        else if (ui.questionText.text === countriesLabels.yamaloNenetsAutonomousOkrug) {
            ui.questionText.text = labels.yamaloNenetsAutonomousOkrug2;
        }
        else if (ui.questionText.text === countriesLabels.crimeaRepublicDisputedArea) {
            ui.questionText.text = labels.crimeaRepublicDisputedArea2;
        }
        else if (ui.questionText.text === countriesLabels.sevastopolDisputedArea) {
            ui.questionText.text = labels.sevastopolDisputedArea2;
        }

        // small font size for these labels
        if (ui.questionText.text === countriesLabels.kabardinoBalkarRepublic || ui.questionText.text === countriesLabels.karachayCherkessRepublic || ui.questionText.text === countriesLabels.northOssetiaAlaniaRepublic) {
            ui.questionText.setFontSize(25);
        }
        else {
            ui.questionText.setFontSize(33);
        }
        
        // tween
        this.tweens.add({
           targets: [ui.questionText],
           //scaleX: '-=.2',
           //angle: 10,
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });

        // remove the previous question
        this.questionsArray.shift();
    }

    gameOver() {
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;

        // play sound
        this.gameOverSound.play();

        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();

        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {

        // tween camera
        if (camera.zoom > .38) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: .38,
                x: 0, 
                y: 0,
                duration: 1500,
                onComplete: () => {
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }

        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: 0,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showLabels(country) {
            // use another label
            if (country.name === countriesLabels.anotherLbl) {
                country.name = labels.anotherLbl2;
            }

            // write country name
            country.txt = this.add.text(country.x, country.y, country.name, { fontFamily: "bold", fontSize: 18, align: "center", color: '#000000' });
            country.txt.setOrigin(.5,.5);
            this.japanContainer.add(country.txt);

            // position text
            if (country.labelX) {
                country.txt.x = country.labelX;
                country.txt.y = country.labelY;
            }
            
            // create white rectangles
            country.rect = this.add.sprite(country.txt.x, country.txt.y, "ui", "rectangle.jpg");
            country.rect.displayWidth = country.txt.width + 1;
            country.rect.displayHeight = country.txt.height;
            this.japanContainer.add(country.rect);
            
            // bring to top text field
            this.japanContainer.bringToTop(country.txt);
    }
    
    displayJapan(aScene) {
        // perfectures
        aScene.niigata = aScene.add.image(width/2, height/2 + 31.5, "atlas", "niigata.png");
        aScene.fukushima = aScene.add.image(width/2 + 145, height/2 + 66, "atlas", "fukushima.png");
        aScene.yamagata = aScene.add.image(width/2 + 144, height/2 - 72, "atlas", "yamagata.png");
        aScene.miyagi = aScene.add.image(width/2 + 241, height/2 - 65.5, "atlas", "miyagi.png");
        aScene.akita = aScene.add.image(width/2 + 172.5, height/2 - 237, "atlas", "akita.png");
        aScene.iwate = aScene.add.image(width/2 + 283.5, height/2 - 224.5, "atlas", "iwate.png");
        aScene.aomori = aScene.add.image(width/2 + 219, height/2 - 392.5, "atlas", "aomori.png");
        aScene.hokkaido = aScene.add.image(width/2 + 415, height/2 - 728, "atlas", "hokkaido.png");
        aScene.okinawa = aScene.add.image(width/2 + 686, height/2 + 535, "okinawa");

        aScene.ishikawa = aScene.add.image(width/2 - 214.5, height/2 + 142, "atlas", "ishikawa.png");
        aScene.toyama = aScene.add.image(width/2 - 163, height/2 + 164, "atlas","toyama.png");
        aScene.nagano = aScene.add.image(width/2 - 80, height/2 + 232, "atlas","nagano.png");
        aScene.gunma = aScene.add.image(width/2 + 29, height/2 + 179, "atlas","gunma.png");
        aScene.tochigi = aScene.add.image(width/2 + 114, height/2 + 159, "atlas","tochigi.png");
        aScene.ibaraki = aScene.add.image(width/2 + 166, height/2 + 203.5, "atlas","ibaraki.png");
        aScene.chiba = aScene.add.image(width/2 + 168.5, height/2 + 312, "atlas","chiba.png");
        aScene.tokyo = aScene.add.image(width/2 + 75, height/2 + 287, "atlas","tokyo.png");
        aScene.kanagawa = aScene.add.image(width/2 + 64, height/2 + 325.5, "atlas","kanagawa.png");
        aScene.saitama = aScene.add.image(width/2 + 59.5, height/2 + 245, "atlas","saitama.png");
        aScene.yamanashi = aScene.add.image(width/2 - 11.5, height/2 + 303, "atlas","yamanashi.png");
        aScene.shizuoka = aScene.add.image(width/2 - 10, height/2 + 503, "atlas","shizuoka.png");
        aScene.aichi = aScene.add.image(width/2 - 165, height/2 + 377.5, "atlas","aichi.png");
        aScene.gifu = aScene.add.image(width/2 - 197, height/2 + 272.5, "atlas","gifu.png");
        aScene.fukui = aScene.add.image(width/2 - 287, height/2 + 270, "atlas","fukui.png");
        aScene.shiga = aScene.add.image(width/2 - 290, height/2 + 345, "atlas","shiga.png");
        aScene.mie = aScene.add.image(width/2 - 259.5, height/2 + 444.5, "atlas","mie.png");
        aScene.kyoto = aScene.add.image(width/2 - 360, height/2 + 345, "atlas", "kyoto.png");
        aScene.hyogo = aScene.add.image(width/2 - 424, height/2 + 385.5, "atlas", "hyogo.png");
        aScene.osaka = aScene.add.image(width/2 - 364, height/2 + 421.5, "atlas", "osaka.png");
        aScene.nara = aScene.add.image(width/2 - 313.3, height/2 + 465.5, "atlas", "nara.png");
        aScene.wakayama = aScene.add.image(width/2 - 351, height/2 + 520, "atlas","wakayama.png");
        aScene.tottori = aScene.add.image(width/2 - 537, height/2 + 332.5, "atlas","tottori.png");
        aScene.okayama = aScene.add.image(width/2 - 535.5, height/2 + 390.5, "atlas","okayama.png");
        aScene.shimane = aScene.add.image(width/2 - 682, height/2 + 383, "atlas","shimane.png");
        aScene.hiroshima = aScene.add.image(width/2 - 655.5, height/2 + 431, "atlas","hiroshima.png");
        aScene.yamaguchi = aScene.add.image(width/2 - 772.5, height/2 + 474.5, "atlas","yamaguchi.png");
        aScene.kagawa = aScene.add.image(width/2 - 522.5, height/2 + 470.5, "atlas","kagawa.png");
        aScene.tokushima = aScene.add.image(width/2 - 500, height/2 + 521, "atlas","tokushima.png");
        aScene.ehime = aScene.add.image(width/2 - 647, height/2 + 562, "atlas","ehime.png");
        aScene.kochi = aScene.add.image(width/2 - 581.5, height/2 + 600, "atlas","kochi.png");
        aScene.fukuoka = aScene.add.image(width/2 - 887, height/2 + 577, "atlas","fukuoka.png");
        aScene.saga = aScene.add.image(width/2 - 938.5, height/2 + 606, "atlas","saga.png");
        aScene.oita = aScene.add.image(width/2 - 794.5, height/2 + 612.5, "atlas","oita.png");
        aScene.nagasaki = aScene.add.image(width/2 - 1010, height/2 + 555.5, "atlas","nagasaki.png");
        aScene.kumamoto = aScene.add.image(width/2 - 882.5, height/2 + 686.5, "atlas","kumamoto.png");
        aScene.miyazaki = aScene.add.image(width/2 - 813.5, height/2 + 757.5, "atlas","miyazaki.png");
        aScene.kagoshima = aScene.add.image(width/2 - 905.5, height/2 + 871, "atlas","kagoshima.png");

        // repositions some labels
        aScene.fukuoka.labelX = aScene.fukuoka.x;
        aScene.fukuoka.labelY = aScene.fukuoka.y - 20;
        aScene.yamaguchi.labelX = aScene.yamaguchi.x - 15;
        aScene.yamaguchi.labelY = aScene.yamaguchi.y + 5;
        aScene.shimane.labelX = aScene.shimane.x - 10;
        aScene.shimane.labelY = aScene.shimane.y - 10;
        aScene.tottori.labelX = aScene.tottori.x;
        aScene.tottori.labelY = aScene.tottori.y - 15;
        aScene.ehime.labelX = aScene.ehime.x - 10;
        aScene.ehime.labelY = aScene.ehime.y - 5;
        aScene.tokushima.labelX = aScene.tokushima.x + 5;
        aScene.tokushima.labelY = aScene.tokushima.y - 5;
        aScene.wakayama.labelX = aScene.wakayama.x - 20;
        aScene.wakayama.labelY = aScene.wakayama.y;
        aScene.mie.labelX = aScene.mie.x + 15;
        aScene.mie.labelY = aScene.mie.y;
        aScene.gifu.labelX = aScene.gifu.x + 10;
        aScene.gifu.labelY = aScene.gifu.y + 5;
        aScene.ishikawa.labelX = aScene.ishikawa.x + 10;
        aScene.ishikawa.labelY = aScene.ishikawa.y - 45;
        aScene.shizuoka.labelX = aScene.shizuoka.x - 15;
        aScene.shizuoka.labelY = aScene.shizuoka.y - 105;
        aScene.yamanashi.labelX = aScene.yamanashi.x - 10;
        aScene.yamanashi.labelY = aScene.yamanashi.y - 5;
        aScene.ibaraki.labelX = aScene.ibaraki.x + 30;
        aScene.ibaraki.labelY = aScene.ibaraki.y;
        aScene.okinawa.labelX = aScene.okinawa.x + 100;
        aScene.okinawa.labelY = aScene.okinawa.y + 50;
        aScene.nagasaki.labelX = aScene.nagasaki.x;
        aScene.nagasaki.labelY = aScene.nagasaki.y + 85;

        // spritesheet
        aScene.okinawa.isSpritesheet = true;
        // names
        aScene.niigata.name = countriesLabels.niigata;
        aScene.fukushima.name = countriesLabels.fukushima;
        aScene.yamagata.name = countriesLabels.yamagata;
        aScene.miyagi.name = countriesLabels.miyagi;
        aScene.akita.name = countriesLabels.akita;
        aScene.iwate.name = countriesLabels.iwate;
        aScene.iwate.name = countriesLabels.iwate;
        aScene.aomori.name = countriesLabels.aomori;
        aScene.hokkaido.name = countriesLabels.hokkaido;
        aScene.okinawa.name = countriesLabels.okinawa;
        aScene.ishikawa.name = countriesLabels.ishikawa;
        aScene.toyama.name = countriesLabels.toyama;
        aScene.nagano.name = countriesLabels.nagano;
        aScene.gunma.name = countriesLabels.gunma;
        aScene.tochigi.name = countriesLabels.tochigi;
        aScene.ibaraki.name = countriesLabels.ibaraki;
        aScene.chiba.name = countriesLabels.chiba;
        aScene.tokyo.name = countriesLabels.tokyo;
        aScene.kanagawa.name = countriesLabels.kanagawa;
        aScene.saitama.name = countriesLabels.saitama;
        aScene.yamanashi.name = countriesLabels.yamanashi;
        aScene.shizuoka.name = countriesLabels.shizuoka;
        aScene.gifu.name = countriesLabels.gifu;
        aScene.fukui.name = countriesLabels.fukui;
        aScene.aichi.name = countriesLabels.aichi;
        aScene.shiga.name = countriesLabels.shiga;
        aScene.mie.name = countriesLabels.mie;
        aScene.kyoto.name = countriesLabels.kyoto;
        aScene.hyogo.name = countriesLabels.hyogo;
        aScene.osaka.name = countriesLabels.osaka;
        aScene.nara.name = countriesLabels.nara;
        aScene.wakayama.name = countriesLabels.wakayama;
        aScene.tottori.name = countriesLabels.tottori;
        aScene.okayama.name = countriesLabels.okayama;
        aScene.shimane.name = countriesLabels.shimane;
        aScene.hiroshima.name = countriesLabels.hiroshima;
        aScene.yamaguchi.name = countriesLabels.yamaguchi;
        aScene.kagawa.name = countriesLabels.kagawa;
        aScene.tokushima.name = countriesLabels.tokushima;
        aScene.ehime.name = countriesLabels.ehime;
        aScene.kochi.name = countriesLabels.kochi;
        aScene.kagoshima.name = countriesLabels.kagoshima;
        aScene.fukuoka.name = countriesLabels.fukuoka;
        aScene.oita.name = countriesLabels.oita;
        aScene.saga.name = countriesLabels.saga;
        aScene.nagasaki.name = countriesLabels.nagasaki;
        aScene.kumamoto.name = countriesLabels.kumamoto;
        aScene.miyazaki.name = countriesLabels.miyazaki;
        aScene.kagoshima.name = countriesLabels.kagoshima;

        // create container and put countries into it
        aScene.japanContainer = aScene.add.container(0, 0, [ aScene.okinawa, aScene.niigata, aScene.fukushima, aScene.yamagata, aScene.miyagi, aScene.akita, aScene.iwate, aScene.aomori, aScene.hokkaido, aScene.ishikawa, aScene.toyama, aScene.nagano, aScene.gunma, aScene.tochigi, aScene.ibaraki, aScene.chiba, aScene.tokyo, aScene.kanagawa, aScene.saitama, aScene.yamanashi, aScene.shizuoka, aScene.gifu, aScene.fukui, aScene.aichi, aScene.shiga, aScene.mie, aScene.kyoto, aScene.hyogo, aScene.osaka, aScene.nara, aScene.wakayama, aScene.tottori, aScene.okayama, aScene.shimane, aScene.hiroshima, aScene.yamaguchi, aScene.kagawa, aScene.tokushima, aScene.ehime, aScene.kochi, aScene.kagoshima, aScene.fukuoka, aScene.oita, aScene.nagasaki, aScene.saga, aScene.kumamoto, aScene.miyazaki, aScene.kagoshima ]);
        
        aScene.japanContainer.setSize(width, height);
        aScene.japanContainer.x = 0;
        aScene.japanContainer.y = 0;     

        aScene.line = aScene.add.image(aScene.okinawa.x - 145, aScene.okinawa.y - 70, "line")
     }
}
