"use strict"
var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        });
    }
    
    create() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;
        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;

        // min max zoom
        if (this.sys.game.device.os.desktop) {
            this.minZoom = .6;  
            this.maxZoom = 2.5;
            camera.zoom = .7;
        }
        else {
            this.minZoom = .6;  
            this.maxZoom = 1.8;
            camera.zoom = .7;
        }

        // display countries in this scene
        this.displayMap(this);
        // get countries (sprites) array from the container
        this.countriesArray = this.mapContainer.getAll();
        // for each subject (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {
            /*
            this.countriesArray[i].setInteractive()
            this.input.setDraggable(this.countriesArray[i]);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {
                gameObject.x = dragX;
                gameObject.y = dragY;
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });
            */
            
            let subject = this.countriesArray[i];

            //interactive
             if (subject.name === subjects.cityOfLondon) {
                subject.setInteractive({ 
                    useHandCursor: true,             
                 });
             }
             else {
                subject.setInteractive({ 
                    useHandCursor: true,             
                    pixelPerfect: true,
                    alphaTolerance: 255
                 });
             }

             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over subject
                subject.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                       subject.setTintFill(0xFFFFFF);
                    }
                },this);
                subject.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        subject.clearTint();
                    }
                },this);
            }
            subject.on('pointerdown', () => {
                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });
            subject.on('pointerup', () => {
                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);
                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    subject.xPos = camera.x;
                    subject.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false) {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === subject.name) {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this subject
                            subject.disableInteractive();
                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }
                            // create the subject label
                            this.showLabels(subject);
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // else don't tap, drag the map
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();
        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false) {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();
                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip, ui.buttonSound],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                let dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {
                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        let drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }
                }).on('pinch', dragScale => {
                    let scaleFactor = dragScale.scaleFactor;
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                }, this);
                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }
        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 50, align: "center", color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 50, align: "center", color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });
        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                camera.zoom *= 0.9;
            }
        }
        // limit zoom
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.mapContainer.setSize(width, height);
        this.mapContainer.x = 0;
        this.mapContainer.y = 0;

        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2, height/2);
        }
    }

    getQuestion() {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;
        this.questionsArray.shift();

        if (ui.questionText.text === subjects.santoDomingoDeLosTsachilas) {
            ui.questionText.setFontSize(26);
        }
        else {
            ui.questionText.setFontSize(32);
        }

        // tween
        this.tweens.add({
           targets: [ui.questionText],
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;
        // play sound
        this.gameOverSound.play();
        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        ui.buttonSound.destroy();
        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {
        // tween camera
        if (camera.zoom > this.minZoom) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: this.minZoom,
                x: 0, 
                y: 0,
                duration: 1500,
                onComplete: () => {
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }
        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: 0,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showLabels(subject) {
        // rectangle
        subject.rect = this.add.sprite(subject.x, subject.y, "rectangle");
        // subject name
        subject.txt = this.add.text(subject.x, subject.y, subject.name, { fontFamily: "bold", fontSize: 27, align: "center", color: '#000000' });
        subject.txt.setOrigin(.5,.5);
        
        // position text
        if (subject.labelX) {
            subject.txt.x = subject.labelX;
            subject.txt.y = subject.labelY;
            subject.rect.x = subject.labelX;
            subject.rect.y = subject.labelY;
        }
        subject.rect.displayWidth = subject.txt.width + 4;
        subject.rect.displayHeight = subject.txt.height + 2;

        if (subject.hasLine) {
            if (subject.name === subjects.santoDomingoDeLosTsachilas) {
                let line = this.add.image(subject.x, subject.y-25, "texture", "lineSantoDomingo.png").setOrigin(1,0.5);
                this.mapContainer.add(line);
            }
        }
    }

    displayMap(aScene) {
        //aScene.map = aScene.add.image(width/2, height/2, "map");
        //aScene.map.alpha = .3;
        
        aScene.azuay = aScene.add.sprite(width/2 + 63.8, height/2 + 240.6, "texture", "azuay.png");
        aScene.bolivar = aScene.add.sprite(width/2 + 61.1, height/2 + 53.2, "texture", "bolivar.png");
        aScene.canar = aScene.add.sprite(width/2 + 70.3, height/2 + 168.2, "texture", "canar.png");
        aScene.chimborazo = aScene.add.sprite(width/2 + 101.2, height/2 + 95.8, "texture", "chimborazo.png");
        aScene.cotopaxi = aScene.add.sprite(width/2 + 94.7, height/2 - 65.7, "texture", "cotopaxi.png");
        aScene.elOro = aScene.add.sprite(width/2 - 31.8, height/2 + 289.8, "texture", "elOro.png");
        aScene.galapagos = aScene.add.sprite(width/2 - 514.3, height/2 + 28.6, "texture", "galapagos.png");
        aScene.guayas = aScene.add.sprite(width/2 - 33.6, height/2 + 90.6, "texture", "guayas.png");
        aScene.carchi = aScene.add.sprite(width/2 + 198, height/2 - 268.6, "texture", "carchi.png");
        aScene.esmeraldas = aScene.add.sprite(width/2 + 41.7, height/2 - 264.9, "texture", "esmeraldas.png");
        aScene.imbabura = aScene.add.sprite(width/2 + 134.8, height/2 - 232.7, "texture", "imbabura.png");
        aScene.loja = aScene.add.sprite(width/2 - 29.5, height/2 + 363.5, "texture", "loja.png");
        aScene.losRios = aScene.add.sprite(width/2 + 13.2, height/2 + 8, "texture", "losRios.png");
        aScene.manabi = aScene.add.sprite(width/2 - 86.4, height/2 - 61.8, "texture", "manabi.png");
        aScene.moronaSantiago = aScene.add.sprite(width/2 + 234.1, height/2 + 163, "texture", "moronaSantiago.png");
        aScene.napo = aScene.add.sprite(width/2 + 243.2, height/2 - 87.8, "texture", "napo.png");
        aScene.orellana = aScene.add.sprite(width/2 + 415.2, height/2 - 62, "texture", "orellana.png");
        aScene.pastaza = aScene.add.sprite(width/2 + 355.6, height/2 + 71, "texture", "pastaza.png");
        aScene.pichincha = aScene.add.sprite(width/2 + 127.9, height/2 - 141.1, "texture", "pichincha.png");
        aScene.santaElena = aScene.add.sprite(width/2 - 134.7, height/2 + 109.7, "texture", "santaElena.png");
        aScene.santoDomingoDeLosTsachilas = aScene.add.sprite(width/2 + 51.6, height/2 - 130.8, "texture", "santoDomingoDeLosTsachilas.png");
        aScene.sucumbios = aScene.add.sprite(width/2 + 390.2, height/2 - 167, "texture", "sucumbios.png");
        aScene.tungurahua = aScene.add.sprite(width/2 + 139, height/2 - 2.5, "texture", "tungurahua.png");
        aScene.zamoraChinchipe = aScene.add.sprite(width/2 + 90.2, height/2 + 383.7, "texture", "zamoraChinchipe.png");

        // lines
        aScene.santoDomingoDeLosTsachilas.hasLine = true;
        aScene.galapagos.hasLine = true;

        aScene.lineGalapagos = aScene.add.image(aScene.galapagos.x+160, aScene.galapagos.y-45, "texture", "lineGalapagos.png").setOrigin(1,0);

        // position labels
        aScene.santoDomingoDeLosTsachilas.labelX = aScene.santoDomingoDeLosTsachilas.x - 295;
        aScene.santoDomingoDeLosTsachilas.labelY = aScene.santoDomingoDeLosTsachilas.y - 65;
        aScene.imbabura.labelX = aScene.imbabura.x + 25;
        aScene.imbabura.labelY = aScene.imbabura.y + 17;
        aScene.carchi.labelX = aScene.carchi.x + 20;
        aScene.carchi.labelY = aScene.carchi.y - 10;
        aScene.sucumbios.labelX = aScene.sucumbios.x + 40;
        aScene.sucumbios.labelY = aScene.sucumbios.y + 10;
        aScene.santaElena.labelX = aScene.santaElena.x - 30;
        aScene.santaElena.labelY = aScene.santaElena.y + 10;
        aScene.canar.labelX = aScene.canar.x + 10;
        aScene.canar.labelY = aScene.canar.y + 3;
        aScene.napo.labelX = aScene.napo.x - 30;
        aScene.napo.labelY = aScene.napo.y;
        aScene.guayas.labelX = aScene.guayas.x + 5;
        aScene.guayas.labelY = aScene.guayas.y + 45;
        aScene.zamoraChinchipe.labelX = aScene.zamoraChinchipe.x + 70;
        aScene.zamoraChinchipe.labelY = aScene.zamoraChinchipe.y - 15;
        aScene.moronaSantiago.labelX = aScene.moronaSantiago.x + 10;
        aScene.moronaSantiago.labelY = aScene.moronaSantiago.y + 15;
        aScene.azuay.labelX = aScene.azuay.x - 10;
        aScene.azuay.labelY = aScene.azuay.y - 5;
        aScene.loja.labelX = aScene.loja.x + 15;
        aScene.loja.labelY = aScene.loja.y + 10;
        aScene.elOro.labelX = aScene.elOro.x - 5;
        aScene.elOro.labelY = aScene.elOro.y + 5;
        aScene.losRios.labelX = aScene.losRios.x - 10;
        aScene.losRios.labelY = aScene.losRios.y + 10;
        aScene.cotopaxi.labelX = aScene.cotopaxi.x + 7;
        aScene.cotopaxi.labelY = aScene.cotopaxi.y + 12;
        aScene.pichincha.labelX = aScene.pichincha.x + 15;
        aScene.pichincha.labelY = aScene.pichincha.y - 25;
        // names
        aScene.azuay.name = subjects.azuay;
        aScene.bolivar.name = subjects.bolivar;
        aScene.canar.name = subjects.canar;
        aScene.carchi.name = subjects.carchi;
        aScene.chimborazo.name = subjects.chimborazo;
        aScene.cotopaxi.name = subjects.cotopaxi;
        aScene.elOro.name = subjects.elOro;
        aScene.esmeraldas.name = subjects.esmeraldas;
        aScene.galapagos.name = subjects.galapagos;
        aScene.guayas.name = subjects.guayas;
        aScene.imbabura.name = subjects.imbabura;
        aScene.loja.name = subjects.loja;
        aScene.losRios.name = subjects.losRios;
        aScene.manabi.name = subjects.manabi;
        aScene.moronaSantiago.name = subjects.moronaSantiago;
        aScene.napo.name = subjects.napo;
        aScene.orellana.name = subjects.orellana;
        aScene.pastaza.name = subjects.pastaza;
        aScene.pichincha.name = subjects.pichincha;
        aScene.santaElena.name = subjects.santaElena;
        aScene.santoDomingoDeLosTsachilas.name = subjects.santoDomingoDeLosTsachilas;
        aScene.sucumbios.name = subjects.sucumbios;
        aScene.tungurahua.name = subjects.tungurahua;
        aScene.zamoraChinchipe.name = subjects.zamoraChinchipe;

        // create container 
        aScene.mapContainer = aScene.add.container(0, 0, [aScene.azuay, aScene.bolivar, aScene.canar, aScene.carchi, aScene.chimborazo, aScene.cotopaxi, aScene.elOro, aScene.esmeraldas, aScene.galapagos, aScene.guayas, aScene.loja, aScene.imbabura, aScene.losRios, aScene.manabi, aScene.moronaSantiago, aScene.napo, aScene.orellana, aScene.pastaza, aScene.pichincha, aScene.santaElena, aScene.santoDomingoDeLosTsachilas, aScene.sucumbios, aScene.tungurahua, aScene.zamoraChinchipe]);

        aScene.mapContainer.setSize(width, height);
        aScene.mapContainer.x = 0;
        aScene.mapContainer.y = 0;
     }
}