/* var game = new Phaser.Game(500, 800, Phaser.Canvas, null, null, true); */
var game = new Phaser.Game(500, 800, Phaser.Canvas, "phaser", null, true);

game.global =
{
	orientated     : false,
    instructions   : true,
}

// edit below to change a language
collator = 'en'
website_url = "https://world-geography-games.com/world.html";
website_label = "World Geography Games"
title_label = "   Flags of\n the World"
title_oneline = "Flags of the World"
play_again_label = "Play again"
stop_label = "Stop"
score_label = "Score: "
next_label = "Next"
out_of_label = "out of"
play_label = "play"
options_label = "options"
short_label = "Short of flags, please change options"
back_label = "back"
sound_label = "SOUND"
number_of_flags_label = "NUMBER OF FLAGS"
flags_label = "FLAGS"
select_label = "select"
library_label = "library"

europe_label = "Europe"
north_america_label = "North America"
oceania_label = "Oceania"
asia_label = "Asia"
africa_label = "Africa"
south_america_label = "South America"

countries = ["Algeria", "Angola", "Benin", "Botswana", "Burkina Faso", "Burundi", "Cameroon", "Cape Verde", "Central African Republic", "Chad", "Comoros", "DR Congo", "Djibouti", "Egypt", "Equatorial Guinea", "Eritrea", "Eswatini", "Ethiopia", "Gabon", "Gambia", "Ghana", "Guinea", "Guinea-Bissau", "Ivory Coast", "Kenya", "Lesotho", "Liberia", "Libya", "Madagascar", "Malawi", "Mali", "Mauritania", "Mauritius", "Morocco", "Mozambique", "Namibia", "Niger", "Nigeria", "Republic of the Congo", "Rwanda", "São Tomé  and Príncipe", "Senegal", "Seychelles", "Sierra Leone", "Somalia", "South Africa", "South Sudan", "Sudan", "Tanzania", "Togo", "Tunisia", "Uganda", "Zambia", "Zimbabwe",
// 54 - 102
"Afghanistan", "Armenia", "Azerbaijan", "Bahrain", "Bangladesh", "Bhutan", "Brunei", "Cambodia", "China", "East Timor", "Georgia", "India", "Indonesia", "Iran", "Iraq", "Israel", "Japan", "Jordan", "Kazakhstan", "Kuwait", "Kyrgyzstan", "Laos", "Lebanon", "Malaysia", "Maldives", "Mongolia", "Myanmar", "Nepal", "North Korea", "Oman", "Pakistan", "State of Palestine", "Philippines", "Qatar", "Russia", "Saudi Arabia", "Singapore", "South Korea", "Sri Lanka", "Syria", "Taiwan", "Tajikistan", "Thailand", "Turkey", "Turkmenistan", "UAE", "Uzbekistan", "Vietnam", "Yemen",
// north america, south america
"Antigua and Barbuda", "Argentina", "Bahamas", "Barbados", "Belize", "Bolivia", "Brazil", "Canada", "Chile", "Colombia", "Costa Rica", "Cuba", "Dominica", "Dominican Republic", "Ecuador", "El Salvador", "Grenada", "Guatemala", "Guyana", "Haiti", "Honduras", "Jamaica", "Mexico", "Nicaragua", "Panama", "Paraguay", "Peru", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and Grenadines", "Suriname", "Trinidad and Tobago", "United States", "Uruguay", "Venezuela",
// starts at 138
"Albania", "Andorra", "Austria", "Belarus", "Belgium", "Bosnia and Herzegovina", "Bulgaria", "Croatia", "Cyprus", "Czech Republic", "Denmark", "Estonia", "Finland", "France", "Germany", "Greece", "Hungary", "Iceland", "Ireland", "Italy", "Kosovo", "Latvia", "Liechtenstein", "Lithuania", "Luxembourg", "Malta", "Moldova", "Monaco", "Montenegro", "Netherlands", "North Macedonia", "Norway", "Poland", "Portugal", "Romania", "San Marino", "Serbia", "Slovakia", "Slovenia", "Spain", "Sweden", "Switzerland", "Ukraine", "United Kingdom", "Vatican City",
// starts at 183
"Australia", "Fiji", "Kiribati", "Marshall Islands", "Micronesia", "Nauru", "New Zealand", "Palau", "Papua New Guinea", "Samoa", "Solomon Islands", "Tonga", "Tuvalu", "Vanuatu"]


// ** DO NOT EDIT BELOW!
// create new array, don't change the first one, order alphabetically
countries_alphabet = countries.slice().sort(Intl.Collator(collator).compare);

// how many flags selected
flags_used = 25;

// frames that will be used (frames represent flags)
frames = []
for (let f = 0; f < 197; f++){
    frames.push(f);
}

// always contains all frames, get random flags from this array
all_frames = frames.slice();

// shuffled frames
slider_array = frames.slice();

africa = []
for (let f = 0; f < 54; f++){
    africa.push(f);
}

asia = []
for (let f = 54; f < 103; f++){
    asia.push(f);
}

north_america = [103,105,106,107,110,113,114,115,116,118,119,120,122, 123,124,125,126,127,130,131,132,134,135];

south_america = [104,108,109,111,112,117,121,128,129,133,136,137];

europe = [];
for (let f = 138; f < 183; f++){
    europe.push(f);

}
// add russia to europe
europe.push(88);

oceania = []
for (let f = 183; f < 197; f++){
    oceania.push(f);
}

// toggle buttons used for regions, possible frame 0 or 1
europe_btn = 0;
africa_btn = 0;
north_america_btn = 0;
asia_btn = 0;
oceania_btn = 0;
south_america_btn = 0;

// toggle buttons used for countries, possible frame 0 or 1
toggle_button_frames = [];

for (var i = 0; i < frames.length; i++)
{
    // by default all buttons are on (frame 0)
    toggle_button_frames.push(0);
}

// sound toggle button
sound_frame = 0;

// selecting regions or countries in options (back button depends on this)
selecting_regions = true;

// countries have lookalikes
have_lookalikes =
// africa
[0,2,6,9,18,20,21,22,23,26,30,33,36,40,41,43,44,45,48,50,
// asia
55,57,62,65,66,67,68, 71,75,77,82,84,85,87,88,93,94,95,96,97,99,101,102,
// europe
138,139,140,142,144,145,148,152,153,154,155,156,157,159,160,161,162,164,165,166, 167,169,170,172,174,175,176,178,
// oceania
183,184, 187,189,192,195,196,
// south america
104,112,117,128,136,137,
// north america
113,118,120,122,123,125,126,130
];

lookalikes = [
// africa
[84],[22],[30,41,21],[139,164,55],[43],[40],[30,41,6],[2],[156,157],[77],[41,21,6],
[62],[65],[20],[30,21,6],[18],[187],[196],[130],[97],
// asia and europe
[161],[87],[101,33],[36],
[170,57,84],[95],[93,102],[85,99],[82],[26],[75],[0],[71,99],[57],[175,176],[68,102],[192],[67],[113],[50],[71,85],[62],[68,93],[166],[172,164],[159],[152],[154],[167],[169],[142],[136],[144],[178],[157,23],[156,125],[140],[122],[55],[167],[139,172],[170,163,173],[138],[162],[155,148],[165,66],[139,164,142],[175],[176,88],[88,175],[155],
// oceania
[189],[196],[44],[183],[94],[184],[45],
// south america
[120],[117,137],[137,112],[167,145],[153],[117,112],
// north america
[96],[126,123],[104],[160],[118,126],[157],[118,123],[48]
];

// game states
game.state.add('boot', bootState);
game.state.add("Loading", loading);
game.state.add("menu", menuState);
game.state.add("options", optionsState);
game.state.add("library", libraryState);
game.state.add("level1", state1);
game.state.start("boot");
