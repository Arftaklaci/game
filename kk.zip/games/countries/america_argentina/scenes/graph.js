"use strict"

class Graph extends Phaser.Scene {
    constructor() {
        super({
            key: "graph"
        })
    }

    create() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        // gameplay scene
        let gameplay = this.scene.get("gameplay");
        gameplay.displayMap(this);
        
        // show labels
        this.showLabels();
        // user interface
        this.ui = this.scene.get("graphUI");
        // launch user interface 
        this.scene.launch("graphUI");
        this.scene.moveAbove("graph", "graphUI");
       // camera
       camera = this.cameras.main;
       camera.zoom = .55;
       camera.scrollY = -50;
        // min max zoom
        this.minZoom = .55;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.6;
        }
        else {
            this.maxZoom = 1.9;
        }
        // enable drag and pinch to zoom
        var dragScale = this.plugins.get('rexpinchplugin').add(this);
        dragScale.on('drag1', dragScale => {
                var drag1Vector = dragScale.drag1Vector;
                camera.scrollX -= drag1Vector.x / camera.zoom;
                camera.scrollY -= drag1Vector.y / camera.zoom;
        }).on('pinch', dragScale => {
            var scaleFactor = dragScale.scaleFactor;
            
            // camera zoom
            camera.zoom *= scaleFactor;
        }, this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);

            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
            //this.upKeyDown = cursorKeys.up.isDown;
            //this.downKeyDown = cursorKeys.down.isDown;
        }

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on("resize", (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }
    
    update() {
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop) {
            if (this.cursorKeys.up.isDown) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown) {
                
                camera.zoom *= 0.9;
            }
        }
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    showLabels(subject) {
        
        this.subjectsArray = this.mapContainer.getAll();

        for (let i = 0; i < this.subjectsArray.length; i++) {
            let subject = this.subjectsArray[i];

            // create white rectangle
            subject.rect = this.add.image(subject.x, subject.y, "rectangle");
            // text
            subject.txt = this.add.text(subject.x, subject.y, subject.name, { fontFamily: "bold", fontSize: 25, align: "center", color: '#000000' });
            subject.txt.setOrigin(.5,.5);

            // special
            if (subject.name === subjects.santiagoDelEstero) {
                subject.txt.setText("Santiago\ndel Estero")
            }
            else if (subject.name === subjects.tierraDelFuego) {
                // disputed
                this.disputed1 = this.add.text(subject.x + 60, subject.y - 240, labels.disputed, { fontFamily: "bold", fontSize: 28, align: "center", color: '#FFFFFF' });
                subject.txt.setOrigin(.5,.5);

                this.disputed2 = this.add.text(subject.x - 10, subject.y + 20, labels.disputed, { fontFamily: "bold", fontSize: 28, align: "center", color: '#FFFFFF' });
                subject.txt.setOrigin(.5,.5);
            }
            
            // position text
            if (subject.labelX) {
                subject.txt.x = subject.labelX;
                subject.txt.y = subject.labelY;
                subject.rect.x = subject.labelX;
                subject.rect.y = subject.labelY;
            }
            // rectangle width/height
            subject.rect.displayWidth = subject.txt.width + 4;
            subject.rect.displayHeight = subject.txt.height;
        }
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        
        this.chile.setPosition(this.neuquen.x - 35, this.neuquen.y - 78.5);

        this.mapContainer.setSize(width, height);
        this.mapContainer.x = 0;
        this.mapContainer.y = 0;
    }
}
