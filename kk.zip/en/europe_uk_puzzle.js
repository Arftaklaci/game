var width, height;
var soundButtonFrame = 0;
var webUrl = "https://world-geography-games.com/europe_uk.html";

var config =
{
    type            : Phaser.Auto,
    width           : 1280,
    height          : 720,
    backgroundColor : 0x34c5eb,
    scale           : 
    {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH,
        parent: "thegame",
    },
    
    scene           : [Loading, Level1]
}

var labels =
{
    website           : "World Geography Games",
    title             : "UK & Ireland Puzzle",
    score             : "score: ",
    attempts          : "attempts: ",
    stop              : "stop",
    playAgain         : "play again",
    dragCountries     : "Drag the countries on the map",
    london            : "London",
    dublin            : "Dublin",
    belfast           : "Belfast",
    edinburgh         : "Edinburgh",
    cardiff           : "Cardiff",
}

var subjects = {
    england          : "England",
    ireland          : "Ireland",
    northernIreland  : "Northern Ireland",
    scotland         : "Scotland",
    wales            : "Wales",
}

var questionsArray = Object.values(subjects);

var game = new Phaser.Game(config)

function shuffle(a) {
    for (let i = a.length - 1; i > 0; i--) 
    {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}