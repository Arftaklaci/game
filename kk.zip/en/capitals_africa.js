var game = new Phaser.Game(500, 800, Phaser.Canvas, null, null, true)

game.global = 
{
	orientated    : false,
    instructions  : true,
}

// edit below 
collator = "en"
website_url = "https://world-geography-games.com/africa.html";
website_label = "World Geography Games"
title_label = "Capitals of Africa"
title_oneline = "Capitals of Africa"
play_again_label = "Play again"
stop_label = "Stop"
score_label = "score: "
final_score = "Score"
next_label = "Next"
out_of_label = "out of"
play_label = "play"
options_label = "options"
select_atleast_label = "Select at least 5 capitals"
back_label = "back"
sound_label = "SOUND"
number_of_capitals_label = "NUMBER OF CAPITALS"
capitals_label = "CAPITALS"
select_label = "select"
library_label = "library"

northernLabel = "Northern Africa"
westernLabel = "Western Africa"
centralLabel = "Central Africa"
southernLabel = "Southern Africa"
easternLabel = "Eastern Africa"

countries = ["Nigeria", "Ghana", "Ethiopia", "Algeria", "Madagascar", "Eritrea", "Mali", "Central African Republic", "Gambia", "Guinea-Bissau", "Republic of the Congo", "Egypt", "Guinea", "Senegal", "Djibouti", "Tanzania", "Sierra Leone", "Botswana", "Burundi", "Zimbabwe", "South Sudan", "Uganda", "Sudan", "Rwanda", "D.R. Congo", "Gabon", "Malawi", "Togo", "Angola", "Zambia", "Equatorial Guinea", "Mozambique", "Lesotho", "Eswatini", "Somalia", "Liberia", "Comoros", "Kenya", "Chad", "Niger", "Mauritania", "Burkina Faso", "Mauritius", "Benin", "Cape Verde", "South Africa", "Morocco", "São Tomé and Príncipe", "Libya", "Tunisia", "Seychelles", "Namibia", "Ivory Coast", "Cameroon"]

capitals = ["Abuja", "Accra", "Addis Ababa", "Algiers", "Antananarivo", "Asmara", "Bamako", "Bangui", "Banjul", "Bissau", "Brazzaville", "Cairo", "Conakry", "Dakar", "Djibouti", "Dodoma", "Freetown", "Gaborone", "Gitega", "Harare", "Juba", "Kampala", "Khartoum", "Kigali", "Kinshasa", "Libreville", "Lilongwe", "Lomé", "Luanda", "Lusaka", "Malabo", "Maputo", "Maseru", "Mbabane", "Mogadishu", "Monrovia", "Moroni", "Nairobi", "N'Djamena", "Niamey", "Nouakchott", "Ouagadougou", "Port Louis", "Porto-Novo", "Praia", "Pretoria", "Rabat", "São Tomé", "Tripoli", "Tunis", "Victoria", "Windhoek", "Yamoussoukro", "Yaoundé"]

// ** DO NOT EDIT BELOW!
// create new array, order alphabetically
countriesAlphabet = countries.slice().sort(Intl.Collator(collator).compare);

var capitalsUsed = 54;

// frames that will be used (frames represent images)
frames = [];
for (let f = 0; f < capitalsUsed; f++) {
    frames.push(f);
}

// always contains all frames, get random capitals from this array
allFrames = frames.slice();

northernAfrica = [11,3,46,48,49,22];
westernAfrica = [43,41,44,8,1,9,12,52,35,6,40,0,39,13,16,27];
centralAfrica = [28,7,53,24,38,25,30,10,47];
southernAfrica = [17,33,32,51,45];
easternAfrica = [18,14,36,5,2,4,37,26,42,31,23,50,34,20,15,21,29,19];

// toggle buttons used for regions, frame 0 or 1
northernBtn = 0;
southernBtn = 0;
centralBtn = 0;
westernBtn = 0;
easternAfricaBtn = 0;

// toggle buttons used for countries, frame 0 or 1
toggleButtonFrames = [];

for (let i = 0; i < frames.length; i++) {
    // by default all buttons are on (frame 0)
    toggleButtonFrames.push(0);
}

// sound toggle button
soundFrame = 0;
// selecting regions or countries in options (back button depends on this)
selectingRegions = true;

// all capitals
haveLookalikes = [];
for (let i = 0; i < 54; i++) {
    haveLookalikes.push(i);
}

// capitals from the same region
lookalikes = [
[53, 39],[52,41],[34,37],[46,48],[31],[2],[40],[24,38],[13],[12],[24,25],[48,22],[52],[40],[5],[23,29],[35],[51,45],
[23,15],[31,29],[2],[37],[11],[21,18],[7],[30],[31,15],[43],[24],[19],[53,25],[26,19],[33,45],[45],[2],[52,16],[4],[34,21],[53,7],[43,0],[6,13],[6,27],[4],[0],[40],[32,17],[3],[30],[3,11],[48,3],[34],[17],[41,35],[7,25]
];

// game states
game.state.add('boot', bootState);
game.state.add("Loading", loading);
game.state.add("menu", menuState);
game.state.add("options", optionsState);
game.state.add("library", libraryState);
game.state.add("level1", state1);
game.state.start("boot");