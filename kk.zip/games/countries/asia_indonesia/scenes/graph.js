"use strict"

class Graph extends Phaser.Scene {
    constructor() {
        super({
            key: "graph"
        })
    }

    create() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        // gameplay scene
        let gameplay = this.scene.get("gameplay");
        gameplay.displayMap(this);
        // show labels
        this.showLabels();
        // user interface
        this.ui = this.scene.get("graphUI");
        // launch user interface 
        this.scene.launch("graphUI");
        this.scene.moveAbove("graph", "graphUI");
       // camera
       camera = this.cameras.main;
       camera.zoom = .45;
        // min max zoom
        this.minZoom = .4;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.5;
        }
        else {
            this.maxZoom = 1.7;
        }
        // enable drag and pinch to zoom
        var dragScale = this.plugins.get('rexpinchplugin').add(this);
        dragScale.on('drag1', dragScale => {
                var drag1Vector = dragScale.drag1Vector;
                camera.scrollX -= drag1Vector.x / camera.zoom;
                camera.scrollY -= drag1Vector.y / camera.zoom;
        }).on('pinch', dragScale => {
            var scaleFactor = dragScale.scaleFactor;
            
            // camera zoom
            camera.zoom *= scaleFactor;
        }, this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);

            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
            //this.upKeyDown = cursorKeys.up.isDown;
            //this.downKeyDown = cursorKeys.down.isDown;
        }

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on("resize", (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }
    
    update() {
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop) {
            if (this.cursorKeys.up.isDown) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown) {
                
                camera.zoom *= 0.9;
            }
        }
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    showLabels(country) {
        // get countries (sprites) array from the container
        this.countriesArray = this.mapContainer.getAll();

        for (let i = 0; i < this.countriesArray.length; i++) {
            let country = this.countriesArray[i];

            country.rect = this.add.image(country.x, country.y, "rectangle");
            // write text
            country.txt = this.add.text(country.x, country.y, country.name, { fontFamily: "bold", fontSize: 26, align: "center", color: '#000000' });
            country.txt.setOrigin(.5,.5);
            // position text
            if (country.labelX) {
                country.txt.x = country.labelX;
                country.txt.y = country.labelY;
                country.rect.x = country.labelX;
                country.rect.y = country.labelY;
            }
            // rectangle width/height
            country.rect.displayWidth = country.txt.width + 4;
            country.rect.displayHeight = country.txt.height;

            if (country.name === countriesLabels.jakarta) {
                let line = this.add.image(country.x, country.y, "texture", "jakartaLine.png").setOrigin(0.5,1);
                this.mapContainer.add(line);
            }
            else if (country.name === countriesLabels.yogyakarta) {
                let line = this.add.image(country.x, country.y, "texture", "yogyakartaLine.png").setOrigin(0.5,0);
                this.mapContainer.add(line);
            }
        }
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.mapContainer.setSize(width, height);
        this.mapContainer.x = 0;
        this.mapContainer.y = 0;
    }
}
