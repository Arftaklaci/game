"use strict"
var width, height, resize;
var webUrl = "https://world-geography-games.com/world.html";

var labels = 
{
    website         : "World Geography Games",
    title           : "Cities",
    titleTwo        : "Cities",
    play            : "play",
    options         : "options",
    map             : "map",
    sound           : "SOUND",
    photos          : "PHOTOS",
    tapStart        : "Tap on the map to start",
    clickStart      : "Click on the map to start",
    incorrect       : "Incorrect. Try again!",
    score           : "Score: ",
    attempts        : "Attempts: ",
    attemptsEnd     : "Attempts",
    points          : "Points",
    back            : "back",
    playAgain       : "Play Again",
    stop            : "Stop",
    skip            : "Skip",
    skipped         : "Skipped",
}

// the order of labels is important!
var credits = {
  credit1   : "Photo: 空央 2018 (CC-BY-NC-ND)",
  credit2   : "Photo: Sandra Vallaure 2020 (CC-BY)",
  credit3   : "Photo: Mohammad Tauheed 2019 (CC-BY-NC)",
  credit4   : "Photo: Naval S 2019 (CC-BY-NC)",
  credit5   : "Photo: Purnadi Phan 2017 (CC-BY-NC)",
  credit6   : "Photo: Wasif Malik 2015 (CC-BY)",
  credit7   : "Photo: MONUSCO Photos 2015 (CC-BY-ND) ",
  credit8   : "Photo: Omoeko Media 2019 (CC-BY-ND)",
  credit9   : "Photo: Luca Sartori 2019 (CC-BY-ND)",
  credit10  : "Photo: MudflapDC 2018 (CC-BY-NC-ND)",
  credit11  : "Photo: Elisabetta Stringhi 2017 (CC-BY-NC)",
  credit12  : "Photo: Karthik Pasupathy Ramachandran 2015 (CC-BY-ND)",
  credit13  : "Photo: Chandradhar yadav 2017 (CC-BY-SA)",
  credit14  : "Photo: Eden, Janine and Jim 2020 (CC-BY)",
  credit15  : "Photo: Diego Torres Silvestre 2017 (CC-BY)",
  credit16  : "Photo: Xiquinhosilva 2018 (CC-BY)",
  credit17  : "Photo: Daniel Taka 2018 (CC-BY-ND)",
  credit18  : "Photo: Jorge Castro Ruso 2018 (CC-BY-NC)",
  credit19  : "Photo: Plb06 2017 (CC-BY-NC-ND)",
  credit20  : "Photo: Aaron Paulson 2018 (CC-BY-NC)",
}
var creditsArray = Object.values(credits);

var subjects = {
  beijing:           "Beijing",
  cairo:             "Cairo",
  dhaka:             "Dhaka",
  istanbul:          "Istanbul",
  jakarta:           "Jakarta",
  karachi:           "Karachi",
  kinshasa:          "Kinshasa",
  lagos:             "Lagos",
  london:            "London",
  mexicoCity:        "Mexico City",
  moscow:            "Moscow",
  mumbai:            "Mumbai",
  newDelhi:          "Delhi",
  newYork:           "New York",
  saoPaulo:          "São Paulo",
  seoul:             "Seoul",
  shanghai:          "Shanghai",
  sydney:            "Sydney",
  teheran:           "Teheran",
  tokyo:             "Tokyo",
}

var countriesNames = ["China", "Egypt", "Bangladesh", "Turkey", "Indonesia", "Pakistan", "DR Congo", "Nigeria", "United Kingdom", "Mexico", "Russia", "India", "India", "USA", "Brazil", "South Korea", "China", "Australia", "Iran", "Japan"];

var infoText = [
"Population: 20.463.000 \nSource: CIA World Factbook", 
"Population: 20.901.000 \nSource: CIA World Factbook", 
"Population: 21.006.000 \nSource: CIA World Factbook", 
"Population: 15.190.000 \nSource: CIA World Factbook", 
"Population: 10.770.000 \nSource: CIA World Factbook", 
"Population: 16.094.000 \nSource: CIA World Factbook", 
"Population: 14.342.000 \nSource: CIA World Factbook", 
"Population: 14.368.000 \nSource: CIA World Factbook", 
"Population: 9.304.000 \nSource: CIA World Factbook", 
"Population: 21.782.000 \nSource: CIA World Factbook", 
"Population: 12.538.000 \nSource: CIA World Factbook", 
"Population: 20.411.000 \nSource: CIA World Factbook", 
"Population: 30.291.000 \nSource: CIA World Factbook", 
"Population: 18.804.000 \nSource: CIA World Factbook", 
"Population: 22.043.000 \nSource: CIA World Factbook", 
"Population: 9.963.000 \nSource: CIA World Factbook", 
"Population: 27.058.000 \nSource: CIA World Factbook", 
"Population: 4.926.000 \nSource: CIA World Factbook", 
"Population: 9.135.000 \nSource: CIA World Factbook", 
"Population: 37.393.000 \nSource: CIA World Factbook"];
// don't edit below


// sound is on by default
var soundButtonFrame = 0;
// show photos by default
var showPhotos = true;
var photosButtonFrame = 0;
// number of attempts
var attempts = +0;
// number of skipped countries
var skips = +0;
// make array
var questionsArray = Object.values(subjects);
var questionsArrayStatic = Object.values(subjects);

// resize
const DEFAULT_WIDTH = 1280
const DEFAULT_HEIGHT = 720
const MAX_WIDTH = DEFAULT_WIDTH * 1.5
const MAX_HEIGHT = DEFAULT_HEIGHT * 1.5
let SCALE_MODE = 'SMOOTH'

const config = {
    type: Phaser.AUTO,
    parent: 'geo-game',
    backgroundColor : 0x34C5EB,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,

    scale: 
    {
        mode: Phaser.Scale.NONE,
        parent: "geo-game",
    },
    scene: [Loading, Menu, Options, UserInterface, GraphUI, Gameplay, Graph]
}

window.addEventListener('load', () => {
    const game = new Phaser.Game(config)
  
    resize = () => {
      const w = window.innerWidth
      const h = window.innerHeight
  
      let width = DEFAULT_WIDTH
      let height = DEFAULT_HEIGHT
      let maxWidth = MAX_WIDTH
      let maxHeight = MAX_HEIGHT
      let scaleMode = SCALE_MODE
  
      let scale = Math.min(w / width, h / height)
      let newWidth = Math.min(w / scale, maxWidth)
      let newHeight = Math.min(h / scale, maxHeight)
  
      let defaultRatio = DEFAULT_WIDTH / DEFAULT_HEIGHT
      let maxRatioWidth = MAX_WIDTH / DEFAULT_HEIGHT
      let maxRatioHeight = DEFAULT_WIDTH / MAX_HEIGHT
  
      // smooth scaling
      let smooth = 1
      if (scaleMode === 'SMOOTH') {
        const maxSmoothScale = 1.15
        const normalize = (value, min, max) => {
          return (value - min) / (max - min)
        }
        if (width / height < w / h) {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioWidth) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        } else {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioHeight) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        }
      }

      // resize the game
      game.scale.resize(newWidth * smooth, newHeight * smooth)
      // scale the width and height of the css
      game.canvas.style.width = newWidth * scale + 'px'
      game.canvas.style.height = newHeight * scale + 'px'
      // center the game with css margin
      game.canvas.style.marginTop = `${(h - newHeight * scale) / 2}px`
      game.canvas.style.marginLeft = `${(w - newWidth * scale) / 2}px`
    }

    window.addEventListener('resize', event => {
      resize()
    })
  
    resize()
  })
