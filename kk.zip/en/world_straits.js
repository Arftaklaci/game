"use strict"
var width, height, resize;
var webUrl = "https://world-geography-games.com/world.html";

var labels = 
{
    website         : "World Geography Games",
    title           : "Straits",
    titleTwo        : "Straits",
    play            : "play",
    options         : "options",
    map             : "map",
    sound           : "SOUND",
    photos          : "PHOTOS",
    tapStart        : "Tap on the map to start",
    clickStart      : "Click on the map to start",
    incorrect       : "Incorrect. Try again!",
    score           : "Score: ",
    attempts        : "Attempts: ",
    attemptsEnd     : "Attempts",
    points          : "Points",
    back            : "back",
    playAgain       : "Play Again",
    stop            : "Stop",
    skip            : "Skip",
    skipped         : "Skipped",
}

// the order of labels below is important!
var credits = {
  credit1   : "Photo: Riccardo Rossi & NASA 2014 (CC-BY-NC-SA)",
  credit2   : "Photo: Tim Sneddon 2018 (CC-BY-SA)",
  credit3   : "Photo: Karsten Bidstrup 2019 (CC-BY-SA)",
  credit4   : "Photo: Masa Sakano 2019 (CC-BY-SA)",
  credit5   : "Photo: Sandra Vallaure 2016 (CC-BY)",
  credit6   : "Photo: J Brew 2009 (CC-BY-SA)",
  credit7   : "Photo: Themactep 2013 (CC-BY-NC)",
  credit8   : "Photo: Vil.sandi 2018 (CC-BY-SA)",
  credit9   : "Photo: helen@littlethorpe 2019 (CC-BY-NC-SA)",
  credit10  : "Photo: Øyvind Holmstad 2014 (CC-BY-SA)",
  credit11  : "Photo: Nine LaMaitre 2014 (CC-BY-SA)",
  credit12  : "Photo: Kitmasterbloke 2016 (CC-BY)",
  credit13  : "Photo: Tony Fernandez 2018 (CC-BY-NC)",
  credit14  : "Photo: ESA 2011 (CC-BY-SA)",
  credit15  : "Photo: Guillaume Baviere 2015 (CC-BY-SA)",
  credit16  : "Photo: Dronepicr 2017 (CC-BY)",
  credit17  : "Photo: Claudia Brauer 2016 (CC-BY)",
  credit18  : "Photo: International Maritime Organisation 2018 (CC-BY)",
  credit19  : "Photo: Rutger van der Maar 2014 (CC-BY)",
  credit20  : "Photo: Hideya Hamano 2008 (CC-BY-NC-SA)"
}
var creditsArray = Object.values(credits);

var subjects = {
  babElMandeb:       "Bab-el-Mandeb",
  bassStrait:        "Bass Strait",
  beringStrait:      "Bering Strait",
  bosporus:          "Bosporus",
  cookStrait:        "Cook Strait",
  davisStrait:       "Davis Strait",
  detroitRiver:      "Detroit River",
  mozambiqueChannel: "Mozambique Channel",
  panamaCanal:       "Panama Canal",
  skagerrak:         "Skagerrak",
  straitOfDover:     "Strait of Dover",
  straitOfGeorgia:   "Strait of Georgia",
  straitOfGibraltar: "Strait of Gibraltar",
  straitOfHormuz:    "Strait of Hormuz",
  straitOfMagellan:  "Strait of Magellan",
  straitOfMalacca:   "Strait of Malacca",
  straitsOfFlorida:  "Straits of Florida",
  suezCanal:         "Suez Canal",
  taiwanStrait:      "Taiwan Strait",
  tsugaruStrait:     "Tsugaru Strait",
}

var countriesNames = ["Horn of Africa", "Australia", "Russia/USA", "Turkey", "New Zealand", "Canada/Greenland", "Canada/USA", "Indian Ocean", "Panama", "Scandinavia", "English Channel", "Canada/USA", "Africa/Europe", "Middle East", "Argentina/Chile", "Southeast Asia", "Cuba/USA", "Egypt", "South China Sea", "Japan"];

var infoText = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""];

// don't edit below

// sound is on by default
var soundButtonFrame = 0;
// show photos by default
var showPhotos = true;
var photosButtonFrame = 0;
// number of attempts
var attempts = +0;
// number of skipped countries
var skips = +0;
// make array
var questionsArray = Object.values(subjects);
var questionsArrayStatic = [...questionsArray];

// resize
const DEFAULT_WIDTH = 1280
const DEFAULT_HEIGHT = 720
const MAX_WIDTH = DEFAULT_WIDTH * 1.5
const MAX_HEIGHT = DEFAULT_HEIGHT * 1.5
let SCALE_MODE = 'SMOOTH'

const config = {
    type: Phaser.AUTO,
    parent: 'geo-game',
    backgroundColor : 0x34C5EB,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,

    scale: 
    {
        mode: Phaser.Scale.NONE,
        parent: "geo-game",
    },
    scene: [Loading, Menu, Options, UserInterface, GraphUI, Gameplay, Graph]
}

window.addEventListener('load', () => {
    const game = new Phaser.Game(config)
  
    resize = () => {
      const w = window.innerWidth
      const h = window.innerHeight
  
      let width = DEFAULT_WIDTH
      let height = DEFAULT_HEIGHT
      let maxWidth = MAX_WIDTH
      let maxHeight = MAX_HEIGHT
      let scaleMode = SCALE_MODE
  
      let scale = Math.min(w / width, h / height)
      let newWidth = Math.min(w / scale, maxWidth)
      let newHeight = Math.min(h / scale, maxHeight)
  
      let defaultRatio = DEFAULT_WIDTH / DEFAULT_HEIGHT
      let maxRatioWidth = MAX_WIDTH / DEFAULT_HEIGHT
      let maxRatioHeight = DEFAULT_WIDTH / MAX_HEIGHT
  
      // smooth scaling
      let smooth = 1
      if (scaleMode === 'SMOOTH') {
        const maxSmoothScale = 1.15
        const normalize = (value, min, max) => {
          return (value - min) / (max - min)
        }
        if (width / height < w / h) {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioWidth) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        } else {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioHeight) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        }
      }

      // resize the game
      game.scale.resize(newWidth * smooth, newHeight * smooth)
      // scale the width and height of the css
      game.canvas.style.width = newWidth * scale + 'px'
      game.canvas.style.height = newHeight * scale + 'px'
      // center the game with css margin
      game.canvas.style.marginTop = `${(h - newHeight * scale) / 2}px`
      game.canvas.style.marginLeft = `${(w - newWidth * scale) / 2}px`
    }

    window.addEventListener('resize', event => {
      resize()
    })
  
    resize()
  })
