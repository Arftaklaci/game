"use strict"
var width, height, resize;
var webUrl = "https://world-geography-games.com/world.html";

var labels = 
{
    website         : "World Geography Games",
    title           : "Rivers",
    titleTwo        : "Rivers",
    play            : "play",
    options         : "options",
    map             : "map",
    sound           : "SOUND",
    photos          : "PHOTOS",
    tapStart        : "Tap on the map to start",
    clickStart      : "Click on the map to start",
    incorrect       : "Incorrect. Try again!",
    score           : "Score: ",
    attempts        : "Attempts: ",
    attemptsEnd     : "Attempts",
    points          : "Points",
    back            : "back",
    playAgain       : "Play Again",
    stop            : "Stop",
    skip            : "Skip",
    skipped         : "Skipped",
}

// the order of labels below is important!
var credits = {
  credit1   : "Photo: MM 2013 (CC-BY-SA)",
  credit2   : "Photo: Paul Asman and Jill Lenoble 2019 (CC-BY)",
  credit3   : "Photo: DaBeet 2018 (CC-BY-SA)",
  credit4   : "Photo: ŽupaBA VUCBA 2020 (CC-BY)",
  credit5   : "Photo: Aziz1005 2015 (CC-BY)",
  credit6   : "Photo: Ekabhishek 2010 (CC-BY-SA)",
  credit7   : "Photo: Ymblanter 2019 (CC-BY-SA)",
  credit8   : "Photo: Basil Morin 2019 (CC-BY-SA)",
  credit9   : "Photo: Mississippi WMO (CC-BY-NC)",
  credit10  : "Photo: Stephan Ridgway 2019 (CC-BY)",
  credit11  : "Photo: Roland 2006 (CC-BY-SA)",
  credit12  : "Photo: Jawed 2010 (CC-BY-SA)",
  credit13  : "Photo: Dronepicr 2019 (CC-BY)",
  credit14  : "Photo: Trick on 2017 (CC-BY-SA)",
  credit15  : "Photo: Senol Demir 2008 (CC-BY)",
  credit16  : "Photo: Dmitriy Protsenko 2019 (CC-BY-SA)",
  credit17  : "Photo: Chen Hualin 2009 (CC-BY-SA)",
  credit18  : "Photo: Caitriana Nicholson 2015 (CC-BY-SA)",
  credit19  : "Photo: Elteko Yulia 2015 (CC-BY-SA)",
  credit20  : "Photo: Diego Delso delso.photo 2018 (CC-BY-SA)"
}
var creditsArray = Object.values(credits);

var subjects = {
  amazonRiver:     "Amazon River",
  coloradoRiver:   "Colorado River",
  congoRiver:      "Congo River",
  danube:          "Danube",
  euphrates:       "Euphrates",
  ganges:          "Ganges",
  mackenzieRiver:  "Mackenzie River",
  mekong:          "Mekong",
  mississippi:     "Mississippi",
  murrayRiver:     "Murray River",
  nigerRiver:      "Niger River",
  nile:            "Nile",
  rhine:           "Rhine",
  rioGrande:       "Rio Grande",
  tigris:          "Tigris",
  volgaRiver:      "Volga River",
  yangtzeRiver:    "Yangtze River",
  yellowRiver:     "Yellow River",
  yenisei:         "Yenisei",
  zambezi:         "Zambezi"
}
// display this next to river name
var countriesNames = ["South America", "Mexico/USA", "Africa", "Europe", "Western Asia", "India", "Canada", "Southeast Asia", "USA", "Australia", "Western Africa", "Africa", "Europe", "Mexico/USA", "Western Asia", "Russia", "China", "China", "Mongolia/Russia", "Africa"];

var infoText = ["Length: 7000 km approx.", "Length: 2334 km", "Length: 4700 km", "Length: 2860 km", "Length: 2800 km", "Length: 2525 km", "Length: 1738 km", "Length: 4350 km", "Length: 3734 km", "Length: 2375 km", "Length: 4180 km", "Length: 6650 km", "Length: 1233 km", "Length: 3051 km", "Length: 1850 km", "Length: 3692 km", "Length: 6300 km", "Length: 5464 km", "Length: 5539 km", "Length: 2574 km"];

// don't edit below

// sound is on by default
var soundButtonFrame = 0;
// show photos by default
var showPhotos = true;
var photosButtonFrame = 0;
// number of attempts
var attempts = +0;
// number of skipped countries
var skips = +0;
// make array
var questionsArray = Object.values(subjects);
var questionsArrayStatic = [...questionsArray];

// resize
const DEFAULT_WIDTH = 1280
const DEFAULT_HEIGHT = 720
const MAX_WIDTH = DEFAULT_WIDTH * 1.5
const MAX_HEIGHT = DEFAULT_HEIGHT * 1.5
let SCALE_MODE = 'SMOOTH'

const config = {
    type: Phaser.AUTO,
    parent: 'geo-game',
    backgroundColor : 0x34C5EB,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,

    scale: 
    {
        mode: Phaser.Scale.NONE,
        parent: "geo-game",
    },
    scene: [Loading, Menu, Options, UserInterface, GraphUI, Gameplay, Graph]
}

window.addEventListener('load', () => {
    const game = new Phaser.Game(config)
  
    resize = () => {
      const w = window.innerWidth
      const h = window.innerHeight
  
      let width = DEFAULT_WIDTH
      let height = DEFAULT_HEIGHT
      let maxWidth = MAX_WIDTH
      let maxHeight = MAX_HEIGHT
      let scaleMode = SCALE_MODE
  
      let scale = Math.min(w / width, h / height)
      let newWidth = Math.min(w / scale, maxWidth)
      let newHeight = Math.min(h / scale, maxHeight)
  
      let defaultRatio = DEFAULT_WIDTH / DEFAULT_HEIGHT
      let maxRatioWidth = MAX_WIDTH / DEFAULT_HEIGHT
      let maxRatioHeight = DEFAULT_WIDTH / MAX_HEIGHT
  
      // smooth scaling
      let smooth = 1
      if (scaleMode === 'SMOOTH') {
        const maxSmoothScale = 1.15
        const normalize = (value, min, max) => {
          return (value - min) / (max - min)
        }
        if (width / height < w / h) {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioWidth) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        } else {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioHeight) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        }
      }

      // resize the game
      game.scale.resize(newWidth * smooth, newHeight * smooth)
      // scale the width and height of the css
      game.canvas.style.width = newWidth * scale + 'px'
      game.canvas.style.height = newHeight * scale + 'px'
      // center the game with css margin
      game.canvas.style.marginTop = `${(h - newHeight * scale) / 2}px`
      game.canvas.style.marginLeft = `${(w - newWidth * scale) / 2}px`
    }

    window.addEventListener('resize', event => {
      resize()
    })
  
    resize()
  })
