"use strict"

class Graph extends Phaser.Scene {
    constructor() {
        super({
            key: "graph"
        })
    }

    create() {

        width = this.cameras.main.width;
        height = this.cameras.main.height;

        // get user interface scene (static objects)
        let gameplay = this.scene.get("gameplay");
        gameplay.displayEurope(this);

        // use delay to avoid lag when "map" button is clicked
        let timer = this.time.delayedCall(100, () => {
            // show europe labels
            this.showEuropeLabels();
        },this);

        // user interface
        this.ui = this.scene.get("graphUI");
        // launch user interface 
        this.scene.launch("graphUI");
        this.scene.moveAbove("graph", "graphUI");

       // camera
       camera = this.cameras.main;
       camera.zoom = 0.7;

        // min max zoom
        this.minZoom = 0.6;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.5;
        }
        else {
            this.maxZoom = 2;
        }

        // enable drag and pinch to zoom
        var dragScale = this.plugins.get('rexpinchplugin').add(this);
        dragScale.on('drag1', dragScale => {
                var drag1Vector = dragScale.drag1Vector;
                camera.scrollX -= drag1Vector.x / camera.zoom;
                camera.scrollY -= drag1Vector.y / camera.zoom;
        }).on('pinch', dragScale => {
            var scaleFactor = dragScale.scaleFactor;
            
            // camera zoom
            camera.zoom *= scaleFactor;
        }, this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);

            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
            //this.upKeyDown = cursorKeys.up.isDown;
            //this.downKeyDown = cursorKeys.down.isDown;
        }

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on("resize", (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }
    
    update() {
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop) {
            if (this.cursorKeys.up.isDown) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown) {
                
                camera.zoom *= 0.9;
            }
        }
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, 0.7, this.maxZoom));
    }

    showEuropeLabels(country) {

        // get countries (sprites) array from the container
        this.countriesArray = this.europeContainer.getAll();

        for (let i = 0; i < this.countriesArray.length; i++) {

            let country = this.countriesArray[i];
            country.txt = this.add.text(country.x, country.y, country.name, { fontFamily: "bold", fontSize: 19, color: '#000000' });
            country.txt.setOrigin(.5,.5);
            this.europeContainer.add(country.txt);
            // position text
            if (country.labelX) {
                country.txt.x = country.labelX;
                country.txt.y = country.labelY;
            }

            // create a line if needed
            if (country.hasLine) {
                // different lines for Vatican and San Marino
                if (country.name === countriesLabels.sanMarino || country.name === countriesLabels.vaticanCity) {
                let line = this.add.image(country.lineX, country.lineY, "lineSanMarino");
                line.setOrigin(1,0);
                 this.europeContainer.add(line);
                }
                // north macedonia
                else if (country.name === countriesLabels.northMacedonia) {
                    let line = this.add.image(country.lineX, country.lineY, "lineMacedonia");
                    line.setOrigin(0.5,0.5);
                    this.europeContainer.add(line);
                }
                else {
                    let line = this.add.image(country.lineX, country.lineY, "line");
                    line.setOrigin(0,0.5);
                    // flip horizontally
                    if (country.flipLine) {
                        line.scaleX = -1;
                        line.x += 4;
                    }
                    // rotate a line
                    if (country.name === countriesLabels.kosovo) {
                        line.angle = 6;
                    }
                    else if (country.name === countriesLabels.montenegro) {
                        line.angle = -4;
                    }
                    else if (country.name === countriesLabels.bosnia) {
                        line.angle = -2;
                    }
                    this.europeContainer.add(line);
                }
            }
            
            // create white rectangle
            country.rect = this.add.sprite(country.txt.x, country.txt.y, "rectangle");
            country.rect.displayWidth = country.txt.width + 2;
            country.rect.displayHeight = country.txt.height;
            this.europeContainer.add(country.rect);

            // bring to top text field
            this.europeContainer.bringToTop(country.txt);
        }
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
    }
}
