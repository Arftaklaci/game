"use strict"

var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        })
    }

    create() {

        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;
        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;
       camera.zoom = 0.3;

        // min max zoom
        this.minZoom = 0.3;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.4;
        }
        else {
            this.maxZoom = 2.1;
        }

        // display countries in this scene
        this.displayAsia(this);
       
        // get countries (sprites) array from the container
        this.countriesArray = this.asiaContainer.getAll();

        // for each country (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {

            let country = this.countriesArray[i];

            // make countries sprites interactive
            country.setInteractive({ 
                useHandCursor: true,             
                pixelPerfect: true,
                alphaTolerance: 255
             });

             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over country
                country.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                        if (country.isMicrostate === true) {
                            this.mouseOverMicro.setVisible(true);
                            this.mouseOverMicro.x = country.x;
                            this.mouseOverMicro.y = country.y;
                        }
                        else {
                            country.alpha = .5;

                            // hide microstetes
                            if (country.name === countriesLabels.malaysia) {
                                this.singapore.alpha = 0.01;
                                this.brunei.alpha = 0.01;
                            }
                            else if (country.name === countriesLabels.saudiArabia) {
                                this.bahrain.alpha = 0.01;
                            }
                        }
                    }
                },this);

                country.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        if (country.isMicrostate === true) {
                            this.mouseOverMicro.setVisible(false);
                        }
                        else {
                            country.alpha = 1;

                            // show microstetes
                            if (country.name === countriesLabels.malaysia) {
                                this.singapore.alpha = 1;
                                this.brunei.alpha = 1;
                            }
                            else if (country.name === countriesLabels.saudiArabia) {
                                this.bahrain.alpha = 1;
                            }
                        }
                    }
                },this);
            }

            country.on('pointerdown', () => {

                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });

            country.on('pointerup', () => {

                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);

                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    country.xPos = camera.x;
                    country.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false)
                    {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === country.name)
                        {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this country
                            country.disableInteractive();

                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }

                            // create the country label
                            this.showAsiaLabels(country);
    
                            // get new question
                            if (this.questionsArray.length > 0)
                            {
                                this.getQuestion();
                            }
                            else
                            {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
    
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // drag
                else {
                    // console.log("don't tap, drag the map");
                }
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();

        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false)
            {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();

                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                var dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {

                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        var drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }

                }).on('pinch', dragScale => {
                    var scaleFactor = dragScale.scaleFactor;
                    
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                    
                }, this);

                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        //if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        //}

        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 65, color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 65, color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });

        // mouse over microstate sprite
        this.mouseOverMicro = this.add.image(0,0, 'mouseOverMicrostate');
        this.mouseOverMicro.setVisible(false);

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        
        // mouse wheel zoom in/out
        //if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                
                camera.zoom *= 0.9;
            }
        //}

        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.asiaContainer.setSize(width, height);
        this.asiaContainer.x = 0;
        this.asiaContainer.y = 0; 
        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2, height/2);
        }
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;
        // play sound
        this.gameOverSound.play();
        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        // show animation at the end
        this.showAnimation();
    }

    getQuestion()
    {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;
        this.questionsArray.shift();
		
		 if (ui.questionText.text === countriesLabels.uae) {
            ui.questionText.setFontSize(28);
        }
        else {
            ui.questionText.setFontSize(34);
        }
        
        // tween
        this.tweens.add({
           targets: [ui.questionText],
           //scaleX: '-=.2',
           //angle: 10,
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
           //repeatDelay: 1000
           //onComplete: () => {console.log("COMPLETED")}
           //onCompleteParams: [ this.questionText ]
        });
    }

    showAnimation() {

        // tween camera
        if (camera.zoom > .3) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: .3,
                x: 0, 
                y: 0,
                duration: 2000,
                onComplete: () => {
                    
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }

        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: 0,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showAsiaLabels(country) {
        
            country.txt = this.add.text(country.x, country.y, country.name, { fontFamily: "bold", fontSize: 35, color: '#000000' });
            country.txt.setOrigin(.5,.5);
            this.asiaContainer.add(country.txt);
            // position text
            if (country.labelX) {
                country.txt.x = country.labelX;
                country.txt.y = country.labelY;
            }

            // create a line if needed
            if (country.hasLine) {
                
                let line;
                if (country.name === countriesLabels.azerbaijan) {
                    line = this.add.image(country.lineX, country.lineY, "lineAzerbaijan");
                    line.setOrigin(0.5,1);
                }
                else if (country.name === countriesLabels.armenia || country.name === countriesLabels.georgia) {
                    line = this.add.image(country.lineX, country.lineY, "lineArmenia");
                    line.setOrigin(0.5,1);
                }
                else if (country.name === countriesLabels.lebanon || country.name === countriesLabels.palestine) {
                    line = this.add.image(country.lineX, country.lineY, "lineLebanon");
                    line.setOrigin(1,0.5);
                }
                else if (country.name === countriesLabels.kuwait || country.name === countriesLabels.palestine) {
                    line = this.add.image(country.lineX, country.lineY, "lineLebanon");
                    line.scaleX = -1;
                    line.setOrigin(1,0.5);
                }
                else if (country.name === countriesLabels.jordan) {
                    line = this.add.image(country.lineX, country.lineY, "lineJordan");
                    line.setOrigin(1,0.5);
                }
                else if (country.name === countriesLabels.israel) {
                    line = this.add.image(country.lineX, country.lineY, "lineIsrael");
                    line.setOrigin(1,0.5);
                }
                else if (country.name === countriesLabels.bahrain) {
                    line = this.add.image(country.lineX, country.lineY, "lineBahrain");
                    line.setOrigin(1,0);
                }
                else if (country.name === countriesLabels.qatar) {
                    line = this.add.image(country.lineX, country.lineY, "lineQatar");
                    line.setOrigin(.5,0);
                }
                else if (country.name === countriesLabels.brunei) {
                    line = this.add.image(country.lineX, country.lineY, "lineBrunei");
                    line.setOrigin(.5, 1);
                }
                else if (country.name === countriesLabels.singapore) {
                    line = this.add.image(country.lineX, country.lineY, "lineBrunei");
                    line.setOrigin(.5,0);
                }

                this.asiaContainer.add(line);
            }

            // create white rectangle
            country.rect = this.add.sprite(country.txt.x, country.txt.y, "rectangle");
            country.rect.displayWidth = country.txt.width + 2;
            country.rect.displayHeight = country.txt.height;
            this.asiaContainer.add(country.rect);

            // bring to top text field
            this.asiaContainer.bringToTop(country.txt);
        
    }
    
    displayAsia(aScene) {
        // extra
        aScene.egypt = aScene.add.image(width/2 - 1594, height/2 + 236, "extraEgypt");
        aScene.kashmir = aScene.add.image(width/2 - 350, height/2 - 3, "extraKashmir");
        aScene.newGuinea = aScene.add.image(width/2 + 1623, height/2 + 1264, "extraNewGuinea");

        // countries
        aScene.afghanistan = aScene.add.image(width/2 - 647, height/2 + 21, "afghanistan");
        aScene.afghanistan.labelX = aScene.afghanistan.x - 20;
        aScene.afghanistan.labelY = aScene.afghanistan.y;
        aScene.pakistan = aScene.add.image(width/2 - 589, height/2 + 131, "pakistan");
        aScene.pakistan.labelX = aScene.pakistan.x + 10;
        aScene.pakistan.labelY = aScene.pakistan.y + 20;
        aScene.india = aScene.add.image(width/2 - 199, height/2 + 397, "india");
        aScene.tajikistan = aScene.add.image(width/2 - 572, height/2 - 131, "tajikistan");
        aScene.kyrgyzstan = aScene.add.image(width/2 - 506, height/2 - 203, "kyrgyzstan");
        aScene.iran = aScene.add.image(width/2 - 993, height/2 + 67.5, "iran");
        aScene.turkmenistan = aScene.add.image(width/2 - 878, height/2 - 133.5, "turkmenistan");
        aScene.uzbekistan = aScene.add.image(width/2 - 772, height/2 - 207, "uzbekistan");
        aScene.russia = aScene.add.image(width/2 - 87, height/2 - 752.5, "russia");
        aScene.kazakhstan = aScene.add.image(width/2 - 767.5, height/2 - 408, "kazakhstan");
        aScene.georgia = aScene.add.image(width/2 - 1299, height/2 - 238, "georgia");
        aScene.georgia.labelX = aScene.georgia.x - 20;
        aScene.georgia.labelY = aScene.georgia.y - 230;
        aScene.georgia.hasLine = true;
        aScene.georgia.lineX = aScene.georgia.x - 25;
        aScene.georgia.lineY = aScene.georgia.y;
        aScene.azerbaijan = aScene.add.image(width/2 - 1183, height/2 - 172, "azerbaijan");
        aScene.azerbaijan.labelX = aScene.azerbaijan.x + 65;
        aScene.azerbaijan.labelY = aScene.azerbaijan.y - 150;
        aScene.azerbaijan.hasLine = true;
        aScene.azerbaijan.lineX = aScene.azerbaijan.x + 25;
        aScene.azerbaijan.lineY = aScene.azerbaijan.y - 10;

        aScene.armenia = aScene.add.image(width/2 - 1247.5, height/2 -169, "armenia");
        aScene.armenia.labelX = aScene.armenia.x + 50;
        aScene.armenia.labelY = aScene.armenia.y - 225;
        aScene.armenia.hasLine = true;
        aScene.armenia.lineX = aScene.armenia.x - 15;
        aScene.armenia.lineY = aScene.armenia.y - 15;
        aScene.turkey = aScene.add.image(width/2 - 1486, height/2 - 134, "turkey");
        aScene.iraq = aScene.add.image(width/2 - 1250, height/2 + 43, "iraq");
        aScene.syria = aScene.add.image(width/2 - 1385, height/2 - 6, "syria");
        aScene.saudiArabia = aScene.add.image(width/2 - 1196, height/2 + 320.5, "saudiArabia");
        aScene.saudiArabia.labelX = aScene.saudiArabia.x - 50;
        aScene.saudiArabia.labelY = aScene.saudiArabia.y - 80;
        aScene.jordan = aScene.add.image(width/2 - 1420, height/2 + 102.5, "jordan");
        aScene.jordan.labelX = aScene.jordan.x - 200;
        aScene.jordan.labelY = aScene.jordan.y + 130;
        aScene.jordan.hasLine = true;
        aScene.jordan.lineX = aScene.jordan.x - 15;
        aScene.jordan.lineY = aScene.jordan.y + 80;
        aScene.yemen = aScene.add.image(width/2 - 1083.5, height/2 + 586, "yemen");
        aScene.oman = aScene.add.image(width/2 - 899, height/2 + 406.5, "oman");
        aScene.oman.labelX = aScene.oman.x + 20;
        aScene.oman.labelY = aScene.oman.y + 40;
        aScene.uae = aScene.add.image(width/2 - 959, height/2 + 318, "uae");
		aScene.uae.labelX = aScene.uae.x + 200;
        aScene.uae.labelY = aScene.uae.y + 15;
        aScene.lebanon = aScene.add.image(width/2 - 1465.5, height/2 + 22.5, "lebanon");
        aScene.lebanon.labelX = aScene.lebanon.x - 120;
        aScene.lebanon.labelY = aScene.lebanon.y;
        aScene.lebanon.hasLine = true;
        aScene.lebanon.lineX = aScene.lebanon.x + 10;
        aScene.lebanon.lineY = aScene.lebanon.y;
        aScene.israel = aScene.add.image(width/2 - 1488, height/2 + 100, "israel");
        aScene.israel.labelX = aScene.israel.x - 140;
        aScene.israel.labelY = aScene.israel.y + 55;
        aScene.israel.hasLine = true;
        aScene.israel.lineX = aScene.israel.x + 15;
        aScene.israel.lineY = aScene.israel.y + 40;
        aScene.palestine = aScene.add.image(width/2 - 1480, height/2 + 85, "palestine");
        aScene.palestine.labelX = aScene.palestine.x - 130;
        aScene.palestine.labelY = aScene.palestine.y;
        aScene.palestine.hasLine = true;
        aScene.palestine.lineX = aScene.palestine.x + 15;
        aScene.palestine.lineY = aScene.palestine.y;
        aScene.nepal = aScene.add.image(width/2 - 170, height/2 + 192, "nepal");
        aScene.china = aScene.add.image(width/2 + 184, height/2 - 34, "china");
        aScene.mongolia = aScene.add.image(width/2 + 134.5, height/2 - 375.5, "mongolia");
        aScene.myanmar = aScene.add.image(width/2 + 195, height/2 + 478, "myanmar");
        aScene.bangladesh = aScene.add.image(width/2 + 17, height/2 + 338, "bangladesh");
        aScene.bhutan = aScene.add.image(width/2 + 1.5, height/2 + 219, "bhutan");
        aScene.bhutan.labelX = aScene.bhutan.x;
        aScene.bhutan.labelY = aScene.bhutan.y - 20;
        aScene.maldives = aScene.add.image(width/2 - 615, height/2 + 814, "maldives");
        aScene.sriLanka = aScene.add.image(width/2 - 182, height/2 + 818, "sriLanka");
        aScene.thailand = aScene.add.image(width/2 + 343, height/2 + 668, "thailand");
        aScene.thailand.labelX = aScene.thailand.x + 10;
        aScene.thailand.labelY = aScene.thailand.y - 80;
        aScene.laos = aScene.add.image(width/2 + 404.5, height/2 + 509, "laos");
        aScene.cambodia = aScene.add.image(width/2 + 449.5, height/2 + 683.5, "cambodia");
        aScene.cambodia.labelX = aScene.cambodia.x;
        aScene.cambodia.labelY = aScene.cambodia.y - 20;
        aScene.vietnam = aScene.add.image(width/2 + 455.5, height/2 + 577, "vietnam");
        aScene.vietnam.labelX = aScene.vietnam.x + 90;
        aScene.vietnam.labelY = aScene.vietnam.y + 150;
        aScene.malaysia = aScene.add.image(width/2 + 594.5, height/2 + 950.5, "malaysia");
        aScene.malaysia.labelX = aScene.malaysia.x - 90;
        aScene.malaysia.labelY = aScene.malaysia.y;
        aScene.singapore = aScene.add.image(width/2 + 435.5, height/2 + 1024.5, "singapore");
        aScene.singapore.labelX = aScene.singapore.x;
        aScene.singapore.labelY = aScene.singapore.y + 55;
        aScene.singapore.isMicrostate = true;
        aScene.singapore.hasLine = true;
        aScene.singapore.lineX = aScene.singapore.x;
        aScene.singapore.lineY = aScene.singapore.y + 17;
        aScene.brunei = aScene.add.image(width/2 + 735, height/2 + 932, "brunei");
        aScene.brunei.isMicrostate = true;
        aScene.brunei.labelX = aScene.brunei.x;
        aScene.brunei.labelY = aScene.brunei.y - 55;
        aScene.brunei.hasLine = true;
        aScene.brunei.lineX = aScene.brunei.x;
        aScene.brunei.lineY = aScene.brunei.y - 17;
        aScene.indonesia = aScene.add.image(width/2 + 804.5, height/2 + 1134, "indonesia");
        aScene.eastTimor = aScene.add.image(width/2 + 1030, height/2 + 1346, "eastTimor");
        aScene.eastTimor.labelX = aScene.eastTimor.x;
        aScene.eastTimor.labelY = aScene.eastTimor.y + 45;
        aScene.philippines = aScene.add.image(width/2 + 917, height/2 + 704, "philippines");
        aScene.taiwan = aScene.add.image(width/2 + 840, height/2 + 342, "taiwan");
        aScene.northKorea = aScene.add.image(width/2 + 815, height/2 - 177, "northKorea");
        aScene.southKorea = aScene.add.image(width/2 + 891, height/2 - 41, "southKorea");
        aScene.japan = aScene.add.image(width/2 + 1111, height/2 - 35, "japan");
        aScene.japan.labelX = aScene.japan.x + 60;
        aScene.japan.labelY = aScene.japan.y - 80;
        aScene.bahrain = aScene.add.image(width/2 - 1063, height/2 + 262.5, "bahrain");
        aScene.bahrain.isMicrostate = true;
        aScene.bahrain.labelX = aScene.bahrain.x - 80;
        aScene.bahrain.labelY = aScene.bahrain.y + 50;
        aScene.bahrain.hasLine = true;
        aScene.bahrain.lineX = aScene.bahrain.x - 12;
        aScene.bahrain.lineY = aScene.bahrain.y + 13;
        aScene.qatar = aScene.add.image(width/2 - 1025.5, height/2 + 282.5, "qatar");
        aScene.qatar.labelX = aScene.qatar.x - 20;
        aScene.qatar.labelY = aScene.qatar.y + 100;
        aScene.qatar.hasLine = true;
        aScene.qatar.lineX = aScene.qatar.x - 10;
        aScene.qatar.lineY = aScene.qatar.y;
        aScene.kuwait = aScene.add.image(width/2 - 1133, height/2 + 163.5, "kuwait");
        aScene.kuwait.labelX = aScene.kuwait.x + 110;
        aScene.kuwait.labelY = aScene.kuwait.y - 5;
        aScene.kuwait.hasLine = true;
        aScene.kuwait.lineX = aScene.kuwait.x - 10;
        aScene.kuwait.lineY = aScene.kuwait.y - 5;
 
        // names
        aScene.afghanistan.name = countriesLabels.afghanistan;
        aScene.armenia.name = countriesLabels.armenia;
        aScene.azerbaijan.name = countriesLabels.azerbaijan;
        aScene.bahrain.name = countriesLabels.bahrain;
        aScene.bangladesh.name = countriesLabels.bangladesh;
        aScene.bhutan.name = countriesLabels.bhutan;
        aScene.brunei.name = countriesLabels.brunei;
        aScene.cambodia.name = countriesLabels.cambodia;
        aScene.china.name = countriesLabels.china;
        aScene.eastTimor.name = countriesLabels.eastTimor;
        aScene.georgia.name = countriesLabels.georgia;
        aScene.india.name = countriesLabels.india;
        aScene.indonesia.name = countriesLabels.indonesia;
        aScene.iran.name = countriesLabels.iran;
        aScene.iraq.name = countriesLabels.iraq;
        aScene.israel.name = countriesLabels.israel;
        aScene.japan.name = countriesLabels.japan;
        aScene.jordan.name = countriesLabels.jordan;
        aScene.kazakhstan.name = countriesLabels.kazakhstan;
        aScene.kuwait.name = countriesLabels.kuwait;
        aScene.kyrgyzstan.name = countriesLabels.kyrgyzstan;
        aScene.laos.name = countriesLabels.laos;
        aScene.lebanon.name = countriesLabels.lebanon;
        aScene.malaysia.name = countriesLabels.malaysia;
        aScene.maldives.name = countriesLabels.maldives;
        aScene.mongolia.name = countriesLabels.mongolia;
        aScene.myanmar.name = countriesLabels.myanmar;
        aScene.nepal.name = countriesLabels.nepal;
        aScene.northKorea.name = countriesLabels.northKorea;
        aScene.oman.name = countriesLabels.oman;
        aScene.pakistan.name = countriesLabels.pakistan;
        aScene.palestine.name = countriesLabels.palestine;
        aScene.philippines.name = countriesLabels.philippines;
        aScene.qatar.name = countriesLabels.qatar;
        aScene.russia.name = countriesLabels.russia;
        aScene.saudiArabia.name = countriesLabels.saudiArabia;
        aScene.singapore.name = countriesLabels.singapore;
        aScene.southKorea.name = countriesLabels.southKorea;
        aScene.sriLanka.name = countriesLabels.sriLanka;
        aScene.syria.name = countriesLabels.syria;
        aScene.taiwan.name = countriesLabels.taiwan;
        aScene.tajikistan.name = countriesLabels.tajikistan;
        aScene.thailand.name = countriesLabels.thailand;
        aScene.turkmenistan.name = countriesLabels.turkmenistan;
        aScene.turkey.name = labels.turkey;
        aScene.uae.name = countriesLabels.uae;
        aScene.uzbekistan.name = countriesLabels.uzbekistan;
        aScene.vietnam.name = countriesLabels.vietnam;
        aScene.yemen.name = countriesLabels.yemen;
 
        // create container and put countries into it
        aScene.asiaContainer = aScene.add.container(0, 0, [aScene.russia, aScene.kazakhstan, aScene.afghanistan, aScene.pakistan, aScene.india, aScene.turkey, aScene.kyrgyzstan, aScene.tajikistan, aScene.iran, aScene.turkmenistan, aScene.uzbekistan, aScene.georgia, aScene.azerbaijan, aScene.armenia, aScene.iraq, aScene.syria, aScene.saudiArabia, aScene.jordan, aScene.yemen, aScene.oman, aScene.uae, aScene.israel, aScene.lebanon, aScene.palestine, aScene.china, aScene.mongolia, aScene.nepal, aScene.myanmar, aScene.bangladesh, aScene.bhutan, aScene.maldives, aScene.sriLanka, aScene.thailand, aScene.cambodia, aScene.vietnam, aScene.laos, aScene.malaysia, aScene.singapore, aScene.brunei, aScene.indonesia, aScene.eastTimor, aScene.philippines, aScene.southKorea, aScene.northKorea, aScene.taiwan, aScene.japan, aScene.kuwait, aScene.qatar, aScene.bahrain]);
        
        aScene.asiaContainer.setSize(width, height);
        aScene.asiaContainer.x = 0;
        aScene.asiaContainer.y = 0;     
     }
}
