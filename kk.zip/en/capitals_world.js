var game = new Phaser.Game(500, 800, Phaser.Canvas, null, null, true);

game.global =
{
	orientated     : false,
    instructions   : true,
}

// edit below to change a language
collator = 'en'
website_url = "https://world-geography-games.com/";
website_label = "World Geography Games"
title_label = "Capitals of the World"
title_oneline = "Capitals of the World"
play_again_label = "Play again"
stop_label = "Stop"
score_label = "score: "
final_score = "Score"
next_label = "Next"
out_of_label = "out of"
play_label = "play"
options_label = "options"
short_label = "Short of capitals, please change options"
back_label = "back"
sound_label = "SOUND"
number_of_flags_label = "NUMBER OF CAPITALS"
flags_label = "CAPITALS"
select_label = "select"
library_label = "library"

europe_label = "Europe"
north_america_label = "North America"
oceania_label = "Oceania"
asia_label = "Asia"
africa_label = "Africa"
south_america_label = "South America"

countries = [
"Nigeria", "Ghana", "Ethiopia", "Algeria", "Madagascar", "Eritrea", "Mali", "Central African Republic", "Gambia", "Guinea-Bissau", "Republic of the Congo", "Egypt", "Guinea", "Senegal", "Djibouti", "Tanzania", "Sierra Leone", "Botswana", "Burundi", "Zimbabwe", "South Sudan", "Uganda", "Sudan", "Rwanda", "D.R. Congo", "Gabon", "Malawi", "Togo", "Angola", "Zambia", "Equatorial Guinea", "Mozambique", "Lesotho", "Eswatini", "Somalia", "Liberia", "Comoros", "Kenya", "Chad", "Niger", "Mauritania", "Burkina Faso", "Mauritius", "Benin", "Cape Verde", "South Africa", "Morocco", "São Tomé and Principe", "Libya", "Tunisia", "Seychelles", "Namibia", "Ivory Coast", "Cameroon",
"United Arab Emirates", "Jordan", "Turkey", "Turkmenistan", "Iraq", "Azerbaijan", "Brunei", "Thailand", "China", "Lebanon", "Kyrgyzstan", "Syria", "Bangladesh", "East Timor", "Qatar", "Tajikistan", "Palestine", "Vietnam", "Pakistan", "Indonesia", "Israel", "Afghanistan", "Nepal", "Malaysia", "Kuwait", "Maldives", "Bahrain", "Philippines", "Russia", "Oman", "Myanmar", "India", "Kazakhstan", "Cambodia", "North Korea", "Saudi Arabia", "Yemen", "South Korea", "Singapore", "Sri Lanka", "Taiwan", "Uzbekistan", "Georgia", "Iran", "Bhutan", "Japan", "Mongolia", "Laos", "Armenia",
"Paraguay", "Saint Kitts and Nevis", "Belize", "Colombia", "Brazil", "Barbados", "Argentina", "Venezuela", "Saint Lucia", "Guyana", "Guatemala", "Cuba", "Jamaica", "St. Vincent and the Grenadines", "Peru", "Nicaragua", "Mexico", "Uruguay", "Bahamas", "Canada", "Panama", "Suriname", "Haiti", "Trinidad and Tobago", "Ecuador", "Dominica", "Antigua and Barbuda", "Costa Rica", "El Salvador", "Chile", "Dominican Republic", "Grenada", "Bolivia", "Honduras", "United States",
"Netherlands", "Andorra", "Greece", "Serbia", "Germany", "Switzerland", "Slovakia", "Belgium", "Romania", "Hungary", "Moldova", "Denmark", "Ireland", "Finland", "Ukraine", "Portugal", "Slovenia", "United Kingdom", "Luxembourg", "Spain", "Belarus", "Monaco", "Cyprus", "Norway", "France", "Montenegro", "Czech Republic", "Kosovo", "Iceland", "Latvia", "Italy", "San Marino", "Bosnia and Herzegovina", "North Macedonia", "Bulgaria", "Sweden", "Estonia", "Albania", "Liechtenstein", "Malta", "Vatican City", "Austria", "Lithuania", "Poland", "Croatia",
"Samoa", "Australia", "Tuvalu", "Solomon Islands", "Marshall Islands", "Palau", "Tonga", "Micronesia", "Papua New Guinea", "Vanuatu", "Kiribati", "Fiji", "New Zealand", "Nauru"
]

capitals = [
"Abuja", "Accra", "Addis Ababa", "Algiers", "Antananarivo", "Asmara", "Bamako", "Bangui", "Banjul", "Bissau", "Brazzaville", "Cairo", "Conakry", "Dakar", "Djibouti", "Dodoma", "Freetown", "Gaborone", "Gitega", "Harare", "Juba", "Kampala", "Khartoum", "Kigali", "Kinshasa", "Libreville", "Lilongwe", "Lome", "Luanda", "Lusaka", "Malabo", "Maputo", "Maseru", "Mbabane", "Mogadishu", "Monrovia", "Moroni", "Nairobi", "N'Djamena", "Niamey", "Nouakchott", "Ouagadougou", "Port Louis", "Porto-Novo", "Praia", "Pretoria", "Rabat", "São Tomé", "Tripoli", "Tunis", "Victoria", "Windhoek", "Yamoussoukro", "Yaoundé",
"Abu Dhabi", "Amman", "Ankara", "Ashgabat‎", "Baghdad", "Baku", "Bandar Seri Begawan‎", "Bangkok", "Beijing", "Beirut", "Bishkek", "Damascus", "Dhaka", "Dili", "Doha", "Dushanbe", "East Jerusalem", "Hanoi", "Islamabad", "Jakarta", "Jerusalem", "Kabul", "Kathmandu‎", "Kuala Lumpur", "Kuwait City", "Malé", "Manama", "Manila", "Moscow", "Muscat", "Naypyidaw‎", "New Delhi", "Nur-Sultan", "Phnom Penh‎", "Pyongyang‎", "Riyadh", "Sana'a", "Seoul", "Singapore", "Sri Jayawardenepura Kotte‎", "Taipei", "Tashkent", "Tbilisi", "Tehran", "Thimphu‎", "Tokyo", "Ulaanbaatar‎", "Vientiane‎", "Yerevan",
"Asunción", "Basseterre", "Belmopan", "Bogota", "Brasilia", "Bridgetown", "Buenos Aires", "Caracas", "Castries", "Georgetown", "Guatemala City", "Havana", "Kingston", "Kingstown", "Lima", "Managua", "Mexico City", "Montevideo", "Nassau", "Ottawa", "Panama City", "Paramaribo", "Port-au-Prince", "Port of Spain", "Quito", "Roseau", "Saint John's", "San José", "San Salvador", "Santiago", "Santo Domingo", "Saint George's", "Sucre", "Tegucigalpa", "Washington, D.C.",
"Amsterdam", "Andorra la Vella", "Athens", "Belgrade", "Berlin", "Bern", "Bratislava", "Brussels", "Bucharest", "Budapest", "Chișinău", "Copenhagen", "Dublin", "Helsinki", "Kyiv", "Lisbon", "Ljubljana", "London", "Luxembourg City", "Madrid", "Minsk", "Monaco", "Nicosia", "Oslo", "Paris", "Podgorica", "Prague", "Pristina", "Reykjavík", "Riga", "Rome", "San Marino", "Sarajevo", "Skopje", "Sofia", "Stockholm", "Tallinn", "Tirana", "Vaduz", "Valletta", "Vatican City", "Vienna", "Vilnius", "Warsaw", "Zagreb",
"Apia", "Canberra", "Funafuti", "Honiara", "Majuro", "Ngerulmud", "Nuku'alofa", "Palikir", "Port Moresby", "Port Vila", "South Tarawa", "Suva", "Wellington", "Yaren"
]

// ** DO NOT EDIT BELOW!
// create new array, don't change the first one, order alphabetically
countriesAlphabet = countries.slice().sort(Intl.Collator(collator).compare);

// how many capitals selected
capitalsUsed = 25;

// frames that will be used
frames = []
for (let f = 0; f < 197; f++){
    frames.push(f);
}

// always contains all frames, get random capitals from this array
allFrames = frames.slice();

// always contains all frames, get random capitals from this array
all_frames = frames.slice();

// shuffled frames
slider_array = frames.slice();

africa = []
for (let f = 0; f < 54; f++){
    africa.push(f);
}

asia = []
for (let f = 54; f < 103; f++){
    asia.push(f);
}

north_america = [104,105,108,111,113,114,115,116,118,119,121,122,123,125,126,128,129,130,131,133,134,136,137];

south_america = [103,106,107,109,110,112,117,120,124,127,132,135];

europe = [];
for (let f = 138; f < 183; f++){
    europe.push(f);
}

// add russia to europe
europe.push(88);

oceania = [];
for (let f = 183; f < 197; f++){
    oceania.push(f);
}

// toggle buttons used for regions, possible frame 0 or 1
europe_btn = 0;
africa_btn = 0;
north_america_btn = 0;
asia_btn = 0;
oceania_btn = 0;
south_america_btn = 0;

// toggle buttons used for countries, possible frame 0 or 1
toggle_button_frames = [];

for (var i = 0; i < frames.length; i++)
{
    // by default all buttons are on (frame 0)
    toggle_button_frames.push(0);
}

// sound toggle button
sound_frame = 0;

// game states
game.state.add('boot', bootState);
game.state.add("Loading", loading);
game.state.add("menu", menuState);
game.state.add("options", optionsState);
game.state.add("library", libraryState);
game.state.add("level1", state1);
game.state.start("boot");
