var mouseIsDown = false;
var distX = 0;

function mouseDown(){
    	//set the mouseIsDown to true
        mouseIsDown = true;
        startX = game.input.y;
}

function mouseUp(){
       mouseIsDown = false;
}

function swipeDone() {
    //get the ending point
    var endX = game.input.y;

    if (endX < startX) {
        flags_group.y -= distX / 6
    } 
    else{
        flags_group.y += distX / 6
    }
}

var libraryState =
{
	
create: function()
{
    game.input.onUp.add(mouseUp, this);
    game.input.onDown.add(mouseDown, this);
    
    vy = 0
    number_of_clicks = 0
    
    // bg rectangle
    bg = game.add.image(0, 0, 'bg')
    
    scroll_up = false
	scroll_down = false
    number_of_clicks = 0
    
    // group contains flags and texts
    flags_group = game.add.group()
    flags_group.y = 100
    
    // capitals and countries #66d940 green color
    y_pos = 10;
    for (let i = 0; i < countries_alphabet.length; i++)
    {
        let index = countries.indexOf(countries_alphabet[i])
         
        if (index === 33) {
            country_name = game.add.text(W/2 - 15, y_pos + 30, countries_alphabet[i], {font:"18px semiBold", fill:"#0000000"}, flags_group);
            country_name.anchor.setTo(1,0)
        }
		 else if (index === 17) {
            country_name = game.add.text(W/2 - 15, y_pos + 30, countries_alphabet[i], {font:"21px semiBold", fill:"#0000000"}, flags_group);
            country_name.anchor.setTo(1,0)
        }
		
		else if (index === 34 ) {
            country_name = game.add.text(W/2 - 15, y_pos + 30, countries_alphabet[i], {font:"21px semiBold", fill:"#0000000"}, flags_group);
            country_name.anchor.setTo(1,0)
        }
		
        else {
            country_name = game.add.text(W/2 - 15, y_pos + 30, countries_alphabet[i], {font:"23px semiBold", fill:"#0000000"}, flags_group);
            country_name.anchor.setTo(1,0)
        }
        
        capital_name = game.add.text(W/2 + 15, y_pos + 30, capitals[index], {font:"23px semiBold", fill:"#30cd42"}, flags_group);

        y_pos += 55
    }
    
    // arrows
	arrow_down = game.add.button(446, 755, 'button_back')
    arrow_down.angle = -90
	arrow_up = game.add.button(480, 105, 'button_back')
    arrow_up.angle = 90
	arrow_up.frame = 1;
	
	arrow_down.events.onInputOut.add(function(){scroll_down=false;}, this);
	arrow_down.events.onInputDown.add(function()
    {
        scroll_down=true;
    }, this);
    
	arrow_down.events.onInputUp.add(function(){
        scroll_down=false;}, this);
	arrow_up.events.onInputOut.add(function(){scroll_up=false;}, this);
	arrow_up.events.onInputDown.add(function()
    {
        scroll_up=true
    }, this);
	arrow_up.events.onInputUp.add(function(){
        scroll_up=false;
    }, this);
    
    // rectangle on top
    bg_top = game.add.image(0,0,'bg_top')
    
    // text library 
    textLibrary = game.add.text(W - 40, 22, library_label, {font:"36px extraBold", fill:"#0099ff"});
    textLibrary.anchor.setTo(1, 0);

    textLibrary.anchor.setTo(1,0)
    buttonLibrary = game.add.button(W - 55 - textLibrary.width, 18, 'button_library')
    buttonLibrary.anchor.setTo(1,0)
    buttonLibrary.scale.x = .8
    buttonLibrary.scale.y = .8
    
    // button back
    button_back_small = game.add.button(20, 21, 'button_back')
    text_back = game.add.text(55, 23, back_label, {font:"26px bold", fill:"#000000"});
    
    button_back_clickable = game.add.button(10, 20, 'button_invisible', go_to_menu)
    button_back_clickable.width = 60 + text_back.width
    button_back_clickable.height = 40
    
    // mouse wheel on desktop
    mouseWheelScroll();
},
    
update: function()
{
    if (mouseIsDown == true) 
    {
        //get the distance between the start and end point
        distX = Math.abs(game.input.y - startX);
        //if the distance is greater than 50 pixels then a swipe has happened
        if (distX > 50) 
        {
            if (distX > 100)
            {
                distX = 100
            }
            swipeDone();
        }
    }
    
    // tap buttons to scroll
	if (scroll_down == true){
		flags_group.y -= 10;
	}
	else if (scroll_up == true){
		flags_group.y += 10;
	}
    
    if (flags_group.y < -1800)
    {
        flags_group.y = -1800
    }
    else if (flags_group.y > 100)
    {
        flags_group.y = 100
    }
}
}