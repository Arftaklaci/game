var game = new Phaser.Game(500, 800, Phaser.Canvas, null, null, true)

game.global = 
{
	orientated    : false,
    instructions  : true,
}

// edit below 
collator = "en"
website_url = "https://world-geography-games.com/asia.html";
website_label = "World Geography Games"
title_label = "Capitals of Asia"
title_oneline = "Capitals of Asia"
play_again_label = "Play again"
stop_label = "Stop"
score_label = "score: "
final_score = "Score"
next_label = "Next"
out_of_label = "out of"
play_label = "play"
options_label = "options"
select_atleast_label = "Select at least 5 capitals"
back_label = "back"
sound_label = "SOUND"
number_of_capitals_label = "NUMBER OF CAPITALS"
capitals_label = "CAPITALS"
select_label = "select"
library_label = "library"

southEastLabel = "Southeast Asia"
westernLabel = "Western Asia"
centralLabel = "Central and Northern Asia"
southernLabel = "South Asia"
easternLabel = "East Asia"

countries = ["United Arab Emirates", "Jordan", "Turkey", "Turkmenistan", "Iraq", "Azerbaijan", "Brunei", "Thailand", "China", "Lebanon", "Kyrgyzstan", "Syria", "Bangladesh", "East Timor", "Qatar", "Tajikistan", "Palestine", "Vietnam", "Pakistan", "Indonesia", "Israel", "Afghanistan", "Nepal", "Malaysia", "Kuwait", "Maldives", "Bahrain", "Philippines", "Russia", "Oman", "Myanmar", "India", "Kazakhstan", "Cambodia", "North Korea", "Saudi Arabia", "Yemen", "South Korea", "Singapore", "Sri Lanka", "Taiwan", "Uzbekistan", "Georgia", "Iran", "Bhutan", "Japan", "Mongolia", "Laos", "Armenia"]

capitals = ["Abu Dhabi", "Amman", "Ankara", "Ashgabat‎", "Baghdad", "Baku", "Bandar Seri Begawan‎", "Bangkok", "Beijing", "Beirut", "Bishkek", "Damascus", "Dhaka", "Dili", "Doha", "Dushanbe", "East Jerusalem", "Hanoi", "Islamabad", "Jakarta", "Jerusalem", "Kabul", "Kathmandu‎", "Kuala Lumpur", "Kuwait City", "Malé", "Manama", "Manila", "Moscow", "Muscat", "Naypyidaw‎", "New Delhi", "Nur-Sultan", "Phnom Penh‎", "Pyongyang‎", "Riyadh", "Sana'a", "Seoul", "Singapore", "Sri Jayawardenepura Kotte‎", "Taipei", "Tashkent", "Tbilisi", "Tehran", "Thimphu‎", "Tokyo", "Ulaanbaatar‎", "Vientiane‎", "Yerevan"]

// ** DO NOT EDIT BELOW!
// create new array, order alphabetically
countriesAlphabet = countries.slice().sort(Intl.Collator(collator).compare);

var capitalsUsed = 49;

// frames that will be used (frames represent images)
frames = [];
for (let f = 0; f < capitalsUsed; f++) {
    frames.push(f);
}

// always contains all frames, get random capitals from this array
allFrames = frames.slice();

southEastAsia = [6,7,13,17,19,23,27,33,30,38,47];
westernAsia = [0,1,2,4,5,9,11,14,20,16,26,24,29,35,36,42,48,43];
centralAndNorthernAsia = [3,10,15,28,32,41];
southAsia = [12,18,21,22,25,31,39,44]; 
eastAsia = [8,37,45,34,40,46]; 

// toggle buttons used for regions, frame 0 or 1
southEastBtn = 0;
southernBtn = 0;
centralBtn = 0;
westernBtn = 0;
eastBtn = 0;

// toggle buttons used for countries, frame 0 or 1
toggleButtonFrames = [];

for (let i = 0; i < frames.length; i++) {
    // by default all buttons are on (frame 0)
    toggleButtonFrames.push(0);
}

// sound toggle button
soundFrame = 0;
// selecting regions or countries in options (back button depends on this)
selectingRegions = true;

// all capitals
haveLookalikes = [];
for (let i = 0; i < capitalsUsed; i++) {
    haveLookalikes.push(i);
}

// capitals from the same region
lookalikes = [
[1,4],[0,16],[5,9],[10],[43],[14,20],[7,13],[17],[45,27],[16,26],[15],[24,29],[18],[23,33],[20,29],[32],[35,36],[30],[39],[38,47],[43,48],[22,44],[31],[30,6],
// kuwait
[42,36],[12],[24,29],[7,13],[41],[35,1],[47],[18,12],[28],[19],[37,8],[4,5],[9,20],[34],[47],[22,25],[46,45],[3],[14,29],[4],[31,39],[8],[34,37],[6,7],[42,26]
];

// game states
game.state.add('boot', bootState);
game.state.add("Loading", loading);
game.state.add("menu", menuState);
game.state.add("options", optionsState);
game.state.add("library", libraryState);
game.state.add("level1", state1);
game.state.start("boot");