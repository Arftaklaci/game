var config = {
    type            : Phaser.Auto,
    width           : 640,
    height          : 960,
    backgroundColor : 0x34C5EB,
    webLink         : "https://world-geography-games.com/en/europe_uk_ireland.html",
    stopLink        : "https://world-geography-games.com/europe_uk.html",
    scale           : {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH,
        parent: "geo-game",
    },
    scene           : [Loading, Level1]
}

var labels = {
    website_label         : "World Geography Games",
    url                   : "https://world-geography-games.com/europe_uk.html",
    tap_label             : "Tap on the map to start",
    click_label           : "Click on the map to start",
	incorrect             : "Incorrect, try again!",
    score_label           : "score: ",
    attempts_label        : "attempts: ",
    solution_label        : "solution",
    stop_label            : "stop",
    play_again_label      : "play again",
    title_label           : "UK and Ireland",
    capital_city_label    : "Capital city...",
    game_completed        : "Game completed",
    england_label         : "England",
    wales_label           : "Wales",
    scotland_label        : "Scotland",
    ireland_label         : "Ireland",
    northern_ireland_label: "Northern Ireland",
    swansea_label         : "Swansea",
    cardiff_label         : "Cardiff",
    newport_label         : "Newport",
    london_label          : "London",
    manchester_label      : "Manchester",
    birmingham_label      : "Birmingham",
    dublin_label          : "Dublin",
    limerick_label        : "Limerick",
    cork_label            : "Cork",
    aberdeen_label        : "Aberdeen",
    glasgow_label         : "Glasgow",
    edinburgh_label       : "Edinburgh",
    belfast_label         : "Belfast",
    lisburn_label         : "Lisburn",
    londonderry_label     : "Londonderry"
}

function shuffle(a) {
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

var game = new Phaser.Game(config);