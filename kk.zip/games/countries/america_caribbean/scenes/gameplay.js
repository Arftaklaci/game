"use strict"

var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        })
    }

    create() {

        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;

        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;
       camera.zoom = .65;
        // min max zoom
        this.minZoom = .65;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.7;
        }
        else {
            this.maxZoom = 2.1;
        }
        
        // display countries in this scene
        this.displayCaribbean(this);
        // get countries (sprites) array from the container
        this.countriesArray = this.caribbeanContainer.getAll();

        // for each country (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {

            let country = this.countriesArray[i];
			
            /* enable drag to position countries
            country.setInteractive()
            this.input.setDraggable(country);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {

                gameObject.x = dragX;
                gameObject.y = dragY;
        
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });
            */

            // make countries sprites interactive
            country.setInteractive({ 
                useHandCursor: true,             
                pixelPerfect: true,
                alphaTolerance: 255
             });

             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over country
                country.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                        country.setFrame(1);
                    }
                },this);

                country.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        country.setFrame(0);
                    }
                },this);
            }

            country.on('pointerdown', () => {

                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });

            country.on('pointerup', () => {

                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);

                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    country.xPos = camera.x;
                    country.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false)
                    {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === country.name)
                        {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this country
                            country.disableInteractive();

                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }

                            // create the country label
                            this.displayLabels(country);
    
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
    
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // else don't tap, drag the map
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();

        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false)
            {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();

                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip, ui.buttonSound],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                let dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {

                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        let drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }

                }).on('pinch', dragScale => {
                    let scaleFactor = dragScale.scaleFactor;
                    
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                    
                }, this);

                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        //if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        //}

        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 50, color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 50, color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });

        // mouse over microstate sprite
        this.mouseOverMicro = this.add.image(0,0, 'mouseOverMicrostate');
        this.mouseOverMicro.setVisible(false);

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        
        // mouse wheel zoom in/out
        //if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                
                camera.zoom *= 0.9;
            }
        //}

        // limit zoom
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.caribbeanContainer.setSize(width, height);
        this.caribbeanContainer.x = 0;
        this.caribbeanContainer.y = 0; 

        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2, height/2);
        }
    }

    getQuestion()
    {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;

        if (this.question === countriesLabels.saintVincent) {
            ui.questionText.setFontSize(25);
        }
        else if (this.question === countriesLabels.usVirginIslands || this.question === countriesLabels.saintKittsAndNevis) {
            ui.questionText.setFontSize(27);
        }
		
        else if (this.question === countriesLabels.turksAndCaicos || this.question === countriesLabels.britishVirginIslands || this.question === countriesLabels.dominicanRepublic) {
            ui.questionText.setFontSize(30);
        }
        else {
            ui.questionText.setFontSize(33);
        }

        this.questionsArray.shift();
        
        // tween
        this.tweens.add({
           targets: [ui.questionText],
           //scaleX: '-=.2',
           //angle: 10,
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
           //repeatDelay: 1000
           //onComplete: () => {console.log("COMPLETED")}
           //onCompleteParams: [ this.questionText ]
        });
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;

        // play sound
        this.gameOverSound.play();

        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        ui.buttonSound.destroy();

        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {

        // tween camera
        if (camera.zoom > this.minZoom) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: this.minZoom,
                x: 0, 
                y: 0,
                duration: 3000,
                onComplete: () => {
                    
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }

        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: 0,
            ease: 'Linear',
            duration: 3000,
        });
    }

    displayLabels(country) {
            if (country.name === countriesLabels.aruba) {
                let line = this.add.image(country.lineX, country.lineY, "lineAruba");
                line.setOrigin(0.5,0.5);
                this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.bonaire) {
                let line = this.add.image(country.lineX, country.lineY, "lineBonaire");
                line.setOrigin(0,0.5);
                this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.curacao) {
                let line = this.add.image(country.lineX, country.lineY, "lineCuracao");
                line.setOrigin(.5,.5);
                    this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.trinidadAndTobago) {
                let line = this.add.image(country.lineX, country.lineY, "lineTrinidadAndTobago");
                line.setOrigin(0,0.5);
                    this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.turksAndCaicos) {
                let line = this.add.image(country.lineX, country.lineY, "lineTurksAndCaicosIslands");
                line.setOrigin(0,0.5);
                    this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.usVirginIslands) {
                let line = this.add.image(country.lineX, country.lineY, "lineUnitedStatesVirginIslands");
                line.setOrigin(0.5,1);
                    this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.britishVirginIslands) {
                let line = this.add.image(country.lineX, country.lineY, "lineBritishVirginIslands");
                    line.setOrigin(0.5,0.5);
                    this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.puertoRico) {
                let line = this.add.image(country.lineX, country.lineY, "linePuertoRico");
                    line.setOrigin(0.5,1);
                    this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.grenada || country.name === countriesLabels.saintVincent) {
                let line = this.add.image(country.lineX, country.lineY, "lineGrenada");
                line.setOrigin(0,0.5);
                this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.barbados) {
                let line = this.add.image(country.lineX, country.lineY, "lineAruba");
                line.setOrigin(0,0.5);
                this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.saba) {
                let line = this.add.image(country.lineX, country.lineY, "lineSaba");
                line.setOrigin(1,0.5);
                this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.sintEustatius ||country.name === countriesLabels.saintKittsAndNevis || country.name === countriesLabels.montserrat) {
                let line = this.add.image(country.lineX, country.lineY, "lineMontserrat");
                line.setOrigin(1,0.5);
                this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.saintMartin ||country.name === countriesLabels.sintMaarten) {
                let line = this.add.image(country.lineX, country.lineY, "lineSaintMartin");
                line.setOrigin(0,0.5);
                this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.saintLucia || country.name === countriesLabels.martinique || country.name === countriesLabels.dominica || country.name === countriesLabels.guadeloupe || country.name === countriesLabels.saintBarthelemy || country.name === countriesLabels.antiguaAndBarbuda) {
                let line = this.add.image(country.lineX, country.lineY, "lineGuadeloupe");
                    line.setOrigin(0,0.5);
                    this.caribbeanContainer.add(line);
            }

            // text
            country.txt = this.add.text(country.x, country.y, country.name, { fontFamily: "bold", fontSize: 24, align: "center", color: '#000000' });
            country.txt.setOrigin(.5,.5);
            this.caribbeanContainer.add(country.txt);

            // different labels for these territories (UK, NL, FR, USA)
            if (country.name === countriesLabels.anguilla) {
                country.txt.setText(labels.anguillaT);
            }
            else if (country.name === countriesLabels.saintMartin) {
                country.txt.setText(labels.saintMartinT);
            }
            else if (country.name === countriesLabels.sintMaarten) {
                country.txt.setText(labels.sintMaartenT);
            }
            else if (country.name === countriesLabels.saintBarthelemy) {
                country.txt.setText(labels.saintBarthelemyT);
            }
            else if (country.name === countriesLabels.guadeloupe) {
                country.txt.setText(labels.guadeloupeT);
            }
            else if (country.name === countriesLabels.martinique) {
                country.txt.setText(labels.martiniqueT);
            }
            else if (country.name === countriesLabels.britishVirginIslands) {
                country.txt.setText(labels.britishVirginIslandsT);
            }
            else if (country.name === countriesLabels.puertoRico) {
                country.txt.setText(labels.puertoRicoT);
            }
            else if (country.name === countriesLabels.usVirginIslands) {
                country.txt.setText(labels.usVirginIslandsT);
            }
            else if (country.name === countriesLabels.turksAndCaicos) {
                country.txt.setText(labels.turksAndCaicosT);
            }
            else if (country.name === countriesLabels.caymanIslands) {
                country.txt.setText(labels.caymanIslandsT);
            }
            else if (country.name === countriesLabels.aruba) {
                country.txt.setText(labels.arubaT);
            }
            else if (country.name === countriesLabels.curacao) {
                country.txt.setText(labels.curacaoT);
            }
            else if (country.name === countriesLabels.bonaire) {
                country.txt.setText(labels.bonaireT);
            }


            // position text
            if (country.labelX) {
                country.txt.x = country.labelX;
                country.txt.y = country.labelY;
            }
            // create white rectangle
            country.rect = this.add.sprite(country.txt.x, country.txt.y, "rectangle");
            country.rect.displayWidth = country.txt.width + 2;
            country.rect.displayHeight = country.txt.height;
            this.caribbeanContainer.add(country.rect);
            // set different origin for some rectangles
            if (country.name === countriesLabels.aruba ||country.name === countriesLabels.saba ||country.name === countriesLabels.sintEustatius ||country.name === countriesLabels.saintKittsAndNevis || country.name === countriesLabels.montserrat) {
                country.rect.setOrigin(1,0.5);
                country.txt.setOrigin(1,0.5);
                country.txt.x -= 1;
            }
            else if (country.name === countriesLabels.bonaire || country.name === countriesLabels.trinidadAndTobago || country.name === countriesLabels.turksAndCaicos || country.name === countriesLabels.britishVirginIslands || country.name === countriesLabels.grenada || country.name === countriesLabels.saintVincent || country.name === countriesLabels.barbados || country.name === countriesLabels.saintLucia || country.name === countriesLabels.martinique || country.name === countriesLabels.dominica || country.name === countriesLabels.guadeloupe || country.name === countriesLabels.saintBarthelemy || country.name === countriesLabels.antiguaAndBarbuda || country.name === countriesLabels.saintMartin || country.name === countriesLabels.sintMaarten) {
                country.rect.setOrigin(0,0.5);
                country.txt.setOrigin(0,0.5);
                country.txt.x += 1;
            }

            // bring to top text field
            this.caribbeanContainer.bringToTop(country.txt);
    }
    
    displayCaribbean(aScene) {
        // extra
        aScene.extraEnlargement = aScene.add.image(width/2 + 573.5, height/2 - 87, "extraEnlargement");
        aScene.extraSouthAmerica = aScene.add.image(width/2 - 460, height/2 + 257, "extraSouthAmerica");
        // states
        aScene.barbados = aScene.add.sprite(width/2 + 616, height/2 + 348, "barbados");
        aScene.aruba = aScene.add.sprite(width/2 + 11.5, height/2 + 384, "aruba");
        aScene.curacao = aScene.add.sprite(width/2 + 66.5, height/2 + 400, "curacao");
        aScene.bonaire = aScene.add.sprite(width/2 + 113.5, height/2 + 404, "bonaire");
        aScene.trinidadAndTobago = aScene.add.sprite(width/2 + 523, height/2 + 490, "trinidadAndTobago");
        aScene.grenada = aScene.add.sprite(width/2 + 497, height/2 + 402, "grenada");
        aScene.saintVincent = aScene.add.sprite(width/2 + 519, height/2 + 351, "saintVincent");
        aScene.saintLucia = aScene.add.sprite(width/2 + 534, height/2 + 308, "saintLucia");
        aScene.martinique = aScene.add.sprite(width/2 + 530, height/2 + 262, "martinique");
        aScene.dominica = aScene.add.sprite(width/2 + 509, height/2 + 219, "dominica");
        aScene.guadeloupe = aScene.add.sprite(width/2 + 509, height/2 + 173, "guadeloupe");
        aScene.antiguaAndBarbuda = aScene.add.sprite(width/2 + 486, height/2 + 106, "antiguaAndBarbuda");
        aScene.montserrat = aScene.add.sprite(width/2 + 462, height/2 + 145, "montserrat");
        aScene.saintKittsAndNevis = aScene.add.sprite(width/2 + 433.5, height/2 + 117, "saintKittsAndNevis");
        aScene.saintBarthelemy = aScene.add.sprite(width/2 + 431, height/2 + 78, "saintBarthelemy");
        aScene.sintEustatius = aScene.add.sprite(width/2 + 407.5, height/2 + 97, "sintEustatius");
        aScene.saba = aScene.add.sprite(width/2 + 381.5, height/2 + 80, "saba");
        aScene.puertoRico = aScene.add.sprite(width/2 + 219, height/2 + 58, "puertoRico");
        aScene.unitedStatesVirginIslands = aScene.add.sprite(width/2 + 302, height/2 + 64, "unitedStatesVirginIslands");
        aScene.britishVirginIslands = aScene.add.sprite(width/2 + 341, height/2 + 36, "britishVirginIslands");
        aScene.anguilla = aScene.add.sprite(width/2 + 648, height/2 - 185, "anguilla");
        aScene.saintMartin = aScene.add.sprite(width/2 + 666, height/2 - 120, "saintMartin");
        aScene.sintMaarten = aScene.add.sprite(width/2 + 656, height/2 - 84.5, "sintMaarten");
        aScene.dominicanRepublic = aScene.add.sprite(width/2, height/2 + 28, "dominicanRepublic");
        aScene.haiti = aScene.add.sprite(width/2 - 163, height/2 + 8, "haiti");
        aScene.turksAndCaicos = aScene.add.sprite(width/2 - 84, height/2 - 139, "turksAndCaicosIslands");
        aScene.bahamas = aScene.add.sprite(width/2 - 320, height/2 - 268, "bahamas");
        aScene.cuba = aScene.add.sprite(width/2 - 542, height/2 - 136, "cuba");
        aScene.jamaica = aScene.add.sprite(width/2 - 395, height/2 + 78, "jamaica");
        aScene.caymanIslands = aScene.add.sprite(width/2 - 595, height/2 - 19, "caymanIslands");
        // lines connected to labels
        aScene.aruba.lineX = aScene.aruba.x - 35;
        aScene.aruba.lineY = aScene.aruba.y;
        aScene.bonaire.lineX = aScene.bonaire.x + 10;
        aScene.bonaire.lineY = aScene.bonaire.y + 20;
        aScene.curacao.lineX = aScene.curacao.x;
        aScene.curacao.lineY = aScene.curacao.y + 30;
        aScene.saintMartin.lineX = aScene.saintMartin.x;
        aScene.saintMartin.lineY = aScene.saintMartin.y;
        aScene.sintMaarten.lineX = aScene.sintMaarten.x + 10;
        aScene.sintMaarten.lineY = aScene.sintMaarten.y;
        aScene.trinidadAndTobago.lineX = aScene.trinidadAndTobago.x - 10;
        aScene.trinidadAndTobago.lineY = aScene.trinidadAndTobago.y + 25;
        aScene.turksAndCaicos.lineX = aScene.turksAndCaicos.x + 20;
        aScene.turksAndCaicos.lineY = aScene.turksAndCaicos.y - 40;
        aScene.unitedStatesVirginIslands.lineX = aScene.unitedStatesVirginIslands.x;
        aScene.unitedStatesVirginIslands.lineY = aScene.unitedStatesVirginIslands.y - 25;
        aScene.britishVirginIslands.lineX = aScene.britishVirginIslands.x;
        aScene.britishVirginIslands.lineY = aScene.britishVirginIslands.y - 35;
        aScene.puertoRico.lineX = aScene.puertoRico.x;
        aScene.puertoRico.lineY = aScene.puertoRico.y;
        aScene.grenada.lineX = aScene.grenada.x + 19;
        aScene.grenada.lineY = aScene.grenada.y + 38;
        aScene.saintVincent.lineX = aScene.saintVincent.x + 19;
        aScene.saintVincent.lineY = aScene.saintVincent.y + 38;
        aScene.barbados.lineX = aScene.barbados.x + 17;
        aScene.barbados.lineY = aScene.barbados.y;
        aScene.saintLucia.lineX = aScene.saintLucia.x + 15;
        aScene.saintLucia.lineY = aScene.saintLucia.y - 5;
        aScene.martinique.lineX = aScene.martinique.x + 18;
        aScene.martinique.lineY = aScene.martinique.y - 5;
        aScene.dominica.lineX = aScene.dominica.x + 18;
        aScene.dominica.lineY = aScene.dominica.y - 5;
        aScene.guadeloupe.lineX = aScene.guadeloupe.x + 25;
        aScene.guadeloupe.lineY = aScene.guadeloupe.y - 9;
        aScene.antiguaAndBarbuda.lineX = aScene.antiguaAndBarbuda.x + 25;
        aScene.antiguaAndBarbuda.lineY = aScene.antiguaAndBarbuda.y - 9;
        aScene.saintBarthelemy.lineX = aScene.saintBarthelemy.x + 11;
        aScene.saintBarthelemy.lineY = aScene.saintBarthelemy.y - 10;
        aScene.saba.lineX = aScene.saba.x - 8;
        aScene.saba.lineY = aScene.saba.y + 25;
        aScene.sintEustatius.lineX = aScene.sintEustatius.x - 7;
        aScene.sintEustatius.lineY = aScene.sintEustatius.y + 52;
        aScene.saintKittsAndNevis.lineX = aScene.saintKittsAndNevis.x - 5;
        aScene.saintKittsAndNevis.lineY = aScene.saintKittsAndNevis.y + 62;
        aScene.montserrat.lineX = aScene.montserrat.x;
        aScene.montserrat.lineY = aScene.montserrat.y + 63;
        // reposition other labels
        aScene.caymanIslands.labelX = aScene.caymanIslands.x;
        aScene.caymanIslands.labelY = aScene.caymanIslands.y + 50;
        aScene.cuba.labelX = aScene.cuba.x;
        aScene.cuba.labelY = aScene.cuba.y - 30;
        aScene.jamaica.labelX = aScene.jamaica.x;
        aScene.jamaica.labelY = aScene.jamaica.y + 30;
        aScene.haiti.labelX = aScene.haiti.x;
        aScene.haiti.labelY = aScene.haiti.y - 10;
        aScene.dominicanRepublic.labelX = aScene.dominicanRepublic.x;
        aScene.dominicanRepublic.labelY = aScene.dominicanRepublic.y + 5;
        aScene.curacao.labelX = aScene.curacao.x - 35;
        aScene.curacao.labelY = aScene.curacao.y + 50;
        aScene.aruba.labelX = aScene.aruba.x - 50;
        aScene.aruba.labelY = aScene.aruba.y;
        aScene.bonaire.labelX = aScene.bonaire.x + 20;
        aScene.bonaire.labelY = aScene.bonaire.y + 37;
        aScene.saintMartin.labelX = aScene.saintMartin.x + 60;
        aScene.saintMartin.labelY = aScene.saintMartin.y;
        aScene.sintMaarten.labelX = aScene.sintMaarten.x + 70;
        aScene.sintMaarten.labelY = aScene.sintMaarten.y;
        aScene.trinidadAndTobago.labelX = aScene.trinidadAndTobago.x + 25;
        aScene.trinidadAndTobago.labelY = aScene.trinidadAndTobago.y + 50;
        aScene.turksAndCaicos.labelX = aScene.turksAndCaicos.x + 55;
        aScene.turksAndCaicos.labelY = aScene.turksAndCaicos.y - 70;
        aScene.unitedStatesVirginIslands.labelX = aScene.unitedStatesVirginIslands.x - 20;
        aScene.unitedStatesVirginIslands.labelY = aScene.unitedStatesVirginIslands.y - 195;
        aScene.britishVirginIslands.labelX = aScene.britishVirginIslands.x - 30;
        aScene.britishVirginIslands.labelY = aScene.britishVirginIslands.y - 80;
        aScene.puertoRico.labelX = aScene.puertoRico.x - 20;
        aScene.puertoRico.labelY = aScene.puertoRico.y - 85;
        aScene.grenada.labelX = aScene.grenada.x + 117;
        aScene.grenada.labelY = aScene.grenada.y + 74;
        aScene.saintVincent.labelX = aScene.saintVincent.x + 117;
        aScene.saintVincent.labelY = aScene.saintVincent.y + 74;
        aScene.barbados.labelX = aScene.barbados.x + 60;
        aScene.barbados.labelY = aScene.barbados.y;
        aScene.saintLucia.labelX = aScene.saintLucia.x + 95;
        aScene.saintLucia.labelY = aScene.saintLucia.y - 16;
        aScene.martinique.labelX = aScene.martinique.x + 100;
        aScene.martinique.labelY = aScene.martinique.y - 15;
        aScene.dominica.labelX = aScene.dominica.x + 100;
        aScene.dominica.labelY = aScene.dominica.y - 15;
        aScene.guadeloupe.labelX = aScene.guadeloupe.x + 100;
        aScene.guadeloupe.labelY = aScene.guadeloupe.y - 15;
        aScene.antiguaAndBarbuda.labelX = aScene.antiguaAndBarbuda.x + 100;
        aScene.antiguaAndBarbuda.labelY = aScene.antiguaAndBarbuda.y - 15;
        aScene.saintBarthelemy.labelX = aScene.saintBarthelemy.x + 90;
        aScene.saintBarthelemy.labelY = aScene.saintBarthelemy.y - 30;
        aScene.saba.labelX = aScene.saba.x - 70;
        aScene.saba.labelY = aScene.saba.y + 50;
        aScene.sintEustatius.labelX = aScene.sintEustatius.x - 50;
        aScene.sintEustatius.labelY = aScene.sintEustatius.y + 100;
        aScene.saintKittsAndNevis.labelX = aScene.saintKittsAndNevis.x - 45;
        aScene.saintKittsAndNevis.labelY = aScene.saintKittsAndNevis.y + 115;
        aScene.montserrat.labelX = aScene.montserrat.x - 40;
        aScene.montserrat.labelY = aScene.montserrat.y + 120;
        // names
        aScene.barbados.name = countriesLabels.barbados;
        aScene.aruba.name = countriesLabels.aruba;
        aScene.curacao.name = countriesLabels.curacao;
        aScene.bonaire.name = countriesLabels.bonaire;
        aScene.trinidadAndTobago.name = countriesLabels.trinidadAndTobago;
        aScene.saintVincent.name = countriesLabels.saintVincent;
        aScene.grenada.name = countriesLabels.grenada;
        aScene.saintLucia.name = countriesLabels.saintLucia;
        aScene.dominica.name = countriesLabels.dominica;
        aScene.martinique.name = countriesLabels.martinique;
        aScene.guadeloupe.name = countriesLabels.guadeloupe;
        aScene.montserrat.name = countriesLabels.montserrat;
        aScene.antiguaAndBarbuda.name = countriesLabels.antiguaAndBarbuda;
        aScene.saintKittsAndNevis.name = countriesLabels.saintKittsAndNevis;
        aScene.saintBarthelemy.name = countriesLabels.saintBarthelemy;
        aScene.sintEustatius.name = countriesLabels.sintEustatius;
        aScene.saba.name = countriesLabels.saba;
        aScene.puertoRico.name = countriesLabels.puertoRico;
        aScene.britishVirginIslands.name = countriesLabels.britishVirginIslands;
        aScene.unitedStatesVirginIslands.name = countriesLabels.usVirginIslands;
        aScene.anguilla.name = countriesLabels.anguilla;
        aScene.sintMaarten.name = countriesLabels.sintMaarten;
        aScene.saintMartin.name = countriesLabels.saintMartin;
        aScene.turksAndCaicos.name = countriesLabels.turksAndCaicos;
        aScene.haiti.name = countriesLabels.haiti;
        aScene.dominicanRepublic.name = countriesLabels.dominicanRepublic;
        aScene.bahamas.name = countriesLabels.bahamas;
        aScene.cuba.name = countriesLabels.cuba;
        aScene.jamaica.name = countriesLabels.jamaica;
        aScene.caymanIslands.name = countriesLabels.caymanIslands;
 
        // create container and put countries into it
        aScene.caribbeanContainer = aScene.add.container(0, 0, [ aScene.barbados, aScene.aruba, aScene.curacao, aScene.bonaire, aScene.trinidadAndTobago, aScene.saintVincent, aScene.grenada, aScene.saintLucia, aScene.martinique, aScene.guadeloupe, aScene.dominica, aScene.antiguaAndBarbuda, aScene.saintKittsAndNevis, aScene.montserrat, aScene.saintBarthelemy, aScene.saba, aScene.sintEustatius, aScene.puertoRico, aScene.unitedStatesVirginIslands, aScene.britishVirginIslands, aScene.anguilla, aScene.sintMaarten, aScene.saintMartin, aScene.haiti, aScene.dominicanRepublic,aScene.bahamas, aScene.cuba, aScene.jamaica, aScene.caymanIslands, aScene.turksAndCaicos ]);
        
        aScene.caribbeanContainer.setSize(width, height);
        aScene.caribbeanContainer.x = 0;
        aScene.caribbeanContainer.y = 0;     
     }
}
