var mouseIsDown = false;
var distX = 0;

function mouseDown(){
    	//set the mouseIsDown to true
        mouseIsDown = true;
        startX = game.input.y;
}

function mouseUp(){
       mouseIsDown = false;
}

function swipeDone() {
    //get the ending point
    var endX = game.input.y;

    if (endX < startX) {
        capitalsGroup.y -= distX / 6
    }
    else{
        capitalsGroup.y += distX / 6
    }
}

var libraryState =
{

create: function()
{
    game.input.onUp.add(mouseUp, this);
    game.input.onDown.add(mouseDown, this);

    vy = 0
    number_of_clicks = 0

    // bg blue rectangle
    bg = game.add.image(0, 0, 'bg')

    scroll_up = false
	scroll_down = false
    number_of_clicks = 0

    // group contains capitals
    capitalsGroup = game.add.group()
    capitalsGroup.y = 100

    // capitals and countries #66d940 green color
    let y_pos = 10;
    for (let i = 0; i < countriesAlphabet.length; i++) {

        // get index of a capital in original array
        let index = countries.indexOf(countriesAlphabet[i]);

        // saint vincent only
        if (index === 116) {
            country_name = game.add.text(W/2 - 8, y_pos + 34,countriesAlphabet[i], {font:"16px semiBold", fill:"#000000"}, capitalsGroup);
        }
        // car uae
        else if ( index === 7 || index === 54) {
            country_name = game.add.text(W/2 - 8, y_pos + 33,countriesAlphabet[i], {font:"17px semiBold", fill:"#000000"}, capitalsGroup);
        }
		     //  united states papua st kitts
        else if ( index === 137 || index === 191 || index === 104) {
            country_name = game.add.text(W/2 - 8, y_pos + 33,countriesAlphabet[i], {font:"18px semiBold", fill:"#000000"}, capitalsGroup);
        }
		 else if ( index === 52 || index === 44 || index === 45 || index === 47 || index === 129  || index === 133 || index === 137 || index === 155 || index === 170 ) {
            country_name = game.add.text(W/2 - 8, y_pos + 33,countriesAlphabet[i], {font:"19px semiBold", fill:"#000000"}, capitalsGroup);
        }
		
        else {
            country_name = game.add.text(W/2 - 8, y_pos + 30,countriesAlphabet[i], {font:"22px semiBold", fill:"#000000"}, capitalsGroup);
        }
        country_name.anchor.setTo(1, 0);

        // capitals
        
        // Bandar Seri Begawan small font size
        if (index === 60) {
            capital_name = game.add.text(W/2 + 8, y_pos + 31, capitals[index], {font:"21px semiBold", fill:"#30cd42"}, capitalsGroup);
            y_pos += 55;
        }
        // Sri Jayawardenepura Kotte
        else if (index === 93) {
            capital_name = game.add.text(W/2 + 8, y_pos + 34, capitals[index], {font:"17px semiBold", fill:"#30cd42"}, capitalsGroup);
            y_pos += 55;
        }
        else {  // all other cities
            capital_name = game.add.text(W/2 + 8, y_pos + 30, capitals[index], {font:"22px semiBold", fill:"#30cd42"}, capitalsGroup);
            y_pos += 50;
        }
    }

    // arrows
	arrow_down = game.add.button(446, 755, 'button_back')
    arrow_down.angle = -90
	arrow_up = game.add.button(480, 105, 'button_back')
    arrow_up.angle = 90
	arrow_up.frame = 1;

	arrow_down.events.onInputOut.add(function(){scroll_down=false;}, this);
	arrow_down.events.onInputDown.add(function()
    {
        scroll_down=true;
    }, this);

	arrow_down.events.onInputUp.add(function(){
        scroll_down=false;}, this);
	arrow_up.events.onInputOut.add(function(){scroll_up=false;}, this);
	arrow_up.events.onInputDown.add(function()
    {
        scroll_up=true
    }, this);
	arrow_up.events.onInputUp.add(function(){
        scroll_up=false;
    }, this);

    // blue rectangle on top
    bg_top = game.add.image(0,0,'bg_top')

    // text options
    textLibrary = game.add.text(W - 30, 22, library_label, {font:"32px extraBold", fill:"#000000"});
    textLibrary.anchor.setTo(1,0)
    button_library = game.add.button(W - 35 - textLibrary.width, 18, 'button_library')
    button_library.anchor.setTo(1,0)
    button_library.scale.x = .8
    button_library.scale.y = .8

    // button back
    button_back_small = game.add.button(20, 21, 'button_back')
    text_back = game.add.text(55, 23, back_label, {font:"26px bold", fill:"#000000"});
    button_back_clickable = game.add.button(10, 20, 'button_invisible', go_to_menu)
    button_back_clickable.width = 60 + text_back.width
    button_back_clickable.height = 40

    // mouse wheel on desktop
    if (game.device.desktop) {
        mouseWheelScroll();
    }
    
},

update: function()
{
    if (mouseIsDown === true)
    {
        //get the distance between the start and end point
        distX = Math.abs(game.input.y - startX);
        //if the distance is greater than 50 pixels then a swipe has happened
        if (distX > 50)
        {
            if (distX > 100)
            {
                distX = 100
            }
            swipeDone();
        }
    }

    // tap buttons to scroll
	if (scroll_down === true){
		capitalsGroup.y -= 10;
	}
	else if (scroll_up === true){
		capitalsGroup.y += 10;
	}

    if (capitalsGroup.y < -9200)
    {
        capitalsGroup.y = -9200
    }
    else if (capitalsGroup.y > 100)
    {
        capitalsGroup.y = 100
    }
}
}
