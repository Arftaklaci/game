var game = new Phaser.Game(500, 800, Phaser.Canvas, null, null, true)

game.global = 
{
	orientated : false
}

collator = "en"
var webURL = "https://world-geography-games.com/europe.html";
var websiteName = "World Geography Games";
 
title_label = "Flags of\n Europe"
title_oneline = "Flags of Europe"
play_again_label = "Play again"
stop_label = "Stop"
score_label = "Score: "
next_label = "Next flag"
out_of_label = "out of"

play_label = "play"
options_label = "options"
select_atleast_label = "Select at least 5 flags"
back_label = "back"
sound_label = "SOUND"
number_of_flags_label = "NUMBER OF FLAGS"
flags_label = "FLAGS"
northern_label = "Northern Europe"
central_and_eastern_label = "Central and Eastern Europe"
southern_label = "Southern Europe"
western_label = "Western Europe"
microstates_label = "Microstates"
select_label = "select"
library_label = "library"

countries = ["Albania", "Andorra", "Austria", "Belarus", "Belgium", "Bosnia and Herzegovina", "Bulgaria", "Croatia", "Cyprus", "Czech Republic", "Denmark", "Estonia", "Finland", "France", "Germany", "Greece", "Hungary", "Iceland", "Ireland", "Italy", "Kosovo", "Latvia", "Liechtenstein", "Lithuania", "Luxembourg", "Malta", "Moldova", "Monaco", "Montenegro", "Netherlands", "North Macedonia", "Norway", "Poland", "Portugal", "Romania", "Russia", "San Marino", "Serbia", "Slovakia", "Slovenia", "Spain", "Sweden", "Switzerland", "Ukraine", "United Kingdom", "Vatican City"]

countries_alphabet = countries.slice().sort(Intl.Collator(collator).compare); 

// how many flags selected, 46 by default
flags_used = 46

// frames that will be used (frames represent flags)
frames = []
for (var f = 0; f < flags_used; f++)
{
    frames.push(f)
}

// always contains all frames, get random flags from this array
all_frames = frames.slice()

// regions
central_and_eastern_europe =[0,3,5,6,7,9,16,20,26,28,30, 32,34,35,37,38,39,43]
western_europe = [1,2,4,13,14,18,22,24,27,29,42,44]
southern_europe = [8,15,19,25,33,36,40,45]
northern_europe = [10,11,12,17,21,23,31,41]
microstates_europe = [1,22,27,36,45]

// toggle buttons used for regions, possible frame 0 or 1
central_btn = 0
western_btn = 0
southern_btn = 0
northern_btn = 0
microstates_btn = 0

// toggle buttons used for countries, possible frame 0 or 1
toggle_button_frames = []

for (var i = 0; i < frames.length; i++)
{
    // by default all buttons are on (frame 0)
    toggle_button_frames.push(0)
}

// sound toggle button
sound_frame = 0

// selecting regions or countries in options (back butt on depends on this)
selecting_regions = true

// countries have lookalikes
have_lookalikes = [0,1,2,3,4,6,7,10,14,16,17,18,19,21,24,25,26,27,28,29,31,32, 33,34,35,37,38,39,42];

// lookalikes
lookalikes = [
[28],[26,34],[21,10],[35],[14],[16],[29,38],[42],[4],[6],[41],[19],[18],[10,2],[29,35],[32,27],[1,34],[32,25],[0],[24,7],[10,17],[27,25],[3],[1,26], [38,39],[38],[35,39],[35,38],[10]
];

// game states
game.state.add('boot', bootState);
game.state.add("Loading", loading);
game.state.add("menu", menuState);
game.state.add("options", optionsState);
game.state.add("library", libraryState);
game.state.add("level1", state1);
game.state.start("boot");

