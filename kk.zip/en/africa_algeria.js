"use strict"
var width, height, resize;

// edit below
var collator = "en";
var webUrl = "https://world-geography-games.com/africa.html";

var labels =
{
    website         : "World Geography Games",
    title           : "Algeria: Provinces",
    titleTwo        : "Algeria:\nProvinces",
    play            : "play",
    options         : "options",
    map             : "map",
    tapStart        : "Tap on the map to start",
    clickStart      : "Click on the map to start\nUse mouse wheel to zoom",
    incorrect       : "Incorrect. Try again!",
    score           : "Score: ",
    attempts        : "Attempts: ",
    attemptsEnd     : "Attempts",
    countries       : "Provinces",
    sound           : "SOUND",
	  numOfCountries  : "Number of Provinces",
	  select          : "select",
    selectAtleast   : "Please select at least 5 provinces",
    back            : "back",
    map             : "map",
    playAgain       : "Play Again",
    stop            : "Stop",
    skip            : "Skip",
    skipped         : "Skipped",

    region1         : "Le Tell central",
    region2         : "Le Tell occidental",
    region3         : "Le Tell oriental",
    region4         : "Hauts Plateaux",
    region5         : "Sahara"
}

var countriesLabels = {
  // Le Tell central
  algiers:       "Algiers", 
  tipaza:        "Tipaza", 
  blida:         "Blida", 
  boumerdes:     "Boumerdès", 
  ainDefla:      "Aïn Defla", 
  medea:         "Médéa", 
  chlef:         "Chlef", 
  bouira:        "Bouira", 
  bejaia:        "Bejaïa", 
  tiziOuzou:     "Tizi Ouzou", 
  // Le Tell occidental
  oran:          "Oran", 
  mostaganem:    "Mostaganem", 
  mascara:       "Mascara", 
  sidiBelAbbes:  "Sidi Bel Abbès", 
  relizane:      "Relizane", 
  ainTemouchent: "Aïn Témouchent", 
  tlemcen:       "Tlemcen", 
  // Le Tell oriental
  constantine:   "Constantine",
  mila:          "Mila",
  skikda:        "Skikda", 
  annaba:        "Annaba",
  elTaref:       "El Taref", 
  soukAhras:     "Souk Ahras", 
  guelma:        "Guelma",
  jijel:         "Jijel",
  // Hauts Plateaux
  bordjBouArreridj: "Bordj Bou Arreridj",
  setif:            "Sétif",
  oumElBouaghi:     "Oum El Bouaghi",
  batna:            "Batna",
  khenchela:        "Khenchela",
  tebessa:          "Tébessa",
  djelfa:           "Djelfa",
  laghouat:         "Laghouat", 
  msila:            "M’Sila",
  tissemsilt:       "Tissemsilt",
  tiaret:           "Tiaret",
  saida:            "Saïda",
  naama:            "Naâma",
  elBayadh:         "El Bayadh",
  // Sahara
  adrar:            "Adrar", 
  bechar:           "Béchar", 
  beniAbbes:        "Béni Abbès",
  biskra:           "Biskra",
  bordjBajiMokhtar: "Bordj Baji Mokhtar",
  djanet:           "Djanet",
  ElMGhair:         "El M'Ghair",
  elOued:           "El Oued",
  elMenia:          "El Menia", 
  ghardaia:         "Ghardaïa",
  illizi:           "Illizi",
  inGuezzam:        "In Guezzam",
  inSalah:          "In Salah",
  ouargla:          "Ouargla",
  ouledDjellal:     "Ouled Djellal",
  tamanrasset:      "Tamanrasset",
  timimoun:         "Timimoun",
  tindouf:          "Tindouf",
  touggourt:        "Touggourt"
}

// don't edit below
var attempts = +0;
var skips = +0;
var questionsArray = Object.values(countriesLabels);
const questionsArrayStatic = questionsArray.slice();

// Le Tell central 
var region1Array = [];
for (let x = 0; x < 10; x++) {
  region1Array.push(questionsArray[x]);
}
// Le Tell occidental
var region2Array = [];
for (let x = 10; x < 17; x++) {
  region2Array.push(questionsArray[x]);
}
// Le Tell oriental
var region3Array = [];
for (let x = 17; x < 25; x++) {
  region3Array.push(questionsArray[x]);
}
// Hauts Plateaux
var region4Array = [];
for (let x = 25; x < 39; x++) {
  region4Array.push(questionsArray[x]);
}
// Sahara
var region5Array = [];
for (let x = 39; x < 58; x++) {
  region5Array.push(questionsArray[x]);
}

// toggle buttons, by default they are green (frame 0)
var btnRegion1Frame = 0;
var btnRegion2Frame = 0;
var btnRegion3Frame = 0;
var btnRegion4Frame = 0;
var btnRegion5Frame = 0;
var soundButtonFrame = 0;

var toggleButtonsFrames = [];
for (let x = 0; x < questionsArrayStatic.length; x++) {
  toggleButtonsFrames.push(+0);
}

// you can see list of regions or states
var regionsVisible = true;

function tweenObj(aScene, obj, fromN, toN) {
  obj.alpha = fromN;

  aScene.tweens.add({
      targets: [obj],
      alpha: { value: toN },
      ease: 'Linear',
      duration: 400,
  });
}

// resize
const DEFAULT_WIDTH = 1280
const DEFAULT_HEIGHT = 720
const MAX_WIDTH = DEFAULT_WIDTH * 1.5
const MAX_HEIGHT = DEFAULT_HEIGHT * 1.5
let SCALE_MODE = 'SMOOTH'

const config = {
    type: Phaser.AUTO,
    parent: 'geo-game',
    backgroundColor : 0x34C5EB,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,

    scale: 
    {
        mode: Phaser.Scale.NONE,
        parent: "geo-game",
    },
    scene: [Loading, Menu, UserInterface, GraphUI, Gameplay, Options, Graph]
}

window.addEventListener('load', () => {
    const game = new Phaser.Game(config)
  
    const resize = () => {
      const w = window.innerWidth
      const h = window.innerHeight
  
      let width = DEFAULT_WIDTH
      let height = DEFAULT_HEIGHT
      let maxWidth = MAX_WIDTH
      let maxHeight = MAX_HEIGHT
      let scaleMode = SCALE_MODE
  
      let scale = Math.min(w / width, h / height)
      let newWidth = Math.min(w / scale, maxWidth)
      let newHeight = Math.min(h / scale, maxHeight)
  
      let defaultRatio = DEFAULT_WIDTH / DEFAULT_HEIGHT
      let maxRatioWidth = MAX_WIDTH / DEFAULT_HEIGHT
      let maxRatioHeight = DEFAULT_WIDTH / MAX_HEIGHT
  
      // smooth scaling
      let smooth = 1
      if (scaleMode === 'SMOOTH') {
        const maxSmoothScale = 1.15
        const normalize = (value, min, max) => {
          return (value - min) / (max - min)
        }
        if (width / height < w / h) {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioWidth) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        } else {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioHeight) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        }
      }

      // resize the game
      game.scale.resize(newWidth * smooth, newHeight * smooth)
      // scale the width and height of the css
      game.canvas.style.width = newWidth * scale + 'px'
      game.canvas.style.height = newHeight * scale + 'px'
      // center the game with css margin
      game.canvas.style.marginTop = `${(h - newHeight * scale) / 2}px`
      game.canvas.style.marginLeft = `${(w - newWidth * scale) / 2}px`
    }

    window.addEventListener('resize', event => {
      resize()
    })
  
    resize()
  })
