class Loading extends Phaser.Scene
{    
    constructor()
    {
        super({
            
            key   : 'loading',
            pack  : 
            {
                files : 
                [
                    // pre-preload these images
                    { type: 'image', key: 'preloader1', url: '/games/countries/america_peru/img/preloader1.png' },
                    { type: 'image', key: 'preloader2', url: '/games/countries/america_peru/img/preloader2.png' },
                    { type: 'image', key: 'btnPlay', url: '/games/countries/america_peru/img/btnPlay.png' },
                ] 
            }
        })
    }
    
    setPreloadSprite (sprite) 
    {
		this.preloadSprite = { sprite: sprite, width: sprite.width, height: sprite.height }
		sprite.visible = true
		// set callback for loading progress updates
		this.load.on('progress', this.onProgress, this);
	}
	
	onProgress (value) {
		if (this.preloadSprite) {
			// calculate width based on value (0.0 .. 1.0)
            let w = Math.floor(this.preloadSprite.width * value);
			// set width of sprite			
			this.preloadSprite.sprite.frame.width = w;
            this.preloadSprite.sprite.frame.cutWidth = w;
			// update screen
            this.preloadSprite.sprite.frame.updateUVs();
            // adjust positions while loading
            this.setPositions();
		}
    }
    
    preload(){

        // load custom fonts (extra bold loaded in index.html)
        this.font1 = this.add.text(0, 0, 'custom font', {
            fontFamily: "regular", fontSize: 16, color: '#000000'
        });
        this.font1.setVisible(false);
        this.font3 = this.add.text(0, 0, 'custom font', {
            fontFamily: "semiBold", fontSize: 16, color: '#000000'
        });
        this.font3.setVisible(false);
        this.font2 = this.add.text(0, 0, 'custom font', {
            fontFamily: "bold", fontSize: 16, color: '#000000'
        });
        this.font2.setVisible(false);

        // init width and height
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        // display loading bar
		this.preloader1 = this.add.sprite(width/2, height/2 + 400, "preloader1");
		this.preloader2 = this.add.sprite(width/2, height/2 + 400, "preloader2");
        this.setPreloadSprite(this.preloader2);
        // play button
        this.btnPlay = this.add.image(width/2, height/2 + 400, "btnPlay");
        this.btnPlay.setVisible(false);
        // display text
        this.txtWebsite = this.add.text(width/2, height/2 - 350, labels.website, { fontFamily: "extraBold", fontSize: 60, color: '#000000', align: 'center' });
        this.txtTitle = this.add.text(width/2, height/2 - 275, labels.title, { fontFamily: "extraBold", fontSize: 60, color: '#FFFFFF', align: 'center' });
        this.txtTitle.setOrigin(0.5, 0.5);
        this.txtWebsite.setOrigin(0.5, 0.5);
        // animation
        this.load.spritesheet('armadillo2', '/games/countries/america_peru/img/armadillo2.png', {frameWidth: 300, frameHeight: 204});
        // regions
        this.load.atlas('texture', '/games/countries/america_peru/img/texture.png', '/games/countries/america_peru/img/texture.json');
        this.load.image('armadillo1', '/games/countries/america_peru/img/armadillo1.png');
        
        // buttons
        this.load.spritesheet('button', '/games/countries/america_peru/img/button.png', {frameWidth: 420, frameHeight: 62});
        this.load.image('btnPlay', '/games/countries/america_peru/img/btnPlay.png');
        this.load.image('buttonBack', '/games/countries/america_peru/img/buttonBack.png');
        this.load.image('buttonBackBlack', '/games/countries/america_peru/img/buttonBackBlack.png');
        this.load.image('buttonStart', '/games/countries/america_peru/img/buttonStart.png');
        this.load.image('buttonMap', '/games/countries/america_peru/img/buttonMap.png');
        this.load.image('buttonMapWhite', '/games/countries/america_peru/img/buttonMapWhite.png');
        // images
		this.load.image('map', '/games/countries/america_peru/img/map.png');
		this.load.spritesheet('bgQuestion', '/games/countries/america_peru/img/bgQuestion.png', { frameWidth: 500, frameHeight: 65 });
		this.load.image('bgWhite', '/games/countries/america_peru/img/bgWhite.jpg');
		this.load.image('rectangle', '/games/countries/america_peru/img/rectangle.jpg');
		this.load.image('circle', '/games/countries/america_peru/img/circle.png');
		this.load.image('circleGreen', '/games/countries/america_peru/img/circleGreen.png');
		this.load.image('circleYellow', '/games/countries/america_peru/img/circleYellow.png');
		this.load.image('circleRed', '/games/countries/america_peru/img/circleRed.png');
		this.load.spritesheet('buttonSound', '/games/countries/america_peru/img/buttonSound.png', { frameWidth: 42, frameHeight: 52 });
        // update plugins url
        this.url = '/phaser/plugins/pinchplugin.min.js';
        this.url2 = '/phaser/plugins/mousewheelplugin.min.js';
        this.url3 = '/phaser/plugins/rexscrollerplugin.min.js';
        
        this.load.plugin('rexpinchplugin', this.url, true);
        this.load.plugin('rexmousewheeltoupdownplugin', this.url2, true);
        this.load.plugin('rexscrollerplugin', this.url3, true);
        // update sounds url
		this.load.audio('wrongSound', ['/phaser/audio/wrongSound.mp3', '/phaser/audio/wrongSound.ogg']);
		this.load.audio('correctSound', ['/phaser/audio/correctSound.mp3', '/phaser/audio/correctSound.ogg']);
        this.load.audio('gameOverSound', ['/phaser/audio/gameOverSound.mp3', '/phaser/audio/gameOverSound.mp3']);
    }
    
    create() {    

        // play button
        this.btnPlay.setVisible(true);
        this.btnPlay.setInteractive({useHandCursor: true})
        this.btnPlay.on("pointerup", () => { 
            this.scene.start("menu");
        }, this);

        // remove preloader
        this.preloader1.destroy();
        this.preloader2.destroy();
        
        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on("resize", (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.preloader1.setPosition(width/2, height/2 + 400);
        this.preloader2.setPosition(width/2, height/2 + 400);
        this.btnPlay.setPosition(width/2, height/2 + 400);
        this.txtTitle.setPosition(width/2, height/2 - 275);
        this.txtWebsite.setPosition(width/2, height/2 - 350);
    }
}