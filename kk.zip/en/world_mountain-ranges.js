"use strict"
var width, height, resize;
var webUrl = "https://world-geography-games.com/world.html";

var labels = 
{
    website         : "World Geography Games",
    title           : "Mountain Ranges",
    titleTwo        : "Mountain\nRanges",
    play            : "play",
    options         : "options",
    map             : "map",
    sound           : "SOUND",
    photos          : "PHOTOS",
    tapStart        : "Tap on the map to start",
    clickStart      : "Click on the map to start",
    incorrect       : "Incorrect. Try again!",
    score           : "Score: ",
    attempts        : "Attempts: ",
    attemptsEnd     : "Attempts",
    points          : "Points",
    back            : "back",
    playAgain       : "Play Again",
    stop            : "Stop",
    skip            : "Skip",
    skipped         : "Skipped",
}

// the order of labels below is important!
var credits = {
  credit1   : "Photo: Danielle Brigida/USFWS 2019 (CC-BY)",
  credit2   : "Photo: Heikki Holstila 2017 (CC-BY-SA)",
  credit3   : "Photo: Dmitry A. Mottl 2008 (CC-BY-SA)",
  credit4   : "Photo: Massimiliano Marocchi 2018 (Public Domain)",
  credit5   : "Photo: MusikAnimal 2014 (CC-BY-SA)",
  credit6   : "Photo: Tola Akindipe 2014 (CC-BY-SA)",
  credit7   : "Photo: Vicuna R 2016 (CC-BY-SA)",
  credit8   : "Photo: Diriye Amey 2015 (CC-BY)",
  credit9   : "Photo: Georgie Dee 2020 (CC-BY-SA)",
  credit10  : "Photo: Mohit Tomar 2018 (CC-BY)",
  credit11  : "Photo: Mohammad Amri 2015 (CC-BY-SA)",
  credit12  : "Photo: Alllexxxis 2017 (CC-BY-SA)",
  credit13  : "Photo: Ilee_wu 2012 (CC-BY-SA)",
  credit14  : "Photo: Arfani Mujib 2015 (CC-BY-SA)",
  credit15  : "Photo: David Herrera 2020 (CC-BY)",
  credit16  : "Photo: Rodrigo Soldon 2014 (CC-BY-SA)",
  credit17  : "Photo: Alejandro Perez 2017 (CC-BY-SA)",
  credit18  : "Photo: Zeynel Cebeci 2016 (CC-BY-SA)",
  credit19  : "Photo: Chen Zhao 2009 (CC-BY)",
  credit20  : "Photo: Maxim Panteleyev 2015 (CC-BY-SA)"
}

var creditsArray = Object.values(credits);

var subjects = {
  alaskaRange:          "Alaska Range",
  alps:                 "Alps",
  altaiMountains:       "Altai Mountains",
  andes:                "Andes",
  appalachianMountains: "Appalachian Mountains",
  atlasMountains:       "Atlas Mountains",
  caucasusMountains:    "Caucasus Mountains",
  drakensberg:          "Drakensberg",
  greatDividingRange:   "Great Dividing Range",
  himalayas:            "Himalayas",
  hoggarMountains:      "Hoggar Mountains",
  karakoram:            "Karakoram",
  kunlunMountains:      "Kunlun Mountains",
  maokeMountains:       "Maoke Mountains",
  rockyMountains:       "Rocky Mountains",
  serraDoMar:           "Serra Do Mar",
  sierraMadreOccidental:"Sierra Madre Occidental",
  taurusMountains:      "Taurus Mountains",
  tianShan:             "Tian Shan",
  uralMountains:        "Ural Mountains",
}

var countriesNames = ["USA", "Europe", "Central Asia", "South America", "North America", "Maghreb", "Eurasia", "South Africa/Lesotho", "Australia", "Asia", "Algeria", "Asia", "China", "Indonesia", "North America", "Brazil", "Mexico", "Turkey", "Central Asia", "Russia/Kazakhstan"];

var infoText = ["", 
"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""];

// don't edit below

// sound is on by default
var soundButtonFrame = 0;
// show photos by default
var showPhotos = true;
var photosButtonFrame = 0;
// number of attempts
var attempts = +0;
// number of skipped countries
var skips = +0;
// make array
var questionsArray = Object.values(subjects);
var questionsArrayStatic = [...questionsArray];

// resize
const DEFAULT_WIDTH = 1280
const DEFAULT_HEIGHT = 720
const MAX_WIDTH = DEFAULT_WIDTH * 1.5
const MAX_HEIGHT = DEFAULT_HEIGHT * 1.5
let SCALE_MODE = 'SMOOTH'

const config = {
    type: Phaser.AUTO,
    parent: 'geo-game',
    backgroundColor : 0x34C5EB,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,

    scale: 
    {
        mode: Phaser.Scale.NONE,
        parent: "geo-game",
    },
    scene: [Loading, Menu, Options, UserInterface, GraphUI, Gameplay, Graph]
}

window.addEventListener('load', () => {
    const game = new Phaser.Game(config)
  
    resize = () => {
      const w = window.innerWidth
      const h = window.innerHeight
  
      let width = DEFAULT_WIDTH
      let height = DEFAULT_HEIGHT
      let maxWidth = MAX_WIDTH
      let maxHeight = MAX_HEIGHT
      let scaleMode = SCALE_MODE
  
      let scale = Math.min(w / width, h / height)
      let newWidth = Math.min(w / scale, maxWidth)
      let newHeight = Math.min(h / scale, maxHeight)
  
      let defaultRatio = DEFAULT_WIDTH / DEFAULT_HEIGHT
      let maxRatioWidth = MAX_WIDTH / DEFAULT_HEIGHT
      let maxRatioHeight = DEFAULT_WIDTH / MAX_HEIGHT
  
      // smooth scaling
      let smooth = 1
      if (scaleMode === 'SMOOTH') {
        const maxSmoothScale = 1.15
        const normalize = (value, min, max) => {
          return (value - min) / (max - min)
        }
        if (width / height < w / h) {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioWidth) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        } else {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioHeight) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        }
      }

      // resize the game
      game.scale.resize(newWidth * smooth, newHeight * smooth)
      // scale the width and height of the css
      game.canvas.style.width = newWidth * scale + 'px'
      game.canvas.style.height = newHeight * scale + 'px'
      // center the game with css margin
      game.canvas.style.marginTop = `${(h - newHeight * scale) / 2}px`
      game.canvas.style.marginLeft = `${(w - newWidth * scale) / 2}px`
    }

    window.addEventListener('resize', event => {
      resize()
    })
  
    resize()
  })
