"use strict"
var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        });
    }
    
    create() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;
        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;
       camera.zoom = .55;
       camera.scrollY = -50;
        // min max zoom
        this.minZoom = .55;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.6;
        }
        else {
            this.maxZoom = 1.9;
        }
        // display countries in this scene
        this.displayMap(this);
        // get countries (sprites) array from the container
        this.countriesArray = this.mapContainer.getAll();
        // for each subject (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {
            /* development phase - enable drag to position countries
            this.countriesArray[i].setInteractive()
            this.input.setDraggable(this.countriesArray[i]);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {
                gameObject.x = dragX;
                gameObject.y = dragY;
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });
            */
            
            let subject = this.countriesArray[i];
            // make countries sprites interactive
            subject.setInteractive({ 
                useHandCursor: true,             
                pixelPerfect: true,
                alphaTolerance: 255
             });
             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over subject
                subject.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                       subject.setTintFill(0xFFFFFF);
                    }
                },this);
                subject.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        subject.clearTint();
                    }
                },this);
            }
            subject.on('pointerdown', () => {
                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });
            subject.on('pointerup', () => {
                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);
                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    subject.xPos = camera.x;
                    subject.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false) {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === subject.name) {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this subject
                            subject.disableInteractive();
                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }
                            // create the subject label
                            this.showLabels(subject);
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // else don't tap, drag the map
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();
        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false) {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();
                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip, ui.buttonSound],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                let dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {
                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        let drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }
                }).on('pinch', dragScale => {
                    let scaleFactor = dragScale.scaleFactor;
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                }, this);
                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }
        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2 + 100, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 70, align: "center", color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2 + 100, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 70, align: "center", color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });
        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                camera.zoom *= 0.9;
            }
        }
        // limit zoom
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.mapContainer.setSize(width, height);
        this.mapContainer.x = 0;
        this.mapContainer.y = 0;

        this.chile.setPosition(this.neuquen.x - 35, this.neuquen.y - 78.5);

        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2 + 100, height/2);
        }
    }

    getQuestion() {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;
        this.questionsArray.shift();

        if (ui.questionText.text === subjects.newfoundland) {
            ui.questionText.setFontSize(26);
        }
        else {
            ui.questionText.setFontSize(34);
        }

        // tween
        this.tweens.add({
           targets: [ui.questionText],
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;
        // play sound
        this.gameOverSound.play();
        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        ui.buttonSound.destroy();
        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {
        // tween camera
        if (camera.zoom > this.minZoom) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: this.minZoom,
                x: 0, 
                y: 0,
                duration: 1500,
                onComplete: () => {
                    
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }
        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: -20,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showLabels(subject) {
        // create white rectangle
        subject.rect = this.add.sprite(subject.x, subject.y, "rectangle");
        // subject name
        subject.txt = this.add.text(subject.x, subject.y, subject.name, { fontFamily: "bold", fontSize: 28, align: "center", color: '#000000' });
        subject.txt.setOrigin(.5,.5);

        if (subject.name === subjects.santiagoDelEstero) {
            subject.txt.setText("Santiago\ndel Estero")
        }
        else if (subject.name === subjects.tierraDelFuego) {
            // disputed
            this.disputed1 = this.add.text(subject.x + 60, subject.y - 240, labels.disputed, { fontFamily: "bold", fontSize: 28, align: "center", color: '#FFFFFF' });
            subject.txt.setOrigin(.5,.5);

            this.disputed2 = this.add.text(subject.x - 10, subject.y + 20, labels.disputed, { fontFamily: "bold", fontSize: 28, align: "center", color: '#FFFFFF' });
            subject.txt.setOrigin(.5,.5);
        }
        
        // position text
        if (subject.labelX) {
            subject.txt.x = subject.labelX;
            subject.txt.y = subject.labelY;
            subject.rect.x = subject.labelX;
            subject.rect.y = subject.labelY;
        }
        subject.rect.displayWidth = subject.txt.width + 4;
        subject.rect.displayHeight = subject.txt.height + 2;
    }

    displayMap(aScene) {
        // interactive sprites
        aScene.laPampa = aScene.add.sprite(width/2 - 74, height/2 - 137.5, "texture", "laPampa.png");
        aScene.mendoza = aScene.add.sprite(width/2 - 184.5, height/2 - 251, "texture", "mendoza.png");
        aScene.sanLuis = aScene.add.sprite(width/2 - 85.5, height/2 - 290.5, "texture", "sanLuis.png");
        aScene.cordoba = aScene.add.sprite(width/2 + 11.5, height/2 - 370.5, "texture", "cordoba.png");
        aScene.buenosAires = aScene.add.sprite(width/2 + 164.5, height/2 - 137.5, "texture", "buenosAires.png");
        aScene.rioNegro = aScene.add.sprite(width/2 - 134.5, height/2 - 14, "texture", "rioNegro.png");
        aScene.neuquen = aScene.add.sprite(width/2 - 248, height/2 - 70, "texture", "neuquen.png");
        aScene.chubut = aScene.add.sprite(width/2 - 155.5, height/2 + 184.5, "texture", "chubut.png");
        aScene.santaFe = aScene.add.sprite(width/2 + 132, height/2 - 418, "texture", "santaFe.png");
        aScene.entreRios = aScene.add.sprite(width/2 + 196.5, height/2 - 375.5, "texture", "entreRios.png");
        aScene.santaCruz = aScene.add.sprite(width/2 - 230, height/2 + 430, "texture", "santaCruz.png");
        aScene.tierraDelFuego = aScene.add.sprite(width/2 + 35, height/2 + 777, "texture", "tierraDelFuego.png");
        aScene.sanJuan = aScene.add.sprite(width/2 - 188, height/2 - 456.5, "texture", "sanJuan.png");
        aScene.laRioja = aScene.add.sprite(width/2 - 136.5, height/2 - 484, "texture", "laRioja.png");
        aScene.catamarca = aScene.add.sprite(width/2 - 119.5, height/2 - 588, "texture", "catamarca.png");
        aScene.santiagoDelEstero = aScene.add.sprite(width/2 + 24, height/2 - 575.5, "texture", "santiagoDelEstero.png");
        aScene.chaco = aScene.add.sprite(width/2 + 128, height/2 - 660, "texture", "chaco.png");
        aScene.tucuman = aScene.add.sprite(width/2 - 53.5, height/2 - 613.5, "texture", "tucuman.png");
        aScene.salta = aScene.add.sprite(width/2 - 57, height/2 - 748.5, "texture", "salta.png");
        aScene.jujuy = aScene.add.sprite(width/2 - 67, height/2 - 796, "texture", "jujuy.png");
        aScene.formosa = aScene.add.sprite(width/2 + 169, height/2 - 725.5, "texture", "formosa.png");
        aScene.corrientes = aScene.add.sprite(width/2 + 263, height/2 - 522.5, "texture", "corrientes.png");
        aScene.misiones = aScene.add.sprite(width/2 + 379, height/2 - 625, "texture", "misiones.png");

        // reposition labels
        aScene.tierraDelFuego.labelX = aScene.tierraDelFuego.x;
        aScene.tierraDelFuego.labelY = aScene.tierraDelFuego.y - 140;
        aScene.rioNegro.labelX = aScene.rioNegro.x;
        aScene.rioNegro.labelY = aScene.rioNegro.y + 20;
        aScene.cordoba.labelX = aScene.cordoba.x - 5;
        aScene.cordoba.labelY = aScene.cordoba.y - 40;
        aScene.santaFe.labelX = aScene.santaFe.x;
        aScene.santaFe.labelY = aScene.santaFe.y - 30;
        aScene.corrientes.labelX = aScene.corrientes.x + 25;
        aScene.corrientes.labelY = aScene.corrientes.y;
        aScene.sanJuan.labelX = aScene.sanJuan.x - 25;
        aScene.sanJuan.labelY = aScene.sanJuan.y + 10;
        aScene.laRioja.labelX = aScene.laRioja.x;
        aScene.laRioja.labelY = aScene.laRioja.y - 25;
        aScene.formosa.labelX = aScene.formosa.x + 20;
        aScene.formosa.labelY = aScene.formosa.y - 10;
        aScene.salta.labelX = aScene.salta.x + 5;
        aScene.salta.labelY = aScene.salta.y + 40;
        aScene.jujuy.labelX = aScene.jujuy.x - 20;
        aScene.jujuy.labelY = aScene.jujuy.y - 30;
        aScene.santiagoDelEstero.labelX = aScene.santiagoDelEstero.x + 10;
        aScene.santiagoDelEstero.labelY = aScene.santiagoDelEstero.y;
        aScene.tucuman.labelX = aScene.tucuman.x;
        aScene.tucuman.labelY = aScene.tucuman.y - 25;
        aScene.catamarca.labelX = aScene.catamarca.x - 40;
        aScene.catamarca.labelY = aScene.catamarca.y - 15;
        aScene.chaco.labelX = aScene.chaco.x + 10;
        aScene.chaco.labelY = aScene.chaco.y + 10;
        // names
        aScene.laPampa.name = subjects.laPampa;
        aScene.mendoza.name = subjects.mendoza;
        aScene.sanLuis.name = subjects.sanLuis;
        aScene.cordoba.name = subjects.cordoba;
        aScene.buenosAires.name = subjects.buenosAires;
        aScene.rioNegro.name = subjects.rioNegro;
        aScene.neuquen.name = subjects.neuquen;
        aScene.chubut.name = subjects.chubut;
        aScene.santaFe.name = subjects.santaFe;
        aScene.entreRios.name = subjects.entreRios;
        aScene.tierraDelFuego.name = subjects.tierraDelFuego;
        aScene.santaCruz.name = subjects.santaCruz;
        aScene.sanJuan.name = subjects.sanJuan;
        aScene.laRioja.name = subjects.laRioja;
        aScene.catamarca.name = subjects.catamarca;
        aScene.santiagoDelEstero.name = subjects.santiagoDelEstero;
        aScene.chaco.name = subjects.chaco;
        aScene.tucuman.name = subjects.tucuman;
        aScene.salta.name = subjects.salta;
        aScene.jujuy.name = subjects.jujuy;
        aScene.formosa.name = subjects.formosa;
        aScene.corrientes.name = subjects.corrientes;
        aScene.misiones.name = subjects.misiones;

        // create container and put countries into it
        aScene.mapContainer = aScene.add.container(0, 0, [aScene.laPampa, aScene.sanLuis, aScene.mendoza, aScene.cordoba, aScene.buenosAires, aScene.rioNegro, aScene.neuquen, aScene.chubut, aScene.santaFe, aScene.entreRios, aScene.tierraDelFuego, aScene.santaCruz, aScene.sanJuan, aScene.laRioja, aScene.catamarca, aScene.santiagoDelEstero, aScene.chaco, aScene.tucuman, aScene.salta, aScene.jujuy,  aScene.formosa, aScene.corrientes, aScene.misiones]);

        aScene.chile = aScene.add.image(aScene.neuquen.x - 35, aScene.neuquen.y - 78.5, 'texture', 'extraChile.png');

        aScene.mapContainer.setSize(width, height);
        aScene.mapContainer.x = 0;
        aScene.mapContainer.y = 0;
     }
}