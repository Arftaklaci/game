"use strict"

var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        })
    }

    create() {

        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;

        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;
       camera.scrollY = -40;

        // min max zoom
        this.minZoom = 0.8;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.6;
            camera.zoom = 0.9;
        }
        else {
            this.maxZoom = 1.8;
            camera.zoom = 0.9;
        }

        // display countries in this scene
        this.displayStates(this);
       
        // get countries (sprites) array from the container
        this.countriesArray = this.statesContainer.getAll();
        // for each country (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {

            let country = this.countriesArray[i];

            /* development phase
            country.setInteractive()
            this.input.setDraggable(country);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {

                gameObject.x = dragX;
                gameObject.y = dragY;
        
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });
            */

            // make countries sprites interactive
            country.setInteractive({ 
                useHandCursor: true,             
                pixelPerfect: true,
                alphaTolerance: 255
             });

             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over country
                country.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                        if (country.isSpritesheet === true) {
                            country.setFrame(1);
                        }
                        else {
                            country.setTintFill(0xFFFFFF);
                        }
                    }
                },this);

                country.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        if (country.isSpritesheet === true) {
                            country.setFrame(0);
                        }
                        else {
                            country.clearTint();
                        }
                    }
                },this);
            }

            country.on('pointerdown', () => {

                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });

            country.on('pointerup', () => {

                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);

                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    country.xPos = camera.x;
                    country.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false)
                    {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === country.name)
                        {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this country
                            country.disableInteractive();

                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }

                            // create the country label
                            this.showLabels(country);
    
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
    
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // drag
                else {
                    // console.log("don't tap, drag the map");
                }
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();

        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false)
            {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();

                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                var dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {

                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        var drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }

                }).on('pinch', dragScale => {
                    var scaleFactor = dragScale.scaleFactor;
                    
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                    
                }, this);

                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }

        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 65, color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 65, color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });

        // mouse over microstate sprite
        this.mouseOverMicro = this.add.image(0,0, 'mouseOverMicrostate');
        this.mouseOverMicro.setVisible(false);

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                
                camera.zoom *= 0.9;
            }
        }
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.statesContainer.setSize(width, height);
        this.statesContainer.x = 0;
        this.statesContainer.y = 0; 
        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2, height/2);
        }
    }

    getQuestion() {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;
		
		
		 if (ui.questionText.text === countriesLabels.fct) {
            ui.questionText.setFontSize(27);
        }
        else {
            ui.questionText.setFontSize(34);
        }

		
        // tween
        this.tweens.add({
           targets: [ui.questionText],
           //scaleX: '-=.2',
           //angle: 10,
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });
		
		
		
        // remove the previous question
        this.questionsArray.shift();
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;

        // play sound
        this.gameOverSound.play();

        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        ui.buttonSound.destroy();

        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {

        // tween camera
        if (camera.zoom > this.minZoom) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: this.minZoom,
                x: 0, 
                y: 0,
                duration: 2000,
                onComplete: () => {
                    
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }

        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: 0,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showLabels(country) {
            country.txt = this.add.text(country.x, country.y, country.name, { fontFamily: "bold", fontSize: 22, align: "center", color: '#000000' });
            country.txt.setOrigin(.5,.5);
            this.statesContainer.add(country.txt);

            if (country.labelX) {
                country.txt.x = country.labelX;
                country.txt.y = country.labelY;
            }
            // rect
            country.rect = this.add.sprite(country.txt.x, country.txt.y, "rectangle");
            country.rect.displayWidth = country.txt.width + 1;
            country.rect.displayHeight = country.txt.height;
            this.statesContainer.add(country.rect);
            // bring to top
            this.statesContainer.bringToTop(country.txt);
    }
    
    displayStates(aScene) {
        // map
        aScene.map = aScene.add.image(width/2, height/2, 'map');
        aScene.map.alpha = .5;

        // states
        aScene.fct = aScene.add.image(width/2 - 65, height/2 + 29.5, 'texture', 'federal-capital-territory.png');
        aScene.niger = aScene.add.image(width/2 - 224, height/2 - 58, 'texture', 'niger.png');
        aScene.nasarawa = aScene.add.image(width/2 - 16.5, height/2 + 41.5, 'texture', 'nasarawa.png');
        aScene.taraba = aScene.add.image(width/2 + 149, height/2 + 72.5, 'texture', 'taraba.png');
        aScene.plateau = aScene.add.image(width/2 + 89, height/2 - 23.5, 'texture', 'plateau.png');
        aScene.kaduna = aScene.add.image(width/2 - 78.5, height/2 - 92, 'texture', 'kaduna.png');
        aScene.kano = aScene.add.image(width/2 + 17.5, height/2 - 188.5, 'texture', 'kano.png');
        aScene.katsina = aScene.add.image(width/2 - 34, height/2 - 238, 'texture', 'katsina.png');
        aScene.zamfara = aScene.add.image(width/2 - 191.5, height/2 - 222, 'texture', 'zamfara.png');
        aScene.sokoto = aScene.add.image(width/2 - 225, height/2 - 277.5, 'texture', 'sokoto.png');
        aScene.kebbi = aScene.add.image(width/2 - 275.5, height/2 - 196, 'texture', 'kebbi.png');
        aScene.bauchi = aScene.add.image(width/2 + 105, height/2 - 147, 'texture', 'bauchi.png');
        aScene.jigawa = aScene.add.image(width/2 + 63, height/2 - 218, 'texture', 'jigawa.png');
        aScene.gombe = aScene.add.image(width/2 + 223, height/2 - 100, 'texture', 'gombe.png');
        aScene.yobe = aScene.add.image(width/2 + 189, height/2 - 219.5, 'texture', 'yobe.png');
        aScene.adamawa = aScene.add.image(width/2 + 302, height/2 - 15, 'texture', 'adamawa.png');
        aScene.borno = aScene.add.image(width/2 + 341.5, height/2 - 211, 'texture', 'borno.png');
        aScene.benue = aScene.add.image(width/2 + 17.5, height/2 + 134.5, 'texture', 'benue.png');
        aScene.crossRiver = aScene.add.image(width/2 + 17, height/2 + 236, 'texture', 'cross-river.png');
        aScene.kogi = aScene.add.image(width/2 - 137.5, height/2 + 100.5, 'texture', 'kogi.png');
        aScene.edo = aScene.add.image(width/2 - 180, height/2 + 177, 'texture', 'edo.png');
        aScene.ekiti = aScene.add.image(width/2 - 231.5, height/2 + 97.5, 'texture', 'ekiti.png');
        aScene.ondo = aScene.add.image(width/2 - 227.5, height/2 + 163.5, 'texture', 'ondo.png');
        aScene.kwara = aScene.add.image(width/2 - 297, height/2 - 4.5, 'texture', 'kwara.png');
        aScene.oyo = aScene.add.image(width/2 - 346, height/2 + 65.5, 'texture', 'oyo.png');
        aScene.osun = aScene.add.image(width/2 - 262.5, height/2 + 126.5, 'texture', 'osun.png');
        aScene.ogun = aScene.add.image(width/2 - 346, height/2 + 145.5, 'texture', 'ogun.png');
        aScene.lagos = aScene.add.image(width/2 - 348.5, height/2 + 213, 'texture', 'lagos.png');
        aScene.anambra = aScene.add.image(width/2 - 77.5, height/2 + 223, 'texture', 'anambra.png');
        aScene.ebonyi = aScene.add.image(width/2 - 7.5, height/2 + 221.5, 'texture', 'ebonyi.png');
        aScene.enugu = aScene.add.image(width/2 - 53, height/2 + 200, 'texture', 'enugu.png');
        aScene.abia = aScene.add.image(width/2 - 36, height/2 + 281.5, 'texture', 'abia.png');
        aScene.akwaIbom = aScene.add.image(width/2 - 26, height/2 + 314, 'texture', 'akwa-ibom.png');
        aScene.imo = aScene.add.image(width/2 - 75.5, height/2 + 279.5, 'texture', 'imo.png');
        aScene.delta = aScene.add.image(width/2 - 177.5, height/2 + 248.5, 'texture', 'delta.png');
        aScene.bayelsa = aScene.add.image(width/2 - 157, height/2 + 326.5, 'texture', 'bayelsa.png');
        aScene.rivers = aScene.add.image(width/2 - 100, height/2 + 305.5, 'texture', 'rivers.png');

        // position
        aScene.yobe.labelX = aScene.yobe.x + 35;
        aScene.yobe.labelY = aScene.yobe.y - 30;
        aScene.bauchi.labelX = aScene.bauchi.x - 10;
        aScene.bauchi.labelY = aScene.bauchi.y + 45;
        aScene.gombe.labelX = aScene.gombe.x - 20;
        aScene.gombe.labelY = aScene.gombe.y;
        aScene.plateau.labelX = aScene.plateau.x;
        aScene.plateau.labelY = aScene.plateau.y + 20;
        aScene.jigawa.labelX = aScene.jigawa.x + 15;
        aScene.jigawa.labelY = aScene.jigawa.y - 30;
        aScene.kano.labelX = aScene.kano.x - 20;
        aScene.kano.labelY = aScene.kano.y - 20;
        aScene.katsina.labelX = aScene.katsina.x - 30;
        aScene.katsina.labelY = aScene.katsina.y - 30;
        aScene.kaduna.labelX = aScene.kaduna.x + 30;
        aScene.kaduna.labelY = aScene.kaduna.y;
        aScene.kebbi.labelX = aScene.kebbi.x - 50;
        aScene.kebbi.labelY = aScene.kebbi.y - 10;
        aScene.kwara.labelX = aScene.kwara.x - 40;
        aScene.kwara.labelY = aScene.kwara.y - 30;
        aScene.sokoto.labelX = aScene.sokoto.x;
        aScene.sokoto.labelY = aScene.sokoto.y - 35;
        aScene.fct.labelX = aScene.fct.x - 35;
        aScene.fct.labelY = aScene.fct.y - 15;
        aScene.nasarawa.labelX = aScene.nasarawa.x - 10;
        aScene.nasarawa.labelY = aScene.nasarawa.y + 5;
        aScene.lagos.labelX = aScene.lagos.x - 10;
        aScene.lagos.labelY = aScene.lagos.y - 25;
        aScene.ogun.labelX = aScene.ogun.x - 35;
        aScene.ogun.labelY = aScene.ogun.y;
        aScene.oyo.labelX = aScene.oyo.x - 20;
        aScene.oyo.labelY = aScene.oyo.y;
        aScene.osun.labelX = aScene.osun.x - 30;
        aScene.osun.labelY = aScene.osun.y - 20;
        aScene.ekiti.labelX = aScene.ekiti.x - 5;
        aScene.ekiti.labelY = aScene.ekiti.y;
        aScene.ondo.labelX = aScene.ondo.x - 7;
        aScene.ondo.labelY = aScene.ondo.y - 24;
        aScene.delta.labelX = aScene.delta.x - 25;
        aScene.delta.labelY = aScene.delta.y + 10;
        aScene.bayelsa.labelX = aScene.bayelsa.x - 45;
        aScene.bayelsa.labelY = aScene.bayelsa.y - 10;
        aScene.enugu.labelX = aScene.enugu.x - 30;
        aScene.enugu.labelY = aScene.enugu.y - 30;
        aScene.anambra.labelX = aScene.anambra.x - 40;
        aScene.anambra.labelY = aScene.anambra.y - 15;
        aScene.imo.labelX = aScene.imo.x - 30;
        aScene.imo.labelY = aScene.imo.y - 25;
        aScene.ebonyi.labelX = aScene.ebonyi.x - 20;
        aScene.ebonyi.labelY = aScene.ebonyi.y - 15;
        aScene.rivers.labelX = aScene.rivers.x - 25;
        aScene.rivers.labelY = aScene.rivers.y - 5;
        aScene.akwaIbom.labelX = aScene.akwaIbom.x - 15;
        aScene.akwaIbom.labelY = aScene.akwaIbom.y;
        aScene.abia.labelX = aScene.abia.x - 25;
        aScene.abia.labelY = aScene.abia.y - 30;
        aScene.crossRiver.labelX = aScene.crossRiver.x + 10;
        aScene.crossRiver.labelY = aScene.crossRiver.y + 5;

        // names
        aScene.fct.name = countriesLabels.fct;
        aScene.niger.name = countriesLabels.niger;
        aScene.nasarawa.name = countriesLabels.nasarawa;
        aScene.taraba.name = countriesLabels.taraba;
        aScene.plateau.name = countriesLabels.plateau;
        aScene.kaduna.name = countriesLabels.kaduna;
        aScene.kano.name = countriesLabels.kano;
        aScene.katsina.name = countriesLabels.katsina;
        aScene.zamfara.name = countriesLabels.zamfara;
        aScene.sokoto.name = countriesLabels.sokoto;
        aScene.kebbi.name = countriesLabels.kebbi;
        aScene.bauchi.name = countriesLabels.bauchi;
        aScene.jigawa.name = countriesLabels.jigawa;
        aScene.gombe.name = countriesLabels.gombe;
        aScene.yobe.name = countriesLabels.yobe;
        aScene.adamawa.name = countriesLabels.adamawa;
        aScene.borno.name = countriesLabels.borno;
        aScene.benue.name = countriesLabels.benue;
        aScene.crossRiver.name = countriesLabels.crossRiver;
        aScene.kogi.name = countriesLabels.kogi;
        aScene.edo.name = countriesLabels.edo;
        aScene.ekiti.name = countriesLabels.ekiti;
        aScene.ondo.name = countriesLabels.ondo;
        aScene.kwara.name = countriesLabels.kwara;
        aScene.oyo.name = countriesLabels.oyo;
        aScene.osun.name = countriesLabels.osun;
        aScene.ogun.name = countriesLabels.ogun;
        aScene.lagos.name = countriesLabels.lagos;
        aScene.anambra.name = countriesLabels.anambra;
        aScene.ebonyi.name = countriesLabels.ebonyi;
        aScene.enugu.name = countriesLabels.enugu;
        aScene.abia.name = countriesLabels.abia;
        aScene.akwaIbom.name = countriesLabels.akwaIbom;
        aScene.imo.name = countriesLabels.imo;
        aScene.delta.name = countriesLabels.delta;
        aScene.bayelsa.name = countriesLabels.bayelsa;
        aScene.rivers.name = countriesLabels.rivers;

        // create container and put countries into it
        aScene.statesContainer = aScene.add.container(0, 0, [aScene.niger, aScene.fct, aScene.nasarawa, aScene.taraba, aScene.plateau, aScene.katsina, aScene.kaduna, aScene.kano, aScene.zamfara, aScene.sokoto, aScene.kebbi, aScene.bauchi, aScene.jigawa, aScene.gombe, aScene.yobe, aScene.adamawa, aScene.borno, aScene.benue, aScene.crossRiver, aScene.kogi, aScene.edo, aScene.ekiti, aScene.ondo, aScene.ogun, aScene.kwara, aScene.oyo, aScene.osun, aScene.lagos, aScene.lagos, aScene.anambra, aScene.ebonyi, aScene.enugu, aScene.abia, aScene.akwaIbom, aScene.imo, aScene.delta, aScene.bayelsa, aScene.rivers]);
        
        
        aScene.statesContainer.setSize(width, height);
        aScene.statesContainer.x = 0;
        aScene.statesContainer.y = 0;     
     }
}
