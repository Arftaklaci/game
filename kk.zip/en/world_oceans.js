var game = new Phaser.Game(960, 600, Phaser.AUTO, null);

game.global = 
{
	orientated : false,
    language: "english"
}

// edit below to change a language
title_label = "Oceans"
website = "World Geography Games"
webURL = "https://world-geography-games.com/world.html"
tap_to_play_label = "Tap on the map to play"
click_to_play_label = "Click on the map to play"
solution_label = "Solution"
play_again_label = "Play again"
stop_label = "Stop"
score_label = "Score: "
attempts_label = "Attempts: "
game_over_label = "Game over"
pacific_label = "Pacific Ocean"
atlantic_label = "Atlantic Ocean"
arctic_label = "Arctic Ocean"
indian_label = "Indian Ocean"
southern_label = "Southern Ocean"

// this is not needed if you use english only
if (game.global.language == "bosanski")
{
    title_label = "Okeani"
    tap_to_play_label = "Pritisnite mapu da počnete"
    click_to_play_label = "Kliknite mapu da počnete"
    solution_label = "Rješenje"
    play_again_label = "Igraj ponovo"
    stop_label = "Stop"
    score_label = "Rezultat: "
    attempts_label = "Pokušaji: "
    game_over_label = "Kraj igre"
    
    pacific_label = "Tihi Okean"
    atlantic_label = "Atlantski Okean"
    arctic_label = "Arktički Okean"
    indian_label = "Indijski Okean"
    southern_label = "Antarktički Okean"
}

// game states
game.state.add('boot', bootState);
game.state.add("Loading", loading);
game.state.add("level1", state1);

// start boot state
game.state.start("boot");

