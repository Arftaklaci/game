var game = new Phaser.Game(960, 600, Phaser.AUTO, null);

game.global = 
{
	orientated : false,
    language: "english"
}

// edit below to change a language
webURL = "http://world-geography-games.com/world.html"
website = "World Geography Games"
title_label = "Continents"
tap_to_play_label = "Tap on the map to play"
click_to_play_label = "Click on the map to play"
solution_label = "Solution"
play_again_label = "Play again"
stop_label = "Stop"
score_label = "Score: "
attempts_label = "Attempts: "
game_over_label = "Game over"

europe_label = "Europe"
asia_label = "Asia"
africa_label = "Africa"
australia_label = "Oceania"
antarctica_label = "Antarctica"
south_america_label = "South America"
north_america_label = "North America"

// this is not needed if you use english only
if (game.global.language == "bosanski")
{
    title_label = "Kontinenti"
    tap_to_play_label = "Pritisnite mapu da počnete"
    click_to_play_label = "Kliknite mapu da počnete"
    solution_label = "Rješenje"
    play_again_label = "Igraj ponovo"
    stop_label = "Stop"
    score_label = "Rezultat: "
    attempts_label = "Pokušaji: "
    game_over_label = "Kraj igre"
    
    europe_label = "Evropa"
    asia_label = "Azija"
    africa_label = "Afrika"
    australia_label = "Australija"
    antarctica_label = "Antarktik"
    south_america_label = "Južna Amerika"
    north_america_label = "Sjeverna Amerika"
}

// game states
game.state.add('boot', bootState);
game.state.add("Loading", loading);
game.state.add("level1", state1);

// start boot state
game.state.start("boot");

