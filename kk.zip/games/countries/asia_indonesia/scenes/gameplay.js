"use strict"
var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        });
    }
    
    create() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;
        // get user interface scene
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;
       camera.zoom = .45;
       //camera.scrollY = -50;
        // min max zoom
        this.minZoom = .4;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.5;
        }
        else {
            this.maxZoom = 1.7;
        }
        // display countries in this scene
        this.displayMap(this);
        // get countries (sprites) array from the container
        this.countriesArray = this.mapContainer.getAll();
        // for each country (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {
            /*
            this.input.setDraggable(this.countriesArray[i]);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {
                gameObject.x = dragX;
                gameObject.y = dragY;
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });
            */
            
            let country = this.countriesArray[i];
            // make countries sprites interactive
            country.setInteractive({ 
                useHandCursor: true,             
                pixelPerfect: true,
                alphaTolerance: 255
             });
             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over country
                country.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                       country.setTintFill(0xFFFFFF);
                    }
                },this);
                country.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        country.clearTint();
                    }
                },this);
            }
            country.on('pointerdown', () => {
                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });
            country.on('pointerup', () => {
                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);
                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    country.xPos = camera.x;
                    country.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false) {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === country.name) {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this country
                            country.disableInteractive();
                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }
                            // create the country label
                            this.showLabels(country);
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // else don't tap, drag the map
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();
        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false) {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();
                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip, ui.buttonSound],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                let dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {
                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        let drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }
                }).on('pinch', dragScale => {
                    let scaleFactor = dragScale.scaleFactor;
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                }, this);
                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }
        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2 + 100, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 70, align: "center", color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2 + 100, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 80, align: "center", color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });
        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                camera.zoom *= 0.9;
            }
        }
        // limit zoom
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.mapContainer.setSize(width, height);
        this.mapContainer.x = 0;
        this.mapContainer.y = 0;
        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2 + 100, height/2);
        }
    }

    getQuestion() {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;
        this.questionsArray.shift();

        if (ui.questionText.text === countriesLabels.newfoundland) {
            ui.questionText.setFontSize(26);
        }
        else {
            ui.questionText.setFontSize(34);
        }

        // tween
        this.tweens.add({
           targets: [ui.questionText],
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;
        // play sound
        this.gameOverSound.play();
        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        ui.buttonSound.destroy();
        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {
        // tween camera
        if (camera.zoom > this.minZoom) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: this.minZoom,
                x: 0, 
                y: 0,
                duration: 1500,
                onComplete: () => {
                    
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }
        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: 0,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showLabels(country) {
        // create white rectangle
        country.rect = this.add.sprite(country.x, country.y, "rectangle");
        // country name
        country.txt = this.add.text(country.x, country.y, country.name, { fontFamily: "bold", fontSize: 28, align: "center", color: '#000000' });
        country.txt.setOrigin(.5,.5);
        // position text
        if (country.labelX) {
            country.txt.x = country.labelX;
            country.txt.y = country.labelY;
            country.rect.x = country.labelX;
            country.rect.y = country.labelY;
        }
        country.rect.displayWidth = country.txt.width + 4;
        country.rect.displayHeight = country.txt.height + 2;

        if (country.name === countriesLabels.jakarta) {
            let line = this.add.image(country.x, country.y, "texture", "jakartaLine.png").setOrigin(0.5,1);
            this.mapContainer.add(line);
        }
        else if (country.name === countriesLabels.yogyakarta) {
            let line = this.add.image(country.x, country.y, "texture", "yogyakartaLine.png").setOrigin(0.5,0);
            this.mapContainer.add(line);
        }
    }

    displayMap(aScene) {
        aScene.map = aScene.add.image(width/2, height/2, 'map');

        aScene.extraTerritories = aScene.add.sprite(width/2 + 36.2, height/2 - 97.3, "texture", "extraTerritories.png");

        // texture
        aScene.centralKalimantan = aScene.add.sprite(width/2 - 321.9, height/2 - 73.7, "texture", "centralKalimantan.png");
        aScene.eastKalimantan = aScene.add.sprite(width/2 - 104.6, height/2 - 180.1, "texture", "eastKalimantan.png");
        aScene.southKalimantan = aScene.add.sprite(width/2 - 171, height/2 + 44.4, "texture", "southKalimantan.png");
        aScene.westKalimantan = aScene.add.sprite(width/2 - 450, height/2 - 137.1, "texture", "westKalimantan.png");
        aScene.northKalimantan = aScene.add.sprite(width/2 - 113.1, height/2 - 361, "texture", "northKalimantan.png");
        aScene.southSulawesi = aScene.add.sprite(width/2 + 186.6, height/2 + 150.1, "texture", "southSulawesi.png");
        aScene.southeastSulawesi = aScene.add.sprite(width/2 + 316.1, height/2 + 137.8, "texture", "southeastSulawesi.png");
        aScene.westSulawesi = aScene.add.sprite(width/2 + 97.4, height/2 - 19, "texture", "westSulawesi.png");
        aScene.centralSulawesi = aScene.add.sprite(width/2 + 262.3, height/2 - 106.4, "texture", "centralSulawesi.png");
        aScene.gorontalo = aScene.add.sprite(width/2 + 308.6, height/2 - 218, "texture", "gorontalo.png");
        aScene.eastNusaTenggara = aScene.add.sprite(width/2 + 290, height/2 + 488.5, "texture", "eastNusaTenggara.png");
        aScene.westNusaTenggara = aScene.add.sprite(width/2 - 27.3, height/2 + 426.4, "texture", "westNusaTenggara.png");
        aScene.eastJava = aScene.add.sprite(width/2 - 312.1, height/2 + 313.2, "texture", "eastJava.png");
        aScene.bali = aScene.add.sprite(width/2 - 196.4, height/2 + 416.4, "texture", "bali.png");
        aScene.westPapua = aScene.add.sprite(width/2 + 1011.9, height/2 - 59.5, "texture", "westPapua.png");
        aScene.papua = aScene.add.sprite(width/2 + 1372.7, height/2 + 160.8, "texture", "papua.png");

        aScene.centralJava = aScene.add.sprite(width/2 - 543.6, height/2 + 317.4, "texture", "centralJava.png");
        aScene.westJava = aScene.add.sprite(width/2 - 716.5, height/2 + 305, "texture", "westJava.png");
        aScene.yogyakarta = aScene.add.sprite(width/2 - 520, height/2 + 376, "texture", "yogyakarta.png");
        aScene.jakarta = aScene.add.sprite(width/2 - 772.4, height/2 + 260.2, "texture", "jakarta.png");
        aScene.banten = aScene.add.sprite(width/2 - 832.3, height/2 + 276.4, "texture", "banten.png");
        aScene.bengkulu = aScene.add.sprite(width/2 - 1081, height/2 + 97.3, "texture", "bengkulu.png");
        aScene.jambi = aScene.add.sprite(width/2 - 1050, height/2 - 49.3, "texture", "jambi.png");
        aScene.riau = aScene.add.sprite(width/2 - 1112.3, height/2 - 222.5, "texture", "riau.png");
        aScene.aceh = aScene.add.sprite(width/2 - 1481.5, height/2 - 447.5, "texture", "aceh.png");
        aScene.northSumatra = aScene.add.sprite(width/2 - 1334.8, height/2 - 301, "texture", "northSumatra.png");
        aScene.westSumatra = aScene.add.sprite(width/2 - 1232.6, height/2 - 87, "texture", "westSumatra.png");
        aScene.southSumatra = aScene.add.sprite(width/2 - 962.8, height/2 + 59.6, "texture", "southSumatra.png");
        aScene.lampung = aScene.add.sprite(width/2 - 914.8, height/2 + 165.7, "texture", "lampung.png");
        // sprite sheet
        aScene.maluku = aScene.add.sprite(width/2 + 863.4, height/2 + 211.7, "maluku");
        aScene.northMaluku = aScene.add.sprite(width/2 + 628.3, height/2 - 187.5, "northMaluku");
        aScene.northSulawesi = aScene.add.sprite(width/2 + 511.4, height/2 - 358, "northSulawesi");
        aScene.riauIslands = aScene.add.sprite(width/2 - 803.5, height/2 - 317, "riauIslands");
        aScene.bangkaBelitung = aScene.add.sprite(width/2 - 776.2, height/2 - 13.4, "bangkaBelitung");
        // labels
        aScene.westSumatra.labelX = aScene.westSumatra.x - 30;
        aScene.westSumatra.labelY = aScene.westSumatra.y - 10;
        aScene.southSumatra.labelX = aScene.southSumatra.x + 10;
        aScene.southSumatra.labelY = aScene.southSumatra.y - 5;
        aScene.bengkulu.labelX = aScene.bengkulu.x - 20;
        aScene.bengkulu.labelY = aScene.bengkulu.y;
        aScene.bangkaBelitung.labelX = aScene.bangkaBelitung.x;
        aScene.bangkaBelitung.labelY = aScene.bangkaBelitung.y - 30;
        aScene.eastJava.labelX = aScene.eastJava.x - 40;
        aScene.eastJava.labelY = aScene.eastJava.y + 40;
        aScene.westKalimantan.labelX = aScene.westKalimantan.x;
        aScene.westKalimantan.labelY = aScene.westKalimantan.y - 30;
        aScene.centralKalimantan.labelX = aScene.centralKalimantan.x + 10;
        aScene.centralKalimantan.labelY = aScene.centralKalimantan.y + 10;
        aScene.eastKalimantan.labelX = aScene.eastKalimantan.x + 30;
        aScene.eastKalimantan.labelY = aScene.eastKalimantan.y - 20;
        aScene.northKalimantan.labelX = aScene.northKalimantan.x + 70;
        aScene.northKalimantan.labelY = aScene.northKalimantan.y - 20;
        aScene.southKalimantan.labelX = aScene.southKalimantan.x + 20;
        aScene.southKalimantan.labelY = aScene.southKalimantan.y;
        aScene.westSulawesi.labelX = aScene.westSulawesi.x - 40;
        aScene.westSulawesi.labelY = aScene.westSulawesi.y;
        aScene.banten.labelX = aScene.banten.x - 30;
        aScene.banten.labelY = aScene.banten.y;
        aScene.southSulawesi.labelX = aScene.southSulawesi.x - 50;
        aScene.southSulawesi.labelY = aScene.southSulawesi.y;
        aScene.southeastSulawesi.labelX = aScene.southeastSulawesi.x;
        aScene.southeastSulawesi.labelY = aScene.southeastSulawesi.y - 30;
        aScene.jakarta.labelX = aScene.jakarta.x;
        aScene.jakarta.labelY = aScene.jakarta.y - 60;
        aScene.yogyakarta.labelX = aScene.yogyakarta.x;
        aScene.yogyakarta.labelY = aScene.yogyakarta.y + 55;
        aScene.papua.labelX = aScene.papua.x + 30;
        aScene.papua.labelY = aScene.papua.y - 65;
        // names
        aScene.centralKalimantan.name = countriesLabels.centralKalimantan;
        aScene.eastKalimantan.name = countriesLabels.eastKalimantan;
        aScene.southKalimantan.name = countriesLabels.southKalimantan;
        aScene.westKalimantan.name = countriesLabels.westKalimantan;
        aScene.northKalimantan.name = countriesLabels.northKalimantan;
        aScene.southSulawesi.name = countriesLabels.southSulawesi;
        aScene.southeastSulawesi.name = countriesLabels.southeastSulawesi;
        aScene.westSulawesi.name = countriesLabels.westSulawesi;
        aScene.centralSulawesi.name = countriesLabels.centralSulawesi;
        aScene.gorontalo.name = countriesLabels.gorontalo;
        aScene.extraTerritories.name = countriesLabels.extraTerritories;
        aScene.eastNusaTenggara.name = countriesLabels.eastNusaTenggara;
        aScene.westNusaTenggara.name = countriesLabels.westNusaTenggara;
        aScene.eastJava.name = countriesLabels.eastJava;
        aScene.bali.name = countriesLabels.bali;
        aScene.westPapua.name = countriesLabels.westPapua;
        aScene.papua.name = countriesLabels.papua;
        aScene.maluku.name = countriesLabels.maluku;
        aScene.northMaluku.name = countriesLabels.northMaluku;
        aScene.northSulawesi.name = countriesLabels.northSulawesi;
        aScene.riauIslands.name = countriesLabels.riauIslands;
        aScene.bangkaBelitung.name = countriesLabels.bangkaBelitung;
        aScene.centralJava.name = countriesLabels.centralJava;
        aScene.westJava.name = countriesLabels.westJava;
        aScene.yogyakarta.name = countriesLabels.yogyakarta;
        aScene.jakarta.name = countriesLabels.jakarta;
        aScene.banten.name = countriesLabels.banten;
        aScene.lampung.name = countriesLabels.lampung;
        aScene.bengkulu.name = countriesLabels.bengkulu;
        aScene.jambi.name = countriesLabels.jambi;
        aScene.southSumatra.name = countriesLabels.southSumatra;
        aScene.riau.name = countriesLabels.riau;
        aScene.aceh.name = countriesLabels.aceh;
        aScene.northSumatra.name = countriesLabels.northSumatra;
        aScene.westSumatra.name = countriesLabels.westSumatra;
        
        // create container
        aScene.mapContainer = aScene.add.container(0, 0, [aScene.centralKalimantan, aScene.eastKalimantan, aScene.southKalimantan, aScene.westKalimantan, aScene.northKalimantan, aScene.southSulawesi, aScene.southeastSulawesi, aScene.westSulawesi, aScene.centralSulawesi, aScene.eastNusaTenggara, aScene.westNusaTenggara, aScene.eastJava, aScene.westPapua, aScene.papua, aScene.maluku, aScene.northSulawesi, aScene.gorontalo, aScene.riauIslands, aScene.bangkaBelitung, aScene.northMaluku, aScene.centralJava, aScene.westJava, aScene.bengkulu, aScene.banten, aScene.jambi, aScene.southSumatra, aScene.riau, aScene.aceh, aScene.northSumatra, aScene.westSumatra, aScene.lampung, aScene.bali, aScene.yogyakarta, aScene.jakarta]);

        aScene.mapContainer.setSize(width, height);
        aScene.mapContainer.x = 0;
        aScene.mapContainer.y = 0;
     }
}