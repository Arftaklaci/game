var mouseIsDown = false;
var distX = 0;

function mouseDown() {
    //set the mouseIsDown to true
    mouseIsDown = true;
    startX = game.input.y;
}

function mouseUp() {
    mouseIsDown = false;
}

var optionsState = {
    create: function () {

        mouseWheelScroll();
        game.input.onUp.add(mouseUp, this);
        game.input.onDown.add(mouseDown, this);
        // bg rectangle
        bg = game.add.image(0, 0, 'bg');

        // *** SELECT ANY COUNTRY IN ANY REGION
        // central america
        centralGroup = game.add.group();
        centralGroup.visible = false;
        // caribbean group
        caribbeanGroup = game.add.group();
        caribbeanGroup.visible = false;
        // rectangle on top, hide capitals
        bgTop = game.add.image(0, 0, 'bg_top');
        bgTop.height = 150;

        // caribbean
        textcaribbean = game.add.text(50, 110, caribbeanLabel.toLocaleUpperCase(), {font:"26px bold", fill:"#0099ff"});
        textcaribbean.visible = false;

        // add all capitals to array and reorder items alphabetically
        array4 = [];

        caribbean.forEach(function (fr) {
            array4.push(capitals[fr]);
        }, this)

        array4 = array4.sort(Intl.Collator(collator).compare);

        yPos = 170
        array4.forEach(function (country) {
            // write text
            writeText(50, yPos, country, caribbeanGroup);
            // get index
            let index = capitals.indexOf(country);
            // create a button for each country
            addButton(W - 120, yPos - 5, index, toggleCapitals, caribbeanGroup);
            yPos += 50;
        }, this)
       
        // central america
        text_centralGroup = game.add.text(50, 110, centralLabel.toLocaleUpperCase(), {font:"26px bold", fill:"#0099ff"});
        text_centralGroup.visible = false;

        // add all capitals to array and reorder items alphabetically
        array2 = [];

        centralAmerica.forEach(function (fr) {
            array2.push(capitals[fr]);
        }, this);

        array2 = array2.sort(Intl.Collator(collator).compare);

        yPos = 170;
        array2.forEach(function (country) {
            // write text
            writeText(50, yPos, country, centralGroup);
            // get index
            let index = capitals.indexOf(country);
            // create a button for each country
            addButton(W - 120, yPos - 5, index, toggleCapitals, centralGroup);
            yPos += 50
        }, this);

        // south group
        southGroup = game.add.group();
        southGroup.visible = false;

        if (game.global.instructions === true) {
            if (game.device.desktop) {
                scroll_instruction = game.add.sprite(250, 400, 'scroll_desktop');
            } else {
                scroll_instruction = game.add.sprite(250, 400, 'scroll_mobile');
            }
            southGroup.add(scroll_instruction);
        }

        textSouth = game.add.text(50, 110, southLabel.toLocaleUpperCase(), {font:"25px bold", fill:"#0099ff"}, southGroup);

        // add all capitals to array and reorder items
        array1 = [];

        southAmerica.forEach(function (f) {
            array1.push(capitals[f]);
        }, this);

        array1 = array1.sort(Intl.Collator(collator).compare);

        var yPos = 170;
        array1.forEach(function (country) {
            // write text
            writeText(50, yPos, country, southGroup);
            // get index
            let index = capitals.indexOf(country);
            // create a button for each country
            addButton(W - 120, yPos - 5, index, toggleCapitals, southGroup);
            yPos += 50
        }, this)

        // northern
        northernGroup = game.add.group();
        northernGroup.visible = false;

        text_northern = game.add.text(50, 110, northernLabel.toLocaleUpperCase(), {font:"26px bold", fill:"#0099ff"}, northernGroup);

        // add all capitals to array and reorder items alphabetically
        array3 = [];

        canadaUsMexico.forEach(function (fr) {
            array3.push(capitals[fr]);
        }, this)

        array3 = array3.sort(Intl.Collator(collator).compare);

        yPos = 170;
        array3.forEach(function (country) {

            // write text
            writeText(50, yPos, country, northernGroup);

            // get index
            let index = capitals.indexOf(country);

            // create a button for each country
            addButton(W - 120, yPos - 5, index, toggleCapitals, northernGroup);

            yPos += 50;
        }, this);

        // text options
        textOptions = game.add.text(W - 40, 22, options_label, {font:"36px extraBold", fill:"#0099ff"});
        textOptions.anchor.setTo(1, 0)
        buttonOptions = game.add.button(W - 55 - textOptions.width, 18, 'button_options')
        buttonOptions.anchor.setTo(1, 0)
        buttonOptions.scale.x = .8
        buttonOptions.scale.y = .8

        // button back
        buttonBackSmall = game.add.button(20, 21, 'button_back')
        textBack = game.add.text(55, 23, back_label, {font:"26px bold", fill:"#000000"});
        buttonBackClickable = game.add.button(10, 20, 'button_invisible', goBack)
        buttonBackClickable.width = 60 + textBack.width
        buttonBackClickable.height = 40

        // ** BASIC OPTIONS(sound, number of capitals, regions)
        regionsGroup = game.add.group()

        selectAtleast = game.add.text(W / 2, 670, select_atleast_label, {font:"24px bold", fill:"#f80007"}, regionsGroup);
        selectAtleast.visible = false
        selectAtleast.anchor.setTo(0.5, 0)

        // number of capitals
        textNumberOfCapitals = game.add.text(20, 240, number_of_capitals_label, {font:"27px bold", fill:"#0099ff"}, regionsGroup);

        numberOfCapitals = game.add.text(350, 235, capitalsUsed, {font:"36px bold", fill:"#000000"}, regionsGroup);

        // capitals
        textCapitals = game.add.text(20, 340, capitals_label, {font:"27px bold", fill:"#0099ff"}, regionsGroup);

        // regions text
        northernTxt = game.add.text(20, 395, northernLabel, {font:"21px bold", fill:"#000000"}, regionsGroup);

        southTxt = game.add.text(20, 445, southLabel, {font:"21px bold", fill:"#000000"}, regionsGroup);

        centralTxt = game.add.text(20, 495, centralLabel, {font:"21px bold", fill:"#000000"}, regionsGroup);

        caribbeanTxt = game.add.text(20, 545, caribbeanLabel, {font:"21px bold", fill:"#000000"}, regionsGroup);

        // select links
        select_south = game.add.text(W - 20, 395, select_label, {font:"20px bold", fill:"#000000"}, regionsGroup);

        selectSouth = game.add.text(W - 20, 445, select_label, {font:"20px bold", fill:"#000000"}, regionsGroup);

        selectCentral = game.add.text(W-20, 495, select_label, {font:"20px bold", fill:"#000000"}, regionsGroup);

        selectCaribbean = game.add.text(W-20, 545, select_label, {font:"20px bold", fill:"#000000"}, regionsGroup);

        select_south.anchor.setTo(1, 0)
        selectSouth.anchor.setTo(1, 0)
        selectCentral.anchor.setTo(1, 0)
        selectCaribbean.anchor.setTo(1, 0)

        // underlines
        underline1 = regionsGroup.create(select_south.x - select_south.width, select_south.y + 19, 'underline')
        underline1.width = select_south.width

        underline3 = regionsGroup.create(selectSouth.x - selectSouth.width, selectSouth.y + 19, 'underline')
        underline3.width = selectSouth.width

        underline4 = regionsGroup.create(selectCentral.x - selectCentral.width, selectCentral.y + 19, 'underline')
        underline4.width = selectCentral.width

        underline5 = regionsGroup.create(selectCaribbean.x - selectCaribbean.width, selectCaribbean.y + 19, 'underline')
        underline5.width = selectCaribbean.width

        // invisible clickable buttons (over select texts)
        btnSelectNorthern = game.add.button(select_south.x + 10, select_south.y - 8, 'button_invisible', selectClicked, this)
        btnSelectNorthern.width = 20 + select_south.width
        btnSelectNorthern.height = 40

        btnSelectSouth = game.add.button(selectSouth.x + 10, selectSouth.y - 8, 'button_invisible', selectClicked, this)
        btnSelectSouth.width = 20 + selectSouth.width
        btnSelectSouth.height = 40

        btnSelectCentral = game.add.button(selectCentral.x + 10, selectCentral.y - 8, 'button_invisible', selectClicked, this)
        btnSelectCentral.width = 20 + selectCentral.width
        btnSelectCentral.height = 40

        btnSelectCaribbean = game.add.button(selectCaribbean.x + 10, selectCaribbean.y - 8, 'button_invisible', selectClicked, this)
        btnSelectCaribbean.width = 20 + selectCaribbean.width
        btnSelectCaribbean.height = 40

        btnSelectNorthern.anchor.setTo(1, 0)
        btnSelectSouth.anchor.setTo(1, 0)
        btnSelectCentral.anchor.setTo(1, 0)
        btnSelectCaribbean.anchor.setTo(1, 0)

        regionsGroup.add(btnSelectNorthern)
        regionsGroup.add(btnSelectCentral)
        regionsGroup.add(btnSelectSouth)
        regionsGroup.add(btnSelectCaribbean)

        select_south.anchor.setTo(1, 0)
        selectSouth.anchor.setTo(1, 0)
        selectCentral.anchor.setTo(1, 0)
        selectCaribbean.anchor.setTo(1, 0)

        // toggle buttons for regions
        toggleNorthern = game.add.button(W - 35 - select_south.width, 390, 'button_toggle', toggleRegions, this, null, null, null, null, regionsGroup);
        toggleNorthern.frame = northernBtn;
        toggleSouth = game.add.button(W - 35 - select_south.width, 440, 'button_toggle', toggleRegions, this, null, null, null, null, regionsGroup);
        toggleSouth.frame = southBtn;
        toggleCentral = game.add.button(W - 35 - select_south.width, 490, 'button_toggle', toggleRegions, this, null, null, null, null, regionsGroup);
        toggleCentral.frame = centralBtn;
        toggleCaribbean = game.add.button(W - 35 - select_south.width, 540, 'button_toggle', toggleRegions, this, null, null, null, null, regionsGroup);
        toggleCaribbean.frame = caribbeanBtn;

        toggleNorthern.anchor.setTo(1, 0);
        toggleSouth.anchor.setTo(1, 0);
        toggleCentral.anchor.setTo(1, 0);
        toggleCaribbean.anchor.setTo(1, 0);

        // sound
        //text_sound = game.add.bitmapText(20, 140, 'os-blue-bold', sound_label, 27, regionsGroup);
        text_sound = game.add.text(20, 140, sound_label, {font:"27px bold", fill:"#0099ff"}, regionsGroup);

        button_sound = game.add.button(W - 35 - select_south.width, 137, 'button_toggle', toggleSound, this, null, null, null, null, regionsGroup);
        button_sound.frame = soundFrame;
        button_sound.anchor.setTo(1, 0);
    },

    update: function () {
        if (mouseIsDown === true && caribbeanGroup.visible === true) {
            //get the distance between the start and end point
            distX = Math.abs(game.input.y - startX);
            //if the distance is greater than 50 pixels
            if (distX > 50) {
                if (distX > 100) {
                    distX = 100
                }
                swipeDone();
            }
        }

        if (caribbeanGroup.y < -70) {
            caribbeanGroup.y = -70
        } 
        else if (caribbeanGroup.y > 0) {
            caribbeanGroup.y = 0
        }
    }
}

function swipeDone() {
    //get the ending point
    var endX = game.input.y;

    if (caribbeanGroup.visible === true) {
        if (endX < startX) {
            caribbeanGroup.y -= distX / 6
        } else {
            caribbeanGroup.y += distX / 6
        }
    }
    else if (centralGroup.visible === true) {
        if (endX < startX) {
            centralGroup.y -= distX / 6
        } else {
            centralGroup.y += distX / 6
        }
    }
}

function writeText(x_pos, yPos, this_text, this_group) {
    //country_text = game.add.bitmapText(x_pos, yPos, 'open_sans_bold', this_text, 24, this_group)
    country_text = game.add.text(x_pos, yPos, this_text, {font:"24px bold", fill:"#000000"}, this_group);
}

function addButton(x_pos, yPos, number, callback, btn_group) {
    toggle_btn = game.add.button(x_pos, yPos, 'button_toggle', callback, this, null, null, null, null, btn_group)
    toggle_btn.number = number
    toggle_btn.frame = toggleButtonFrames[number]
}

function selectClicked(btn) {

    // hide sound button, number of capitals, select at least text...
    regionsGroup.visible = false
    selectingRegions = false
    selectAtleast.visible = false

    if (btn === btnSelectNorthern) {
        northernGroup.visible = true

        // switch each single button in this group
        northernGroup.forEach(function (toggle_btn) {
            if (toggle_btn.number != null) {
                toggle_btn.frame = toggleButtonFrames[toggle_btn.number]
            }
        }, this)
    } else if (btn === btnSelectSouth) {
        southGroup.visible = true
        // switch each single button in this group
        southGroup.forEach(function (toggle_btn) {
            if (toggle_btn.number != null) {
                toggle_btn.frame = toggleButtonFrames[toggle_btn.number]
            }
        }, this)

        // scroll instructions
        if (!game.device.desktop && game.global.instructions === true) {
            tween = game.add.tween(scroll_instruction).to({
                y: 300
            }, 700, "Linear", true, 0, 1, true)
            tween.onComplete.add(function () {
                scroll_instruction.visible = false
            }, this)

            game.global.instructions = false
        }
    } else if (btn === btnSelectCentral) {
        centralGroup.visible = true
        // show this text
        text_centralGroup.visible = true;

        // switch each single button in this group
        centralGroup.forEach(function (toggle_btn) {
            if (toggle_btn.number != null) {
                toggle_btn.frame = toggleButtonFrames[toggle_btn.number]
            }
        }, this)
    } else if (btn === btnSelectCaribbean) {
        caribbeanGroup.visible = true;
        // show this text
        textcaribbean.visible = true;

        // switch each single button in this group
        caribbeanGroup.forEach(function (toggle_btn) {
            if (toggle_btn.number != null) {
                toggle_btn.frame = toggleButtonFrames[toggle_btn.number]
            }
        }, this)
    }
}

function toggleCapitals(btn) {
    // remove this frame (map)
    if (btn.frame == 0) {
        for (let i = 0; i < frames.length; i++) {
            if (btn.number == frames[i]) {
                frames.splice(i, 1)
            }
        }
    } else // add this frame to the array
    {
        for (let i = 0; i < frames.length; i++) {
            if (frames.includes(btn.number) == false) {
                frames.push(btn.number)
            }
        }
        // make sure it runs at least once
        if (frames.length == 0) {
            if (frames.includes(btn.number) == false) {
                frames.push(btn.number)
            }
        }
    }

    // update capitals frames
    capitalsUsed = frames.length

    // update number of capitals
    numberOfCapitals.text = capitalsUsed.toString()

    // save toggle button frame (0 or 1)
    toggleButtonFrames[btn.number] = (toggleButtonFrames[btn.number] == 0) ? 1 : 0

    // switch frame of the current button
    btn.frame = (btn.frame == 0) ? 1 : 0
}

function toggleRegions(btn) {
    if (btn == toggleNorthern) {
        // save toggle buttonframe
        northernBtn = (northernBtn == 0) ? 1 : 0

        // exclude frames (capitals)
        if (btn.frame == 0) {
            for (let j = 0; j < canadaUsMexico.length; j++) {
                for (let i = 0; i < frames.length; i++) {
                    if (frames[i] === canadaUsMexico[j]) {
                        // toggle buttons off
                        toggleButtonFrames[frames[i]] = 1

                        // remove these frames
                        frames.splice(i, 1);
                    }
                }
            }
        } else // include frames (capitals)
        {
            for (let j = 0; j < canadaUsMexico.length; j++) {
                if (frames.includes(canadaUsMexico[j]) == false) {
                    // toggle buttons on
                    toggleButtonFrames[canadaUsMexico[j]] = 0

                    // add these frames
                    frames.push(canadaUsMexico[j])
                }
            }
        }
    } else if (btn == toggleSouth) {

        southBtn = (southBtn === 0) ? 1 : 0

        // exclude
        if (btn.frame === 0) {
            for (let j = 0; j < southAmerica.length; j++) {
                for (let i = 0; i < frames.length; i++) {
                    if (frames[i] === southAmerica[j]) {

                        // toggle buttons off
                        toggleButtonFrames[frames[i]] = 1
                        frames.splice(i, 1);
                    }
                }
            }
        } else // include
        {
            for (let j = 0; j < southAmerica.length; j++) {
                if (frames.includes(southAmerica[j]) == false) {
                    // toggle buttons on
                    toggleButtonFrames[southAmerica[j]] = 0

                    frames.push(southAmerica[j])
                }
            }
        }
    } else if (btn == toggleCentral) {
        centralBtn = (centralBtn == 0) ? 1 : 0

        // exclude
        if (btn.frame == 0) {

            for (let j = 0; j < centralAmerica.length; j++) {
                for (let i = 0; i < frames.length; i++) {
                    if (frames[i] === centralAmerica[j]) {
                        toggleButtonFrames[frames[i]] = 1

                        frames.splice(i, 1);
                    }
                }
            }
        } else // include
        {
            for (j = 0; j < centralAmerica.length; j++) {
                if (frames.includes(centralAmerica[j]) == false) {
                    // toggle buttons on
                    toggleButtonFrames[centralAmerica[j]] = 0

                    // add these frames
                    frames.push(centralAmerica[j])
                }
            }
        }
    } else if (btn == toggleCaribbean) {
        caribbeanBtn = (caribbeanBtn == 0) ? 1 : 0

        // exclude
        if (btn.frame == 0) {
            for (let j = 0; j < caribbean.length; j++) {
                for (let i = 0; i < frames.length; i++) {
                    if (frames[i] === caribbean[j]) {
                        toggleButtonFrames[frames[i]] = 1
                        frames.splice(i, 1);
                    }
                }
            }
        } else // include
        {
            for (let j = 0; j < caribbean.length; j++) {
                if (frames.includes(caribbean[j]) == false) {
                    // toggle buttons on
                    toggleButtonFrames[caribbean[j]] = 0

                    // add these frames
                    frames.push(caribbean[j])
                }
            }
        }
    }

    // IMPORTANT switch button's frame
    btn.frame = (btn.frame == 0) ? 1 : 0;
    // update capitals frames
    capitalsUsed = frames.length;
    // update number of capitals
    numberOfCapitals.text = capitalsUsed.toString();
}

function goBack() {
    // go to menu
    if (selectingRegions == true) {
        if (frames.length >= 5) {
            game.state.start("menu")
        } 
        else {
            selectAtleast.visible = true;
        }
    } 
    else // go to basic options
    {
        regionsGroup.visible = true;
        selectingRegions = true;
        northernGroup.visible = false;
        centralGroup.visible = false;
        southGroup.visible = false;
        caribbeanGroup.visible = false;

        // hide text
        text_centralGroup.visible = false;
        textcaribbean.visible = false;
    }
}
