"use strict"

var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        })
    }

    create() {

        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;

        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");

        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");

       // camera
       camera = this.cameras.main;
       camera.zoom = 0.6;

        // min max zoom
        this.minZoom = 0.6;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.6;
        }
        else {
            this.maxZoom = 2;
        }
        
        // display countries in this scene
        this.displayMexico(this);
       
        // get countries (sprites) array from the container
        this.countriesArray = this.mexicoContainer.getAll();

        // for each country (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {

            let country = this.countriesArray[i];

            // make countries sprites interactive
            country.setInteractive({ 
                useHandCursor: true,             
                pixelPerfect: true,
                alphaTolerance: 255
             });

             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over country
                country.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                        country.setTintFill(0xFFFFFF);
                    }
                },this);

                country.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        country.clearTint();
                    }
                },this);
            }

            country.on('pointerdown', () => {
                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });

            country.on('pointerup', () => {
                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);

                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    country.xPos = camera.x;
                    country.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false)
                    {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === country.name)
                        {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this country
                            country.disableInteractive();

                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }

                            // create the country label
                            this.showMexicoLabels(country);
    
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
    
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // else don't tap, drag the map
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();

        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false)
            {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();

                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip, ui.buttonSound],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                var dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {

                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        var drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }

                }).on('pinch', dragScale => {
                    var scaleFactor = dragScale.scaleFactor;
                    
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                    
                }, this);

                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }

        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 50, color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 50, color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });

        // mouse over microstate sprite
        this.mouseOverMicro = this.add.image(0,0, 'mouseOverMicrostate');
        this.mouseOverMicro.setVisible(false);

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                
                camera.zoom *= 0.9;
            }
        }

        // limit zoom
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.mexicoContainer.setSize(width, height);
        this.mexicoContainer.x = 0;
        this.mexicoContainer.y = 0; 

        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2, height/2);
        }
    }

    getQuestion()
    {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;
        this.questionsArray.shift();
        
        // tween
        this.tweens.add({
           targets: [ui.questionText],
           //scaleX: '-=.2',
           //angle: 10,
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;

        // play sound
        this.gameOverSound.play();

        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        ui.buttonSound.destroy();

        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {

        // tween camera
        if (camera.zoom > this.minZoom) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: this.minZoom,
                x: 0, 
                y: 0,
                duration: 3000,
                onComplete: () => {
                    
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }

        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: 0,
            ease: 'Linear',
            duration: 3000,
        });
    }

    showMexicoLabels(country) {

            country.txt = this.add.text(country.x, country.y, country.name, { fontFamily: "bold", fontSize: 18, color: '#000000' });
            country.txt.setOrigin(.5,.5);
            this.mexicoContainer.add(country.txt);
            // position text
            if (country.labelX) {
                country.txt.x = country.labelX;
                country.txt.y = country.labelY;
            }

            // create a line if needed
            if (country.hasLine) {
                if (country.name === countriesLabels.queretaro || country.name === countriesLabels.tlaxcala) {
                    let line = this.add.image(country.lineX, country.lineY, "line");
                    line.setOrigin(0,0.5);
                    this.mexicoContainer.add(line);
                }
                else if (country.name === countriesLabels.colima) {
                    let line = this.add.image(country.lineX, country.lineY, "lineColima");
                    line.setOrigin(1,0);
                    this.mexicoContainer.add(line);
                }
                else if (country.name === countriesLabels.morelos) {
                    let line = this.add.image(country.lineX, country.lineY, "lineMorelos");
                    line.setOrigin(1,0);
                     this.mexicoContainer.add(line);
                }
                else if (country.name === countriesLabels.aguascalientes) {
                    let line = this.add.image(country.lineX, country.lineY, "lineAguascalientes");
                    line.setOrigin(1,0);
                     this.mexicoContainer.add(line);
                }
                else if (country.name === countriesLabels.mexicoCity) {
                    let line = this.add.image(country.lineX, country.lineY, "lineMexicoCity");
                    line.setOrigin(1,0);
                     this.mexicoContainer.add(line);
                }
            }

            // create white rectangle
            country.rect = this.add.sprite(country.txt.x, country.txt.y, "rectangle");
            country.rect.displayWidth = country.txt.width + 2;
            country.rect.displayHeight = country.txt.height;
            this.mexicoContainer.add(country.rect);

            // bring to top text field
            this.mexicoContainer.bringToTop(country.txt);
    }
    
    displayMexico(aScene) {
        
        aScene.zacatecas = aScene.add.sprite(width/2 - 52, height/2 + 24.5, "zacatecas");
        aScene.sanLuisPotosi = aScene.add.sprite(width/2 + 89, height/2 + 37, "sanLuisPotosi");
        aScene.durango = aScene.add.sprite(width/2 - 193, height/2 - 82.5, "durango");
        aScene.coahuila = aScene.add.sprite(width/2 - 11, height/2 - 257, "coahuila");
        aScene.sinaloa = aScene.add.sprite(width/2 - 356.5, height/2 - 91.5, "sinaloa");
        aScene.nuevoLeon = aScene.add.sprite(width/2 + 120.5, height/2 - 139, "nuevoLeon");
        
        aScene.tamaulipas = aScene.add.sprite(width/2 + 191.5, height/2 - 106, "tamaulipas");
        aScene.sonora = aScene.add.sprite(width/2 - 598.5, height/2 - 433, "sonora");
        aScene.chihuahua = aScene.add.sprite(width/2 - 273, height/2 - 363.5, "chihuahua");
        aScene.bajaCalifornia = aScene.add.sprite(width/2 - 820, height/2 - 498, "bajaCalifornia");
        aScene.bajaCaliforniaSur = aScene.add.sprite(width/2 - 642, height/2 - 149.5, "bajaCaliforniaSur");
        aScene.nayarit = aScene.add.sprite(width/2 - 226.5, height/2 + 109, "nayarit");
        aScene.jalisco = aScene.add.sprite(width/2 - 120.5, height/2 + 178.5, "jalisco");
        aScene.colima = aScene.add.sprite(width/2 - 149.5, height/2 + 297, "colima");
        aScene.aguascalientes = aScene.add.sprite(width/2 - 38, height/2 + 94.5, "aguascalientes");
        aScene.guanajuato = aScene.add.sprite(width/2 + 57, height/2 + 175.5, "guanajuato");
        aScene.michoacan = aScene.add.sprite(width/2 - 11.5, height/2 + 295, "michoacan");
        aScene.queretaro = aScene.add.sprite(width/2 + 122.5, height/2 + 176, "queretaro");
        aScene.hidalgo = aScene.add.sprite(width/2 + 182.5, height/2 + 198, "hidalgo");
        aScene.veracruz = aScene.add.sprite(width/2 + 368, height/2 + 240.5, "veracruz");
        aScene.mexico = aScene.add.sprite(width/2 + 140, height/2 + 281.5, "mexico");
        aScene.mexicoCity = aScene.add.sprite(width/2 + 171, height/2 + 278, "mexicoCity");
        aScene.morelos = aScene.add.sprite(width/2 + 177, height/2 + 320, "morelos");
        aScene.guerrero = aScene.add.sprite(width/2 + 110.5, height/2 + 395.5, "guerrero");
        aScene.tlaxcala = aScene.add.sprite(width/2 + 236, height/2 + 273.5, "tlaxcala");
        aScene.puebla = aScene.add.sprite(width/2 + 253.5, height/2 + 276, "puebla");
        aScene.oaxaca = aScene.add.sprite(width/2 + 364, height/2 + 422.5, "oaxaca");
        aScene.tabasco = aScene.add.sprite(width/2 + 604, height/2 + 357, "tabasco");
        aScene.chiapas = aScene.add.sprite(width/2 + 631, height/2 + 471, "chiapas");
        aScene.campeche = aScene.add.sprite(width/2 + 710, height/2 + 249, "campeche");
        aScene.yucatan = aScene.add.sprite(width/2 + 826, height/2 + 126, "yucatan");
        aScene.quintanaRoo = aScene.add.sprite(width/2 + 886, height/2 + 212, "quintanaRoo");

        // line connected to a label
        aScene.aguascalientes.hasLine = true;
        aScene.aguascalientes.labelX = aScene.aguascalientes.x - 300;
        aScene.aguascalientes.labelY = aScene.aguascalientes.y + 107;
        aScene.aguascalientes.lineX = aScene.aguascalientes.x;
        aScene.aguascalientes.lineY = aScene.aguascalientes.y;
        aScene.colima.hasLine = true;
        aScene.colima.lineX = aScene.colima.x;
        aScene.colima.lineY = aScene.colima.y;
        aScene.colima.labelX = aScene.colima.x - 40;
        aScene.colima.labelY = aScene.colima.y + 30;
        aScene.morelos.hasLine = true;
        aScene.morelos.labelX = aScene.morelos.x - 160;
        aScene.morelos.labelY = aScene.morelos.y + 125;
        aScene.morelos.lineX = aScene.morelos.x;
        aScene.morelos.lineY = aScene.morelos.y;
        aScene.tlaxcala.hasLine = true;
        aScene.tlaxcala.lineX = aScene.tlaxcala.x - 10;
        aScene.tlaxcala.lineY = aScene.tlaxcala.y;
        aScene.tlaxcala.labelX = aScene.tlaxcala.x + 230;
        aScene.tlaxcala.labelY = aScene.tlaxcala.y;
        aScene.queretaro.hasLine = true;
        aScene.queretaro.lineX = aScene.queretaro.x - 10;
        aScene.queretaro.lineY = aScene.queretaro.y;
        aScene.queretaro.labelX = aScene.queretaro.x + 240;
        aScene.queretaro.labelY = aScene.queretaro.y;
        aScene.mexicoCity.hasLine = true;
        aScene.mexicoCity.lineX = aScene.mexicoCity.x;
        aScene.mexicoCity.lineY = aScene.mexicoCity.y;
        aScene.mexicoCity.labelX = aScene.mexicoCity.x - 260;
        aScene.mexicoCity.labelY = aScene.mexicoCity.y + 108;

        // reposition other labels
        aScene.tamaulipas.labelX = aScene.tamaulipas.x + 30;
        aScene.tamaulipas.labelY = aScene.tamaulipas.y + 60;
        aScene.chihuahua.labelX = aScene.chihuahua.x + 10;
        aScene.chihuahua.labelY = aScene.chihuahua.y;
        aScene.sonora.labelX = aScene.sonora.x + 60;
        aScene.sonora.labelY = aScene.sonora.y;
        aScene.bajaCalifornia.labelX = aScene.bajaCalifornia.x + 20;
        aScene.bajaCalifornia.labelY = aScene.bajaCalifornia.y + 20;
        aScene.bajaCaliforniaSur.labelX = aScene.bajaCaliforniaSur.x + 10;
        aScene.bajaCaliforniaSur.labelY = aScene.bajaCaliforniaSur.y - 25;
        aScene.sinaloa.labelX = aScene.sinaloa.x - 20;
        aScene.sinaloa.labelY = aScene.sinaloa.y - 25;
        aScene.sanLuisPotosi.labelX = aScene.sanLuisPotosi.x + 25;
        aScene.sanLuisPotosi.labelY = aScene.sanLuisPotosi.y + 50;
        aScene.nayarit.labelX = aScene.nayarit.x;
        aScene.nayarit.labelY = aScene.nayarit.y + 5;
        aScene.jalisco.labelX = aScene.jalisco.x;
        aScene.jalisco.labelY = aScene.jalisco.y + 25;
        aScene.zacatecas.labelX = aScene.zacatecas.x;
        aScene.zacatecas.labelY = aScene.zacatecas.y - 50;
        aScene.michoacan.labelX = aScene.michoacan.x + 20;
        aScene.michoacan.labelY = aScene.michoacan.y;
        aScene.mexico.labelX = aScene.mexico.x - 10;
        aScene.mexico.labelY = aScene.mexico.y - 25;
        aScene.puebla.labelX = aScene.puebla.x;
        aScene.puebla.labelY = aScene.puebla.y + 50;
        aScene.veracruz.labelX = aScene.veracruz.x + 40;
        aScene.veracruz.labelY = aScene.veracruz.y + 80;
        aScene.tabasco.labelX = aScene.tabasco.x - 30;
        aScene.tabasco.labelY = aScene.tabasco.y - 20;
        aScene.sinaloa.labelX = aScene.sinaloa.x;
        aScene.sinaloa.labelY = aScene.sinaloa.y + 20;
        aScene.campeche.labelX = aScene.campeche.x + 20;
        aScene.campeche.labelY = aScene.campeche.y + 20;
        aScene.chiapas.labelX = aScene.chiapas.x - 10;
        aScene.chiapas.labelY = aScene.chiapas.y - 10;
        aScene.quintanaRoo.labelX = aScene.quintanaRoo.x + 10;
        aScene.quintanaRoo.labelY = aScene.quintanaRoo.y + 20;
        aScene.guanajuato.labelX = aScene.guanajuato.x - 10;
        aScene.guanajuato.labelY = aScene.guanajuato.y - 10;
        aScene.guerrero.labelX = aScene.guerrero.x + 40;
        aScene.guerrero.labelY = aScene.guerrero.y + 10;

        // names
        aScene.zacatecas.name = countriesLabels.zacatecas;
        aScene.sanLuisPotosi.name = countriesLabels.sanLuisPotosi;
        aScene.durango.name = countriesLabels.durango;
        aScene.coahuila.name = countriesLabels.coahuila;
        aScene.sinaloa.name = countriesLabels.sinaloa;
        aScene.nuevoLeon.name = countriesLabels.nuevoLeon;
        aScene.tamaulipas.name = countriesLabels.tamaulipas;
        aScene.chihuahua.name = countriesLabels.chihuahua;
        aScene.sonora.name = countriesLabels.sonora;
        aScene.bajaCalifornia.name = countriesLabels.bajaCalifornia;
        aScene.bajaCaliforniaSur.name = countriesLabels.bajaCaliforniaSur;
        aScene.colima.name = countriesLabels.colima;
        aScene.nayarit.name = countriesLabels.nayarit;
        aScene.jalisco.name = countriesLabels.jalisco;
        aScene.aguascalientes.name = countriesLabels.aguascalientes;
        aScene.guanajuato.name = countriesLabels.guanajuato;
        aScene.michoacan.name = countriesLabels.michoacan;
        aScene.hidalgo.name = countriesLabels.hidalgo;
        aScene.queretaro.name = countriesLabels.queretaro;
        aScene.veracruz.name = countriesLabels.veracruz;
        aScene.mexico.name = countriesLabels.mexico;
        aScene.mexicoCity.name = countriesLabels.mexicoCity;
        aScene.guerrero.name = countriesLabels.guerrero;
        aScene.morelos.name = countriesLabels.morelos;
        aScene.puebla.name = countriesLabels.puebla;
        aScene.tlaxcala.name = countriesLabels.tlaxcala;
        aScene.oaxaca.name = countriesLabels.oaxaca;
        aScene.campeche.name = countriesLabels.campeche;
        aScene.chiapas.name = countriesLabels.chiapas;
        aScene.tabasco.name = countriesLabels.tabasco;
        aScene.yucatan.name = countriesLabels.yucatan;
        aScene.quintanaRoo.name = countriesLabels.quintanaRoo;
 
        // create container and put countries into it
        aScene.mexicoContainer = aScene.add.container(0, 0, [ aScene.guanajuato, aScene.michoacan, aScene.sanLuisPotosi, aScene.zacatecas, aScene.aguascalientes, aScene.durango, aScene.tamaulipas, aScene.nuevoLeon, aScene.coahuila, aScene.chihuahua, aScene.sonora, aScene.bajaCalifornia, aScene.bajaCaliforniaSur, aScene.colima, aScene.jalisco, aScene.nayarit, aScene.sinaloa, aScene.veracruz, aScene.hidalgo, aScene.queretaro, aScene.mexico, aScene.guerrero, aScene.morelos, aScene.oaxaca, aScene.puebla, aScene.tlaxcala, aScene.campeche, aScene.chiapas, aScene.tabasco, aScene.quintanaRoo, aScene.yucatan, aScene.mexicoCity ]);
        
        aScene.mexicoContainer.setSize(width, height);
        aScene.mexicoContainer.x = 0;
        aScene.mexicoContainer.y = 0;     
     }
}
