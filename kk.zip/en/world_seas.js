"use strict"
var width, height, resize;
var webUrl = "https://world-geography-games.com/world.html";

var labels = 
{
    website         : "World Geography Games",
    title           : "Seas",
    titleTwo        : "Seas",
    play            : "play",
    options         : "options",
    map             : "map",
    sound           : "SOUND",
    photos          : "PHOTOS",
    tapStart        : "Tap on the map to start",
    clickStart      : "Click on the map to start",
    incorrect       : "Incorrect. Try again!",
    score           : "Score: ",
    attempts        : "Attempts: ",
    attemptsEnd     : "Attempts",
    points          : "Points",
    back            : "back",
    playAgain       : "Play Again",
    stop            : "Stop",
    skip            : "Skip",
    skipped         : "Skipped",
}

// the order of labels below is important!
var credits = {
  credit1   : "Photo: Ptwo 2020 (CC-BY)",
  credit2   : "Photo: Unukorno 2019 (CC-BY)",
  credit3   : "Photo: Teach a girl to swim 2018 (CC-BY-SA)",
  credit4   : "Photo: NASA 2014 (CC-BY-SA)",
  credit5   : "Photo: Jagermesh 2015 (CC-BY-SA)",
  credit6   : "Photo: Antonio Careses 2014 (CC-BY) ",
  credit7   : "Photo: Justin J Heiman 2017 (CC-BY)",
  credit8   : "Photo: Flowcomm 2018 (CC-BY)",
  credit9   : "Photo: NOAA Ocean Exploration & Research 2017 (CC-BY)",
  credit10  : "Photo: GeryB 2017 (CC-BY-SA)",
  credit11  : "Photo: Jocelyn Erskine-Kellie 2018 (CC-BY-SA)",
  credit12  : "Photo: Kees Torn 2017 (CC-BY-SA)",
  credit13  : "Photo: Khalduniqbal 2016 (CC-BY-SA)",
  credit14  : "Photo: 中岑 范姜 2015 (CC-BY-SA)",
  credit15  : "Photo: Guitarfish 2016 (CC-BY-NC)",
  credit16  : "Photo: NASA 2014 (Public Domain)",
  credit17  : "Photo: Allochka22ru 2017 (CC-BY-SA)",
  credit18  : "Photo: Ramon F Velasquez 2013 (CC-BY-SA)",
  credit19  : "Photo: Katja Schulz 2018 (CC-BY)",
  credit20  : "Photo: Gretta Geng 2019 (CC-BY-NC-SA)"
}

var creditsArray = Object.values(credits);

var subjects = {
  arabianSea:      "Arabian Sea",
  balticSea:       "Baltic Sea",
  bayOfBengal:     "Bay of Bengal",
  beringSea:       "Bering Sea",
  blackSea:        "Black Sea",
  caribbeanSea:    "Caribbean Sea",
  coralSea:        "Coral Sea",
  gulfOfGuinea:    "Gulf of Guinea",
  gulfOfMexico:    "Gulf of Mexico",
  hudsonBay:       "Hudson Bay",
  mediterraneanSea: "Mediterranean Sea",
  northSea:        "North Sea",
  persianGulf:     "Persian Gulf",
  philippineSea:   "Philippine Sea",
  redSea:          "Red Sea",
  sargassoSea:     "Sargasso Sea",
  seaOfJapan:      "Sea of Japan/East Sea",
  southChinaSea:   "South China Sea",
  tasmanSea:       "Tasman Sea",
  yellowSea:       "Yellow Sea"
}

var countriesNames = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""];

var infoText = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""];

// don't edit below

// sound is on by default
var soundButtonFrame = 0;
// show photos by default
var showPhotos = true;
var photosButtonFrame = 0;
// number of attempts
var attempts = +0;
// number of skipped countries
var skips = +0;
// make array
var questionsArray = Object.values(subjects);
var questionsArrayStatic = [...questionsArray];

// resize
const DEFAULT_WIDTH = 1280
const DEFAULT_HEIGHT = 720
const MAX_WIDTH = DEFAULT_WIDTH * 1.5
const MAX_HEIGHT = DEFAULT_HEIGHT * 1.5
let SCALE_MODE = 'SMOOTH'

const config = {
    type: Phaser.AUTO,
    parent: 'geo-game',
    backgroundColor : 0x34C5EB,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,

    scale: 
    {
        mode: Phaser.Scale.NONE,
        parent: "geo-game",
    },
    scene: [Loading, Menu, Options, UserInterface, GraphUI, Gameplay, Graph]
}

window.addEventListener('load', () => {
    const game = new Phaser.Game(config)
  
    resize = () => {
      const w = window.innerWidth
      const h = window.innerHeight
  
      let width = DEFAULT_WIDTH
      let height = DEFAULT_HEIGHT
      let maxWidth = MAX_WIDTH
      let maxHeight = MAX_HEIGHT
      let scaleMode = SCALE_MODE
  
      let scale = Math.min(w / width, h / height)
      let newWidth = Math.min(w / scale, maxWidth)
      let newHeight = Math.min(h / scale, maxHeight)
  
      let defaultRatio = DEFAULT_WIDTH / DEFAULT_HEIGHT
      let maxRatioWidth = MAX_WIDTH / DEFAULT_HEIGHT
      let maxRatioHeight = DEFAULT_WIDTH / MAX_HEIGHT
  
      // smooth scaling
      let smooth = 1
      if (scaleMode === 'SMOOTH') {
        const maxSmoothScale = 1.15
        const normalize = (value, min, max) => {
          return (value - min) / (max - min)
        }
        if (width / height < w / h) {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioWidth) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        } else {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioHeight) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        }
      }

      // resize the game
      game.scale.resize(newWidth * smooth, newHeight * smooth)
      // scale the width and height of the css
      game.canvas.style.width = newWidth * scale + 'px'
      game.canvas.style.height = newHeight * scale + 'px'
      // center the game with css margin
      game.canvas.style.marginTop = `${(h - newHeight * scale) / 2}px`
      game.canvas.style.marginLeft = `${(w - newWidth * scale) / 2}px`
    }

    window.addEventListener('resize', event => {
      resize()
    })
  
    resize()
  })
