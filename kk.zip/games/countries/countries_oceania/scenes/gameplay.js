"use strict"

var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        })
    }

    create() {

        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;
        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;
        // min max zoom
        this.minZoom = 0.4;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1;
        }
        else {
            this.maxZoom = 1.3;
        }
        camera.zoom = 0.4;

        // display countries in this scene
        this.displayOceania(this);
        // get countries (sprites) array from the container
        this.countriesArray = this.oceaniaContainer.getAll();
        // for each country (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {

            let country = this.countriesArray[i];
            // make countries sprites interactive
            country.setInteractive({ 
                useHandCursor: true,
                pixelPerfect: true         
             });

             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over country
                country.on("pointerover", () => {
                    if (country.isSpritesheet && this.gameStarted) {
                        country.setFrame(1);
                    }
                    else {
                        country.alpha = 0.5;
                    }
                },this);
                country.on("pointerout", () => {
                    if (country.isSpritesheet && this.gameStarted) {
                        country.setFrame(0);
                    }
                    else {
                        country.alpha = 1;
                    }
                },this);
            }

            country.on('pointerdown', () => {
                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });

            country.on('pointerup', () => {
                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);

                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    country.xPos = camera.x;
                    country.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false)
                    {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === country.name)
                        {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this country
                            country.disableInteractive();

                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }

                            // create the country label
                            this.showOceaniaLabels(country);
    
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
    
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // drag
                else {
                    // console.log("don't tap, drag the map");
                }
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();

        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false)
            {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();
                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                var dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {

                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        var drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }

                }).on('pinch', dragScale => {
                    var scaleFactor = dragScale.scaleFactor;
                    
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                    
                }, this);

                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }

        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 66, color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 66, color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });

        // mouse over microstate sprite
        this.mouseOverMicro = this.add.image(0,0, 'mouseOverMicrostate');
        this.mouseOverMicro.setVisible(false);

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }
    
	update() {
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                camera.zoom *= 0.9;
            }
        }

        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.oceaniaContainer.setSize(width, height);
        this.oceaniaContainer.x = 0;
        this.oceaniaContainer.y = 0; 
        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2, height/2);
        }
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;
        // play sound
        this.gameOverSound.play();
        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        // show animation at the end
        this.showAnimation();
    }

    getQuestion() {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;
        this.questionsArray.shift();
        
        // tween
        this.tweens.add({
           targets: [ui.questionText],
           //scaleX: '-=.2',
           //angle: 10,
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
           //repeatDelay: 1000
           //onComplete: () => {console.log("COMPLETED")}
           //onCompleteParams: [ this.questionText ]
        });
    }

    showAnimation() {

        ui.showKangaroo();

        // tween camera
        this.canZoom = false;
        this.tweens.add({
            targets: [camera],
            callbackScope: this,
            ease: 'Linear',
            zoom: 0.44,
            x: 0, 
            y: 0,
            duration: 2000,
            onComplete: () => {
                
                this.canZoom = true;
                // show end screen
                ui.endScreen();
            },
        });
        
        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: 100,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showOceaniaLabels(country) {
        
        if (country.name != undefined) {
            
            country.txt = this.add.text(country.x, country.y, country.name, { fontFamily: "bold", fontSize: 44, color: '#000000' });
            country.txt.setOrigin(.5,.5);
            this.oceaniaContainer.add(country.txt);
            // position text
            if (country.labelX) {
                country.txt.x = country.labelX;
                country.txt.y = country.labelY;
            }

            // create a line if needed
            if (country.hasLine) {
                // different lines for Vatican and San Marino
                if (country.name === countriesLabels.sanMarino || country.name === countriesLabels.vaticanCity) {
                let line = this.add.image(country.lineX, country.lineY, "lineSanMarino");
                line.setOrigin(1,0);
                 this.oceaniaContainer.add(line);
                }
                // north macedonia
                else if (country.name === countriesLabels.northMacedonia) {
                    let line = this.add.image(country.lineX, country.lineY, "lineMacedonia");
                    line.setOrigin(0.5,0.5);
                    this.oceaniaContainer.add(line);
                }
                else {
                    let line = this.add.image(country.lineX, country.lineY, "line");
                    line.setOrigin(0,0.5);
                    // flip horizontally
                    if (country.flipLine) {
                        line.scaleX = -1;
                        line.x += 4;
                    }
                    // rotate a line
                    if (country.name === countriesLabels.kosovo) {
                        line.angle = 6;
                    }
                    else if (country.name === countriesLabels.montenegro) {
                        line.angle = -4;
                    }
                    else if (country.name === countriesLabels.bosnia) {
                        line.angle = -2;
                    }
                    this.oceaniaContainer.add(line);
                }
            }

            // create white rectangle
            country.rect = this.add.sprite(country.txt.x, country.txt.y, "rectangle");
            country.rect.displayWidth = country.txt.width + 4;
            country.rect.displayHeight = country.txt.height;
            this.oceaniaContainer.add(country.rect);

            // bring to top text field
            this.oceaniaContainer.bringToTop(country.txt);
        }
    }
    
    displayOceania(aScene) {

        aScene.papuaNewGuinea = aScene.add.sprite(width/2 + 2, height/2 - 244, "papuaNewGuinea");
        aScene.solomonIslands = aScene.add.sprite(width/2 + 328, height/2 - 140, "solomonIslands");
        aScene.australia = aScene.add.sprite(width/2 - 506, height/2 + 386, "australia");
        aScene.newZealand = aScene.add.sprite(width/2 + 278, height/2 + 854, "newZealand");
        aScene.tuvalu = aScene.add.sprite(width/2 + 708, height/2 - 178, "tuvalu");
        aScene.vanuatu = aScene.add.sprite(width/2 + 566, height/2 + 108, "vanuatu");
        aScene.fiji = aScene.add.sprite(width/2 + 789, height/2 + 107, "fiji");
        aScene.samoa = aScene.add.sprite(width/2 + 1050, height/2 - 20, "samoa");
        aScene.tonga = aScene.add.sprite(width/2 + 950, height/2 + 192, "tonga");
        aScene.kiribati = aScene.add.sprite(width/2 + 1028, height/2 - 326, "kiribati");
        aScene.nauru = aScene.add.sprite(width/2 + 538, height/2 - 364, "nauru");
        aScene.southeastAsia = aScene.add.sprite(width/2 - 882, height/2 - 718, "southeastAsia");
        aScene.micronesia = aScene.add.sprite(width/2 + 71, height/2 - 644, "micronesia");
        aScene.palau = aScene.add.sprite(width/2 - 468, height/2 - 658, "palau");
        aScene.marshallIslands = aScene.add.sprite(width/2 + 576, height/2 - 656, "marshallIslands");
        aScene.marshallIslands.labelX = aScene.marshallIslands.x;
        aScene.marshallIslands.labelY = aScene.marshallIslands.y - 55;

        aScene.samoa.isSpritesheet = true;
        aScene.palau.isSpritesheet = true;
        aScene.micronesia.isSpritesheet = true;
        aScene.marshallIslands.isSpritesheet = true;
        aScene.solomonIslands.isSpritesheet = true;
        aScene.nauru.isSpritesheet = true;
        aScene.kiribati.isSpritesheet = true;
        aScene.tuvalu.isSpritesheet = true;
        aScene.vanuatu.isSpritesheet = true;
        aScene.fiji.isSpritesheet = true;
        aScene.tonga.isSpritesheet = true;

        // countries names
        aScene.australia.name = countriesLabels.australia;
        aScene.fiji.name = countriesLabels.fiji;
        aScene.kiribati.name = countriesLabels.kiribati;
        aScene.marshallIslands.name = countriesLabels.marshallIslands;
        aScene.micronesia.name = countriesLabels.micronesia;
        aScene.nauru.name = countriesLabels.nauru;
        aScene.newZealand.name = countriesLabels.newZealand;
        aScene.solomonIslands.name = countriesLabels.solomonIslands;
        aScene.samoa.name = countriesLabels.samoa;
        aScene.tonga.name = countriesLabels.tonga;
        aScene.tuvalu.name = countriesLabels.tuvalu;
        aScene.vanuatu.name = countriesLabels.vanuatu;
        aScene.palau.name = countriesLabels.palau;
        aScene.papuaNewGuinea.name = countriesLabels.papuaNewGuinea;

        // create container and put countries into it
       aScene.oceaniaContainer = aScene.add.container(0, 0, [aScene.papuaNewGuinea, aScene.solomonIslands, aScene.australia, aScene.newZealand, aScene.tuvalu, aScene.vanuatu, aScene.samoa, aScene.tonga, aScene.fiji, aScene.kiribati, aScene.marshallIslands, aScene.nauru, aScene.papuaNewGuinea,   aScene.micronesia, aScene.palau]);
        
        aScene.oceaniaContainer.setSize(width, height);
        aScene.oceaniaContainer.x = 0;
        aScene.oceaniaContainer.y = 0;     
     }
}