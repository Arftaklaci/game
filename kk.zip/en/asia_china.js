"use strict"
var width, height, resize;

// edit below
var collator = "en";
var webUrl = "https://world-geography-games.com/asia.html";

var labels =
{
    website         : "World Geography Games",
    play            : "play",
    options         : "options",
    map             : "map",
    tapStart        : "Tap on the map to start",
    clickStart      : "Click on the map to start\nUse mouse wheel to zoom",
    incorrect       : "Incorrect. Try again!",
    score           : "Score: ",
    attempts        : "Attempts: ",
    attemptsEnd     : "Attempts",
    sound           : "SOUND",
	select          : "select",
    back            : "back",
    map             : "map",
    playAgain       : "Play Again",
    stop            : "Stop",
    skip            : "Skip",
    skipped         : "Skipped",
    
	title           : "China: Province-level administrative divisions",
    titleTwo        : "China",
	countries       : "Provinces",
	numOfCountries  : "Number of provinces",
	selectAtleast   : "Please select at least 5 provinces",
    region1         : "East China",
    region2         : "North China",
    region3         : "Northeast China",
    region4         : "Northwest China",
    region5         : "South Central China",
    region6         : "Southwest China",
}

var countriesLabels = {
  // region 1
  anhui          : "Anhui",
  fujian         : "Fujian",
  jiangsu        : "Jiangsu",
  jiangxi        : "Jiangxi",
  shandong       : "Shandong",
  shanghai       : "Shanghai",
  zhejiang       : "Zhejiang",
  // region 2
  beijing        : "Beijing",
  hebei          : "Hebei",
  innerMongolia  : "Inner Mongolia",
  shanxi         : "Shanxi",
  tianjin        : "Tianjin",
  // region 3
  heilongjiang   : "Heilongjiang",
  jilin          : "Jilin",
  liaoning       : "Liaoning",
  // region 4
  gansu          : "Gansu",
  ningxia        : "Ningxia",
  qinghai        : "Qinghai",
  shaanxi        : "Shaanxi",
  xinjiang       : "Xinjiang",
  // region 5
  guangdong      : "Guangdong",
  guangxi        : "Guangxi",
  hainan         : "Hainan",
  henan          : "Henan",
  hongKong       : "Hong Kong",
  hubei          : "Hubei",
  hunan          : "Hunan",
  macau          : "Macau",
  // region 6
  chongqing      : "Chongqing",
  guizhou        : "Guizhou",
  sichuan        : "Sichuan",
  tibet          : "Tibet",
  yunnan         : "Yunnan",
}

// don't edit below

// number of attempts
var attempts = +0;
// number of skipped countries
var skips = +0;
// by default all countries are included
var questionsArray = Object.values(countriesLabels);
// always contains all countries
const questionsArrayStatic = questionsArray.slice();

// region 1
var region1Array = [];
for (let x = 0; x < 7; x++) {
  region1Array.push(questionsArray[x]);
}
// region 2
var region2Array = [];
for (let x = 7; x < 12; x++) {
  region2Array.push(questionsArray[x]);
}
// region 3
var region3Array = [];
for (let x = 12; x < 15; x++) {
  region3Array.push(questionsArray[x]);
}
// region 4
var region4Array = [];
for (let x = 15; x < 20; x++) {
  region4Array.push(questionsArray[x]);
}
// region 5
var region5Array = [];
for (let x = 20; x < 28; x++) {
  region5Array.push(questionsArray[x]);
}
// region 6
var region6Array = [];
for (let x = 28; x < 33; x++) {
  region6Array.push(questionsArray[x]);
}

// toggle buttons, by default they are green (frame 0)
var btnRegion1Frame = 0;
var btnRegion2Frame = 0;
var btnRegion3Frame = 0;
var btnRegion4Frame = 0;
var btnRegion5Frame = 0;
var btnRegion6Frame = 0;
var soundButtonFrame = 0;

var toggleButtonsFrames = [];
for (let x = 0; x < questionsArrayStatic.length; x++) {
  toggleButtonsFrames.push(+0);
}

// if true you can toggle regions, else you toggle countries on options
var regionsVisible = true;

function tweenObj(aScene, obj, fromN, toN) {
  obj.alpha = fromN;

  aScene.tweens.add({
      targets: [obj],
      alpha: { value: toN },
      ease: 'Linear',
      duration: 400,
  });
}

// resize
const DEFAULT_WIDTH = 1280
const DEFAULT_HEIGHT = 720
const MAX_WIDTH = DEFAULT_WIDTH * 1.5
const MAX_HEIGHT = DEFAULT_HEIGHT * 1.5
let SCALE_MODE = 'SMOOTH'

const config = {
    type: Phaser.AUTO,
    parent: 'geo-game',
    backgroundColor : 0x34C5EB,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,

    scale: 
    {
        mode: Phaser.Scale.NONE,
        parent: "geo-game",
    },
    scene: [Loading, Menu, UserInterface, GraphUI, Gameplay, Options, Graph]
}

window.addEventListener('load', () => {
    const game = new Phaser.Game(config)
  
    const resize = () => {
      const w = window.innerWidth
      const h = window.innerHeight
  
      let width = DEFAULT_WIDTH
      let height = DEFAULT_HEIGHT
      let maxWidth = MAX_WIDTH
      let maxHeight = MAX_HEIGHT
      let scaleMode = SCALE_MODE
  
      let scale = Math.min(w / width, h / height)
      let newWidth = Math.min(w / scale, maxWidth)
      let newHeight = Math.min(h / scale, maxHeight)
  
      let defaultRatio = DEFAULT_WIDTH / DEFAULT_HEIGHT
      let maxRatioWidth = MAX_WIDTH / DEFAULT_HEIGHT
      let maxRatioHeight = DEFAULT_WIDTH / MAX_HEIGHT
  
      // smooth scaling
      let smooth = 1
      if (scaleMode === 'SMOOTH') {
        const maxSmoothScale = 1.15
        const normalize = (value, min, max) => {
          return (value - min) / (max - min)
        }
        if (width / height < w / h) {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioWidth) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        } else {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioHeight) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        }
      }

      // resize the game
      game.scale.resize(newWidth * smooth, newHeight * smooth)
      // scale the width and height of the css
      game.canvas.style.width = newWidth * scale + 'px'
      game.canvas.style.height = newHeight * scale + 'px'
      // center the game with css margin
      game.canvas.style.marginTop = `${(h - newHeight * scale) / 2}px`
      game.canvas.style.marginLeft = `${(w - newWidth * scale) / 2}px`
    }

    window.addEventListener('resize', event => {
      resize()
    })
  
    resize()
  })
