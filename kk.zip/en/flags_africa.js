var game = new Phaser.Game(500, 800, Phaser.Canvas, null, null, true)

game.global = 
{
	orientated             : false,
    library_instructions   : true,
    options_instructions   : true,
}

// edit below to change a language
collator = 'en'
var webURL = "https://world-geography-games.com/africa.html";
var websiteName = "World Geography Games";

title_label = "Flags of\n  Africa"
title_oneline = "Flags of Africa"
play_again_label = "Play again"
stop_label = "Stop"
score_label = "Score: "
next_label = "Next"
out_of_label = "out of"
play_label = "play"
options_label = "options"
select_atleast_label = "Select at least 5 flags"
back_label = "back"
sound_label = "SOUND"
number_of_flags_label = "NUMBER OF FLAGS"
flags_label = "FLAGS"
select_label = "select"
library_label = "library"

south_label = "Southern Africa"
central_label = "Central Africa"
east_label = "Eastern Africa"
western_label = "Western Africa"
northern_label = "Northern Africa"

countries = ["Algeria", "Angola", "Benin", "Botswana", "Burkina Faso", "Burundi", "Cameroon", "Cape Verde", "Central African Republic", "Chad", "Comoros", "DR Congo", "Djibouti", "Egypt", "Equatorial Guinea", "Eritrea", "Eswatini", "Ethiopia", "Gabon", "Gambia", "Ghana", "Guinea", "Guinea-Bissau", "Ivory Coast", "Kenya", "Lesotho", "Liberia", "Libya", "Madagascar", "Malawi", "Mali", "Mauritania", "Mauritius", "Morocco", "Mozambique", "Namibia", "Niger", "Nigeria", "Republic of the Congo", "Rwanda", "São Tomé  and Príncipe", "Senegal", "Seychelles", "Sierra Leone", "Somalia", "South Africa", "South Sudan", "Sudan", "Tanzania", "Togo", "Tunisia", "Uganda", "Zambia", "Zimbabwe"]


// ** DO NOT EDIT BELOW!

// create new array, don't change the first one, order alphabetically
countries_alphabet = countries.slice().sort(Intl.Collator(collator).compare);

// how many flags selected
flags_used = 54

// frames that will be used (frames represent flags)
frames = []
for (var f = 0; f < flags_used; f++)
{
    frames.push(f)
}

// always contains all frames, get random flags from this array
all_frames = frames.slice()

// regions
northern_africa = [0,13,27,33,47,50]
western_africa =[2,4,19,20,21,22,23,7,26,30,31,36,37,41,43,49]
central_africa = [1,8,11,38,14,18,6,40,9]
eastern_africa = [5,10,12,15,17,24,28,29,32,34,51,39,42,44,48,46,52,53]
southern_africa = [3,25,16,35,45]

// toggle buttons used for regions, possible frame 0 or 1
south_btn = 0
northern_btn = 0
central_btn = 0
western_btn = 0
east_btn = 0

// toggle buttons used for countries, possible frame 0 or 1
toggle_button_frames = []

for (var i = 0; i < frames.length; i++)
{
    // by default all buttons are on (frame 0)
    toggle_button_frames.push(0)
}

// sound toggle button
sound_frame = 0

// selecting regions or countries in options (back button depends on this)
selecting_regions = true

// countries have lookalikes
have_lookalikes = 
[18,6,40,33,50,2,20,21,22,30,41,43];

// lookalikes
lookalikes = [
[43],[41,30,21],[20],[50],[33],[22],[40],[30,41,6],[2],[41,21,6],[30,21,6],[18]
];

// game states
game.state.add('boot', bootState);
game.state.add("Loading", loading);
game.state.add("menu", menuState);
game.state.add("options", optionsState);
game.state.add("library", libraryState);
game.state.add("level1", state1);
game.state.start("boot");

