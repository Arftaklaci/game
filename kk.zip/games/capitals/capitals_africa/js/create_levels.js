function init() {
    W = game.width;
    H = game.height;
    score = 0;
    question_number = 0;
    can_tap = true;
    game_done = false;
    play_animation = false;
}

function createSounds() {
    wrong_sound = game.add.audio('wrong_sound');
    correct_sound = game.add.audio('correct_sound');
    game_over_sound = game.add.audio('game_over_sound');
}