class Level1 extends Phaser.Scene{
    
    constructor()
    {
        super({key: 'level1'})
    }
    
    create(){
        this.color = "#333333";
        this.gameStarted = false;
        // circles
        this.circles = this.add.sprite(width/2 - 180, height/2 + 278, 'circles').setInteractive({useHandCursor: true});
        // atmosphere image
        this.atmosphere = this.add.sprite(width/2 - 84, height/2 + 67, 'atmosphere').setInteractive({useHandCursor: true});

        // labels positions
        this.yPos = [height/2, height/2 - 80, height/2 - 160, height/2 + 80, height/2 + 160];
        shuffle(this.yPos);

        // rectangles: exosphere, stratosphere, mesosphere, thermosphere, troposphere
        this.rectTroposphere = this.add.image(20, this.yPos[0], 'rectangle').setOrigin(0,0.5).setInteractive({useHandCursor: true});
        this.rectStratosphere = this.add.image(20, this.yPos[1], 'rectangle').setOrigin(0,0.5).setInteractive({useHandCursor: true});
        this.rectMesosphere = this.add.image(20, this.yPos[2], 'rectangle').setOrigin(0,0.5).setInteractive({useHandCursor: true});
        this.rectThermosphere = this.add.image(20, this.yPos[3], 'rectangle').setOrigin(0,0.5).setInteractive({useHandCursor: true});
        this.rectExosphere = this.add.image(20, this.yPos[4], 'rectangle').setOrigin(0,0.5).setInteractive({useHandCursor: true});
        this.rectExosphere.completed = false;
        this.rectStratosphere.completed = false;
        this.rectMesosphere.completed = false;
        this.rectThermosphere.completed = false;
        this.rectTroposphere.completed = false;
        // texts
        this.rectTroposphere.label = this.add.text(this.rectTroposphere.x + 5, this.rectTroposphere.y, subjects.troposphere, { fontFamily: "semiBold", fontSize: 26, align: "center", color: '#000000' });
        this.rectTroposphere.label.setOrigin(0,0.5);
        this.rectTroposphere.displayWidth = this.rectTroposphere.label.width + 10;
        this.rectTroposphere.displayHeight = this.rectTroposphere.label.height + 10;

        this.rectStratosphere.label = this.add.text(this.rectStratosphere.x + 5, this.rectStratosphere.y, subjects.stratosphere, { fontFamily: "semiBold", fontSize: 26, align: "center", color: '#000000' });
        this.rectStratosphere.label.setOrigin(0,0.5);
        this.rectStratosphere.displayWidth = this.rectStratosphere.label.width + 10;
        this.rectStratosphere.displayHeight = this.rectStratosphere.label.height + 10;
        
        this.rectMesosphere.label = this.add.text(this.rectMesosphere.x + 5, this.rectMesosphere.y, subjects.mesosphere, { fontFamily: "semiBold", fontSize: 26, align: "center", color: '#000000' });
        this.rectMesosphere.label.setOrigin(0,0.5);
        this.rectMesosphere.displayWidth = this.rectMesosphere.label.width + 10;
        this.rectMesosphere.displayHeight = this.rectMesosphere.label.height + 10;

        this.rectThermosphere.label = this.add.text(this.rectThermosphere.x + 5, this.rectThermosphere.y, subjects.thermosphere, { fontFamily: "semiBold", fontSize: 26, align: "center", color: '#000000' });
        this.rectThermosphere.label.setOrigin(0,0.5);
        this.rectThermosphere.displayWidth = this.rectThermosphere.label.width + 10;
        this.rectThermosphere.displayHeight = this.rectThermosphere.label.height + 10;

        this.rectExosphere.label = this.add.text(this.rectExosphere.x + 5, this.rectExosphere.y, subjects.exosphere, { fontFamily: "semiBold", fontSize: 26, align: "center", color: '#000000' });
        this.rectExosphere.label.setOrigin(0,0.5);
        this.rectExosphere.displayWidth = this.rectExosphere.label.width + 10;
        this.rectExosphere.displayHeight = this.rectExosphere.label.height + 10;

        // add 5 rectangles to the array
        this.subjects = [this.rectTroposphere, this.rectStratosphere, this.rectMesosphere, this.rectThermosphere, this.rectExosphere];
        for (let x = 0; x < this.subjects.length; x++) {
            let subject = this.subjects[x];
            this.input.setDraggable(subject);
        }

        // drop labels to these areas
        this.troposphereArea = this.add.image(width/2 - 141, height/2 + 204, 'rectangle').setInteractive();
        this.troposphereArea.alpha = 0;
        this.stratosphereArea = this.add.image(width/2 + -122, height/2 + 127, 'rectangle').setInteractive().setScale(1, 1.2);
        this.stratosphereArea.alpha = 0;
        this.mesosphereArea = this.add.image(width/2 + -101, height/2 + 25, 'rectangle').setInteractive().setScale(1, 1.8);
        this.mesosphereArea.alpha = 0;
        this.thermosphereArea = this.add.image(width/2 - 65, height/2 - 110, 'rectangle').setInteractive().setScale(1.4, 2.7);
        this.thermosphereArea.alpha = 0;
        this.exosphereArea = this.add.image(width/2 - 10, height/2 - 290, 'rectangle').setInteractive().setScale(2.5, 5);
        this.exosphereArea.alpha = 0;

        // about stratosphere
        this.txtAboutStratosphere = this.add.text(width/2, this.stratosphereArea.y + 35, " Planes fly in the lower levels of this layer.\n The ozone layer is located in the higher levels,\n which absorbs UV radiation.", { fontFamily: "semiBold", fontSize: 22, align: "left", color: '#000000' });
        this.txtAboutStratosphere.setOrigin(0,0.5);
        this.bgStratosphere = this.add.image(this.txtAboutStratosphere.x - 5, this.txtAboutStratosphere.y, 'bgText').setOrigin(0,0.5);
        this.bgStratosphere.displayHeight = this.txtAboutStratosphere.height + 10;
        this.bgStratosphere.displayWidth = this.txtAboutStratosphere.width + 10;
        this.children.bringToTop(this.txtAboutStratosphere);
        // pointer stratosphere
        this.pointerStratosphere = this.add.image(this.txtAboutStratosphere.x, this.txtAboutStratosphere.y, 'pointer').setOrigin(1,.5);
        this.pointerStratosphere.setScale(1.9,1.9);
        // about troposphere
        this.txtAboutTroposphere = this.add.text(width/2-10, this.troposphereArea.y + 55, " Wind, clouds and thunderstorms: Where weather \n occurs. Higher in this layer temperatures fall to\n roughly -50°C / -58°F", {fontSize: 22, fontFamily: "semiBold", align: "left", color: '#000000' });
        this.txtAboutTroposphere.setOrigin(0,0.5);
        this.bgTroposphere = this.add.image(this.txtAboutTroposphere.x - 5, this.txtAboutTroposphere.y, 'bgText').setOrigin(0,0.5);
        this.bgTroposphere.displayHeight = this.txtAboutTroposphere.height + 10;
        this.bgTroposphere.displayWidth = this.txtAboutTroposphere.width + 10;
        this.children.bringToTop(this.txtAboutTroposphere);
        // pointer troposphere
        this.pointerTroposphere = this.add.image(this.txtAboutTroposphere.x, this.txtAboutTroposphere.y - 10, 'pointer').setOrigin(1,.5);
        this.pointerTroposphere.setScale(2.5,2);
        // about mesosphere
        this.txtAboutMesosphere = this.add.text(width/2 + 40, this.mesosphereArea.y + 40, " In this layer, most meteors burn up: shooting stars.\n Higher up, temperatures fall to -100°C / -148°F", {fontSize: 22, fontFamily: "semiBold", align: "left", color: '#000000' });
        this.txtAboutMesosphere.setOrigin(0,0.5);
        this.bgMesosphere = this.add.image(this.txtAboutMesosphere.x - 5, this.txtAboutMesosphere.y, 'bgText').setOrigin(0,0.5);
        this.bgMesosphere.displayHeight = this.txtAboutMesosphere.height + 10;
        this.bgMesosphere.displayWidth = this.txtAboutMesosphere.width + 10;
        this.children.bringToTop(this.txtAboutMesosphere);
        // pointer mesosphere
        this.pointerMesosphere = this.add.image(this.txtAboutMesosphere.x, this.txtAboutMesosphere.y - 10, 'pointer').setOrigin(1,.5);
        this.pointerMesosphere.setScale(1.6,1.6);
        // about termosphere
        this.txtAboutTermosphere = this.add.text(width/2 + 100, this.thermosphereArea.y + 55, " This is where northern lights develop.\n Higher in this layer temperatures\n may rise to over 1000°C / 1832°F", {fontSize: 22, fontFamily: "semiBold", align: "left", color: '#000000' });
        this.txtAboutTermosphere.setOrigin(0,0.5);
        this.bgThermosphere = this.add.image(this.txtAboutTermosphere.x - 5, this.txtAboutTermosphere.y, 'bgText').setOrigin(0,0.5);
        this.bgThermosphere.displayHeight = this.txtAboutTermosphere.height + 10;
        this.bgThermosphere.displayWidth = this.txtAboutTermosphere.width + 10;
        this.children.bringToTop(this.txtAboutTermosphere);
        // pointer termosphere
        this.pointerThermosphere = this.add.image(this.txtAboutTermosphere.x, this.txtAboutTermosphere.y - 10, 'pointer').setOrigin(1,.5);
        this.pointerThermosphere.setScale(1.55,1.55);
        // about exosphere
        this.txtAboutExosphere = this.add.text(width/2 + 185, this.exosphereArea.y + 90, " Very thin, outermost layer of the \n atmosphere. Many satellites orbit here.", {fontSize: 22, fontFamily: "semiBold", align: "left", color: '#000000' });
        this.txtAboutExosphere.setOrigin(0,0.5);
        this.bgExosphere = this.add.image(this.txtAboutExosphere.x - 5, this.txtAboutExosphere.y, 'bgText').setOrigin(0,0.5);
        this.bgExosphere.displayHeight = this.txtAboutExosphere.height + 10;
        this.bgExosphere.displayWidth = this.txtAboutExosphere.width + 10;
        this.children.bringToTop(this.txtAboutExosphere);
        // pointer exosphere
        this.pointerExosphere = this.add.image(this.txtAboutExosphere.x, this.txtAboutExosphere.y - 5, 'pointer').setOrigin(1,.5);
        this.pointerExosphere.setScale(1.6,1.6);

        // drag and drop
        this.input.on('drag', (pointer, gameObject, dragX, dragY) => {
            gameObject.x = dragX;
            gameObject.y = dragY;
            this.children.bringToTop(gameObject);
            this.children.bringToTop(gameObject.label);
            gameObject.label.x = gameObject.x;
            gameObject.label.y = gameObject.y;
        });
        this.input.on('dragend', (pointer, gameObject) => {

            if (this.rectExosphere.completed === false && this.checkOverlap(this.exosphereArea, this.rectExosphere)) {
                this.correctAnswer(this.rectExosphere, this.rectExosphere.label, this.exosphereArea.y);
            }
            else if (this.rectThermosphere.completed === false && this.checkOverlap(this.thermosphereArea, this.rectThermosphere)) {
                this.correctAnswer(this.rectThermosphere, this.rectThermosphere.label, this.thermosphereArea.y-14);
            }
            else if (this.rectMesosphere.completed === false && this.checkOverlap(this.mesosphereArea, this.rectMesosphere)) {
                this.correctAnswer(this.rectMesosphere, this.rectMesosphere.label, this.mesosphereArea.y-11);
            }
            else if (this.rectStratosphere.completed === false && this.checkOverlap(this.stratosphereArea, this.rectStratosphere)) {
                this.correctAnswer(this.rectStratosphere, this.rectStratosphere.label, this.stratosphereArea.y-10);
            }
            else if (this.rectTroposphere.completed === false && this.checkOverlap(this.troposphereArea, this.rectTroposphere)) {
                 this.correctAnswer(this.rectTroposphere, this.rectTroposphere.label, this.troposphereArea.y);
            }

            // game completed?
            if (this.score == 5) {
                this.gameOverSound.play();
                // light
                this.light = this.add.image(80, 80, 'light').setScale(1.5,1.5);
                this.light.alpha = 0;
                this.tweens.add({
                    targets: [this.light],
                    alpha: 1,
                    duration: 2000
                });
                this.tween = this.tweens.add({
                    targets: this.light,
                    duration: 10000,
                    angle: 360,
                    repeat: -1
                });
                // tree
                this.timerDelay = this.time.delayedCall(1500, () => {
                    let config = {
                        key: "gameAnim",
                        frames: this.anims.generateFrameNumbers("mees", { frames: [ 0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17 ] }),
                        frameRate: 10,
                        repeat: -1
                    };
                    // create animations
                    this.gameAnimation = this.anims.create(config);
                    this.mees = this.add.sprite(-200, height/2 - 100, 'mees');
                    this.mees.anims.play("gameAnim");
                    // tween
                    this.tweens.add({
                        targets: this.mees,
                        duration: 8000,
                        x: width + 1000,
                        onComplete: () => {
                            this.mees.scaleX = -1;
                            this.tweens.add({
                                targets: this.mees,
                                duration: 7000,
                                delay: 1000,
                                x: -200,
                            });
                        }
                    })
                }, this);

                // stop
                this.txtStop = this.add.text(width - 30, height - 25, labels.stop, { fontFamily: "bold", fontSize: 34, color: '#FF0000' }).setInteractive({useHandCursor: true});
                this.txtStop.on("pointerdown", () => {
                    window.location.href = webUrl;
                });
                this.txtStop.setOrigin(1,1);
                // play again
                this.txtPlayAgain = this.add.text(width - 90 - this.txtStop.width, height - 25, labels.playAgain, { fontFamily: "bold", fontSize: 34, color: '#FF0000' }).setInteractive({useHandCursor: true});
                this.txtPlayAgain.on("pointerdown", () => {
                    this.scene.restart();
                });
                this.txtPlayAgain.setOrigin(1,1);
                // line between stop and play again
                this.txtLine = this.add.text(width - 55 - this.txtStop.width, height - 25, "|", { fontFamily: "regular", fontSize: 34, color: '#000000' }).setOrigin(1,1);
                // fade in
                this.txtStop.alpha = 0;
                this.txtPlayAgain.alpha = 0;
                this.tweens.add({
                    targets: [this.txtPlayAgain, this.txtStop],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                });
            }
        });

        // drag the countries on the map
        this.txtStart = this.add.text(20, height/2 - 240, labels.dropLabels, { fontFamily: "bold", fontSize: 30, align: "center", color: '#FFFFFF' });
        this.txtStart.setOrigin(0,0.5);
        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Power.easeIn",
            alpha: .1,
            duration: 350,
            repeat: 4,
            yoyo: true,
        });

        // click anywhere       
        this.input.on('pointerdown', () => {
            if (this.gameStarted === false) {
                this.gameStarted = true;
                this.txtStart.destroy()
                // fade in
                this.tweens.add({
                   targets: [this.buttonSound, this.txtScore],
                   ease: 'Power1',
                   alpha: 1,
                   duration: 700,
                })
            }
        },this);

        // score
        this.score = 0;
        this.txtScore = this.add.text(width-20, 15, labels.score + this.score.toString() + "/5" , { fontFamily: "semiBold", fontSize: 36, color: '#000000' });
        this.txtScore.setOrigin(1,0);
        // sound button
        this.buttonSound = this.add.sprite(20, height - 20, 'buttonSound').setInteractive({ useHandCursor: true });
        this.buttonSound.on("pointerdown", () => {
            // mute/unmute sounds
            this.sound.mute = !this.sound.mute;
            // switch button
            if (soundButtonFrame === 0) {
                this.buttonSound.setFrame(1);
                soundButtonFrame = 1;
            }
            else {
                this.buttonSound.setFrame(0);
                soundButtonFrame = 0;
            }
        });
        this.buttonSound.alpha = 0;
        this.buttonSound.setOrigin(0,1);
        // audio
        this.wrongSound = this.sound.add('wrongSound')
        this.correctSound = this.sound.add('correctSound')
        this.gameOverSound = this.sound.add('gameOverSound')

        // check orientation
        checkOriention(this.scale.orientation);
        this.scale.on('orientationchange', checkOriention, this);

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

    correctAnswer(rect, label, yPos) {
        rect.setVisible(false);
        rect.disableInteractive();
        label.setOrigin(1,.5);
        label.setFontSize(28);
        label.setColor(this.color)
        rect.completed = true;
        label.setPosition(width/2 - 205, yPos);
        this.correctSound.play();
        // update score
        this.score += 1;
        this.txtScore.setText("score: 0/" + this.score.toString());
    }
    
    checkOverlap(spriteA, spriteB) {
        var boundsA = spriteA.getBounds();
        var boundsB = spriteB.getBounds();
        return Phaser.Geom.Intersects.RectangleToRectangle(boundsA, boundsB);
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.txtScore.setPosition(width - 20, 15);
        this.buttonSound.setPosition(20, height - 20);
        this.circles.setPosition(width/2 - 180, height/2 + 278);
        this.atmosphere.setPosition(width/2 - 84, height/2 + 67);
        
        if (this.txtStart != null) {
            this.txtStart.setPosition(20, height/2 - 240);
        }
        if (this.txtStop != null) {
            this.txtStop.setPosition(width - 30, height - 25);
            this.txtPlayAgain.setPosition(width - 90 - this.txtStop.width, height - 25);
            this.txtLine.setPosition(width - 55 - this.txtStop.width, height - 25);
        }
        if (this.tree != null) {
            this.light.setPosition(80, 80);
            this.tree.setPosition(this.atmosphere.x - 380, this.atmosphere.y - 55);
        }
    }
}