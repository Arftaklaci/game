"use strict"

var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        })
    }

    create() {

        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;

        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;
       camera.zoom = 0.38;

        // min max zoom
        this.minZoom = 0.38;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.7;
        }
        else {
            this.maxZoom = 2;
        }

        // display countries in this scene
        this.displayChina(this);
       
        // get countries (sprites) array from the container
        this.countriesArray = this.chinaContainer.getAll();
        // for each country (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {

            let country = this.countriesArray[i];

            /* enable drag to position countries
            country.setInteractive()
            this.input.setDraggable(country);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {

                gameObject.x = dragX;
                gameObject.y = dragY;
        
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });*/
            
            // make countries sprites interactive
            if (country.name === countriesLabels.okinawa) {
                country.setInteractive({           
                useHandCursor: true,             
                pixelPerfect: false,
                });
            }
            else {
                country.setInteractive({ 
                    useHandCursor: true,             
                    pixelPerfect: true,
                    alphaTolerance: 255
                    });
            }

             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over country
                country.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                        if (country.isSpritesheet === true) {
                            country.setFrame(1);
                        }
                        else {
                            country.setTintFill(0xFFFFFF);
                        }
                    }
                },this);

                country.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        if (country.isSpritesheet === true) {
                            country.setFrame(0);
                        }
                        else {
                            country.clearTint();
                        }
                    }
                },this);
            }

            country.on('pointerdown', () => {

                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });

            country.on('pointerup', () => {

                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);

                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    country.xPos = camera.x;
                    country.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false)
                    {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === country.name || (ui.questionText.text === labels.mariElRepublic2 && country.name === countriesLabels.mariElRepublic) || (ui.questionText.text === labels.northOssetiaAlaniaRepublic2 && country.name === countriesLabels.northOssetiaAlaniaRepublic) || (ui.questionText.text === labels.chukotkaAutonomousOkrug2 && country.name === countriesLabels.chukotkaAutonomousOkrug) || (ui.questionText.text === labels.jewishAutonomousOblast2 && country.name === countriesLabels.jewishAutonomousOblast) || (ui.questionText.text === labels.nenetsAutonomousOkrug2 && country.name === countriesLabels.nenetsAutonomousOkrug) || (ui.questionText.text === labels.khantyMansiAutonomousOkrug2 && country.name === countriesLabels.khantyMansiAutonomousOkrug) || (ui.questionText.text === labels.yamaloNenetsAutonomousOkrug2 && country.name === countriesLabels.yamaloNenetsAutonomousOkrug) || (ui.questionText.text === labels.crimeaRepublicDisputedArea2 && country.name === countriesLabels.crimeaRepublicDisputedArea) || (ui.questionText.text === labels.sevastopolDisputedArea2 && country.name === countriesLabels.sevastopolDisputedArea))
                        {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this country
                            country.disableInteractive();

                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }

                            // create the country label
                            this.showLabels(country);
    
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
    
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // drag
                else {
                    // console.log("don't tap, drag the map");
                }
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();

        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false)
            {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();

                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                var dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {

                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        var drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }

                }).on('pinch', dragScale => {
                    var scaleFactor = dragScale.scaleFactor;
                    
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                    
                }, this);

                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }

        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 65, color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 65, color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                
                camera.zoom *= 0.9;
            }
        }
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.chinaContainer.setSize(width, height);
        this.chinaContainer.x = 0;
        this.chinaContainer.y = 0; 
        this.taiwan.setPosition(this.fujian.x + 113, this.fujian.y + 91);
        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2, height/2);
        }
    }

    getQuestion()
    {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;

        // use short labels for these regions
        if (ui.questionText.text === countriesLabels.chukotkaAutonomousOkrug) {
            ui.questionText.text = labels.chukotkaAutonomousOkrug2;
        }
        else if (ui.questionText.text === countriesLabels.jewishAutonomousOblast) {
            ui.questionText.text = labels.jewishAutonomousOblast2;
        }
        else if (ui.questionText.text === countriesLabels.nenetsAutonomousOkrug) {
            ui.questionText.text = labels.nenetsAutonomousOkrug2;
        }
        else if (ui.questionText.text === countriesLabels.khantyMansiAutonomousOkrug) {
            ui.questionText.text = labels.khantyMansiAutonomousOkrug2;
        }
        else if (ui.questionText.text === countriesLabels.yamaloNenetsAutonomousOkrug) {
            ui.questionText.text = labels.yamaloNenetsAutonomousOkrug2;
        }
        else if (ui.questionText.text === countriesLabels.crimeaRepublicDisputedArea) {
            ui.questionText.text = labels.crimeaRepublicDisputedArea2;
        }
        else if (ui.questionText.text === countriesLabels.sevastopolDisputedArea) {
            ui.questionText.text = labels.sevastopolDisputedArea2;
        }

        // small font size for these labels
        if (ui.questionText.text === countriesLabels.kabardinoBalkarRepublic || ui.questionText.text === countriesLabels.karachayCherkessRepublic || ui.questionText.text === countriesLabels.northOssetiaAlaniaRepublic) {
            ui.questionText.setFontSize(25);
        }
        else {
            ui.questionText.setFontSize(33);
        }
        
        // tween
        this.tweens.add({
           targets: [ui.questionText],
           //scaleX: '-=.2',
           //angle: 10,
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });

        // remove the previous question
        this.questionsArray.shift();
    }

    gameOver() {
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;

        // play sound
        this.gameOverSound.play();

        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();

        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {

        // tween camera
        if (camera.zoom > .38) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: .38,
                x: 0, 
                y: 0,
                duration: 1500,
                onComplete: () => {
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }

        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: 0,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showLabels(country) {

        if (country.hasLine) {
            if (country.name === countriesLabels.macau) {
                let line = this.add.image(country.lineX, country.lineY, "lineMacau");
                this.chinaContainer.add(line);
            }
            else if (country.name === countriesLabels.shanghai) {
                let line = this.add.image(country.lineX, country.lineY, "lineShanghai");
                this.chinaContainer.add(line);
            }
            else if (country.name === countriesLabels.hongKong) {
                let line = this.add.image(country.lineX, country.lineY, "lineHongKong");
                this.chinaContainer.add(line);
            }
        }

        // write country name
        country.txt = this.add.text(country.x, country.y, country.name, { fontFamily: "bold", fontSize: 25, align: "center", color: '#000000' });
        country.txt.setOrigin(.5,.5);
        this.chinaContainer.add(country.txt);

        // position text
        if (country.labelX) {
            country.txt.x = country.labelX;
            country.txt.y = country.labelY;
        }
        
        // create white rectangles
        country.rect = this.add.sprite(country.txt.x, country.txt.y, "ui", "rectangle.jpg");
        country.rect.displayWidth = country.txt.width + 1;
        country.rect.displayHeight = country.txt.height;
        this.chinaContainer.add(country.rect);

        if (country.name === countriesLabels.shanghai || country.name === countriesLabels.hongKong) {
            country.rect.setOrigin(0,0.5);
            country.txt.setOrigin(0,0.5);
            country.txt.x += 1;
        }
        
        // bring to top text field
        this.chinaContainer.bringToTop(country.txt);
    }
    
    displayChina(aScene) {
        // provinces
        aScene.shanxi = aScene.add.image(width/2 + 387, height/2 - 87, "atlas", "shanxi.png");
        aScene.shaanxi = aScene.add.image(width/2 + 212, height/2 + 23.5, "atlas", "shaanxi.png");
        aScene.gansu = aScene.add.image(width/2 - 93.5, height/2 - 103, "atlas", "gansu.png");
        aScene.ningxia = aScene.add.image(width/2 + 125.5, height/2 - 66, "atlas", "ningxia.png");
        aScene.innerMongolia = aScene.add.image(width/2 + 315.7, height/2 - 509.5, "innerMongolia");
        aScene.xinjiang = aScene.add.image(width/2 - 709, height/2 - 432, "xinjiang");
        aScene.qinghai = aScene.add.image(width/2 - 300, height/2 - 11.5, "atlas", "qinghai.png");
        aScene.tibet = aScene.add.image(width/2 - 656, height/2 + 119, "atlas", "tibet.png");
        aScene.sichuan = aScene.add.image(width/2 - 22.5, height/2 + 297.5, "atlas", "sichuan.png");
        aScene.yunnan = aScene.add.image(width/2 - 111.5, height/2 + 559, "atlas", "yunnan.png");
        aScene.chongqing = aScene.add.image(width/2 + 183, height/2 + 312.5, "atlas", "chongqing.png");
        aScene.guizhou = aScene.add.image(width/2 + 126.5, height/2 + 485, "atlas", "guizhou.png");
        aScene.guangxi = aScene.add.image(width/2 + 204, height/2 + 650, "atlas", "guangxi.png");
        aScene.hunan = aScene.add.image(width/2 + 363, height/2 + 464, "atlas", "hunan.png");
        aScene.hubei = aScene.add.image(width/2 + 396, height/2 + 261.5, "atlas", "hubei.png");
        aScene.henan = aScene.add.image(width/2 + 443.5, height/2 + 113, "atlas", "henan.png");
        aScene.hainan = aScene.add.image(width/2 + 281.5, height/2 + 907.5, "atlas", "hainan.png");
        aScene.guangdong = aScene.add.image(width/2 + 457.5, height/2 + 705.5, "atlas", "guangdong.png");
        aScene.fujian = aScene.add.image(width/2 + 682, height/2 + 533, "atlas", "fujian.png");
        aScene.jiangxi = aScene.add.image(width/2 + 574.5, height/2 + 460, "atlas", "jiangxi.png");
        aScene.zhejiang = aScene.add.image(width/2 + 774, height/2 + 331.5, "atlas", "zhejiang.png");
        aScene.anhui = aScene.add.image(width/2 + 617.5, height/2 + 202, "atlas", "anhui.png");
        aScene.jiangsu = aScene.add.image(width/2 + 697.5, height/2 + 144, "atlas", "jiangsu.png");
        aScene.shanghai = aScene.add.image(width/2 + 808.5, height/2 + 224, "atlas", "shanghai.png");
        aScene.macau = aScene.add.image(width/2 + 472, height/2 + 747.5, "atlas", "macau.png");
        aScene.hongKong = aScene.add.image(width/2 + 508, height/2 + 726.5, "atlas", "hongKong.png");
        aScene.hebei = aScene.add.image(width/2 + 563.5, height/2 - 181.5, "atlas", "hebei.png");
        aScene.shandong = aScene.add.image(width/2 + 659.5, height/2 - 38.5, "atlas", "shandong.png");
        aScene.beijing = aScene.add.image(width/2 + 551, height/2 - 228, "atlas", "beijing.png");
        aScene.tianjin = aScene.add.image(width/2 + 591.7, height/2 - 187.5, "atlas", "tianjin.png");
        aScene.liaoning = aScene.add.image(width/2 + 782.5, height/2 - 297, "atlas", "liaoning.png");
        aScene.jilin = aScene.add.image(width/2 + 913.5, height/2 - 436.5, "atlas", "jilin.png");
        aScene.heilongjiang = aScene.add.image(width/2 + 923, height/2 - 710, "atlas", "heilongjiang.png");

        // repositions some labels
        aScene.shaanxi.labelX = aScene.shaanxi.x;
        aScene.shaanxi.labelY = aScene.shaanxi.y + 65;
        aScene.innerMongolia.labelX = aScene.innerMongolia.x - 50;
        aScene.innerMongolia.labelY = aScene.innerMongolia.y + 220;
        aScene.gansu.labelX = aScene.gansu.x - 180;
        aScene.gansu.labelY = aScene.gansu.y - 150;
        aScene.ningxia.labelX = aScene.ningxia.x;
        aScene.ningxia.labelY = aScene.ningxia.y - 5;
        aScene.chongqing.labelX = aScene.chongqing.x - 25;
        aScene.chongqing.labelY = aScene.chongqing.y + 25;
        aScene.guangdong.labelX = aScene.guangdong.x + 20;
        aScene.guangdong.labelY = aScene.guangdong.y - 40;
        aScene.shanghai.labelX = aScene.shanghai.x + 50;
        aScene.shanghai.labelY = aScene.shanghai.y;
        aScene.hongKong.labelX = aScene.hongKong.x + 50;
        aScene.hongKong.labelY = aScene.hongKong.y;
        aScene.jiangsu.labelX = aScene.jiangsu.x + 40;
        aScene.jiangsu.labelY = aScene.jiangsu.y - 15;
        aScene.hebei.labelX = aScene.hebei.x - 40;
        aScene.hebei.labelY = aScene.hebei.y + 55;
        aScene.macau.labelX = aScene.macau.x;
        aScene.macau.labelY = aScene.macau.y + 45;
        aScene.tianjin.labelX = aScene.tianjin.x;
        aScene.tianjin.labelY = aScene.tianjin.y + 15;
        // lines
        aScene.macau.hasLine = true;
        aScene.macau.lineX = aScene.macau.x;
        aScene.macau.lineY = aScene.macau.y + 30;
        aScene.shanghai.hasLine = true;
        aScene.shanghai.lineX = aScene.shanghai.x + 30;
        aScene.shanghai.lineY = aScene.shanghai.y;
        aScene.hongKong.hasLine = true;
        aScene.hongKong.lineX = aScene.hongKong.x + 50;
        aScene.hongKong.lineY = aScene.hongKong.y;
        // names
        aScene.shanxi.name = countriesLabels.shanxi;
        aScene.shaanxi.name = countriesLabels.shaanxi;
        aScene.gansu.name = countriesLabels.gansu;
        aScene.shanxi.name = countriesLabels.shanxi;
        aScene.innerMongolia.name = countriesLabels.innerMongolia;
        aScene.ningxia.name = countriesLabels.ningxia;
        aScene.xinjiang.name = countriesLabels.xinjiang;
        aScene.qinghai.name = countriesLabels.qinghai;
        aScene.tibet.name = countriesLabels.tibet;
        aScene.sichuan.name = countriesLabels.sichuan;
        aScene.yunnan.name = countriesLabels.yunnan;
        aScene.chongqing.name = countriesLabels.chongqing;
        aScene.guizhou.name = countriesLabels.guizhou;
        aScene.guangxi.name = countriesLabels.guangxi;
        aScene.hunan.name = countriesLabels.hunan;
        aScene.hubei.name = countriesLabels.hubei;
        aScene.henan.name = countriesLabels.henan;
        aScene.hainan.name = countriesLabels.hainan;
        aScene.guangdong.name = countriesLabels.guangdong;
        aScene.fujian.name = countriesLabels.fujian;
        aScene.jiangxi.name = countriesLabels.jiangxi;
        aScene.zhejiang.name = countriesLabels.zhejiang;
        aScene.anhui.name = countriesLabels.anhui;
        aScene.jiangsu.name = countriesLabels.jiangsu;
        aScene.shanghai.name = countriesLabels.shanghai;
        aScene.shanghai.name = countriesLabels.shanghai;
        aScene.macau.name = countriesLabels.macau;
        aScene.hongKong.name = countriesLabels.hongKong;
        aScene.hebei.name = countriesLabels.hebei;
        aScene.shandong.name = countriesLabels.shandong;
        aScene.beijing.name = countriesLabels.beijing;
        aScene.tianjin.name = countriesLabels.tianjin;
        aScene.liaoning.name = countriesLabels.liaoning;
        aScene.jilin.name = countriesLabels.jilin;
        aScene.tianjin.name = countriesLabels.tianjin;
        aScene.heilongjiang.name = countriesLabels.heilongjiang;

        // create container and put countries into it
        aScene.chinaContainer = aScene.add.container(0, 0, [ aScene.shanxi, aScene.shaanxi, aScene.gansu, aScene.ningxia, aScene.innerMongolia, aScene.xinjiang, aScene.qinghai, aScene.tibet, aScene.sichuan, aScene.yunnan, aScene.chongqing, aScene.guizhou, aScene.guangxi, aScene.hunan, aScene.hubei, aScene.henan, aScene.hainan, aScene.guangdong, aScene.fujian, aScene.jiangxi, aScene.zhejiang, aScene.anhui, aScene.jiangsu, aScene.shanghai, aScene.macau, aScene.hongKong, aScene.hebei, aScene.shandong, aScene.beijing, aScene.tianjin, aScene.liaoning, aScene.jilin, aScene.heilongjiang ]);
        
        aScene.chinaContainer.setSize(width, height);
        aScene.chinaContainer.x = 0;
        aScene.chinaContainer.y = 0;     

        aScene.taiwan = aScene.add.image(aScene.fujian.x + 113, aScene.fujian.y + 91, "atlas", "extraTaiwan.png");
     }
}
