class Loading extends Phaser.Scene
{    
    constructor()
    {
        super({
            
            key   : 'loading',
            pack  : 
            {
                files : 
                [
                    // pre-preload these images
                    { type: 'image', key: 'preloader1', url: '/games/countries/countries_africa/img/preloader1.png' },
                    { type: 'image', key: 'preloader2', url: '/games/countries/countries_africa/img/preloader2.png' },
                    { type: 'image', key: 'btnPlay', url: '/games/countries/countries_africa/img/btnPlay.png' },
                ] 
            }
        })
    }
    
    setPreloadSprite (sprite) 
    {
		this.preloadSprite = { sprite: sprite, width: sprite.width, height: sprite.height }
		sprite.visible = true
		// set callback for loading progress updates
		this.load.on('progress', this.onProgress, this);
	}
	
	onProgress (value) {
		if (this.preloadSprite) {
			// calculate width based on value (0.0 .. 1.0)
            let w = Math.floor(this.preloadSprite.width * value);
			// set width of sprite			
			this.preloadSprite.sprite.frame.width = w;
            this.preloadSprite.sprite.frame.cutWidth = w;
			// update screen
            this.preloadSprite.sprite.frame.updateUVs();
            // adjust positions while loading
            this.setPositions();
		}
    }
    
    preload(){

        // load custom fonts (extra bold loaded in index.html)
        this.font1 = this.add.text(0, 0, 'custom font', {
            fontFamily: "regular", fontSize: 16, color: '#000000'
        });
        this.font1.setVisible(false);
        this.font3 = this.add.text(0, 0, 'custom font', {
            fontFamily: "semiBold", fontSize: 16, color: '#000000'
        });
        this.font3.setVisible(false);
        this.font2 = this.add.text(0, 0, 'custom font', {
            fontFamily: "bold", fontSize: 16, color: '#000000'
        });
        this.font2.setVisible(false);

        // init width and height
        width = this.cameras.main.width;
        height = this.cameras.main.height;

        // display loading bar
		this.preloader1 = this.add.sprite(width/2, height/2 + 140, "preloader1");
		this.preloader2 = this.add.sprite(width/2, height/2 + 140, "preloader2");
        this.setPreloadSprite(this.preloader2);
        // play button
        this.btnPlay = this.add.image(width/2, height/2 + 140, "btnPlay");
        this.btnPlay.setVisible(false);

        // display text
        this.txtWebsite = this.add.text(width/2, height/2 - 150, labels.website, { fontFamily: "extraBold", fontSize: 60, color: '#000000' });
        this.txtTitle = this.add.text(width/2, height/2 - 80, labels.title, { fontFamily: "extraBold", fontSize: 55, color: '#FFFFFF' });
        this.txtTitle.setOrigin(0.5, 0.5);
        this.txtWebsite.setOrigin(0.5, 0.5);
        
        // plugins
        this.url = '/games/countries/countries_africa/plugins/pinchplugin.min.js';
        this.load.plugin('rexpinchplugin', this.url, true);
        this.url2 = '/games/countries/countries_africa/plugins/mousewheelplugin.min.js';
        this.load.plugin('rexmousewheeltoupdownplugin', this.url2, true);
        this.url3 = '/games/countries/countries_africa/plugins/rexscrollerplugin.min.js';
        this.load.plugin('rexscrollerplugin', this.url3, true);

        // animation
        this.load.spritesheet('ostrich', '/games/countries/countries_africa/img/ostrich.png', { frameWidth: 241, frameHeight: 302 });
        
        // african countries
        this.load.image('extraWesternSahara', '/games/countries/countries_africa/img/extraWesternSahara.png');
        this.load.image('algeria', '/games/countries/countries_africa/img/algeria.png');
        this.load.image('angola', '/games/countries/countries_africa/img/angola.png');
        this.load.image('benin', '/games/countries/countries_africa/img/benin.png');
        this.load.image('botswana', '/games/countries/countries_africa/img/botswana.png');
        this.load.image('burkinaFaso', '/games/countries/countries_africa/img/burkinaFaso.png');
        this.load.image('burundi', '/games/countries/countries_africa/img/burundi.png');
        this.load.image('cameroon', '/games/countries/countries_africa/img/cameroon.png');
        this.load.image('car', '/games/countries/countries_africa/img/car.png');
        this.load.image('chad', '/games/countries/countries_africa/img/chad.png');
        this.load.image('congo', '/games/countries/countries_africa/img/congo.png');
        this.load.image('djibouti', '/games/countries/countries_africa/img/djibouti.png');
        this.load.image('drCongo', '/games/countries/countries_africa/img/drCongo.png');
        this.load.image('egypt', '/games/countries/countries_africa/img/egypt.png');
        this.load.image('equatorialGuinea', '/games/countries/countries_africa/img/equatorialGuinea.png');
        this.load.image('eritrea', '/games/countries/countries_africa/img/eritrea.png');
        this.load.image('eswatini', '/games/countries/countries_africa/img/eswatini.png');
        this.load.image('ethiopia', '/games/countries/countries_africa/img/ethiopia.png');
        this.load.image('gabon', '/games/countries/countries_africa/img/gabon.png');
        this.load.image('gambia', '/games/countries/countries_africa/img/gambia.png');
        this.load.image('ghana', '/games/countries/countries_africa/img/ghana.png');
        this.load.image('guinea', '/games/countries/countries_africa/img/guinea.png');
        this.load.image('guineaBissau', '/games/countries/countries_africa/img/guineaBissau.png');
        this.load.image('ivoryCoast', '/games/countries/countries_africa/img/ivoryCoast.png');
        this.load.image('kenya', '/games/countries/countries_africa/img/kenya.png');
        this.load.image('lesotho', '/games/countries/countries_africa/img/lesotho.png');
        this.load.image('liberia', '/games/countries/countries_africa/img/liberia.png');
        this.load.image('libya', '/games/countries/countries_africa/img/libya.png');
        this.load.image('madagascar', '/games/countries/countries_africa/img/madagascar.png');
        this.load.image('malawi', '/games/countries/countries_africa/img/malawi.png');
        this.load.image('mali', '/games/countries/countries_africa/img/mali.png');
        this.load.image('mauritania', '/games/countries/countries_africa/img/mauritania.png');
        this.load.image('morocco', '/games/countries/countries_africa/img/morocco.png');
        this.load.image('mozambique', '/games/countries/countries_africa/img/mozambique.png');
        this.load.image('namibia', '/games/countries/countries_africa/img/namibia.png');
        this.load.image('niger', '/games/countries/countries_africa/img/niger.png');
        this.load.image('nigeria', '/games/countries/countries_africa/img/nigeria.png');
        this.load.image('rwanda', '/games/countries/countries_africa/img/rwanda.png');
        this.load.image('senegal', '/games/countries/countries_africa/img/senegal.png');
        this.load.image('sierraLeone', '/games/countries/countries_africa/img/sierraLeone.png');
        this.load.image('somalia', '/games/countries/countries_africa/img/somalia.png');
        this.load.image('southAfrica', '/games/countries/countries_africa/img/southAfrica.png');
        this.load.image('southSudan', '/games/countries/countries_africa/img/southSudan.png');
        this.load.image('sudan', '/games/countries/countries_africa/img/sudan.png');
        this.load.image('tanzania', '/games/countries/countries_africa/img/tanzania.png');
        this.load.image('togo', '/games/countries/countries_africa/img/togo.png');
        this.load.image('tunisia', '/games/countries/countries_africa/img/tunisia.png');
        this.load.image('uganda', '/games/countries/countries_africa/img/uganda.png');
        this.load.image('zambia', '/games/countries/countries_africa/img/zambia.png');
        this.load.image('zimbabwe', '/games/countries/countries_africa/img/zimbabwe.png');
        // spritesheets
        this.load.spritesheet('mauritius', '/games/countries/countries_africa/img/mauritius.png', { frameWidth: 299, frameHeight: 358});
        this.load.spritesheet('capeVerde', '/games/countries/countries_africa/img/capeVerde.png', { frameWidth: 138, frameHeight: 138});
        this.load.spritesheet('saoTomeAndPrincipe', '/games/countries/countries_africa/img/saoTomeAndPrincipe.png', { frameWidth: 101, frameHeight: 84});
        this.load.spritesheet('seychelles', '/games/countries/countries_africa/img/seychelles.png', { frameWidth: 337, frameHeight: 209});
        this.load.spritesheet('comoros', '/games/countries/countries_africa/img/comoros.png', { frameWidth: 101, frameHeight: 114});

        // buttons
        this.load.spritesheet('button', '/games/countries/countries_africa/img/button.png', {frameWidth: 420, frameHeight: 62});
        this.load.image('btnPlay', '/games/countries/countries_africa/img/btnPlay.png');
        this.load.image('buttonBack', '/games/countries/countries_africa/img/buttonBack.png');
        this.load.image('buttonBackBlack', '/games/countries/countries_africa/img/buttonBackBlack.png');
        this.load.image('buttonStart', '/games/countries/countries_africa/img/buttonStart.png');
        this.load.image('buttonMap', '/games/countries/countries_africa/img/buttonMap.png');
        this.load.image('buttonMapWhite', '/games/countries/countries_africa/img/buttonMapWhite.png');
        this.load.image('buttonOptions', '/games/countries/countries_africa/img/buttonOptions.png');
        this.load.spritesheet('buttonToggle', '/games/countries/countries_africa/img/buttonToggle.png', {frameWidth: 89, frameHeight: 52 });
        
        // images
		this.load.spritesheet('bgQuestion', '/games/countries/countries_africa/img/bgQuestion.png', { frameWidth: 500, frameHeight: 65 });
		this.load.image('bgWhite', '/games/countries/countries_africa/img/bgWhite.jpg');
		this.load.image('rectangle', '/games/countries/countries_africa/img/rectangle.jpg');
		this.load.image('map', '/games/countries/countries_africa/img/map.png');
		this.load.image('circle', '/games/countries/countries_africa/img/circle.png');
		this.load.image('circleGreen', '/games/countries/countries_africa/img/circleGreen.png');
		this.load.image('circleRed', '/games/countries/countries_africa/img/circleRed.png');
		this.load.image('circleYellow', '/games/countries/countries_africa/img/circleYellow.png');
		this.load.image('lineSenegal', '/games/countries/countries_africa/img/lineSenegal.png');
		this.load.image('lineRwanda', '/games/countries/countries_africa/img/lineRwanda.png');
		this.load.image('lineLesotho', '/games/countries/countries_africa/img/lineLesotho.png');
		this.load.image('lineEswatini', '/games/countries/countries_africa/img/lineEswatini.png');
		this.load.image('lineGambia', '/games/countries/countries_africa/img/lineGambia.png');
		this.load.image('lineLiberia', '/games/countries/countries_africa/img/lineLiberia.png');
		this.load.image('lineIvory', '/games/countries/countries_africa/img/lineIvory.png');
		this.load.image('lineGhana', '/games/countries/countries_africa/img/lineGhana.png');
		this.load.image('lineEquatorial', '/games/countries/countries_africa/img/lineEquatorial.png');
		this.load.image('lineBenin', '/games/countries/countries_africa/img/lineBenin.png');
		this.load.image('lineSaoTome', '/games/countries/countries_africa/img/lineSaoTome.png');
		this.load.image('lineTogo', '/games/countries/countries_africa/img/lineTogo.png');
		this.load.image('mouseOverMicrostate', '/games/countries/countries_africa/img/mouseOverMicrostate.png');
		this.load.image('underline', '/games/countries/countries_africa/img/underline.png');
        // sounds
		this.load.audio('wrongSound', ['/games/countries/countries_africa/audio/wrongSound.mp3', '/games/countries/countries_africa/audio/wrongSound.ogg']);
		this.load.audio('correctSound', ['/games/countries/countries_africa/audio/correctSound.mp3', '/games/countries/countries_africa/audio/correctSound.ogg']);
		this.load.audio('gameOverSound', ['/games/countries/countries_africa/audio/gameOverSound.mp3', '/games/countries/countries_africa/audio/gameOverSound']);
    }
    
    create() {    

        // play button
        this.btnPlay.setVisible(true);
        this.btnPlay.setInteractive({useHandCursor: true})
        this.btnPlay.on("pointerup", () => { 
            this.scene.start("menu");
        }, this);

        // remove preloader
        this.preloader1.destroy();
        this.preloader2.destroy();
        
        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on("resize", (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.preloader1.setPosition(width/2, height/2 + 170);
        this.preloader2.setPosition(width/2, height/2 + 170);
        this.btnPlay.setPosition(width/2, height/2 + 170);
        this.txtTitle.setPosition(width/2, height/2 - 80);
        this.txtWebsite.setPosition(width/2, height/2 - 150);
    }
}