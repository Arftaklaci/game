"use strict"
var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        });
    }
    
    create() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;
        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;
       camera.zoom = .23;
       camera.scrollY = -70;
        // min max zoom
        this.minZoom = .23;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.6;
        }
        else {
            this.maxZoom = 1.9;
        }
        // display countries in this scene
        this.displayMap(this);
        // get countries (sprites) array from the container
        this.countriesArray = this.mapContainer.getAll();
        // for each subject (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {
            /* development phase - enable drag to position countries
            this.countriesArray[i].setInteractive()
            this.input.setDraggable(this.countriesArray[i]);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {
                gameObject.x = dragX;
                gameObject.y = dragY;
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });
            */
            
            let subject = this.countriesArray[i];
            // make countries sprites interactive
            subject.setInteractive({ 
                useHandCursor: true,             
                pixelPerfect: true,
                alphaTolerance: 255
             });
             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over subject
                subject.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                       subject.setTintFill(0xFFFFFF);
                    }
                },this);
                subject.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        subject.clearTint();
                    }
                },this);
            }
            subject.on('pointerdown', () => {
                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });
            subject.on('pointerup', () => {
                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);
                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    subject.xPos = camera.x;
                    subject.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false) {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === subject.name) {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this subject
                            subject.disableInteractive();
                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }
                            // create the subject label
                            this.showLabels(subject);
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // else don't tap, drag the map
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();
        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false) {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();
                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip, ui.buttonSound],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                let dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {
                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        let drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }
                }).on('pinch', dragScale => {
                    let scaleFactor = dragScale.scaleFactor;
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                }, this);
                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }
        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2 + 100, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 110, align: "center", color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2 + 100, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 110, align: "center", color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });
        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                camera.zoom *= 0.9;
            }
        }
        // limit zoom
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.mapContainer.setSize(width, height);
        this.mapContainer.x = 0;
        this.mapContainer.y = 0;
        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2 + 100, height/2);
        }
    }

    getQuestion() {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;
        this.questionsArray.shift();

        if (ui.questionText.text === subjects.newfoundland) {
            ui.questionText.setFontSize(26);
        }
        else {
            ui.questionText.setFontSize(34);
        }

        // tween
        this.tweens.add({
           targets: [ui.questionText],
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;
        // play sound
        this.gameOverSound.play();
        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        ui.buttonSound.destroy();
        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {
        // tween camera
        if (camera.zoom > this.minZoom) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: this.minZoom,
                x: 0, 
                y: 0,
                duration: 1500,
                onComplete: () => {
                    
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }
        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: -70,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showLabels(subject) {
        // create white rectangle
        subject.rect = this.add.sprite(subject.x, subject.y, "rectangle");
        // subject name
        subject.txt = this.add.text(subject.x, subject.y, subject.name, { fontFamily: "bold", fontSize: 46, align: "center", color: '#000000' });
        subject.txt.setOrigin(.5,.5);

        if (subject.name === subjects.snnpr) {
            subject.txt.setText(snnprL);
        }

        // position text
        if (subject.labelX) {
            subject.txt.x = subject.labelX;
            subject.txt.y = subject.labelY;
            subject.rect.x = subject.labelX;
            subject.rect.y = subject.labelY;
        }
        subject.rect.displayWidth = subject.txt.width + 4;
        subject.rect.displayHeight = subject.txt.height + 2;

        if (subject.hasLine) {
            let line;
            if (subject.name === subjects.direDawa) {
                console.log(subject.name)
                line = this.add.image(subject.lineX, subject.lineY, "lineDireDawa").setOrigin(0.5,1);
            }
            else if (subject.name === subjects.harari) {
                console.log(subject.name)
                line = this.add.image(subject.lineX, subject.lineY, "lineHarari").setOrigin(0.5,0);
            }
            else if (subject.name === subjects.addisAbaba) {
                console.log(subject.name)
                line = this.add.image(subject.lineX, subject.lineY, "lineAddisAbaba").setOrigin(0.5,1);
            }

            this.mapContainer.add(line);
        }
    }
    
    displayMap(aScene) {
        // interactive sprites
        aScene.addisAbaba = aScene.add.sprite(width/2 -422.5, height/2 + 44, "addisAbaba");
        aScene.oromia = aScene.add.sprite(width/2 - 472, height/2 + 549.5, "oromia");
        aScene.snnpr = aScene.add.sprite(width/2 - 804, height/2 + 676.5, "snnpr");
        aScene.gambela = aScene.add.sprite(width/2 - 1550, height/2 + 413, "gambela");
        aScene.amhara = aScene.add.sprite(width/2 - 679, height/2 - 529.5, "amhara");
        aScene.benishangulGumuz = aScene.add.sprite(width/2 - 1253, height/2 - 331, "benishangulGumuz");
        aScene.tigray = aScene.add.sprite(width/2 - 558, height/2 - 1110, "tigray");
        aScene.afar = aScene.add.sprite(width/2 + 131.5, height/2 - 629, "afar");
        aScene.direDawa = aScene.add.sprite(width/2 + 383, height/2 - 125, "direDawa");
        aScene.somali = aScene.add.sprite(width/2 + 746.5, height/2 + 478.5, "somali");
        aScene.harari = aScene.add.sprite(width/2 + 416, height/2 - 39, "harari");
        aScene.southWest = aScene.add.sprite(width/2 - 1060, height/2 + 611.5, "southWest");
        aScene.sidama = aScene.add.sprite(width/2 - 473.5, height/2 + 621, "sidama");
        
        // position labels
        aScene.addisAbaba.hasLine = true;
        aScene.harari.hasLine = true;
        aScene.direDawa.hasLine = true;
        aScene.addisAbaba.lineX = aScene.addisAbaba.x;
        aScene.addisAbaba.lineY = aScene.addisAbaba.y;
        aScene.harari.lineX = aScene.harari.x;
        aScene.harari.lineY = aScene.harari.y - 5;
        aScene.direDawa.lineX = aScene.direDawa.x;
        aScene.direDawa.lineY = aScene.direDawa.y + 20;

        aScene.addisAbaba.labelX = aScene.addisAbaba.x - 70;
        aScene.addisAbaba.labelY = aScene.addisAbaba.y - 110;
        aScene.direDawa.labelX = aScene.direDawa.x;
        aScene.direDawa.labelY = aScene.direDawa.y - 90;
        aScene.harari.labelX = aScene.harari.x;
        aScene.harari.labelY = aScene.harari.y + 90;

        aScene.gambela.labelX = aScene.gambela.x;
        aScene.gambela.labelY = aScene.gambela.y - 100;
        aScene.tigray.labelX = aScene.tigray.x;
        aScene.tigray.labelY = aScene.tigray.y - 100;
        aScene.oromia.labelX = aScene.oromia.x + 300;
        aScene.oromia.labelY = aScene.oromia.y - 120;
        aScene.afar.labelX = aScene.afar.x;
        aScene.afar.labelY = aScene.afar.y - 150;
        aScene.amhara.labelX = aScene.amhara.x + 130;
        aScene.amhara.labelY = aScene.amhara.y - 50;
        aScene.snnpr.labelX = aScene.snnpr.x - 40;
        aScene.snnpr.labelY = aScene.snnpr.y + 90;
        aScene.benishangulGumuz.labelX = aScene.benishangulGumuz.x - 40;
        aScene.benishangulGumuz.labelY = aScene.benishangulGumuz.y;
        aScene.southWest.labelX = aScene.southWest.x - 30;
        aScene.southWest.labelY = aScene.southWest.y - 30;

        // names
        aScene.addisAbaba.name = subjects.addisAbaba;
        aScene.oromia.name = subjects.oromia;
        aScene.snnpr.name = subjects.snnpr;
        aScene.gambela.name = subjects.gambela;
        aScene.amhara.name = subjects.amhara;
        aScene.benishangulGumuz.name = subjects.benishangulGumuz;
        aScene.tigray.name = subjects.tigray;
        aScene.afar.name = subjects.afar;
        aScene.direDawa.name = subjects.direDawa;
        aScene.harari.name = subjects.harari;
        aScene.somali.name = subjects.somali;
        aScene.sidama.name = subjects.sidama;
        aScene.southWest.name = subjects.southWest;

        // create container and put countries into it
        aScene.mapContainer = aScene.add.container(0, 0, [aScene.oromia, aScene.addisAbaba, aScene.gambela, aScene.snnpr, aScene.benishangulGumuz, aScene.amhara, aScene.tigray, aScene.afar, aScene.somali, aScene.harari, aScene.direDawa, aScene.southWest, aScene.sidama]);

        aScene.mapContainer.setSize(width, height);
        aScene.mapContainer.x = 0;
        aScene.mapContainer.y = 0;
     }
}