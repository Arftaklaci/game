"use strict"
var width, height, resize;
var webUrl = "https://world-geography-games.com/world.html";

var labels = 
{
    website         : "World Geography Games",
    title           : "Deserts",
    titleTwo        : "Deserts",
    play            : "play",
    options         : "options",
    map             : "map",
    sound           : "SOUND",
    photos          : "PHOTOS",
    tapStart        : "Tap on the map to start",
    clickStart      : "Click on the map to start",
    incorrect       : "Incorrect. Try again!",
    score           : "Score: ",
    attempts        : "Attempts: ",
    attemptsEnd     : "Attempts",
    points          : "Points",
    back            : "back",
    playAgain       : "Play Again",
    stop            : "Stop",
    skip            : "Skip",
    skipped         : "Skipped",
}

// the order of labels below is important!
var credits = {
  credit1   : "Photo: Shiva Shenoy 2019 (CC-BY)",
  credit2   : "Photo: Jumars91919120 2019 (CC-BY-SA)",
  credit3   : "Photo: Ron Gilbert 2019 (CC-BY-SA)",
  credit4   : "Photo: Anne Adrian 2019 (CC-BY)",
  credit5   : "Photo: Niek van Son 2019 (CC-BY)",
  credit6   : "Photo: Tor Lindstrand 2017 (CC-BY-SA)",
  credit7   : "Photo: Marian Deschain 2011 (CC-BY-SA)",
  credit8   : "Photo: Olga Ernst & Hp.Baumeler 2017 (CC-BY-SA)",
  credit9   : "Photo: Göran Höglund 2019 (CC-BY-SA)",
  credit10  : "Photo: Jessie Eastland 2014 (CC-BY-SA)",
  credit11  : "Photo: Moongateclimber 2007 (Public Domain)",
  credit12  : "Photo: Mussi Katz 2017 (Public Domain)",
  credit13  : "Photo: Claudio Barrientos 2019 (CC-BY-SA)",
  credit14  : "Photo: Valerian Guillot 2019 (CC-BY)",
  credit15  : "Photo: Neiste 2016 (CC-BY-SA)",
  credit16  : "Photo: Christopher Watson 2013 (CC-BY-SA)",
  credit17  : "Photo: Robb Hannawacker 2019 (Public Domain)",
  credit18  : "Photo: Graeme Maclean 2019 (CC-BY)",
  credit19  : "Photo: NASA 2010 (Public Domain)",
  credit20  : "Photo: Dakshil Shah 2016 (CC-BY-SA)"
}
var creditsArray = Object.values(credits);

var subjects = {
  arabianDesert:        "Arabian Desert",
  atacama:              "Atacama",
  blackRockDesert:      "Black Rock Desert",
  chihuahuanDesert:     "Chihuahuan Desert",
  gobi:                 "Gobi",
  greatSandyDesert:     "Great Sandy Desert",
  greatVictoriaDesert:  "Great Victoria Desert",
  kalahari:             "Kalahari",
  karakum:              "Karakum",
  mojave:          	    "Mojave",
  namib:                "Namib",
  negev:  		          "Negev",
  patagonianDesert:     "Patagonian Desert",
  sahara:       	      "Sahara",
  simpsonDesert:        "Simpson Desert",
  sinai:                "Sinai",
  sonoran:              "Sonoran",
  tabernas:             "Tabernas",
  taklamakan:           "Taklamakan",
  thar:                 "Thar"
}


var countriesNames = ["Middle East", "South America", "USA", "Mexico/USA", "China/Mongolia", "Australia", "Australia", "Southern Africa", "Turkmenistan", "USA", "Southern Africa", "Israel", "Argentina/Chile", "Africa", "Australia", "Egypt", "Mexico/USA", "Spain", "China", "India/Pakistan"];

var infoText = ["", 
"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""];
// don't edit below

// sound is on by default
var soundButtonFrame = 0;
// show photos by default
var showPhotos = true;
var photosButtonFrame = 0;
// number of attempts
var attempts = +0;
// number of skipped countries
var skips = +0;
// make array
var questionsArray = Object.values(subjects);
var questionsArrayStatic = [...questionsArray];

// resize
const DEFAULT_WIDTH = 1280
const DEFAULT_HEIGHT = 720
const MAX_WIDTH = DEFAULT_WIDTH * 1.5
const MAX_HEIGHT = DEFAULT_HEIGHT * 1.5
let SCALE_MODE = 'SMOOTH'

const config = {
    type: Phaser.AUTO,
    parent: 'geo-game',
    backgroundColor : 0x34C5EB,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,

    scale: 
    {
        mode: Phaser.Scale.NONE,
        parent: "geo-game",
    },
    scene: [Loading, Menu, Options, UserInterface, GraphUI, Gameplay, Graph]
}

window.addEventListener('load', () => {
    const game = new Phaser.Game(config)
  
    resize = () => {
      const w = window.innerWidth
      const h = window.innerHeight
  
      let width = DEFAULT_WIDTH
      let height = DEFAULT_HEIGHT
      let maxWidth = MAX_WIDTH
      let maxHeight = MAX_HEIGHT
      let scaleMode = SCALE_MODE
  
      let scale = Math.min(w / width, h / height)
      let newWidth = Math.min(w / scale, maxWidth)
      let newHeight = Math.min(h / scale, maxHeight)
  
      let defaultRatio = DEFAULT_WIDTH / DEFAULT_HEIGHT
      let maxRatioWidth = MAX_WIDTH / DEFAULT_HEIGHT
      let maxRatioHeight = DEFAULT_WIDTH / MAX_HEIGHT
  
      // smooth scaling
      let smooth = 1
      if (scaleMode === 'SMOOTH') {
        const maxSmoothScale = 1.15
        const normalize = (value, min, max) => {
          return (value - min) / (max - min)
        }
        if (width / height < w / h) {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioWidth) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        } else {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioHeight) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        }
      }

      // resize the game
      game.scale.resize(newWidth * smooth, newHeight * smooth)
      // scale the width and height of the css
      game.canvas.style.width = newWidth * scale + 'px'
      game.canvas.style.height = newHeight * scale + 'px'
      // center the game with css margin
      game.canvas.style.marginTop = `${(h - newHeight * scale) / 2}px`
      game.canvas.style.marginLeft = `${(w - newWidth * scale) / 2}px`
    }

    window.addEventListener('resize', event => {
      resize()
    })
  
    resize()
  })
