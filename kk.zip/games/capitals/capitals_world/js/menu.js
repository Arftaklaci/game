var menuState =
{
	
create: function() {
    init()

    // bg rectangle
    var bg = game.add.image(0, 0, 'bg');
    // title
    var gameTitle = game.add.text(W/2, 35,title_label, {font:"44px bold", fill:"#000000"});
    gameTitle.anchor.setTo(0.5, 0);
    var bgMenu = game.add.sprite(W / 2, 140, 'bgMenu');
    bgMenu.anchor.setTo(0.5, 0);

    // buttons
    buttonPlay = game.add.button(W / 2 - 92, H / 2 + 30, 'button_start', buttonClicked);
    buttonPlay.width = 73;
    buttonPlay.height = 73;
    buttonOptions = game.add.button(W / 2 - 90, H / 2 + 115, 'button_options', buttonClicked);
    buttonLibrary = game.add.button(W / 2 - 94, H / 2 + 200, 'button_library', buttonClicked);

    buttonPlay.scale.x = .9;
    buttonPlay.scale.y = .9;
    buttonOptions.scale.x = .9;
    buttonOptions.scale.y = .9;
    buttonLibrary.scale.x = .9;
    buttonLibrary.scale.y = .9;

    // text
    textPlay = game.add.text(W/2, H/2 + 40, play_label, {font:"30px bold", fill:"#000000"});
    buttonPlayClickable = game.add.button(textPlay.x - 40, textPlay.y - 10, 'button_invisible', buttonClicked);
    buttonPlayClickable.width = 50 + textPlay.width;
    buttonPlayClickable.height = 50;

    textOptions = game.add.text(W/2, H/2 + 125,  options_label, {font:"30px bold", fill:"#000000"});
    buttonOptionsClickable = game.add.button(textOptions.x - 40, textOptions.y - 10, 'button_invisible', buttonClicked);
    buttonOptionsClickable.width = 50 + textOptions.width;
    buttonOptionsClickable.height = 50;

    textLibrary = game.add.text(W/2, H/2 + 205, library_label, {font:"30px bold", fill:"#000000"});
    buttonLibraryClickable = game.add.button(textOptions.x - 40, textLibrary.y - 10, 'button_invisible', buttonClicked);
    buttonLibraryClickable.width = 50 + textLibrary.width;
    buttonLibraryClickable.height = 50;
}

}

function buttonClicked(btn) {
    if (btn == buttonPlay || btn == buttonPlayClickable) {
        game.state.start("level1");
    } 
    else if (btn == buttonOptions || btn == buttonOptionsClickable) {
        game.state.start("options", true, false);
    } 
    else if (btn == buttonLibrary || btn == buttonLibraryClickable) {
        game.state.start("library");
    }
}