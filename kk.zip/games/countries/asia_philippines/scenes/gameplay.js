"use strict"
var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        });
    }
    
    create() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;
        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;
       camera.zoom = .45;
       
        // min max zoom
        this.minZoom = .45;
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.5;
        }
        else {
            this.maxZoom = 1.8;
        }
        // display countries in this scene
        this.displayMap(this);
        // get countries (sprites) array from the container
        this.countriesArray = this.mapContainer.getAll();
        // for each subject (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {
            /*
            this.countriesArray[i].setInteractive()
            this.input.setDraggable(this.countriesArray[i]);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {
                gameObject.x = dragX;
                gameObject.y = dragY;
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });
            */
            
            let subject = this.countriesArray[i];
            // make countries sprites interactive
            subject.setInteractive({ 
                useHandCursor: true,             
                pixelPerfect: true,
                alphaTolerance: 255
             });
             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over subject
                subject.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                        if (subject.isSprite) {
                            subject.setFrame(1);
                        }
                        else {
                            subject.setTintFill(0xFFFFFF);
                        }
                    }
                },this);
                subject.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        if (subject.isSprite) {
                            subject.setFrame(0);
                        }
                        else {
                            subject.clearTint();
                        }
                    }
                },this);
            }
            subject.on('pointerdown', () => {
                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });
            subject.on('pointerup', () => {
                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);
                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    subject.xPos = camera.x;
                    subject.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false) {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === subject.name) {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this subject
                            subject.disableInteractive();
                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }
                            // create the subject label
                            this.showLabels(subject);
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // else don't tap, drag the map
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();
        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false) {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();
                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip, ui.buttonSound],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                let dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {
                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        let drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }
                }).on('pinch', dragScale => {
                    let scaleFactor = dragScale.scaleFactor;
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                }, this);
                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }
        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2 - 55, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 50, align: "center", color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2 - 55, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 50, align: "center", color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });
        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                camera.zoom *= 0.9;
            }
        }
        // limit zoom
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.mapContainer.setSize(width, height);
        this.mapContainer.x = 0;
        this.mapContainer.y = 0;

        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2-55, height/2);
        }
    }

    getQuestion() {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;
        this.questionsArray.shift();

        // tween
        this.tweens.add({
           targets: [ui.questionText],
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;
        // play sound
        this.gameOverSound.play();
        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        ui.buttonSound.destroy();
        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {
        // tween camera
        if (camera.zoom > this.minZoom) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: this.minZoom,
                x: 0, 
                y: 0,
                duration: 1500,
                onComplete: () => {
                    
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }
        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: 0,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showLabels(subject) {
        // create white rectangle
        subject.rect = this.add.sprite(subject.x, subject.y, "rectangle");
        // subject name
        subject.txt = this.add.text(subject.x, subject.y, subject.name, { fontFamily: "bold", fontSize: 28, align: "center", color: '#000000' });
        subject.txt.setOrigin(.5,.5);
        
        // position text
        if (subject.labelX) {
            subject.txt.x = subject.labelX;
            subject.txt.y = subject.labelY;
            subject.rect.x = subject.labelX;
            subject.rect.y = subject.labelY;
        }
        subject.rect.displayWidth = subject.txt.width + 4;
        subject.rect.displayHeight = subject.txt.height + 2;

        if (subject.hasLine) {
            if (subject.name === subjects.nationalCapitalRegion) {
                const line = this.add.image(subject.x, subject.y, "lineNationalCapitalRegion").setOrigin(1,.5);
                this.mapContainer.add(line);
            }
        }
    }

    displayMap(aScene) {
        //aScene.map = aScene.add.image(width/2, height/2, "map");

        aScene.bangsamoro = aScene.add.sprite(width/2 - 32.2, height/2 + 988.8, "texture", "bangsamoro.png");
        aScene.bicolRegion = aScene.add.sprite(width/2 + 255.3, height/2 - 62.5, "texture", "bicolRegion.png");
        aScene.cagayanValley = aScene.add.sprite(width/2 - 4.1, height/2 - 874, "texture", "cagayanValley.png");
        aScene.calabarzon = aScene.add.sprite(width/2 + 1.4, height/2 - 236, "texture", "calabarzon.png");
        aScene.caraga = aScene.add.sprite(width/2 + 640.7, height/2 + 553, "texture", "caraga.png");
        aScene.centralLuzon = aScene.add.sprite(width/2 - 235.4, height/2 - 431.1, "texture", "centralLuzon.png");
        aScene.centralVisayas = aScene.add.sprite(width/2 + 294.5, height/2 + 387.6, "texture", "centralVisayas.png");
        aScene.easternVisayas = aScene.add.sprite(width/2 + 509, height/2 + 225, "texture", "easternVisayas.png");
        aScene.cordilleraRegion = aScene.add.sprite(width/2 - 85.4, height/2 - 711.5, "texture", "cordilleraRegion.png");
        aScene.davaoRegion = aScene.add.sprite(width/2 + 646.4, height/2 + 940, "texture", "davaoRegion.png");
        aScene.ilocosRegion = aScene.add.sprite(width/2 - 186.4, height/2 - 679.3, "texture", "ilocosRegion.png");
        aScene.mimaropa = aScene.add.sprite(width/2 - 306.8, height/2 + 293.7, "texture", "mimaropa.png");
        aScene.nationalCapitalRegion = aScene.add.sprite(width/2 - 94.2, height/2 - 293.5, "texture", "nationalCapitalRegion.png");
        aScene.northernMindanao = aScene.add.sprite(width/2 + 439, height/2 + 689, "texture", "northernMindanao.png");
        aScene.soccsksargen = aScene.add.sprite(width/2 + 482.4, height/2 + 948.4, "texture", "soccsksargen.png");
        aScene.westernVisayas = aScene.add.sprite(width/2 + 105.3, height/2 + 302, "texture", "westernVisayas.png");
        aScene.zamboangaPeninsula = aScene.add.sprite(width/2 + 175.4, height/2 + 781.6, "texture", "zamboangaPeninsula.png");

        // line
        aScene.nationalCapitalRegion.hasLine = true;
        
        // labels
        aScene.soccsksargen.labelX = aScene.soccsksargen.x - 15;
        aScene.soccsksargen.labelY = aScene.soccsksargen.y + 55;
        aScene.zamboangaPeninsula.labelX = aScene.zamboangaPeninsula.x - 40;
        aScene.zamboangaPeninsula.labelY = aScene.zamboangaPeninsula.y - 10;
        aScene.bangsamoro.labelX = aScene.bangsamoro.x + 360;
        aScene.bangsamoro.labelY = aScene.bangsamoro.y - 90;
        aScene.centralVisayas.labelX = aScene.centralVisayas.x + 40;
        aScene.centralVisayas.labelY = aScene.centralVisayas.y + 40;
        aScene.davaoRegion.labelX = aScene.davaoRegion.x + 30;
        aScene.davaoRegion.labelY = aScene.davaoRegion.y - 70;
        aScene.bicolRegion.labelX = aScene.bicolRegion.x + 30;
        aScene.bicolRegion.labelY = aScene.bicolRegion.y - 10;
        aScene.calabarzon.labelX = aScene.calabarzon.x - 20;
        aScene.calabarzon.labelY = aScene.calabarzon.y + 15;
        aScene.nationalCapitalRegion.labelX = aScene.nationalCapitalRegion.x - 300;
        aScene.nationalCapitalRegion.labelY = aScene.nationalCapitalRegion.y;
        aScene.centralLuzon.labelX = aScene.centralLuzon.x + 90;
        aScene.centralLuzon.labelY = aScene.centralLuzon.y + 15;
        aScene.cagayanValley.labelX = aScene.cagayanValley.x + 100;
        aScene.cagayanValley.labelY = aScene.cagayanValley.y + 95;
        aScene.ilocosRegion.labelX = aScene.ilocosRegion.x - 20;
        aScene.ilocosRegion.labelY = aScene.ilocosRegion.y - 160;

        // names
        aScene.bangsamoro.name = subjects.bangsamoro;
        aScene.bicolRegion.name = subjects.bicolRegion;
        aScene.cagayanValley.name = subjects.cagayanValley;
        aScene.calabarzon.name = subjects.calabarzon;
        aScene.caraga.name = subjects.caraga;
        aScene.centralLuzon.name = subjects.centralLuzon;
        aScene.centralVisayas.name = subjects.centralVisayas;
        aScene.cordilleraRegion.name = subjects.cordilleraRegion;
        aScene.davaoRegion.name = subjects.davaoRegion;
        aScene.easternVisayas.name = subjects.easternVisayas;
        aScene.ilocosRegion.name = subjects.ilocosRegion;
        aScene.mimaropa.name = subjects.mimaropa;
        aScene.nationalCapitalRegion.name = subjects.nationalCapitalRegion;
        aScene.northernMindanao.name = subjects.northernMindanao;
        aScene.soccsksargen.name = subjects.soccsksargen;
        aScene.westernVisayas.name = subjects.westernVisayas;
        aScene.zamboangaPeninsula.name = subjects.zamboangaPeninsula;
  
        // create container
        aScene.mapContainer = aScene.add.container(0, 0, [aScene.bangsamoro, aScene.bicolRegion, aScene.cagayanValley, aScene.calabarzon, aScene.caraga, aScene.centralLuzon, aScene.centralVisayas, aScene.cordilleraRegion, aScene.davaoRegion, aScene.easternVisayas, aScene.ilocosRegion, aScene.mimaropa, aScene.nationalCapitalRegion, aScene.northernMindanao, aScene.soccsksargen, aScene.westernVisayas, aScene.zamboangaPeninsula]);

        aScene.mapContainer.setSize(width, height);
        aScene.mapContainer.x = 0;
        aScene.mapContainer.y = 0;
     }
}