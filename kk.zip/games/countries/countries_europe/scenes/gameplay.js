"use strict"

var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        })
    }

    create() {

        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;
        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;
       camera.zoom = 0.7;
        // min max zoom
        this.minZoom = 0.6;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.5;
        }
        else {
            this.maxZoom = 2;
        }
        // display countries in this scene
        this.displayEurope(this);
        // get countries (sprites) array from the container
        this.countriesArray = this.europeContainer.getAll();
        // for each country (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {
            let country = this.countriesArray[i];
            /* enable drag to position countries
            country.setInteractive()
            this.input.setDraggable(country);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {

                gameObject.x = dragX;
                gameObject.y = dragY;
        
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });
            */

            // make countries sprites interactive
            country.setInteractive({ 
                useHandCursor: true,             
                pixelPerfect: true,
                alphaTolerance: 255
             });

             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over country
                country.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                        if (country.isMicrostate === true) {
                            this.mouseOverMicro.setVisible(true);
                            this.mouseOverMicro.x = country.x;
                            this.mouseOverMicro.y = country.y;
                        }
                        else {
                            country.alpha = .5;
                            // hide microstetes
                            if (country.name === countriesLabels.france) {
                                this.andorra.alpha = 0.01;
                                this.monaco.alpha = 0.01;
                            }
                            else if (country.name === countriesLabels.spain) {
                                this.andorra.alpha = 0.01;
                            }
                            else if (country.name === countriesLabels.italy) {
                                this.monaco.alpha = 0.01;
                                this.sanMarino.alpha = 0.01;
                                this.vaticanCity.alpha = 0.01;
                            }
                            else if (country.name === countriesLabels.switzerland) {
                                this.liechtenstein.alpha = 0.01;
                            }
                        }
                    }
                },this);

                country.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        if (country.isMicrostate === true) {
                            this.mouseOverMicro.setVisible(false);
                        }
                        else {
                            country.alpha = 1;
                            // show microstetes
                            if (country.name === countriesLabels.france) {
                                this.andorra.alpha = 1;
                                this.monaco.alpha = 1;
                            }
                            else if (country.name === countriesLabels.spain) {
                                this.andorra.alpha = 1;
                            }
                            else if (country.name === countriesLabels.italy) {
                                this.monaco.alpha = 1;
                                this.sanMarino.alpha = 1;
                                this.vaticanCity.alpha = 1;
                            }
                            else if (country.name === countriesLabels.switzerland) {
                                this.liechtenstein.alpha = 1;
                            }
                        }
                    }
                },this);
            }

            country.on('pointerdown', () => {
                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });

            country.on('pointerup', () => {
                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);

                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    country.xPos = camera.x;
                    country.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false)
                    {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === country.name) {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this country
                            country.disableInteractive();

                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }

                            // create the country label
                            this.showEuropeLabels(country);
    
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
    
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // drag
                else {
                    // console.log("don't tap, drag the map");
                }
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();

        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false)
            {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();

                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                var dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {

                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        var drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }

                }).on('pinch', dragScale => {
                    var scaleFactor = dragScale.scaleFactor;
                    
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                    
                }, this);

                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }

        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 34, color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 34, color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });

        // mouse over microstate sprite
        this.mouseOverMicro = this.add.image(0,0, 'mouseOverMicrostate');
        this.mouseOverMicro.setVisible(false);

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                
                camera.zoom *= 0.9;
            }
        }

        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.europeContainer.setSize(width, height);
        this.europeContainer.x = 0;
        this.europeContainer.y = 0; 
        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2, height/2);
        }
    }

    getQuestion()
    {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;
        this.questionsArray.shift();
        
        // tween
        this.tweens.add({
           targets: [ui.questionText],
           //scaleX: '-=.2',
           //angle: 10,
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;
        // play sound
        this.gameOverSound.play();
        // disable mouse over Turkey
        this.turkey.disableInteractive();
        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {

        // tween camera
        if (camera.zoom > this.minZoom) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: .7,
                x: 0, 
                y: 0,
                duration: 2000,
                onComplete: () => {
                    
                    this.canZoom = true;
                    
                    // show end screen
                    ui.endScreen();
                },
            });
        }

        this.tweens.add({
            targets: [camera],
            scrollX: 100,
            scrollY: 0,
            ease: 'Linear',
            duration: 2000,
        });

        // animation
        this.water = this.add.sprite(this.iceland.x + 380, this.iceland.y - 100, 'water');
        this.water.alpha = .4;
        this.bearBody = this.add.image(this.iceland.x + 380, this.iceland.y - 250, 'bearBody');
        this.bearHead = this.add.sprite(this.iceland.x + 310, this.iceland.y - 380, 'bearHead');

        // water animation
        let waterConfig = {
            key: "waterAnim",
            frames: this.anims.generateFrameNumbers("water", { frames: [ 0,1,2,3,3,1 ] }),
            frameRate: 12,
            repeat: -1
        };
        this.anims.create(waterConfig);
        this.water.anims.play("waterAnim");

        // head animation
        let headConfig = {
            key: "headAnim",
            frames: this.anims.generateFrameNumbers("bearHead", { frames: [ 0,1,2,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, 0,0,0,0,0 ] }),
            frameRate: 14,
            repeat: -1
        };
        this.anims.create(headConfig);
        this.bearHead.anims.play("headAnim");

        this.europeContainer.add(this.water);
        this.europeContainer.add(this.bearBody);
        this.europeContainer.add(this.bearHead);
        // add water behind countries
        this.europeContainer.sendToBack(this.water);

        // tween the bear
        this.tweens.add({
            targets: [this.water, this.bearBody, this.bearHead],
            x: '-= 450',
            y: '+= 500',
            ease: 'Linear',
            duration: 6000,
            onComplete: () => {
                this.tweens.add({
                    targets: [this.water, this.bearBody, this.bearHead],
                    x: '+= 120',
                    y: '+= 200',
                    ease: 'Linear',
                    duration: 2000,
                    onComplete: () => {
                        ui.endScreen();
                    }
                 });
            }
         });
    }

    showEuropeLabels(country) {
        
            country.txt = this.add.text(country.x, country.y, country.name, { fontFamily: "bold", fontSize: 19, color: '#000000' });
            country.txt.setOrigin(.5,.5);
            this.europeContainer.add(country.txt);
            // position text
            if (country.labelX) {
                country.txt.x = country.labelX;
                country.txt.y = country.labelY;
            }

            // create a line if needed
            if (country.hasLine) {
                // different lines for Vatican and San Marino
                if (country.name === countriesLabels.sanMarino || country.name === countriesLabels.vaticanCity) {
                let line = this.add.image(country.lineX, country.lineY, "lineSanMarino");
                line.setOrigin(1,0);
                 this.europeContainer.add(line);
                }
                // north macedonia
                else if (country.name === countriesLabels.northMacedonia) {
                    let line = this.add.image(country.lineX, country.lineY, "lineMacedonia");
                    line.setOrigin(0.5,0.5);
                    this.europeContainer.add(line);
                }
                else {
                    let line = this.add.image(country.lineX, country.lineY, "line");
                    line.setOrigin(0,0.5);
                    // flip horizontally
                    if (country.flipLine) {
                        line.scaleX = -1;
                        line.x += 4;
                    }
                    // rotate a line
                    if (country.name === countriesLabels.kosovo) {
                        line.angle = 6;
                    }
                    else if (country.name === countriesLabels.montenegro) {
                        line.angle = -4;
                    }
                    else if (country.name === countriesLabels.bosnia) {
                        line.angle = -2;
                    }
                    this.europeContainer.add(line);
                }
            }

            // create white rectangle
            country.rect = this.add.sprite(country.txt.x, country.txt.y, "rectangle");
            country.rect.displayWidth = country.txt.width + 2;
            country.rect.displayHeight = country.txt.height;
            this.europeContainer.add(country.rect);

            // bring to top text field
            this.europeContainer.bringToTop(country.txt);
        
    }
    
    displayEurope(aScene) {

        aScene.poland = aScene.add.sprite(width/2 + 185, height/2 + 31, "poland");
        aScene.turkey = aScene.add.sprite(width/2 + 681, height/2 + 401, "turkey");
        aScene.greece = aScene.add.sprite(width/2 + 328, height/2 + 442, "greece");
        aScene.ukraine = aScene.add.sprite(width/2 + 476, height/2 + 138, "ukraine");
        aScene.moldova = aScene.add.sprite(width/2 + 414, height/2 + 180, "moldova");
        aScene.romania = aScene.add.sprite(width/2 + 336, height/2 + 210, "romania");
        aScene.russia = aScene.add.sprite(width/2 + 671, height/2 - 59, "russia");
        aScene.belarus = aScene.add.sprite(width/2 + 387, height/2 - 22, "belarus");
        aScene.hungary = aScene.add.sprite(width/2 + 198, height/2 + 173, "hungary");
        aScene.slovenia = aScene.add.sprite(width/2 + 91, height/2 + 203, "slovenia");
        aScene.slovakia = aScene.add.sprite(width/2 + 201, height/2 + 127, "slovakia");
        aScene.czechRepublic = aScene.add.sprite(width/2 + 100, height/2 + 93, "czechRepublic");
        aScene.germany = aScene.add.sprite(width/2 - 19, height/2 + 54, "germany");
        aScene.france = aScene.add.sprite(width/2 - 212, height/2 + 203, "france");
        aScene.italy = aScene.add.sprite(width/2 + 36.5, height/2 + 336, "italy");
        aScene.italy.labelX = aScene.italy.x + 70;
        aScene.italy.labelY = aScene.italy.y + 30;
        aScene.belgium = aScene.add.sprite(width/2 - 160, height/2 + 72, "belgium");
        aScene.netherlands = aScene.add.sprite(width/2 - 139, height/2 + 24.5, "netherlands");
        aScene.denmark = aScene.add.sprite(width/2 + 6, height/2 - 95, "denmark");
        aScene.serbia = aScene.add.sprite(width/2 + 239, height/2 + 262, "serbia");
        aScene.serbia.labelX = aScene.serbia.x;
        aScene.serbia.labelY = aScene.serbia.y - 20;
        aScene.switzerland = aScene.add.sprite(width/2 - 72, height/2 + 184, "switzerland");
        aScene.switzerland.labelX = aScene.switzerland.x;
        aScene.switzerland.labelY = aScene.switzerland.y + 20;
        aScene.denmark.labelX = aScene.denmark.x - 30;
        aScene.denmark.labelY = aScene.denmark.y;
        aScene.finland = aScene.add.sprite(width/2 + 304, height/2 - 338, "finland");
		//label position finland
		aScene.finland.labelX = aScene.finland.x;
        aScene.finland.labelY = aScene.finland.y + 60;
        aScene.sweden = aScene.add.sprite(width/2 + 129, height/2 - 261, "sweden");
		//label position sweden
		aScene.sweden.labelX = aScene.sweden.x - 40;
        aScene.sweden.labelY = aScene.sweden.y + 50;
        aScene.unitedKingdom = aScene.add.sprite(width/2 - 335, height/2 - 70, "unitedKingdom");
        aScene.ireland = aScene.add.sprite(width/2 - 456, height/2 - 13, "ireland");
        aScene.portugal = aScene.add.sprite(width/2 - 480, height/2 + 408, "portugal");
        aScene.spain = aScene.add.sprite(width/2 - 341, height/2 + 397, "spain");
        aScene.iceland = aScene.add.sprite(width/2 - 631, height/2 - 343, "iceland");
        aScene.lithuania = aScene.add.sprite(width/2 + 286.5, height/2 - 65.5, "lithuania");
        aScene.estonia = aScene.add.sprite(width/2 + 300.5, height/2 - 165, "estonia");
        aScene.latvia = aScene.add.sprite(width/2 + 300.5, height/2 - 116, "latvia");
        aScene.andorra = aScene.add.sprite(width/2 - 241, height/2 + 314.5, "andorra");
        aScene.andorra.isMicrostate = true;
        aScene.andorra.labelX = aScene.andorra.x;
        aScene.andorra.labelY = aScene.andorra.y + 30;
        aScene.monaco = aScene.add.sprite(width/2 - 93.5, height/2 + 276, "monaco");
        aScene.monaco.isMicrostate = true;
        aScene.monaco.labelX = aScene.monaco.x;
        aScene.monaco.labelY = aScene.monaco.y + 30;
        aScene.cyprus = aScene.add.sprite(width/2 + 573, height/2 + 550, "cyprus");
        aScene.cyprus.labelX = aScene.cyprus.x;
        aScene.cyprus.labelY = aScene.cyprus.y + 30;
        aScene.norway = aScene.add.sprite(width/2 + 122.5, height/2 - 327, "norway");
        aScene.norway.labelX = aScene.norway.x - 160;
        aScene.norway.labelY = aScene.norway.y + 70;
        aScene.austria = aScene.add.sprite(width/2 + 51, height/2 + 157, "austria");
        aScene.austria.labelX = aScene.austria.x + 20;
        aScene.austria.labelY = aScene.austria.y;
        aScene.croatia = aScene.add.sprite(width/2 + 128.5, height/2 + 254, "croatia");
        aScene.croatia.labelX = aScene.croatia.x - 20;
        aScene.croatia.labelY = aScene.croatia.y - 20;

        aScene.bosnia = aScene.add.sprite(width/2 + 160, height/2 + 272, "bosnia");
        aScene.bosnia.labelX = aScene.bosnia.x + 400;
        aScene.bosnia.labelY = aScene.bosnia.y - 20;
        aScene.bosnia.hasLine = true;
        aScene.bosnia.lineX = aScene.bosnia.x;
        aScene.bosnia.lineY = aScene.bosnia.y - 10;
        aScene.montenegro = aScene.add.sprite(width/2 + 205, height/2 + 309, "montenegro");
        aScene.montenegro.labelX = aScene.montenegro.x + 300;
        aScene.montenegro.labelY = aScene.montenegro.y - 30;
        aScene.montenegro.hasLine = true;
        aScene.montenegro.lineX = aScene.montenegro.x - 10;
        aScene.montenegro.lineY = aScene.montenegro.y - 10;
        aScene.kosovo = aScene.add.sprite(width/2 + 242, height/2 + 313, "kosovo");
        aScene.kosovo.labelX = aScene.kosovo.x + 290;
        aScene.kosovo.labelY = aScene.kosovo.y + 30;
        aScene.kosovo.hasLine = true;
        aScene.kosovo.lineX = aScene.kosovo.x - 10;
        aScene.kosovo.lineY = aScene.kosovo.y;

        aScene.northMacedonia = aScene.add.sprite(width/2 + 264, height/2 + 342, "northMacedonia");
        aScene.northMacedonia.labelX = aScene.northMacedonia.x + 100;
        aScene.northMacedonia.labelY = aScene.northMacedonia.y + 50;
        aScene.northMacedonia.hasLine = true;
        aScene.northMacedonia.lineX = aScene.northMacedonia.x + 20;
        aScene.northMacedonia.lineY = aScene.northMacedonia.y + 25;

        aScene.luxembourg = aScene.add.sprite(width/2 - 117, height/2 + 95.5, "luxembourg");
        aScene.luxembourg.isMicrostate = true;
        aScene.luxembourg.labelX = aScene.luxembourg.x - 300;
        aScene.luxembourg.labelY = aScene.luxembourg.y;
        aScene.luxembourg.hasLine = true;
        aScene.luxembourg.flipLine = true;
        aScene.luxembourg.lineX = aScene.luxembourg.x;
        aScene.luxembourg.lineY = aScene.luxembourg.y;
        aScene.liechtenstein = aScene.add.sprite(width/2 - 40, height/2 + 173, "liechtenstein");
        aScene.liechtenstein.isMicrostate = true;
        aScene.liechtenstein.labelX = aScene.liechtenstein.x - 360;
        aScene.liechtenstein.labelY = aScene.liechtenstein.y;
        aScene.liechtenstein.hasLine = true;
        aScene.liechtenstein.flipLine = true;
        aScene.liechtenstein.lineX = aScene.liechtenstein.x;
        aScene.liechtenstein.lineY = aScene.liechtenstein.y;

        aScene.sanMarino = aScene.add.sprite(width/2 + 29, height/2 + 270, "sanMarino");
        aScene.sanMarino.isMicrostate = true;
        aScene.sanMarino.labelX = aScene.sanMarino.x - 80;
        aScene.sanMarino.labelY = aScene.sanMarino.y + 65;
        aScene.sanMarino.hasLine = true;
        aScene.sanMarino.lineX = aScene.sanMarino.x - 6;
        aScene.sanMarino.lineY = aScene.sanMarino.y + 6;

        aScene.vaticanCity = aScene.add.sprite(width/2 + 36.5, height/2 + 336, "vaticanCity");
        aScene.vaticanCity.isMicrostate = true;
        aScene.vaticanCity.labelX = aScene.vaticanCity.x - 50;
        aScene.vaticanCity.labelY = aScene.vaticanCity.y + 60;
        aScene.vaticanCity.hasLine = true;
        aScene.vaticanCity.lineX = aScene.vaticanCity.x - 6;
        aScene.vaticanCity.lineY = aScene.vaticanCity.y + 6;

        aScene.malta = aScene.add.sprite(width/2 + 85, height/2 + 517, "malta");
        aScene.malta.isMicrostate = true;
        aScene.malta.labelX = aScene.malta.x;
        aScene.malta.labelY = aScene.malta.y + 30;
        aScene.albania = aScene.add.sprite(width/2 + 226, height/2 + 356, "albania");
        aScene.albania.labelX = aScene.albania.x - 10;
        aScene.albania.labelY = aScene.albania.y + 10;
        aScene.bulgaria = aScene.add.sprite(width/2 + 354, height/2 + 307, "bulgaria");
        aScene.bulgaria.labelX = aScene.bulgaria.x + 5;
        aScene.bulgaria.labelY = aScene.bulgaria.y;

        aScene.poland.name = countriesLabels.poland;
        aScene.malta.name = countriesLabels.malta;
        aScene.albania.name = countriesLabels.albania;
        aScene.montenegro.name = countriesLabels.montenegro;
        aScene.kosovo.name = countriesLabels.kosovo;
        aScene.bosnia.name = countriesLabels.bosnia;
        aScene.serbia.name = countriesLabels.serbia;
        aScene.croatia.name = countriesLabels.croatia;
        aScene.northMacedonia.name = countriesLabels.northMacedonia;
        aScene.bulgaria.name = countriesLabels.bulgaria;
        aScene.greece.name = countriesLabels.greece;
        aScene.romania.name = countriesLabels.romania;
        aScene.ukraine.name = countriesLabels.ukraine;
        aScene.moldova.name = countriesLabels.moldova;
        aScene.russia.name = countriesLabels.russia;
        aScene.belarus.name = countriesLabels.belarus;
        aScene.hungary.name = countriesLabels.hungary;
        aScene.slovenia.name = countriesLabels.slovenia;
        aScene.slovakia.name = countriesLabels.slovakia;
        aScene.austria.name = countriesLabels.austria;
        aScene.czechRepublic.name = countriesLabels.czechRepublic;
        aScene.germany.name = countriesLabels.germany;
        aScene.italy.name = countriesLabels.italy;
        aScene.france.name = countriesLabels.france;
        aScene.switzerland.name = countriesLabels.switzerland;
        aScene.belgium.name = countriesLabels.belgium;
        aScene.netherlands.name = countriesLabels.netherlands;
        aScene.finland.name = countriesLabels.finland;
        aScene.sweden.name = countriesLabels.sweden;
        aScene.norway.name = countriesLabels.norway;
        aScene.denmark.name = countriesLabels.denmark;
        aScene.unitedKingdom.name = countriesLabels.unitedKingdom;
        aScene.ireland.name = countriesLabels.ireland;
        aScene.luxembourg.name = countriesLabels.luxembourg;
        aScene.spain.name = countriesLabels.spain;
        aScene.portugal.name = countriesLabels.portugal;
        aScene.cyprus.name = countriesLabels.cyprus;
        aScene.iceland.name = countriesLabels.iceland;
        aScene.lithuania.name = countriesLabels.lithuania;
        aScene.estonia.name = countriesLabels.estonia;
        aScene.latvia.name = countriesLabels.latvia;
        aScene.andorra.name = countriesLabels.andorra;
        aScene.liechtenstein.name = countriesLabels.liechtenstein;
        aScene.monaco.name = countriesLabels.monaco;
        aScene.vaticanCity.name = countriesLabels.vaticanCity;
        aScene.sanMarino.name = countriesLabels.sanMarino;
 
        // create container and put countries into it
        aScene.europeContainer = aScene.add.container(0, 0, [aScene.iceland, aScene.unitedKingdom, aScene.ireland, aScene.russia, aScene.spain, aScene.portugal, aScene.finland, aScene.sweden, aScene.norway, aScene.ukraine, aScene.germany, aScene.denmark, aScene.italy, aScene.france, aScene.poland, aScene.belarus, aScene.romania, aScene.greece, aScene.bulgaria, aScene.hungary, aScene.austria, aScene.serbia, aScene.northMacedonia,aScene.croatia, aScene.albania, aScene.bosnia, aScene.czechRepublic, aScene.slovakia, aScene.montenegro, aScene.kosovo,  aScene.malta, aScene.moldova, aScene.slovenia, aScene.switzerland, aScene.netherlands, aScene.belgium, aScene.luxembourg, aScene.cyprus, aScene.lithuania, aScene.estonia, aScene.latvia, aScene.andorra, aScene.liechtenstein, aScene.monaco, aScene.sanMarino, aScene.vaticanCity]);
        
        aScene.europeContainer.setSize(width, height);
        aScene.europeContainer.x = 0;
        aScene.europeContainer.y = 0;     
     }
}
