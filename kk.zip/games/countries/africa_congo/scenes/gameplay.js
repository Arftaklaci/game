"use strict"
var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        });
    }
    
    create() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;
        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;
       camera.zoom = .55;
       camera.scrollY = -50;
        // min max zoom
        this.minZoom = .55;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.6;
        }
        else {
            this.maxZoom = 1.9;
        }
        // display countries in this scene
        this.displayMap(this);
        // get countries (sprites) array from the container
        this.countriesArray = this.mapContainer.getAll();
        // for each subject (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {
            /* development phase - enable drag to position countries
            this.countriesArray[i].setInteractive()
            this.input.setDraggable(this.countriesArray[i]);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {
                gameObject.x = dragX;
                gameObject.y = dragY;
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });
            */
            
            let subject = this.countriesArray[i];
            // make countries sprites interactive
            subject.setInteractive({ 
                useHandCursor: true,             
                pixelPerfect: true,
                alphaTolerance: 255
             });
             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over subject
                subject.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                       subject.setTintFill(0xFFFFFF);
                    }
                },this);
                subject.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        subject.clearTint();
                    }
                },this);
            }
            subject.on('pointerdown', () => {
                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });
            subject.on('pointerup', () => {
                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);
                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    subject.xPos = camera.x;
                    subject.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false) {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === subject.name) {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this subject
                            subject.disableInteractive();
                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }
                            // create the subject label
                            this.showLabels(subject);
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // else don't tap, drag the map
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();
        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false) {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();
                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip, ui.buttonSound],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                let dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {
                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        let drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }
                }).on('pinch', dragScale => {
                    let scaleFactor = dragScale.scaleFactor;
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                }, this);
                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }
        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2 + 100, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 70, align: "center", color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2 + 100, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 70, align: "center", color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });
        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                camera.zoom *= 0.9;
            }
        }
        // limit zoom
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.mapContainer.setSize(width, height);
        this.mapContainer.x = 0;
        this.mapContainer.y = 0;

        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2 + 100, height/2);
        }
    }

    getQuestion() {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;
        this.questionsArray.shift();

        if (ui.questionText.text === subjects.newfoundland) {
            ui.questionText.setFontSize(26);
        }
        else {
            ui.questionText.setFontSize(34);
        }

        // tween
        this.tweens.add({
           targets: [ui.questionText],
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;
        // play sound
        this.gameOverSound.play();
        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        ui.buttonSound.destroy();
        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {
        // tween camera
        if (camera.zoom > .55 || camera.zoom < .55) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: .55,
                x: 0, 
                y: 0,
                duration: 1500,
                onComplete: () => {
                    
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }
        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: -20,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showLabels(subject) {
        // create white rectangle
        subject.rect = this.add.sprite(subject.x, subject.y, "rectangle");
        // subject name
        subject.txt = this.add.text(subject.x, subject.y, subject.name, { fontFamily: "bold", fontSize: 28, align: "center", color: '#000000' });
        subject.txt.setOrigin(.5,.5);
        // position text
        if (subject.labelX) {
            subject.txt.x = subject.labelX;
            subject.txt.y = subject.labelY;
            subject.rect.x = subject.labelX;
            subject.rect.y = subject.labelY;
        }
        subject.rect.displayWidth = subject.txt.width + 4;
        subject.rect.displayHeight = subject.txt.height + 2;

        if (subject.hasLine) {
            let line;
            if (subject.name === subjects.kinshasa) {
                line = this.add.image(subject.lineX, subject.lineY, "texture", "lineKinshasa.png").setOrigin(1,1);
            }
            else if (subject.name === subjects.kasaiOriental) {
                line = this.add.image(subject.lineX, subject.lineY, "texture", "lineKasaiOriental.png").setOrigin(1,0);
            }

            this.mapContainer.add(line);
        }
    }

    displayMap(aScene) {

        // interactive sprites
        aScene.sankuru = aScene.add.sprite(width/2 + 107, height/2 - 19.5, "texture", "sankuru.png");
        aScene.maniema = aScene.add.sprite(width/2 + 303, height/2 - 94.5, "texture", "maniema.png");
        aScene.southKivu = aScene.add.sprite(width/2 + 398, height/2 - 44, "texture", "southKivu.png");
        aScene.tshuapa = aScene.add.sprite(width/2 + 11, height/2 - 228, "texture", "tshuapa.png");
        aScene.tshopo = aScene.add.sprite(width/2 + 215.5, height/2 - 262, "texture", "tshopo.png");
        aScene.northKivu = aScene.add.sprite(width/2 + 431, height/2 - 219, "texture", "northKivu.png");
        aScene.ituri = aScene.add.sprite(width/2 + 473, height/2 - 386.5, "texture", "ituri.png");
        aScene.hautUele = aScene.add.sprite(width/2 + 433.5, height/2 - 463, "texture", "hautUele.png");
        aScene.basUele = aScene.add.sprite(width/2 + 203, height/2 - 484.5, "texture", "basUele.png");
        aScene.mongala = aScene.add.sprite(width/2 - 16, height/2 - 373, "texture", "mongala.png");
        aScene.nordUbangi = aScene.add.sprite(width/2 - 29.5, height/2 - 499, "texture", "nordUbangi.png");
        aScene.equateur = aScene.add.sprite(width/2 - 193.5, height/2 - 250, "texture", "equateur.png");
        aScene.sudUbangi = aScene.add.sprite(width/2 - 143, height/2 - 454.5, "texture", "sudUbangi.png");
        aScene.kasai = aScene.add.sprite(width/2 - 37.5, height/2 + 49, "texture", "kasai.png");
        aScene.kasaiCentral = aScene.add.sprite(width/2 + 57.5, height/2 + 126.5, "texture", "kasaiCentral.png");
        aScene.kasaiOriental = aScene.add.sprite(width/2 + 111.5, height/2 + 133, "texture", "kasaiOriental.png");
        aScene.lomami = aScene.add.sprite(width/2 + 179.5, height/2 + 146, "texture", "lomami.png");
        aScene.tanganyika = aScene.add.sprite(width/2 + 405, height/2 + 169, "texture", "tanganyika.png");
        aScene.hautLomami = aScene.add.sprite(width/2 + 250, height/2 + 254.5, "texture", "hautLomami.png");
        aScene.lualaba = aScene.add.sprite(width/2 + 171, height/2 + 356, "texture", "lualaba.png");
        aScene.hautKatanga = aScene.add.sprite(width/2 + 375.5, height/2 + 406.5, "texture", "hautKatanga.png");
        aScene.maiNdombe = aScene.add.sprite(width/2 - 203.5, height/2 - 91, "texture", "maiNdombe.png");
        aScene.kwilu = aScene.add.sprite(width/2 - 212, height/2 + 51, "texture", "kwilu.png");
        aScene.kwango = aScene.add.sprite(width/2 - 233, height/2 + 136.5, "texture", "kwango.png");
        aScene.kinshasa = aScene.add.sprite(width/2 - 363.5, height/2 + 27, "texture", "kinshasa.png");
        aScene.kongoCentral = aScene.add.sprite(width/2 - 464.5, height/2 + 69, "texture", "kongoCentral.png");

        // reposition labels
        aScene.sudUbangi.labelX = aScene.sudUbangi.x - 45;
        aScene.sudUbangi.labelY = aScene.sudUbangi.y;
        aScene.ituri.labelX = aScene.ituri.x;
        aScene.ituri.labelY = aScene.ituri.y + 20;
        aScene.northKivu.labelX = aScene.northKivu.x + 50;
        aScene.northKivu.labelY = aScene.northKivu.y;
        aScene.southKivu.labelX = aScene.southKivu.x + 40;
        aScene.southKivu.labelY = aScene.southKivu.y;
        aScene.tshopo.labelX = aScene.tshopo.x;
        aScene.tshopo.labelY = aScene.tshopo.y - 25;
        aScene.maniema.labelX = aScene.maniema.x - 40;
        aScene.maniema.labelY = aScene.maniema.y + 60;
        aScene.lualaba.labelX = aScene.lualaba.x - 30;
        aScene.lualaba.labelY = aScene.lualaba.y + 50;
        aScene.kongoCentral.labelX = aScene.kongoCentral.x;
        aScene.kongoCentral.labelY = aScene.kongoCentral.y + 15;
        aScene.kwango.labelX = aScene.kwango.x + 15;
        aScene.kwango.labelY = aScene.kwango.y + 50;
        aScene.hautKatanga.labelX = aScene.hautKatanga.x + 60;
        aScene.hautKatanga.labelY = aScene.hautKatanga.y;
        aScene.hautLomami.labelX = aScene.hautLomami.x - 10;
        aScene.hautLomami.labelY = aScene.hautLomami.y;
        aScene.tanganyika.labelX = aScene.tanganyika.x - 25;
        aScene.tanganyika.labelY = aScene.tanganyika.y - 25;
        aScene.lomami.labelX = aScene.lomami.x + 25;
        aScene.lomami.labelY = aScene.lomami.y - 40;
        aScene.kasaiCentral.labelX = aScene.kasaiCentral.x;
        aScene.kasaiCentral.labelY = aScene.kasaiCentral.y - 60;
        aScene.kasai.labelX = aScene.kasai.x + 20;
        aScene.kasai.labelY = aScene.kasai.y - 30;

        aScene.kasaiOriental.labelX = aScene.kasaiOriental.x - 275;
        aScene.kasaiOriental.labelY = aScene.kasaiOriental.y + 205;
        aScene.kinshasa.labelX = aScene.kinshasa.x - 120;
        aScene.kinshasa.labelY = aScene.kinshasa.y - 57;

        aScene.kinshasa.hasLine = true;
        aScene.kasaiOriental.hasLine = true;

        aScene.kinshasa.lineX = aScene.kinshasa.x;
        aScene.kinshasa.lineY = aScene.kinshasa.y - 5;
        aScene.kasaiOriental.lineX = aScene.kasaiOriental.x;
        aScene.kasaiOriental.lineY = aScene.kasaiOriental.y - 5;

        // names
        aScene.sankuru.name = subjects.sankuru;
        aScene.maniema.name = subjects.maniema;
        aScene.southKivu.name = subjects.southKivu;
        aScene.tshuapa.name = subjects.tshuapa;
        aScene.tshopo.name = subjects.tshopo;
        aScene.northKivu.name = subjects.northKivu;
        aScene.ituri.name = subjects.ituri;
        aScene.hautUele.name = subjects.hautUele;
        aScene.basUele.name = subjects.basUele;
        aScene.mongala.name = subjects.mongala;
        aScene.nordUbangi.name = subjects.nordUbangi;
        aScene.equateur.name = subjects.equateur;
        aScene.sudUbangi.name = subjects.sudUbangi;
        aScene.kasai.name = subjects.kasai;
        aScene.kasaiCentral.name = subjects.kasaiCentral;
        aScene.kasaiOriental.name = subjects.kasaiOriental;
        aScene.lomami.name = subjects.lomami;
        aScene.tanganyika.name = subjects.tanganyika;
        aScene.hautLomami.name = subjects.hautLomami;
        aScene.lualaba.name = subjects.lualaba;
        aScene.hautKatanga.name = subjects.hautKatanga;
        aScene.maiNdombe.name = subjects.maiNdombe;
        aScene.kwilu.name = subjects.kwilu;
        aScene.kwango.name = subjects.kwango;
        aScene.kinshasa.name = subjects.kinshasa;
        aScene.kongoCentral.name = subjects.kongoCentral;

        // create container and put countries into it
        aScene.mapContainer = aScene.add.container(0, 0, [aScene.maniema, aScene.sankuru, aScene.southKivu, aScene.tshuapa, aScene.hautUele, aScene.tshopo, aScene.nordUbangi, aScene.northKivu, aScene.ituri, aScene.basUele, aScene.mongala,  aScene.equateur, aScene.sudUbangi, aScene.kasai, aScene.kasaiCentral, aScene.kasaiOriental, aScene.lomami, aScene.tanganyika, aScene.hautLomami, aScene.lualaba, aScene.hautKatanga, aScene.maiNdombe, aScene.kwilu, aScene.kwango, aScene.kinshasa, aScene.kongoCentral ]);

        aScene.mapContainer.setSize(width, height);
        aScene.mapContainer.x = 0;
        aScene.mapContainer.y = 0;
     }
}