"use strict"
var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        });
    }
    
    create() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;
        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;
       camera.zoom = .4;
       camera.scrollY = -20;
        // min max zoom
        this.minZoom = .4;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.6;
        }
        else {
            this.maxZoom = 1.9;
        }
        // display countries in this scene
        this.displayMap(this);
        // get countries (sprites) array from the container
        this.countriesArray = this.mapContainer.getAll();
        // for each subject (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {
            /* development phase - enable drag
            this.countriesArray[i].setInteractive()
            this.input.setDraggable(this.countriesArray[i]);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {
                gameObject.x = dragX;
                gameObject.y = dragY;
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });
            */
            
            let subject = this.countriesArray[i];
            // make countries sprites interactive
            subject.setInteractive({ 
                useHandCursor: true,             
                pixelPerfect: true,
                alphaTolerance: 255
             });
             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over subject
                subject.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                       subject.setTintFill(0xFFFFFF);
                    }
                },this);
                subject.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        subject.clearTint();
                    }
                },this);
            }
            subject.on('pointerdown', () => {
                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });
            subject.on('pointerup', () => {
                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);
                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    subject.xPos = camera.x;
                    subject.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false) {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === subject.name) {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this subject
                            subject.disableInteractive();
                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }
                            // create the subject label
                            this.showLabels(subject);
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // else don't tap, drag the map
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();
        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false) {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();
                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip, ui.buttonSound],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                let dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {
                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        let drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }
                }).on('pinch', dragScale => {
                    let scaleFactor = dragScale.scaleFactor;
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                }, this);
                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }
        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2 + 100, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 50, align: "center", color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2 + 100, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 50, align: "center", color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });
        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                camera.zoom *= 0.9;
            }
        }
        // limit zoom
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.mapContainer.setSize(width, height);
        this.mapContainer.x = 0;
        this.mapContainer.y = 0;
        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2 + 100, height/2);
        }
    }

    getQuestion() {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;
        this.questionsArray.shift();

        if (ui.questionText.text === subjects.newfoundland) {
            ui.questionText.setFontSize(26);
        }
        else {
            ui.questionText.setFontSize(34);
        }

        // tween
        this.tweens.add({
           targets: [ui.questionText],
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;
        // play sound
        this.gameOverSound.play();
        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        ui.buttonSound.destroy();
        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {
        // tween camera
        if (camera.zoom > this.minZoom) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: .55,
                x: 0, 
                y: 0,
                duration: 1500,
                onComplete: () => {
                    
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }
        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: -20,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showLabels(subject) {
        // create white rectangle
        subject.rect = this.add.sprite(subject.x, subject.y, "rectangle");
        // subject name
        subject.txt = this.add.text(subject.x, subject.y, subject.name, { fontFamily: "bold", fontSize: 22, align: "center", color: '#000000' });
        subject.txt.setOrigin(.5,.5);

        // special
        if (subject.name == subjects.sanAndres) {
            subject.txt.setText(sanAndres2);
        }

        // position text
        if (subject.labelX) {
            subject.txt.x = subject.labelX;
            subject.txt.y = subject.labelY;
            subject.rect.x = subject.labelX;
            subject.rect.y = subject.labelY;
        }
        subject.rect.displayWidth = subject.txt.width + 4;
        subject.rect.displayHeight = subject.txt.height + 2;
        
        if (subject.hasLine) {
            let line;
            if (subject.name === subjects.risaralda) {
                line = this.add.image(subject.lineX, subject.lineY, "texture", "risaraldaLine.png").setOrigin(1,0.5);
            }
            else if (subject.name === subjects.quindio) {
                line = this.add.image(subject.lineX, subject.lineY, "texture", "quindioLine.png").setOrigin(1,0.5);
            }
            this.mapContainer.add(line);
        }
    }
    
    displayMap(aScene) {
        // interactive sprites
        aScene.cundinamarca = aScene.add.sprite(width/2 - 98.5, height/2 - 61.5, "texture", "cundinamarca.png");
        aScene.boyaca = aScene.add.sprite(width/2 - 34.5, height/2 - 166, "texture", "boyaca.png");
        aScene.bogota = aScene.add.sprite(width/2 - 124.5, height/2 - 10, "texture", "bogota.png");
        aScene.casanare = aScene.add.sprite(width/2 + 143, height/2 - 112, "texture", "casanare.png");
        aScene.tolima = aScene.add.sprite(width/2 - 225.5, height/2 + 5, "texture", "tolima.png");
        aScene.caldas = aScene.add.sprite(width/2 - 224.5, height/2 - 111, "texture", "caldas.png");
        aScene.arauca = aScene.add.sprite(width/2 + 197, height/2 - 234.5, "texture", "arauca.png");
        aScene.santander = aScene.add.sprite(width/2 - 53, height/2 - 267.5, "texture", "santander.png");
        aScene.vichada = aScene.add.sprite(width/2 + 356, height/2 - 39.5, "texture", "vichada.png");
        aScene.antioquia = aScene.add.sprite(width/2 - 245, height/2 - 290, "texture", "antioquia.png");
        aScene.risaralda = aScene.add.sprite(width/2 - 274, height/2 - 95, "texture", "risaralda.png");
        aScene.quindio = aScene.add.sprite(width/2 - 259.5, height/2 - 23.5, "texture", "quindio.png");
        aScene.choco = aScene.add.sprite(width/2 - 386, height/2 - 213.5, "texture", "choco.png");
        aScene.meta = aScene.add.sprite(width/2 - 3.5, height/2 + 87.5, "texture", "meta.png");
        aScene.valleDelCauca = aScene.add.sprite(width/2 - 352.5, height/2 + 10, "texture", "valleDelCauca.png");
        aScene.huila = aScene.add.sprite(width/2 - 246.5, height/2 + 140, "texture", "huila.png");
        aScene.cauca = aScene.add.sprite(width/2 - 388, height/2 + 191.5, "texture", "cauca.png");
        aScene.narino = aScene.add.sprite(width/2 - 480.5, height/2 + 252, "texture", "narino.png");
        aScene.guainia = aScene.add.sprite(width/2 + 395.5, height/2 + 150, "texture", "guainia.png");
        aScene.guaviare = aScene.add.sprite(width/2 + 109.5, height/2 + 226, "texture", "guaviare.png");
        aScene.caqueta = aScene.add.sprite(width/2 - 82.5, height/2 + 289.5, "texture", "caqueta.png");
        aScene.putumayo = aScene.add.sprite(width/2 - 247.5, height/2 + 358, "texture", "putumayo.png");
        aScene.vaupes = aScene.add.sprite(width/2 + 230, height/2 + 356.5, "texture", "vaupes.png");
        aScene.amazonas = aScene.add.sprite(width/2 + 103, height/2 + 594, "texture", "amazonas.png");
        aScene.cordoba = aScene.add.sprite(width/2 - 256.5, height/2 - 410, "texture", "cordoba.png");
        aScene.bolivar = aScene.add.sprite(width/2 - 194, height/2 - 457, "texture", "bolivar.png");
        aScene.cesar = aScene.add.sprite(width/2 - 54, height/2 + -495, "texture", "cesar.png");
        aScene.norteDeSantander = aScene.add.sprite(width/2 + 10.5, height/2 - 379, "texture", "norteDeSantander.png");
        aScene.sucre = aScene.add.sprite(width/2 - 206.5, height/2 - 488, "texture", "sucre.png");
        aScene.magdalena = aScene.add.sprite(width/2 - 125, height/2 - 580, "texture", "magdalena.png");
        aScene.atlantico = aScene.add.sprite(width/2 - 195, height/2 - 629, "texture", "atlantico.png");
        aScene.laGuajira = aScene.add.sprite(width/2 + 51, height/2 - 702, "texture", "laGuajira .png");
        aScene.sanAndres = aScene.add.sprite(width/2 - 456.5, height/2 - 646, "texture", "sanAdres.png");

        // position labels
        aScene.bolivar.labelX = aScene.bolivar.x + 80;
        aScene.bolivar.labelY = aScene.bolivar.y + 20;
        aScene.antioquia.labelX = aScene.antioquia.x;
        aScene.antioquia.labelY = aScene.antioquia.y + 30;
        aScene.santander.labelX = aScene.santander.x;
        aScene.santander.labelY = aScene.santander.y + 30;
        aScene.choco.labelX = aScene.choco.x;
        aScene.choco.labelY = aScene.choco.y + 45;
        aScene.cesar.labelX = aScene.cesar.x + 25;
        aScene.cesar.labelY = aScene.cesar.y - 45;
        aScene.casanare.labelX = aScene.casanare.x;
        aScene.casanare.labelY = aScene.casanare.y - 15;
        aScene.boyaca.labelX = aScene.boyaca.x + 15;
        aScene.boyaca.labelY = aScene.boyaca.y + 20;
        aScene.valleDelCauca.labelX = aScene.valleDelCauca.x - 50;
        aScene.valleDelCauca.labelY = aScene.valleDelCauca.y + 30;
        aScene.tolima.labelX = aScene.tolima.x;
        aScene.tolima.labelY = aScene.tolima.y + 20;
        aScene.cundinamarca.labelX = aScene.cundinamarca.x;
        aScene.cundinamarca.labelY = aScene.cundinamarca.y - 25;
        aScene.caldas.labelX = aScene.caldas.x;
        aScene.caldas.labelY = aScene.caldas.y - 15;
        aScene.cauca.labelX = aScene.cauca.x;
        aScene.cauca.labelY = aScene.cauca.y - 55;
        aScene.guaviare.labelX = aScene.guaviare.x - 35;
        aScene.guaviare.labelY = aScene.guaviare.y - 20;
        aScene.vaupes.labelX = aScene.vaupes.x - 15;
        aScene.vaupes.labelY = aScene.vaupes.y - 30;
        aScene.amazonas.labelX = aScene.amazonas.x + 20;
        aScene.amazonas.labelY = aScene.amazonas.y - 45;
        aScene.putumayo.labelX = aScene.putumayo.x - 50;
        aScene.putumayo.labelY = aScene.putumayo.y + 10;
        aScene.caqueta.labelX = aScene.caqueta.x - 20;
        aScene.caqueta.labelY = aScene.caqueta.y + 35;
        aScene.sanAndres.labelX = aScene.sanAndres.x - 215;
        aScene.sanAndres.labelY = aScene.sanAndres.y;
        aScene.risaralda.labelX = aScene.risaralda.x - 235;
        aScene.risaralda.labelY = aScene.risaralda.y;
        aScene.quindio.labelX = aScene.quindio.x - 255;
        aScene.quindio.labelY = aScene.quindio.y;

        aScene.risaralda.hasLine = true;
        aScene.quindio.hasLine = true;
        aScene.risaralda.lineX = aScene.risaralda.x - 15;
        aScene.risaralda.lineY = aScene.risaralda.y;
        aScene.quindio.lineX = aScene.quindio.x;
        aScene.quindio.lineY = aScene.quindio.y;
        // names
        aScene.cundinamarca.name = subjects.cundinamarca;
        aScene.boyaca.name = subjects.boyaca;
        aScene.bogota.name = subjects.bogota;
        aScene.casanare.name = subjects.casanare;
        aScene.tolima.name = subjects.tolima;
        aScene.caldas.name = subjects.caldas;
        aScene.arauca.name = subjects.arauca;
        aScene.santander.name = subjects.santander;
        aScene.vichada.name = subjects.vichada;
        aScene.antioquia.name = subjects.antioquia;
        aScene.risaralda.name = subjects.risaralda;
        aScene.quindio.name = subjects.quindio;
        aScene.choco.name = subjects.choco;
        aScene.meta.name = subjects.meta;
        aScene.valleDelCauca.name = subjects.valleDelCauca;
        aScene.huila.name = subjects.huila;
        aScene.cauca.name = subjects.cauca;
        aScene.narino.name = subjects.narino;
        aScene.guainia.name = subjects.guainia;
        aScene.guaviare.name = subjects.guaviare;
        aScene.caqueta.name = subjects.caqueta;
        aScene.putumayo.name = subjects.putumayo;
        aScene.vaupes.name = subjects.vaupes;
        aScene.amazonas.name = subjects.amazonas;
        aScene.cordoba.name = subjects.cordoba;
        aScene.bolivar.name = subjects.bolivar;
        aScene.cesar.name = subjects.cesar;
        aScene.norteDeSantander.name = subjects.norteDeSantander;
        aScene.sucre.name = subjects.sucre;
        aScene.magdalena.name = subjects.magdalena;
        aScene.atlantico.name = subjects.atlantico;
        aScene.laGuajira.name = subjects.laGuajira;
        aScene.sanAndres.name = subjects.sanAndres;

        // create container and put countries into it
        aScene.mapContainer = aScene.add.container(0, 0, [aScene.cundinamarca, aScene.boyaca, aScene.bogota, aScene.casanare, aScene.tolima, aScene.caldas, aScene.arauca, aScene.santander, aScene.vichada, aScene.antioquia, aScene.risaralda, aScene.quindio, aScene.choco, aScene.meta, aScene.valleDelCauca, aScene.huila, aScene.cauca, aScene.narino, aScene.guainia, aScene.guaviare, aScene.caqueta, aScene.putumayo, aScene.vaupes, aScene.amazonas, aScene.cordoba, aScene.bolivar, aScene.cesar, aScene.cesar, aScene.norteDeSantander, aScene.sucre, aScene.magdalena, aScene.atlantico, aScene.laGuajira, aScene.sanAndres]);

        aScene.mapContainer.setSize(width, height);
        aScene.mapContainer.x = 0;
        aScene.mapContainer.y = 0;
     }
}