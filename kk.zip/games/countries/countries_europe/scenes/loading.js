class Loading extends Phaser.Scene
{    
    constructor()
    {
        super({
            
            key   : 'loading',
            pack  : 
            {
                files : 
                [
                    // pre-preload these images
                    { type: 'image', key: 'preloader1', url: '/games/countries/countries_europe/img/preloader1.png' },
                    { type: 'image', key: 'preloader2', url: '/games/countries/countries_europe/img/preloader2.png' },
                    { type: 'image', key: 'btnPlay', url: '/games/countries/countries_europe/img/btnPlay.png' },
                ] 
            }
        })
    }
    
    setPreloadSprite (sprite) 
    {
		this.preloadSprite = { sprite: sprite, width: sprite.width, height: sprite.height }
		sprite.visible = true
		// set callback for loading progress updates
		this.load.on('progress', this.onProgress, this);
	}
	
	onProgress (value) {
		if (this.preloadSprite) {
			// calculate width based on value (0.0 .. 1.0)
            let w = Math.floor(this.preloadSprite.width * value);
			// set width of sprite			
			this.preloadSprite.sprite.frame.width = w;
            this.preloadSprite.sprite.frame.cutWidth = w;
			// update screen
            this.preloadSprite.sprite.frame.updateUVs();
            // adjust positions while loading
            this.setPositions();
		}
    }
    
    preload(){

        // load custom fonts (extra bold loaded in index.html)
        this.font1 = this.add.text(0, 0, 'custom font', {
            fontFamily: "regular", fontSize: 16, color: '#000000'
        });
        this.font1.setVisible(false);
        this.font3 = this.add.text(0, 0, 'custom font', {
            fontFamily: "semiBold", fontSize: 16, color: '#000000'
        });
        this.font3.setVisible(false);
        this.font2 = this.add.text(0, 0, 'custom font', {
            fontFamily: "bold", fontSize: 16, color: '#000000'
        });
        this.font2.setVisible(false);

        // init width and height
        width = this.cameras.main.width;
        height = this.cameras.main.height;

        // display loading bar
		this.preloader1 = this.add.sprite(width/2, height/2 + 140, "preloader1");
		this.preloader2 = this.add.sprite(width/2, height/2 + 140, "preloader2");
        this.setPreloadSprite(this.preloader2);
        // play button
        this.btnPlay = this.add.image(width/2, height/2 + 140, "btnPlay");
        this.btnPlay.setVisible(false);

        // display text
        this.txtWebsite = this.add.text(width/2, height/2 - 150, labels.website, { fontFamily: "extraBold", fontSize: 60, color: '#000000' });
        this.txtTitle = this.add.text(width/2, height/2 - 80, labels.title, { fontFamily: "extraBold", fontSize: 55, color: '#FFFFFF' });
        this.txtTitle.setOrigin(0.5, 0.5);
        this.txtWebsite.setOrigin(0.5, 0.5);
        
        // plugins
        this.url = '/games/countries/countries_europe/plugins/pinchplugin.min.js';
        this.load.plugin('rexpinchplugin', this.url, true);
        this.url2 = '/games/countries/countries_europe/plugins/mousewheelplugin.min.js';
        this.load.plugin('rexmousewheeltoupdownplugin', this.url2, true);
        this.url3 = '/games/countries/countries_europe/plugins/rexscrollerplugin.min.js';
        this.load.plugin('rexscrollerplugin', this.url3, true);

        // animation
        this.load.spritesheet('water', '/games/countries/countries_europe/img/water.png', { frameWidth: 464, frameHeight: 114 });
        this.load.spritesheet('bearHead', '/games/countries/countries_europe/img/bearHead.png', { frameWidth: 137, frameHeight: 136 });
        this.load.image('bearBody', '/games/countries/countries_europe/img/bearBody.png');
        
        // europe
        this.load.image('turkey', '/games/countries/countries_europe/img/turkey.png');
        this.load.image('poland', '/games/countries/countries_europe/img/poland.png');
        this.load.image('malta', '/games/countries/countries_europe/img/malta.png');
        this.load.image('albania', '/games/countries/countries_europe/img/albania.png');
        this.load.image('kosovo', '/games/countries/countries_europe/img/kosovo.png');
        this.load.image('montenegro', '/games/countries/countries_europe/img/montenegro.png');
        this.load.image('bosnia', '/games/countries/countries_europe/img/bosnia.png');
        this.load.image('croatia', '/games/countries/countries_europe/img/croatia.png');
        this.load.image('serbia', '/games/countries/countries_europe/img/serbia.png');
        this.load.image('bulgaria', '/games/countries/countries_europe/img/bulgaria.png');
        this.load.image('greece', '/games/countries/countries_europe/img/greece.png');
        this.load.image('northMacedonia', '/games/countries/countries_europe/img/northMacedonia.png');
        this.load.image('ukraine', '/games/countries/countries_europe/img/ukraine.png');
        this.load.image('moldova', '/games/countries/countries_europe/img/moldova.png');
        this.load.image('romania', '/games/countries/countries_europe/img/romania.png');
        this.load.image('russia', '/games/countries/countries_europe/img/russia.png');
        this.load.image('belarus', '/games/countries/countries_europe/img/belarus.png');
        this.load.image('austria', '/games/countries/countries_europe/img/austria.png');
        this.load.image('hungary', '/games/countries/countries_europe/img/hungary.png');
        this.load.image('slovenia', '/games/countries/countries_europe/img/slovenia.png');
        this.load.image('slovakia', '/games/countries/countries_europe/img/slovakia.png');
        this.load.image('czechRepublic', '/games/countries/countries_europe/img/czechRepublic.png');
        this.load.image('italy', '/games/countries/countries_europe/img/italy.png');
        this.load.image('monaco', '/games/countries/countries_europe/img/monaco.png');
        this.load.image('sanMarino', '/games/countries/countries_europe/img/sanMarino.png');
        this.load.image('vaticanCity', '/games/countries/countries_europe/img/vaticanCity.png');
        this.load.image('andorra', '/games/countries/countries_europe/img/andorra.png');
        this.load.image('portugal', '/games/countries/countries_europe/img/portugal.png');
        this.load.image('spain', '/games/countries/countries_europe/img/spain.png');
        this.load.image('switzerland', '/games/countries/countries_europe/img/switzerland.png');
        this.load.image('france', '/games/countries/countries_europe/img/france.png');
        this.load.image('belgium', '/games/countries/countries_europe/img/belgium.png');
        this.load.image('germany', '/games/countries/countries_europe/img/germany.png');
        this.load.image('netherlands', '/games/countries/countries_europe/img/netherlands.png');
        this.load.image('denmark', '/games/countries/countries_europe/img/denmark.png');
        this.load.image('luxembourg', '/games/countries/countries_europe/img/luxembourg.png');
        this.load.image('liechtenstein', '/games/countries/countries_europe/img/liechtenstein.png');
        this.load.image('ireland', '/games/countries/countries_europe/img/ireland.png');
        this.load.image('unitedKingdom', '/games/countries/countries_europe/img/unitedKingdom.png');
        this.load.image('iceland', '/games/countries/countries_europe/img/iceland.png');
        this.load.image('norway', '/games/countries/countries_europe/img/norway.png');
        this.load.image('sweden', '/games/countries/countries_europe/img/sweden.png');
        this.load.image('finland', '/games/countries/countries_europe/img/finland.png');
        this.load.image('estonia', '/games/countries/countries_europe/img/estonia.png');
        this.load.image('latvia', '/games/countries/countries_europe/img/latvia.png');
        this.load.image('lithuania', '/games/countries/countries_europe/img/lithuania.png');
        this.load.image('cyprus', '/games/countries/countries_europe/img/cyprus.png');
        
        // buttons
        this.load.spritesheet('button', '/games/countries/countries_europe/img/button.png', {frameWidth: 420, frameHeight: 62});
        this.load.image('btnPlay', '/games/countries/countries_europe/img/btnPlay.png');
        this.load.image('buttonBack', '/games/countries/countries_europe/img/buttonBack.png');
        this.load.image('buttonBackBlack', '/games/countries/countries_europe/img/buttonBackBlack.png');
        this.load.image('buttonStart', '/games/countries/countries_europe/img/buttonStart.png');
        this.load.image('buttonMap', '/games/countries/countries_europe/img/buttonMap.png');
        this.load.image('buttonMapWhite', '/games/countries/countries_europe/img/buttonMapWhite.png');
        this.load.image('buttonOptions', '/games/countries/countries_europe/img/buttonOptions.png');
        this.load.spritesheet('buttonToggle', '/games/countries/countries_europe/img/buttonToggle.png', {frameWidth: 89, frameHeight: 52 });
        
        // images
		this.load.spritesheet('bgQuestion', '/games/countries/countries_europe/img/bgQuestion.png', { frameWidth: 500, frameHeight: 65 });
		this.load.image('bgWhite', '/games/countries/countries_europe/img/bgWhite.jpg');
		this.load.image('rectangle', '/games/countries/countries_europe/img/rectangle.jpg');
		this.load.image('map', '/games/countries/countries_europe/img/mapEurope.png');
		this.load.image('circle', '/games/countries/countries_europe/img/circle.png');
		this.load.image('circleRed', '/games/countries/countries_europe/img/circleRed.png');
		this.load.image('circleGreen', '/games/countries/countries_europe/img/circleGreen.png');
		this.load.image('circleYellow', '/games/countries/countries_europe/img/circleYellow.png');
		this.load.image('line', '/games/countries/countries_europe/img/line.png');
		this.load.image('lineVatican', '/games/countries/countries_europe/img/lineVatican.png');
		this.load.image('lineSanMarino', '/games/countries/countries_europe/img/lineSanMarino.png');
		this.load.image('lineMacedonia', '/games/countries/countries_europe/img/lineMacedonia.png');
		this.load.image('mouseOverMicrostate', '/games/countries/countries_europe/img/mouseOverMicrostate.png');
		this.load.image('underline', '/games/countries/countries_europe/img/underline.png');
        // sounds
		this.load.audio('wrongSound', ['/games/countries/countries_america/audio/wrongSound.mp3', '/games/countries/countries_america/audio/wrongSound.ogg']);
		this.load.audio('correctSound', ['/games/countries/countries_america/audio/correctSound.mp3', '/games/countries/countries_america/audio/correctSound.ogg']);
		this.load.audio('gameOverSound', ['/games/countries/countries_america/audio/gameOverSound.mp3', '/games/countries/countries_america/audio/gameOverSoun.ogg']);
    }
    
    create() {    

        // play button
        this.btnPlay.setVisible(true);
        this.btnPlay.setInteractive({useHandCursor: true})
        this.btnPlay.on("pointerup", () => { 
            this.scene.start("menu");
        }, this);

        // remove preloader
        this.preloader1.destroy();
        this.preloader2.destroy();
        
        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on("resize", (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.preloader1.setPosition(width/2, height/2 + 170);
        this.preloader2.setPosition(width/2, height/2 + 170);
        this.btnPlay.setPosition(width/2, height/2 + 170);
        this.txtTitle.setPosition(width/2, height/2 - 80);
        this.txtWebsite.setPosition(width/2, height/2 - 150);
    }
}