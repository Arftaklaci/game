var game = new Phaser.Game(500, 800, Phaser.Canvas, null, null, true)

game.global = 
{
	orientated             : false,
    library_instructions   : true,
    options_instructions   : true,
}

// edit below to change a language
collator = 'en'
var websiteName = "World Geography Games";
var webURL = "https://world-geography-games.com/world.html";

title_label = "\nUS Flags"
title_oneline = "US Flags"
play_again_label = "Play again"
stop_label = "Stop"
score_label = "Score: "
next_label = "Next"
out_of_label = "out of"
play_label = "play"
options_label = "options"
select_atleast_label = "Select at least 5 flags"
back_label = "back"
sound_label = "SOUND"
number_of_flags_label = "NUMBER OF FLAGS"
flags_label = "FLAGS"
select_label = "select"
library_label = "library"

south_label = "South"
midwest_label = "Midwest"
northeast_label = "Northeast"
western_label = "West"

countries = ["Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"]


// ** DO NOT EDIT BELOW!

// create new array, don't change the first one, order alphabetically
countries_alphabet = countries.slice().sort(Intl.Collator(collator).compare);

// how many flags selected
flags_used = 50

// frames that will be used (frames represent flags)
frames = []
for (var f = 0; f < flags_used; f++)
{
    frames.push(f)
}

// always contains all frames, get random flags from this array
all_frames = frames.slice()

// regions
west = [1,2,4,5,10,11,25,27,30,36,43,46,49]
south = [0,3,7,8,9,16,17,19,23,32,35,39,41,42,45,47]
northeast = [6,18,20,28,29,31,37,38,44]
midwest = [12,13,14,15,21,22,24,26,33,34,40,48]

// toggle buttons used for regions, possible frame 0 or 1
south_btn = 0
midwest_btn = 0
western_btn = 0
northeast_btn = 0

// toggle buttons used for countries, possible frame 0 or 1
toggle_button_frames = []

for (var i = 0; i < frames.length; i++)
{
    // by default all buttons are on (frame 0)
    toggle_button_frames.push(0)
}

// sound toggle button
sound_frame = 0

// selecting regions or countries in options (back button depends on this)
selecting_regions = true

// countries have lookalikes
have_lookalikes = 
[0,8,9,15,18,21,25,26,28,31,32,33,37,42,44,48];

// lookalikes
lookalikes = [
[8],[0],[42,32],[25],[31,48],[37,44,33],[15],[28],[26],[18,48],[42,9],[37,44,21],[33,44,21],[32,9],[21,33,37],[31,18]
];

// game states
game.state.add('boot', bootState);
game.state.add("Loading", loading);
game.state.add("menu", menuState);
game.state.add("options", optionsState);
game.state.add("library", libraryState);
game.state.add("level1", state1);
game.state.start("boot");

