"use strict"

var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        })
    }

    create() {

        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;

        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        
        // launch user interface 
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");

        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");

       // camera
       camera = this.cameras.main;
       camera.zoom = 0.25;

        // min max zoom
        this.minZoom = 0.25;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 2;
        }
        else {
            this.maxZoom = 2.5;
        }

        // enable drag and pinch to zoom
        var dragScale = this.plugins.get('rexpinchplugin').add(this); 
        // center the map on the start 
        camera.scrollX = 150;

        dragScale.on('drag1', dragScale => {

            // drag if game is not completed
            if (this.gameCompleted === false) {
                var drag1Vector = dragScale.drag1Vector;
                camera.scrollX -= drag1Vector.x / camera.zoom;
                camera.scrollY -= drag1Vector.y / camera.zoom;
            }
        }).on('pinch', dragScale => {
            var scaleFactor = dragScale.scaleFactor;
            
            // camera zoom
            if (this.canZoom === true) {
                if (this.gameCompleted === false) {
                    camera.zoom *= scaleFactor;
                }
            }
            
        }, this);

        // display countries in this scene
        this.displayAmerica(this);
       
        // get countries (sprites) array from the container
        this.countriesArray = this.americaContainer.getAll();

        // for each country (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {

            let country = this.countriesArray[i];

            // make countries sprites interactive
            country.setInteractive({ 
                useHandCursor: true,             
                pixelPerfect: true,
                alphaTolerance: 255
             });

             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over country
                country.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                        if (country.isSpritesheet === true) {
                            if (country.name === countriesLabels.bahamas) {
                                country.setFrame(1);
                            }
                            else {
                                this.mouseOverMicro.setVisible(true);
                                this.mouseOverMicro.x = country.x;
                                this.mouseOverMicro.y = country.y;
                            }
                        }
                        else {
                            country.alpha = 0.5;
                        }
                    }
                },this);

                country.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        if (country.isSpritesheet === true) {
                            if (country.name === countriesLabels.bahamas) {
                                country.setFrame(0);
                            }
                            else {
                                this.mouseOverMicro.setVisible(false);
                            }
                        }
                        else {
                            country.alpha = 1;
                        }
                    }
                },this);
            }

            country.on('pointerdown', () => {
                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });

            country.on('pointerup', () => {
                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);

                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    country.xPos = camera.x;
                    country.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false)
                    {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === country.name)
                        {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this country
                            country.disableInteractive();

                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }

                            // create the country label
                            this.showAmericaLabels(country);
    
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
    
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // drag
                else {
                    // console.log("don't tap, drag the map");
                }
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();

        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false)
            {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();

                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip,],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }

        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 105, color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 75, color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });

        // mouse over microstate sprite
        this.mouseOverMicro = this.add.image(0,0, 'mouseOverMicrostate');
        this.mouseOverMicro.setVisible(false);

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                
                camera.zoom *= 0.9;
            }
        }

        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.americaContainer.setSize(width, height);
        this.americaContainer.x = 0;
        this.americaContainer.y = 0; 
        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2, height/2);
        }
    }

    getQuestion()
    {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;
        this.questionsArray.shift();

        if (ui.questionText.text === countriesLabels.saintVincent 
		|| ui.questionText.text === countriesLabels.saintKittsAndNevis || ui.questionText.text === countriesLabels.unitedStates) {
            ui.questionText.setFontSize(26);
        }
        else {
            ui.questionText.setFontSize(34);
        }
        
        // tween
        this.tweens.add({
           targets: [ui.questionText],
           //scaleX: '-=.2',
           //angle: 10,
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;
        // play sound
        this.gameOverSound.play();
        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {

        // tween camera
        if (camera.zoom > .3) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: .3,
                duration: 2000,
                onComplete: () => {
                    
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }

        this.tweens.add({
            targets: [camera],
            scrollX: 150,
            scrollY: 0,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showAmericaLabels(country) {
            country.txt = this.add.text(country.x, country.y, country.name, { fontFamily: "bold", fontSize: 32, color: '#000000' });
            country.txt.setOrigin(.5,.5);
            this.americaContainer.add(country.txt);

            // position text
            if (country.labelX) {
                country.txt.x = country.labelX;
                country.txt.y = country.labelY;
            }

           // create a line if needed
           if (country.hasLine) {
                
                let line;
                if (country.name === countriesLabels.elSalvador) {
                    line = this.add.image(country.lineX, country.lineY, "lineSalvador");
                    line.setOrigin(1,0);
                }
                else if (country.name === countriesLabels.dominicanRepublic) {
                    line = this.add.image(country.lineX, country.lineY, "lineSalvador");
                    line.setOrigin(1,0);
                    line.scaleX = -1;
                    line.scaleY = -1;
                }
                else if (country.name === countriesLabels.saintKittsAndNevis) {
                    line = this.add.image(country.lineX, country.lineY, "lineSaintKitts");
                    line.setOrigin(0,1);
                }
                else if (country.name === countriesLabels.antiguaAndBarbuda || country.name === countriesLabels.barbados) {
                    line = this.add.image(country.lineX, country.lineY, "lineAntigua");
                    line.setOrigin(0,0.5);
                }
                else if (country.name === countriesLabels.dominica || country.name === countriesLabels.saintLucia) {
                    line = this.add.image(country.lineX, country.lineY, "lineSaintLucia");
                    line.setOrigin(0,1);
                }
                else if (country.name === countriesLabels.saintVincent || country.name === countriesLabels.grenada) {
                    line = this.add.image(country.lineX, country.lineY, "lineGrenada");
                    line.setOrigin(0,0);
                }
                else if (country.name === countriesLabels.trinidadAndTobago) {
                    line = this.add.image(country.lineX, country.lineY, "lineSalvador");
                    line.setOrigin(1,0);
                    line.scaleX = -1;
                }

                this.americaContainer.add(line);
            }
            
            // create white rectangles
            if (country.name === countriesLabels.elSalvador) {
                
                country.rect = this.add.sprite(country.txt.x, country.txt.y, "rectangle");
                country.rect.displayWidth = country.txt.width + 2;
                country.rect.displayHeight = country.txt.height;
                // set different origin for these rectangles
                country.rect.setOrigin(1,0.5);
                country.txt.setOrigin(1,0.5);
                country.txt.x -= 1;
                this.americaContainer.add(country.rect);
            }
            else if (country.hasLine) {
                country.rect = this.add.sprite(country.txt.x, country.txt.y, "rectangle");
                country.rect.displayWidth = country.txt.width + 2;
                country.rect.displayHeight = country.txt.height;
                // set different origin for these rectangles
                country.rect.setOrigin(0,0.5);
                country.txt.setOrigin(0,0.5);
                country.txt.x += 1;
                this.americaContainer.add(country.rect);
            }
            else {
                // same rectangles for all other countries
                country.rect = this.add.sprite(country.txt.x, country.txt.y, "rectangle");
                country.rect.displayWidth = country.txt.width + 2;
                country.rect.displayHeight = country.txt.height;
                this.americaContainer.add(country.rect);
            }

            // bring to top text field
            this.americaContainer.bringToTop(country.txt);
    }
    
    displayAmerica(aScene) {
        // extra
        aScene.extraFrenchGuiana = aScene.add.image(width/2 + 891, height/2 + 218.5, "extraFrenchGuiana");
        aScene.extraFalklands = aScene.add.sprite(width/2 + 986, height/2 + 1940, "extraFalklands");
        aScene.extraCaribbean = aScene.add.sprite(width/2 + 605.5, height/2 - 170, "extraCaribbean");
        // countries
        aScene.unitedStates = aScene.add.image(width/2 - 409, height/2 - 1121, "unitedStates");
        aScene.canada = aScene.add.image(width/2 + 382, height/2 - 1514, "canada");
        aScene.mexico = aScene.add.image(width/2 - 338, height/2 - 392, "mexico");
        aScene.bahamas = aScene.add.sprite(width/2 + 336, height/2 - 402, "bahamas");
        aScene.cuba = aScene.add.sprite(width/2 + 214, height/2 - 326, "cuba");
        aScene.haiti = aScene.add.sprite(width/2 + 379.5, height/2 - 250, "haiti");
        aScene.jamaica = aScene.add.sprite(width/2 + 262, height/2 - 219, "jamaica");
        aScene.dominicanRepublic = aScene.add.sprite(width/2 + 457.5, height/2 - 239.5, "dominicanRepublic");
        aScene.guatemala = aScene.add.sprite(width/2 - 99, height/2 - 149, "guatemala");
        aScene.belize = aScene.add.sprite(width/2 - 46, height/2 - 192, "belize");
        aScene.elSalvador = aScene.add.sprite(width/2 - 67.5, height/2 - 87, "elSalvador");
        aScene.honduras = aScene.add.sprite(width/2 + 8, height/2 - 115, "honduras");
        aScene.nicaragua = aScene.add.sprite(width/2 + 28, height/2 - 58, "nicaragua");
        aScene.costaRica = aScene.add.sprite(width/2 + 50, height/2 + 43, "costaRica");
        aScene.panama = aScene.add.sprite(width/2 + 158.5, height/2 + 81, "panama");
        aScene.colombia = aScene.add.sprite(width/2 + 346, height/2 + 213.5, "colombia");
        aScene.venezuela = aScene.add.sprite(width/2 + 528, height/2 + 141, "venezuela");
        aScene.ecuador = aScene.add.sprite(width/2 + 205, height/2 + 396, "ecuador");
        aScene.brazil = aScene.add.sprite(width/2 + 859.5, height/2 + 782, "brazil");
        aScene.peru = aScene.add.sprite(width/2 + 299.5, height/2 + 626.5, "peru");
        aScene.guyana = aScene.add.sprite(width/2 + 732, height/2 + 189, "guyana");
        aScene.suriname = aScene.add.sprite(width/2 + 812, height/2 + 219, "suriname");
        aScene.bolivia = aScene.add.sprite(width/2 + 624, height/2 + 847, "bolivia");
        aScene.paraguay = aScene.add.sprite(width/2 + 787, height/2 + 1068, "paraguay");
        aScene.chile = aScene.add.sprite(width/2 + 660, height/2 + 1472, "chile");
        aScene.argentina = aScene.add.sprite(width/2 + 718, height/2 + 1525, "argentina");
        aScene.uruguay = aScene.add.sprite(width/2 + 905, height/2 + 1349, "uruguay");
        aScene.saintKittsAndNevis = aScene.add.sprite(width/2 + 651, height/2 - 196, "saintKittsAndNevis");
        aScene.antiguaAndBarbuda = aScene.add.sprite(width/2 + 683, height/2 - 196, "antiguaAndBarbuda");
        aScene.dominica = aScene.add.sprite(width/2 + 682, height/2 - 135, "dominica");
        aScene.saintLucia = aScene.add.sprite(width/2 + 691, height/2 - 95, "saintLucia");
        aScene.saintVincentAndGrenadines = aScene.add.sprite(width/2 + 684, height/2 - 64, "saintVincentAndGrenadines");
        aScene.barbados = aScene.add.sprite(width/2 + 729, height/2 - 65, "barbados");
        aScene.grenada = aScene.add.sprite(width/2 + 670, height/2 - 34, "grenada");
        aScene.trinidadAndTobago = aScene.add.sprite(width/2 + 678, height/2 + 10, "trinidadAndTobago");
        // show frame 2 on mouse over
        aScene.bahamas.isSpritesheet = true;
        aScene.saintKittsAndNevis.isSpritesheet = true;
        aScene.saintVincentAndGrenadines.isSpritesheet = true;
        aScene.saintLucia.isSpritesheet = true;
        aScene.antiguaAndBarbuda.isSpritesheet = true;
        aScene.dominica.isSpritesheet = true;
        aScene.barbados.isSpritesheet = true;
        aScene.grenada.isSpritesheet = true;
// repositions some labels
        aScene.mexico.labelX = aScene.mexico.x - 50;
        aScene.mexico.labelY = aScene.mexico.y;
		//usa en canada reposition
		aScene.canada.labelX = aScene.canada.x - 200;
        aScene.canada.labelY = aScene.canada.y + 100;
		aScene.unitedStates.labelX = aScene.unitedStates.x + 250;
        aScene.unitedStates.labelY = aScene.unitedStates.y + 300;
        aScene.dominicanRepublic.labelX = aScene.dominicanRepublic.x + 56;
        aScene.dominicanRepublic.labelY = aScene.dominicanRepublic.y - 50;
        aScene.belize.labelX = aScene.belize.x + 40;
        aScene.belize.labelY = aScene.belize.y - 15;
        aScene.guatemala.labelX = aScene.guatemala.x;
        aScene.guatemala.labelY = aScene.guatemala.y - 10;
        aScene.haiti.labelX = aScene.haiti.x - 50;
        aScene.haiti.labelY = aScene.haiti.y;
        aScene.elSalvador.labelX = aScene.elSalvador.x - 56;
        aScene.elSalvador.labelY = aScene.elSalvador.y + 50;
        aScene.jamaica.labelX = aScene.jamaica.x;
        aScene.jamaica.labelY = aScene.jamaica.y + 35;
        aScene.guyana.labelX = aScene.guyana.x;
        aScene.guyana.labelY = aScene.guyana.y - 25;
        aScene.venezuela.labelX = aScene.venezuela.x;
        aScene.venezuela.labelY = aScene.venezuela.y - 50;
        aScene.ecuador.labelX = aScene.ecuador.x - 20;
        aScene.ecuador.labelY = aScene.ecuador.y - 10;
        aScene.peru.labelX = aScene.peru.x - 20;
        aScene.peru.labelY = aScene.peru.y;
        aScene.brazil.labelX = aScene.brazil.x + 50;
        aScene.brazil.labelY = aScene.brazil.y - 80;
        aScene.costaRica.labelX = aScene.costaRica.x - 20;
        aScene.costaRica.labelY = aScene.costaRica.y - 5;
        aScene.panama.labelX = aScene.panama.x;
        aScene.panama.labelY = aScene.panama.y + 5;
        aScene.nicaragua.labelX = aScene.nicaragua.x + 10;
        aScene.nicaragua.labelY = aScene.nicaragua.y + 15;
        aScene.honduras.labelX = aScene.honduras.x + 30;
        aScene.honduras.labelY = aScene.honduras.y;
        aScene.argentina.labelX = aScene.argentina.x;
        aScene.argentina.labelY = aScene.argentina.y - 30;
        aScene.chile.labelX = aScene.chile.x - 130;
        aScene.chile.labelY = aScene.chile.y - 45;

        aScene.saintKittsAndNevis.labelX = aScene.saintKittsAndNevis.x + 45;
        aScene.saintKittsAndNevis.labelY = aScene.saintKittsAndNevis.y - 45;
        aScene.saintVincentAndGrenadines.labelX = aScene.saintVincentAndGrenadines.x + 64;
        aScene.saintVincentAndGrenadines.labelY = aScene.saintVincentAndGrenadines.y + 45;
        aScene.antiguaAndBarbuda.labelX = aScene.antiguaAndBarbuda.x + 45;
        aScene.saintLucia.labelX = aScene.saintLucia.x + 50;
        aScene.saintLucia.labelY = aScene.saintLucia.y - 14;
        aScene.antiguaAndBarbuda.labelY = aScene.antiguaAndBarbuda.y;
        aScene.dominica.labelX = aScene.dominica.x + 50;
        aScene.dominica.labelY = aScene.dominica.y - 16;
        aScene.grenada.labelX = aScene.grenada.x + 70;
        aScene.grenada.labelY = aScene.grenada.y + 60;
        aScene.barbados.labelX = aScene.barbados.x + 45;
        aScene.barbados.labelY = aScene.barbados.y;
        aScene.trinidadAndTobago.labelX = aScene.trinidadAndTobago.x + 55;
        aScene.trinidadAndTobago.labelY = aScene.trinidadAndTobago.y + 60;


        // lines and labels
        aScene.elSalvador.hasLine = true;
        aScene.elSalvador.lineX = aScene.elSalvador.x;
        aScene.elSalvador.lineY = aScene.elSalvador.y;
        aScene.dominicanRepublic.hasLine = true;
        aScene.dominicanRepublic.lineX = aScene.dominicanRepublic.x;
        aScene.dominicanRepublic.lineY = aScene.dominicanRepublic.y;
        aScene.saintKittsAndNevis.hasLine = true;
        aScene.saintKittsAndNevis.lineX = aScene.saintKittsAndNevis.x + 9;
        aScene.saintKittsAndNevis.lineY = aScene.saintKittsAndNevis.y -9;
        aScene.antiguaAndBarbuda.hasLine = true;
        aScene.antiguaAndBarbuda.lineX = aScene.antiguaAndBarbuda.x + 15;
        aScene.antiguaAndBarbuda.lineY = aScene.antiguaAndBarbuda.y;
        aScene.barbados.hasLine = true;
        aScene.barbados.lineX = aScene.barbados.x + 13;
        aScene.barbados.lineY = aScene.barbados.y;
        aScene.saintLucia.hasLine = true;
        aScene.saintLucia.lineX = aScene.saintLucia.x + 14;
        aScene.saintLucia.lineY = aScene.saintLucia.y;
        aScene.dominica.hasLine = true;
        aScene.dominica.lineX = aScene.dominica.x + 14;
        aScene.dominica.lineY = aScene.dominica.y;
        aScene.grenada.hasLine = true;
        aScene.grenada.lineX = aScene.grenada.x + 10;
        aScene.grenada.lineY = aScene.grenada.y + 8;
        aScene.saintVincentAndGrenadines.hasLine = true;
        aScene.saintVincentAndGrenadines.lineX = aScene.saintVincentAndGrenadines.x + 10;
        aScene.saintVincentAndGrenadines.lineY = aScene.saintVincentAndGrenadines.y + 8;
        aScene.trinidadAndTobago.hasLine = true;
        aScene.trinidadAndTobago.lineX = aScene.trinidadAndTobago.x;
        aScene.trinidadAndTobago.lineY = aScene.trinidadAndTobago.y + 10;

        // names
        aScene.unitedStates.name = countriesLabels.unitedStates;
        aScene.mexico.name = countriesLabels.mexico;
        aScene.canada.name = countriesLabels.canada;
        aScene.bahamas.name = countriesLabels.bahamas;
        aScene.cuba.name = countriesLabels.cuba;
        aScene.haiti.name = countriesLabels.haiti;
        aScene.jamaica.name = countriesLabels.jamaica;
        aScene.dominicanRepublic.name = countriesLabels.dominicanRepublic;
        aScene.guatemala.name = countriesLabels.guatemala;
        aScene.belize.name = countriesLabels.belize;
        aScene.honduras.name = countriesLabels.honduras;
        aScene.elSalvador.name = countriesLabels.elSalvador;
        aScene.nicaragua.name = countriesLabels.nicaragua;
        aScene.panama.name = countriesLabels.panama;
        aScene.costaRica.name = countriesLabels.costaRica;
        aScene.colombia.name = countriesLabels.colombia;
        aScene.venezuela.name = countriesLabels.venezuela;
        aScene.ecuador.name = countriesLabels.ecuador;
        aScene.brazil.name = countriesLabels.brazil;
        aScene.peru.name = countriesLabels.peru;
        aScene.suriname.name = countriesLabels.suriname;
        aScene.guyana.name = countriesLabels.guyana;
        aScene.bolivia.name = countriesLabels.bolivia;
        aScene.argentina.name = countriesLabels.argentina;
        aScene.chile.name = countriesLabels.chile;
        aScene.paraguay.name = countriesLabels.paraguay;
        aScene.uruguay.name = countriesLabels.uruguay;
        aScene.trinidadAndTobago.name = countriesLabels.trinidadAndTobago;
        aScene.grenada.name = countriesLabels.grenada;
        aScene.saintKittsAndNevis.name = countriesLabels.saintKittsAndNevis;
        aScene.saintVincentAndGrenadines.name = countriesLabels.saintVincent;
        aScene.saintLucia.name = countriesLabels.saintLucia;
        aScene.barbados.name = countriesLabels.barbados;
        aScene.dominica.name = countriesLabels.dominica;
        aScene.antiguaAndBarbuda.name = countriesLabels.antiguaAndBarbuda;

        // create container and put countries into it
        aScene.americaContainer = aScene.add.container(0, 0, [aScene.unitedStates, aScene.mexico, aScene.canada, aScene.bahamas, aScene.cuba, aScene.jamaica, aScene.dominicanRepublic, aScene.haiti, aScene.guatemala, aScene.honduras, aScene.elSalvador, aScene.belize, aScene.panama, aScene.nicaragua, aScene.costaRica, aScene.colombia, aScene.venezuela, aScene.ecuador, aScene.brazil, aScene.peru, aScene.suriname, aScene.guyana, aScene.argentina, aScene.bolivia, aScene.paraguay, aScene.chile, aScene.uruguay, aScene.saintKittsAndNevis, aScene.dominica, aScene.saintLucia, aScene.antiguaAndBarbuda, aScene.trinidadAndTobago, aScene.saintVincentAndGrenadines, aScene.grenada, aScene.barbados ]);
        
        aScene.americaContainer.setSize(width, height);
        aScene.americaContainer.x = 0;
        aScene.americaContainer.y = 0;     
     }
}
