"use strict"

var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        })
    }

    create() {

        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;

        // user interface scene
        ui = this.scene.get("userInterface");
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;
       camera.zoom = 0.6;
       camera.scrollY = -50;

        // min max zoom
        this.minZoom = 0.6; 

        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.6;
        }
        else {
            this.maxZoom = 1.8;
        }

        // display countries in this scene
        this.displayProvinces(this);
       
        // get countries (sprites) array from the container
        this.countriesArray = this.provincesContainer.getAll();
        // for each country (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {

            let country = this.countriesArray[i];

            /* development phase
            country.setInteractive()
            this.input.setDraggable(country);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {

                gameObject.x = dragX;
                gameObject.y = dragY;
        
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });
            */

            // make countries sprites interactive
            country.setInteractive({ 
                useHandCursor: true,             
                pixelPerfect: true,
                alphaTolerance: 255
             });

             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over country
                country.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                        if (country.isSpritesheet === true) {
                            country.setFrame(1);
                        }
                        else {
                            country.setTintFill(0xFFFFFF);
                        }
                    }
                },this);

                country.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        if (country.isSpritesheet === true) {
                            country.setFrame(0);
                        }
                        else {
                            country.clearTint();
                        }
                    }
                },this);
            }

            country.on('pointerdown', () => {

                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });

            country.on('pointerup', () => {

                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);

                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    country.xPos = camera.x;
                    country.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false)
                    {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === country.name || (ui.questionText.text === labels.mariElRepublic2 && country.name === countriesLabels.mariElRepublic) || (ui.questionText.text === labels.northOssetiaAlaniaRepublic2 && country.name === countriesLabels.northOssetiaAlaniaRepublic) || (ui.questionText.text === labels.chukotkaAutonomousOkrug2 && country.name === countriesLabels.chukotkaAutonomousOkrug) || (ui.questionText.text === labels.jewishAutonomousOblast2 && country.name === countriesLabels.jewishAutonomousOblast) || (ui.questionText.text === labels.nenetsAutonomousOkrug2 && country.name === countriesLabels.nenetsAutonomousOkrug) || (ui.questionText.text === labels.khantyMansiAutonomousOkrug2 && country.name === countriesLabels.khantyMansiAutonomousOkrug) || (ui.questionText.text === labels.yamaloNenetsAutonomousOkrug2 && country.name === countriesLabels.yamaloNenetsAutonomousOkrug) || (ui.questionText.text === labels.crimeaRepublicDisputedArea2 && country.name === countriesLabels.crimeaRepublicDisputedArea) || (ui.questionText.text === labels.sevastopolDisputedArea2 && country.name === countriesLabels.sevastopolDisputedArea))
                        {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this country
                            country.disableInteractive();

                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }

                            // create the country label
                            this.showLabels(country);
    
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
    
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // drag
                else {
                    // console.log("don't tap, drag the map");
                }
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();

        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false)
            {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();

                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                var dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {

                    // drag 
                    if (this.gameCompleted === false) {
                        var drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }

                }).on('pinch', dragScale => {
                    var scaleFactor = dragScale.scaleFactor;
                    
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                    
                }, this);

                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }

        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 65, color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 65, color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });

        // mouse over microstate sprite
        this.mouseOverMicro = this.add.image(0,0, 'mouseOverMicrostate');
        this.mouseOverMicro.setVisible(false);

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                
                camera.zoom *= 0.9;
            }
        }
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.provincesContainer.setSize(width, height);
        this.provincesContainer.x = 0;
        this.provincesContainer.y = 0; 
        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2, height/2);
        }
    }

    getQuestion()
    {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;

        // use short labels for these regions
        if (ui.questionText.text === countriesLabels.chukotkaAutonomousOkrug) {
            ui.questionText.text = labels.chukotkaAutonomousOkrug2;
        }
        else if (ui.questionText.text === countriesLabels.jewishAutonomousOblast) {
            ui.questionText.text = labels.jewishAutonomousOblast2;
        }
        else if (ui.questionText.text === countriesLabels.nenetsAutonomousOkrug) {
            ui.questionText.text = labels.nenetsAutonomousOkrug2;
        }
        else if (ui.questionText.text === countriesLabels.khantyMansiAutonomousOkrug) {
            ui.questionText.text = labels.khantyMansiAutonomousOkrug2;
        }
        else if (ui.questionText.text === countriesLabels.yamaloNenetsAutonomousOkrug) {
            ui.questionText.text = labels.yamaloNenetsAutonomousOkrug2;
        }
        else if (ui.questionText.text === countriesLabels.crimeaRepublicDisputedArea) {
            ui.questionText.text = labels.crimeaRepublicDisputedArea2;
        }
        else if (ui.questionText.text === countriesLabels.sevastopolDisputedArea) {
            ui.questionText.text = labels.sevastopolDisputedArea2;
        }

        // small font size for these labels
        if (ui.questionText.text === countriesLabels.kabardinoBalkarRepublic || ui.questionText.text === countriesLabels.karachayCherkessRepublic || ui.questionText.text === countriesLabels.northOssetiaAlaniaRepublic) {
            ui.questionText.setFontSize(25);
        }
        else {
            ui.questionText.setFontSize(33);
        }
        
        // tween
        this.tweens.add({
           targets: [ui.questionText],
           //scaleX: '-=.2',
           //angle: 10,
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });

        // remove the previous question
        this.questionsArray.shift();
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;

        // play sound
        this.gameOverSound.play();

        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        ui.buttonSound.destroy();

        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {

        // tween camera
        if (camera.zoom > .3) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: .3,
                x: 0, 
                y: 0,
                duration: 2000,
                onComplete: () => {
                    
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }

        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: -50,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showLabels(country) {
            // label
            country.txt = this.add.text(country.x, country.y, country.name, { fontFamily: "bold", fontSize: 17, align: "center", color: '#000000' });
            country.txt.setOrigin(.5,.5);
            this.provincesContainer.add(country.txt);

            // position text
            if (country.labelX) {
                country.txt.x = country.labelX;
                country.txt.y = country.labelY;
            }

            // rectangles
            country.rect = this.add.sprite(country.txt.x, country.txt.y, "rectangle");
            country.rect.displayWidth = country.txt.width + 1;
            country.rect.displayHeight = country.txt.height;
            this.provincesContainer.add(country.rect);
            // bring to top
            this.provincesContainer.bringToTop(country.txt);
    }
    
    displayProvinces(aScene) {
        // extra
        aScene.map = aScene.add.image(width/2, height/2, 'map');
        aScene.map.alpha = .5;

        aScene.quangBinh = aScene.add.image(width/2+68.7, height/2-232.2, 'texture', 'quangBinh.png');
        aScene.haTinh = aScene.add.image(width/2-2, height/2-354, 'texture', 'haTinh.png');
        aScene.ngheAn = aScene.add.image(width/2-138.8, height/2-493, 'texture', 'ngheAn.png');
        aScene.quangTri = aScene.add.image(width/2+159.5, height/2-120, 'texture', 'quangTri.png');
        aScene.thuaThienHue = aScene.add.image(width/2+250.5, height/2-68.2, 'texture', 'thuaThien-Hue.png');
        aScene.thanhHoa = aScene.add.image(width/2-86, height/2-595.5, 'texture', 'thanhHoa.png');
        aScene.sonLa = aScene.add.image(width/2-240.2, height/2-789, 'texture', 'sonLa.png');
        aScene.hoaBinh = aScene.add.image(width/2-69, height/2-703.2, 'texture', 'hoaBinh.png');
        aScene.ninhBinh = aScene.add.image(width/2+3.5, height/2-628.5, 'texture', 'ninhBinh.png');
        aScene.haNam = aScene.add.image(width/2+22, height/2-678, 'texture', 'haNam.png');
        aScene.namDinh = aScene.add.image(width/2+58.5, height/2-633, 'texture', 'namDinh.png');
        aScene.haNoi = aScene.add.image(width/2-25.2, height/2-742.5, 'texture', 'haNoi.png');
        aScene.phuTho = aScene.add.image(width/2-99.8, height/2-793, 'texture', 'phuTho.png');
        aScene.yenBai = aScene.add.image(width/2-187, height/2-864.5, 'texture', 'yenBai.png');
        aScene.hungYen = aScene.add.image(width/2+37.5, height/2-717, 'texture', 'hungYen.png');
        aScene.laoCai = aScene.add.image(width/2-247, height/2-945.5, 'texture', 'laoCai.png');
        aScene.laiChau = aScene.add.image(width/2-377.5, height/2-928.7, 'texture', 'laiChau.png');
        aScene.dienBien = aScene.add.image(width/2-415.3, height/2-850, 'texture', 'dienBien.png');
        aScene.tuyenQuang = aScene.add.image(width/2-84.4, height/2-906.2, 'texture', 'tuyenQuang.png');
        aScene.vinhPhuc = aScene.add.image(width/2-36.8, height/2-801, 'texture', 'vinhPhuc.png');
        aScene.thaiNguyen = aScene.add.image(width/2+4, height/2-846, 'texture', 'thaiNguyen.png');
        aScene.bacGiang = aScene.add.image(width/2+88, height/2-799.7, 'texture', 'bacGiang.png');
        aScene.langSon = aScene.add.image(width/2+126, height/2-876.7, 'texture', 'langSon.png');
        aScene.haGiang = aScene.add.image(width/2-123.6, height/2-1007, 'texture', 'haGiang.png');
        aScene.bacKan = aScene.add.image(width/2+2.5, height/2-932, 'texture', 'bacKan.png');
        aScene.caoBang = aScene.add.image(width/2+32, height/2-1000, 'texture', 'caoBang.png');
        aScene.bacNinh = aScene.add.image(width/2+39, height/2-761.6, 'texture', 'bacNinh.png');
        aScene.haiDuong = aScene.add.image(width/2+76.7, height/2-739.2, 'texture', 'haiDuong.png');
        aScene.thaiBinh = aScene.add.image(width/2+78.2, height/2-673.3, 'texture', 'thaiBinh.png');
        aScene.haiPhong = aScene.add.image(width/2+176.5, height/2-683, 'texture', 'haiPhong.png');
        aScene.quangNinh = aScene.add.image(width/2+203, height/2-775.6, 'texture', 'quangNinh.png');
        aScene.daNang = aScene.add.image(width/2+318, height/2-22, 'texture', 'daNang.png');
        aScene.quangNam = aScene.add.image(width/2+302.5, height/2+59, 'texture', 'quangNam.png');
        aScene.quangNgai = aScene.add.image(width/2+403.5, height/2+137.5, 'texture', 'quangNgai.png');
        aScene.konTum = aScene.add.image(width/2+297, height/2+181, 'texture', 'konTum.png');
        aScene.giaLai = aScene.add.image(width/2+329, height/2+310, 'texture', 'giaLai.png');
        aScene.binhDinh = aScene.add.image(width/2+441.5, height/2+265, 'texture', 'binhDinh.png');
        aScene.dakLak = aScene.add.image(width/2+339, height/2+458.5, 'texture', 'dakLak.png');
        aScene.phuYen = aScene.add.image(width/2+458.2, height/2+397, 'texture', 'phuYen.png');
        aScene.dakNong = aScene.add.image(width/2+256.2, height/2+533.2, 'texture', 'dakNong.png');
        aScene.lamDong = aScene.add.image(width/2+304, height/2+608, 'texture', 'lamDong.png');
        aScene.khanhHoa = aScene.add.image(width/2+453, height/2+524.5, 'texture', 'khanhHoa.png');
        aScene.ninhThuan = aScene.add.image(width/2+433.4, height/2+611.5, 'texture', 'ninhThuan.png');
        aScene.binhThuan = aScene.add.image(width/2+331.5, height/2+716, 'texture', 'binhThuan.png');
        aScene.binhPhuoc = aScene.add.image(width/2+151, height/2+603.5, 'texture', 'binhPhuoc.png');
        aScene.dongNai = aScene.add.image(width/2+185.2, height/2+709.5, 'texture', 'dongNai.png');
        aScene.baRiaVungTau = aScene.add.image(width/2+141.5, height/2+913, 'texture', 'baRia-VungTau.png');
        aScene.hoChiMinhCity = aScene.add.image(width/2+120, height/2+755.7, 'texture', 'hoChiMinhCity.png');
        aScene.binhDuong = aScene.add.image(width/2+113.6, height/2+694, 'texture', 'binhDuong.png');
        aScene.tayNinh = aScene.add.image(width/2+43.5, height/2+667.5, 'texture', 'tayNinh.png');
        aScene.longAn = aScene.add.image(width/2+41.8, height/2+762.8, 'texture', 'longAn.png');
        aScene.tienGiang = aScene.add.image(width/2+67.2, height/2+807.7, 'texture', 'tienGiang.png');
        aScene.dongThap = aScene.add.image(width/2-38, height/2+786.7, 'texture', 'dongThap.png');
        aScene.benTre = aScene.add.image(width/2+82.7, height/2+856.7, 'texture', 'benTre.png');
        aScene.vinhLong = aScene.add.image(width/2+18.2, height/2+849.8, 'texture', 'vinhLong.png');
        aScene.traVinh = aScene.add.image(width/2+65.8, height/2+894.5, 'texture', 'traVinh.png');
        aScene.hauGiang = aScene.add.image(width/2-32.2, height/2+898.8, 'texture', 'hauGiang.png');
        aScene.canTho = aScene.add.image(width/2-41.7, height/2+849.7, 'texture', 'canTho.png');
        aScene.anGiang = aScene.add.image(width/2-92.4, height/2+784.8, 'texture', 'anGiang.png');
        aScene.kienGiang = aScene.add.image(width/2-159.8, height/2+871.8, 'texture', 'kienGiang.png');
        aScene.socTrang = aScene.add.image(width/2+12.5, height/2+927.8, 'texture', 'socTrang.png');
        aScene.bacLieu = aScene.add.image(width/2-40.4, height/2+968.4, 'texture', 'bacLieu.png');
        aScene.caMau = aScene.add.image(width/2-106.4, height/2+1016, 'texture', 'caMau.png');

        // positions
        aScene.tuyenQuang.labelX = aScene.tuyenQuang.x - 10;
        aScene.tuyenQuang.labelY = aScene.tuyenQuang.y - 10;
        aScene.thaiNguyen.labelX = aScene.thaiNguyen.x - 5;
        aScene.thaiNguyen.labelY = aScene.thaiNguyen.y - 5;
        aScene.yenBai.labelX = aScene.yenBai.x + 10;
        aScene.yenBai.labelY = aScene.yenBai.y + 10;
        aScene.phuTho.labelX = aScene.phuTho.x - 8;
        aScene.phuTho.labelY = aScene.phuTho.y + 10;
        aScene.bacGiang.labelX = aScene.bacGiang.x;
        aScene.bacGiang.labelY = aScene.bacGiang.y + 7;
        aScene.thanhHoa.labelX = aScene.thanhHoa.x + 25;
        aScene.thanhHoa.labelY = aScene.thanhHoa.y - 10;
        aScene.haNoi.labelX = aScene.haNoi.x;
        aScene.haNoi.labelY = aScene.haNoi.y - 10;
        aScene.namDinh.labelX = aScene.namDinh.x - 5;
        aScene.namDinh.labelY = aScene.namDinh.y - 15;
        aScene.ninhBinh.labelX = aScene.ninhBinh.x + 5;
        aScene.ninhBinh.labelY = aScene.ninhBinh.y;
        aScene.haiPhong.labelX = aScene.haiPhong.x - 35;
        aScene.haiPhong.labelY = aScene.haiPhong.y - 25;
        aScene.thaiBinh.labelX = aScene.thaiBinh.x + 20;
        aScene.thaiBinh.labelY = aScene.thaiBinh.y;
        aScene.quangNinh.labelX = aScene.quangNinh.x + 10;
        aScene.quangNinh.labelY = aScene.quangNinh.y + 5;
        aScene.baRiaVungTau.labelX = aScene.baRiaVungTau.x + 90;
        aScene.baRiaVungTau.labelY = aScene.baRiaVungTau.y - 120;
        aScene.binhDuong.labelX = aScene.binhDuong.x;
        aScene.binhDuong.labelY = aScene.binhDuong.y - 10;
        aScene.tayNinh.labelX = aScene.tayNinh.x - 10;
        aScene.tayNinh.labelY = aScene.tayNinh.y - 10;
        aScene.binhThuan.labelX = aScene.binhThuan.x - 10;
        aScene.binhThuan.labelY = aScene.binhThuan.y - 10;
        aScene.lamDong.labelX = aScene.lamDong.x + 10;
        aScene.lamDong.labelY = aScene.lamDong.y + 15;
        aScene.benTre.labelX = aScene.benTre.x + 10;
        aScene.benTre.labelY = aScene.benTre.y - 10;
        aScene.anGiang.labelX = aScene.anGiang.x;
        aScene.anGiang.labelY = aScene.anGiang.y + 15;
        aScene.dongThap.labelX = aScene.dongThap.x;
        aScene.dongThap.labelY = aScene.dongThap.y - 15;
        aScene.vinhLong.labelX = aScene.vinhLong.x + 5;
        aScene.vinhLong.labelY = aScene.vinhLong.y + 5;
        aScene.canTho.labelX = aScene.canTho.x - 5;
        aScene.canTho.labelY = aScene.canTho.y - 5;
        aScene.kienGiang.labelX = aScene.kienGiang.x + 30;
        aScene.kienGiang.labelY = aScene.kienGiang.y + 5;
        aScene.hoChiMinhCity.labelX = aScene.hoChiMinhCity.x;
        aScene.hoChiMinhCity.labelY = aScene.hoChiMinhCity.y - 10;
        aScene.longAn.labelX = aScene.longAn.x;
        aScene.longAn.labelY = aScene.longAn.y + 5;

        // names
        aScene.quangBinh.name = countriesLabels.quangBinh;
        aScene.haTinh.name = countriesLabels.haTinh;
        aScene.ngheAn.name = countriesLabels.ngheAn;
        aScene.quangTri.name = countriesLabels.quangTri;
        aScene.thuaThienHue.name = countriesLabels.thuaThienHue;
        aScene.thanhHoa.name = countriesLabels.thanhHoa;
        aScene.sonLa.name = countriesLabels.sonLa;
        aScene.hoaBinh.name = countriesLabels.hoaBinh;
        aScene.ninhBinh.name = countriesLabels.ninhBinh;
        aScene.haNam.name = countriesLabels.haNam;
        aScene.namDinh.name = countriesLabels.namDinh;
        aScene.haNoi.name = countriesLabels.haNoi;
        aScene.phuTho.name = countriesLabels.phuTho;
        aScene.yenBai.name = countriesLabels.yenBai;
        aScene.hungYen.name = countriesLabels.hungYen;
        aScene.laoCai.name = countriesLabels.laoCai;
        aScene.laiChau.name = countriesLabels.laiChau;
        aScene.dienBien.name = countriesLabels.dienBien;
        aScene.tuyenQuang.name = countriesLabels.tuyenQuang;
        aScene.vinhPhuc.name = countriesLabels.vinhPhuc;
        aScene.thaiNguyen.name = countriesLabels.thaiNguyen;
        aScene.bacGiang.name = countriesLabels.bacGiang;
        aScene.langSon.name = countriesLabels.langSon;
        aScene.haGiang.name = countriesLabels.haGiang;
        aScene.bacKan.name = countriesLabels.bacKan;
        aScene.caoBang.name = countriesLabels.caoBang;
        aScene.bacNinh.name = countriesLabels.bacNinh;
        aScene.haiDuong.name = countriesLabels.haiDuong;
        aScene.thaiBinh.name = countriesLabels.thaiBinh;
        aScene.haiPhong.name = countriesLabels.haiPhong;
        aScene.quangNinh.name = countriesLabels.quangNinh;
        aScene.daNang.name = countriesLabels.daNang;
        aScene.quangNam.name = countriesLabels.quangNam;
        aScene.quangNgai.name = countriesLabels.quangNgai;
        aScene.konTum.name = countriesLabels.konTum;
        aScene.giaLai.name = countriesLabels.giaLai;
        aScene.binhDinh.name = countriesLabels.binhDinh;
        aScene.dakLak.name = countriesLabels.dakLak;
        aScene.phuYen.name = countriesLabels.phuYen;
        aScene.dakNong.name = countriesLabels.dakNong;
        aScene.lamDong.name = countriesLabels.lamDong;
        aScene.khanhHoa.name = countriesLabels.khanhHoa;
        aScene.ninhThuan.name = countriesLabels.ninhThuan;
        aScene.binhThuan.name = countriesLabels.binhThuan;
        aScene.binhPhuoc.name = countriesLabels.binhPhuoc;
        aScene.dongNai.name = countriesLabels.dongNai;
        aScene.baRiaVungTau.name = countriesLabels.baRiaVungTau;
        aScene.hoChiMinhCity.name = countriesLabels.hoChiMinhCity;
        aScene.binhDuong.name = countriesLabels.binhDuong;
        aScene.tayNinh.name = countriesLabels.tayNinh;
        aScene.longAn.name = countriesLabels.longAn;
        aScene.tienGiang.name = countriesLabels.tienGiang;
        aScene.dongThap.name = countriesLabels.dongThap;
        aScene.benTre.name = countriesLabels.benTre;
        aScene.vinhLong.name = countriesLabels.vinhLong;
        aScene.traVinh.name = countriesLabels.traVinh;
        aScene.hauGiang.name = countriesLabels.hauGiang;
        aScene.canTho.name = countriesLabels.canTho;
        aScene.anGiang.name = countriesLabels.anGiang;
        aScene.kienGiang.name = countriesLabels.kienGiang;
        aScene.socTrang.name = countriesLabels.socTrang;
        aScene.bacLieu.name = countriesLabels.bacLieu;
        aScene.caMau.name = countriesLabels.caMau;

        // add sprites to the container
        aScene.provincesContainer = aScene.add.container(0, 0, [aScene.quangBinh, aScene.haTinh, aScene.ngheAn, aScene.quangTri, aScene.thuaThienHue, aScene.thanhHoa, aScene.sonLa, aScene.hoaBinh, aScene.ninhBinh, aScene.haNam, aScene.namDinh, aScene.haNoi, aScene.phuTho, aScene.yenBai, aScene.hungYen, aScene.laoCai, aScene.laiChau, aScene.dienBien, aScene.tuyenQuang, aScene.vinhPhuc, aScene.thaiNguyen, aScene.bacGiang, aScene.langSon, aScene.haGiang, aScene.bacKan, aScene.caoBang, aScene.bacNinh, aScene.haiDuong, aScene.quangNinh, aScene.daNang, aScene.quangNam, aScene.quangNgai, aScene.thaiBinh, aScene.haiPhong, aScene.konTum, aScene.giaLai, aScene.binhDinh, aScene.dakLak, aScene.phuYen, aScene.dakNong, aScene.lamDong, aScene.khanhHoa, aScene.ninhThuan, aScene.binhThuan, aScene.binhPhuoc, aScene.dongNai, aScene.baRiaVungTau, aScene.hoChiMinhCity, aScene.binhDuong, aScene.tayNinh, aScene.longAn, aScene.tienGiang, aScene.dongThap, aScene.benTre, aScene.vinhLong, aScene.traVinh, aScene.hauGiang, aScene.canTho, aScene.anGiang, aScene.kienGiang, aScene.socTrang, aScene.bacLieu, aScene.caMau]);
        
        aScene.provincesContainer.setSize(width, height);
        aScene.provincesContainer.x = 0;
        aScene.provincesContainer.y = 0;     
     }
}
