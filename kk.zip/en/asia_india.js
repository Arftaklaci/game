"use strict"
var width, height, resize;

// edit below
var collator = "en";
var webUrl = "https://world-geography-games.com/asia.html";

var labels =
{
    website         : "World Geography Games",
    play            : "play",
    options         : "options",
    map             : "map",
    tapStart        : "Tap on the map to start",
    clickStart      : "Click on the map to start\nUse mouse wheel to zoom",
    incorrect       : "Incorrect. Try again!",
    score           : "Score: ",
    attempts        : "Attempts: ",
    attemptsEnd     : "Attempts",
    sound           : "SOUND",
	  select          : "select",
    back            : "back",
    map             : "map",
    playAgain       : "Play Again",
    stop            : "Stop",
    skip            : "Skip",
    skipped         : "Skipped",
    
	  title           : "India: States and Union Territories",
    titleTwo        : "India",
	  countries       : "States and Union Territories",
	  countriesEnd    : "States", // game completed
	  numOfCountries  : "Number of States/Union Territories",
    selectAtleast   : "Please select at least 5 territories",
    region1         : "Central India",
    region2         : "East India",
    region3         : "North India",
    region4         : "Northeast India",
    region5         : "South India",
    region6         : "Western India",
    dadraAndNagarHaveli2 : "Dadra and Nagar Haveli \n and Daman and Diu"
}

var countriesLabels = {
  // region 1
  chhattisgarh             : "Chhattisgarh",
  madhyaPradesh            : "Madhya Pradesh",
  // region 2
  andamanAndNicobarIslands : "Andaman and Nicobar Islands",
  bihar                    : "Bihar",
  jharkhand                : "Jharkhand",
  odisha                   : "Odisha",
  westBengal               : "West Bengal",
  // region 3
  chandigarh               : "Chandigarh",
  delhi                    : "Delhi",
  haryana                  : "Haryana",
  himachalPradesh          : "Himachal Pradesh",
  jammuAndKashmir          : "Jammu and Kashmir",
  ladakh                   : "Ladakh",
  punjab                   : "Punjab",
  uttarPradesh             : "Uttar Pradesh",
  uttarakhand              : "Uttarakhand",
  // region 4
  arunachalPradesh         : "Arunachal Pradesh",
  assam                    : "Assam",
  manipur                  : "Manipur",
  meghalaya                : "Meghalaya",
  mizoram                  : "Mizoram",
  nagaland                 : "Nagaland",
  sikkim                   : "Sikkim",
  tripura                  : "Tripura",
  // region 5
  andhraPradesh            : "Andhra Pradesh",
  karnataka                : "Karnataka",
  kerala                   : "Kerala",
  lakshadweep              : "Lakshadweep",
  puducherry               : "Puducherry",
  tamilNadu                : "Tamil Nadu",
  telangana                : "Telangana",
  // region 6
  goa                      : "Goa",
  gujarat                  : "Gujarat",
  maharashtra              : "Maharashtra",
  rajasthan                : "Rajasthan",
  dadraAndNagarHaveli      : "Dadra and Nagar Haveli and Daman and Diu",
}

// don't edit below

// number of attempts
var attempts = +0;
// number of skipped countries
var skips = +0;
// by default all countries are included
var questionsArray = Object.values(countriesLabels);
// always contains all countries
const questionsArrayStatic = questionsArray.slice();

// region 1
var region1Array = [];
for (let x = 0; x < 2; x++) {
  region1Array.push(questionsArray[x]);
}
// region 2
var region2Array = [];
for (let x = 2; x < 7; x++) {
  region2Array.push(questionsArray[x]);
}
// region 3
var region3Array = [];
for (let x = 7; x < 16; x++) {
  region3Array.push(questionsArray[x]);
}
// region 4
var region4Array = [];
for (let x = 16; x < 24; x++) {
  region4Array.push(questionsArray[x]);
}
// region 5
var region5Array = [];
for (let x = 24; x < 31; x++) {
  region5Array.push(questionsArray[x]);
}
// region 6
var region6Array = [];
for (let x = 31; x < 36; x++) {
  region6Array.push(questionsArray[x]);
}

// toggle buttons, by default they are green (frame 0)
var btnRegion1Frame = 0;
var btnRegion2Frame = 0;
var btnRegion3Frame = 0;
var btnRegion4Frame = 0;
var btnRegion5Frame = 0;
var btnRegion6Frame = 0;
var soundButtonFrame = 0;

var toggleButtonsFrames = [];
for (let x = 0; x < questionsArrayStatic.length; x++) {
  toggleButtonsFrames.push(+0);
}

// if true you can toggle regions, else you toggle countries on options
var regionsVisible = true;

// resize
const DEFAULT_WIDTH = 1280
const DEFAULT_HEIGHT = 720
const MAX_WIDTH = DEFAULT_WIDTH * 1.5
const MAX_HEIGHT = DEFAULT_HEIGHT * 1.5
let SCALE_MODE = 'SMOOTH'

const config = {
    type: Phaser.AUTO,
    parent: 'geo-game',
    backgroundColor : 0x34C5EB,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,

    scale: 
    {
        mode: Phaser.Scale.NONE,
        parent: "geo-game",
    },
    scene: [Loading, Menu, UserInterface, GraphUI, Gameplay, Options, Graph]
}

window.addEventListener('load', () => {
    const game = new Phaser.Game(config)
  
    const resize = () => {
      const w = window.innerWidth
      const h = window.innerHeight
  
      let width = DEFAULT_WIDTH
      let height = DEFAULT_HEIGHT
      let maxWidth = MAX_WIDTH
      let maxHeight = MAX_HEIGHT
      let scaleMode = SCALE_MODE
  
      let scale = Math.min(w / width, h / height)
      let newWidth = Math.min(w / scale, maxWidth)
      let newHeight = Math.min(h / scale, maxHeight)
  
      let defaultRatio = DEFAULT_WIDTH / DEFAULT_HEIGHT
      let maxRatioWidth = MAX_WIDTH / DEFAULT_HEIGHT
      let maxRatioHeight = DEFAULT_WIDTH / MAX_HEIGHT
  
      // smooth scaling
      let smooth = 1
      if (scaleMode === 'SMOOTH') {
        const maxSmoothScale = 1.15
        const normalize = (value, min, max) => {
          return (value - min) / (max - min)
        }
        if (width / height < w / h) {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioWidth) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        } else {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioHeight) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        }
      }

      // resize the game
      game.scale.resize(newWidth * smooth, newHeight * smooth)
      // scale the width and height of the css
      game.canvas.style.width = newWidth * scale + 'px'
      game.canvas.style.height = newHeight * scale + 'px'
      // center the game with css margin
      game.canvas.style.marginTop = `${(h - newHeight * scale) / 2}px`
      game.canvas.style.marginLeft = `${(w - newWidth * scale) / 2}px`
    }

    window.addEventListener('resize', event => {
      resize()
    })
  
    resize()
  })
