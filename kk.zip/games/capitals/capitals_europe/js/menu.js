var menuState = {

    create: function () {
        init()

        // bg rectangle
        bg = game.add.image(0, 0, 'bg')

        // title
        flags_europe = game.add.text(W/2, 25, title_label, {font:"38px extraBold", fill:"#000000"});
        flags_europe.anchor.setTo(0.5, 0)

        bgEurope = game.add.sprite(W / 2, 130, 'bgEurope')
        bgEurope.anchor.setTo(0.5, 0)

        // buttons
        button_play = game.add.button(W / 2 - 92, H / 2 + 30, 'button_start', button_clicked);
        button_play.width = 73;
        button_play.height = 73;

        button_options = game.add.button(W / 2 - 90, H / 2 + 115, 'button_options', button_clicked)
        button_library = game.add.button(W / 2 - 94, H / 2 + 200, 'button_library', button_clicked)

        button_play.scale.x = .9
        button_play.scale.y = .9
        button_options.scale.x = .9
        button_options.scale.y = .9
        button_library.scale.x = .9
        button_library.scale.y = .9

        // text
        // play_text = game.add.bitmapText(W / 2, H / 2 + 40, 'open_sans_bold', play_label, 30)
        play_text = game.add.text(W/2, H/2 + 40, play_label, {font:"30px bold", fill:"#000000"});

        button_play_clickable = game.add.button(play_text.x - 40, play_text.y - 10, 'button_invisible', button_clicked)
        button_play_clickable.width = 50 + play_text.width
        button_play_clickable.height = 50

        //options_text = game.add.bitmapText(W / 2, H / 2 + 125, 'open_sans_bold', options_label, 30)
        options_text = game.add.text(W/2, H/2 + 125,  options_label, {font:"30px bold", fill:"#000000"});

        button_options_clickable = game.add.button(options_text.x - 40, options_text.y - 10, 'button_invisible', button_clicked)
        button_options_clickable.width = 50 + options_text.width
        button_options_clickable.height = 50

        // library_text = game.add.bitmapText(W / 2, H / 2 + 205, 'open_sans_bold', library_label, 30)
        library_text = game.add.text(W/2, H/2 + 205,library_label, {font:"30px bold", fill:"#000000"});

        button_library_clickable = game.add.button(options_text.x - 40, library_text.y - 10, 'button_invisible', button_clicked)

        button_library_clickable.width = 50 + library_text.width
        button_library_clickable.height = 50
    }
}

function button_clicked(btn) {
    if (btn == button_play || btn == button_play_clickable) {
        /* hide large flags background on mobile
        if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent))
        {
            var img = document.getElementById("flags-bg").style.display = 'none';
        }*/

        game.state.start("level1")
    } else if (btn == button_options || btn == button_options_clickable) {
        game.state.start("options", true, false);
    } else if (btn == button_library || btn == button_library_clickable) {
        game.state.start("library")
    }
}