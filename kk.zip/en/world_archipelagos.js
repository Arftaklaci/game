"use strict"
var width, height, resize;
var webUrl = "https://world-geography-games.com/world.html";

var labels = 
{
    website         : "World Geography Games",
    title           : "Archipelagos",
    titleTwo        : "Archipelagos",
    play            : "play",
    options         : "options",
    map             : "map",
    sound           : "SOUND",
    photos          : "PHOTOS",
    tapStart        : "Tap on the map to start",
    clickStart      : "Click on the map to start",
    incorrect       : "Incorrect. Try again!",
    score           : "Score: ",
    attempts        : "Attempts: ",
    attemptsEnd     : "Attempts",
    points          : "Points",
    back            : "back",
    playAgain       : "Play Again",
    stop            : "Stop",
    skip            : "Skip",
    skipped         : "Skipped",
}

// the order of labels below is important!
var credits = {
  credit1   : "Photo: Thomas Doyle 2019 (CC-BY-NC-ND)",
  credit2   : "Photo: Terry Ott 2020 (CC-BY)",
  credit3   : "Photo: Sugar Muffin 2019 (CC-BY-NC-ND)",
  credit4   : "Photo: Jeff 2019 (CC-BY-NC-ND)",
  credit5   : "Photo: Sergei Gussev 2018 (CC-BY)",
  credit6   : "Photo: Rolf Dietrich Brecher 2019 (CC-BY-SA)",
  credit7   : "Photo: Rob Oo 2020 (CC-BY)",
  credit8   : "Photo: Amenderson2 2019 (CC-BY)",
  credit9   : "Photo: Almassengale 2019 (CC-BY-ND)",
  credit10  : "Photo: Maheva bagard laursen 2019 (CC-BY)",
  credit11  : "Photo: Jennifer Krauel 2019 (CC-BY-NC-ND)",
  credit12  : "Photo: Anita Gould 2019 (CC-BY-NC)",
  credit13  : "Photo: Oldravvv 2019 (CC-BY-ND)",
  credit14  : "Photo: Fredrik Rubensson 2011 (CC-BY-SA)",
  credit15  : "Photo: Fabio Achilli 2014 (CC-BY)",
  credit16  : "Photo: Asian Development Bank 2019 (CC-BY-NC-ND)",
  credit17  : "Photo: Nikki Navio 2015 (CC-BY-ND)",
  credit18  : "Photo: Laika ac 2019 (CC-BY-SA)",
  credit19  : "Photo: Uusc4all 2017 (CC-BY-NC-ND)",
  credit20  : "Photo: Landbruks- og matdepartementet 2020 (CC-BY-NC 2.0)"
}
var creditsArray = Object.values(credits);

var subjects = {
  aleutianIslands:     "Aleutian Islands",
  antilles:            "Antilles",
  azores:              "Azores",
  bahamas:       	   "Bahamas",
  balearicIslands:     "Balearic Islands",
  canaryIslands:       "Canary Islands",
  capeVerde:           "Cape Verde",
  falklandIslands:     "Falkland Islands",
  faroeIslands:        "Faroe Islands",
  fiji:          	   "Fiji",
  galapagosIslands:    "Galápagos Islands",
  hawaii:  		       "Hawaii",
  kurilIslands:        "Kuril Islands",
  maldives:       	   "Maldives",
  malukuIslands:       "Maluku Islands",
  marshallIslands:     "Marshall Islands",
  philippines:         "Philippines",
  seychelles:          "Seychelles",
  solomonIslands:      "Solomon Islands",
  svalbard:            "Svalbard"
}


var countriesNames = ["Northern Pacific Ocean", "Caribbean", "Atlantic Ocean", "West Indies", "Mediterranean Sea", "Atlantic Ocean", "Atlantic Ocean", "South Atlantic Ocean", "North Atlantic Ocean", "Melanesia", "Pacific Ocean", "Polynesia", "Pacific Ocean", "Indian Ocean", "Indonesia", "Micronesia", "Western Pacific Ocean", "Indian Ocean", "Melanesia", "Arctic Ocean"];

var infoText = [
"Belong to: Russia/USA\nNumber of islands: more than 300", 
"Many sovereign states and territories\nNumber of islands: more than 7000", 
"Belong to: Portugal\nNumber of islands: 9", 
"Sovereign state\nNumber of islands: more than 700", 
"Belong to: Spain\nNumber of islands: 6\nIncludes Ibiza and Majorca", 
"Belong to: Spain\nNumber of islands: 13\nIncludes Gran Canaria and Tenerife", 
"Sovereign state\nNumber of islands: 10", 
"Belong to: United Kingdom\nNumber of islands: 778", 
"Belong to: Denmark\nNumber of islands: 18", 
"Sovereign state\nNumber of islands: 332", 
"Belong to: Ecuador\nNumber of islands: 21", 
"State of the United States\nNumber of islands: 137", 
"Belong to: Russia\nNumber of islands: 56", 
"Sovereign state\nNumber of islands: 1190", 
"Belong to: Indonesia\nNumber of islands: more than 1000",
"Sovereign state\nNumber of islands: 1100", 
"Sovereign state\nNumber of islands: 7107",  
"Sovereign state\nNumber of islands: more than 115", 
"Sovereign state\nNumber of islands: more than 1000", 
"Belongs to: Norway\nNumber of islands: more than 80"];
 
// don't edit below

// sound is on by default
var soundButtonFrame = 0;
// show photos by default
var showPhotos = true;
var photosButtonFrame = 0;
// number of attempts
var attempts = +0;
// number of skipped countries
var skips = +0;
// make array
var questionsArray = Object.values(subjects);
var questionsArrayStatic = Object.values(subjects);

// resize
const DEFAULT_WIDTH = 1280
const DEFAULT_HEIGHT = 720
const MAX_WIDTH = DEFAULT_WIDTH * 1.5
const MAX_HEIGHT = DEFAULT_HEIGHT * 1.5
let SCALE_MODE = 'SMOOTH'

const config = {
    type: Phaser.AUTO,
    parent: 'geo-game',
    backgroundColor : 0x34C5EB,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,

    scale: 
    {
        mode: Phaser.Scale.NONE,
        parent: "geo-game",
    },
    scene: [Loading, Menu, Options, UserInterface, GraphUI, Gameplay, Graph]
}

window.addEventListener('load', () => {
    const game = new Phaser.Game(config)
  
    resize = () => {
      const w = window.innerWidth
      const h = window.innerHeight
  
      let width = DEFAULT_WIDTH
      let height = DEFAULT_HEIGHT
      let maxWidth = MAX_WIDTH
      let maxHeight = MAX_HEIGHT
      let scaleMode = SCALE_MODE
  
      let scale = Math.min(w / width, h / height)
      let newWidth = Math.min(w / scale, maxWidth)
      let newHeight = Math.min(h / scale, maxHeight)
  
      let defaultRatio = DEFAULT_WIDTH / DEFAULT_HEIGHT
      let maxRatioWidth = MAX_WIDTH / DEFAULT_HEIGHT
      let maxRatioHeight = DEFAULT_WIDTH / MAX_HEIGHT
  
      // smooth scaling
      let smooth = 1
      if (scaleMode === 'SMOOTH') {
        const maxSmoothScale = 1.15
        const normalize = (value, min, max) => {
          return (value - min) / (max - min)
        }
        if (width / height < w / h) {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioWidth) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        } else {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioHeight) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        }
      }

      // resize the game
      game.scale.resize(newWidth * smooth, newHeight * smooth)
      // scale the width and height of the css
      game.canvas.style.width = newWidth * scale + 'px'
      game.canvas.style.height = newHeight * scale + 'px'
      // center the game with css margin
      game.canvas.style.marginTop = `${(h - newHeight * scale) / 2}px`
      game.canvas.style.marginLeft = `${(w - newWidth * scale) / 2}px`
    }

    window.addEventListener('resize', event => {
      resize()
    })
  
    resize()
  })
