var bootState = 
{
	preload: function () 
	{
        // preloader graphics
		game.load.image('preloader1', '/games/capitals/capitals_world/images/preloader1.png')
		game.load.image('preloader2', '/games/capitals/capitals_world/images/preloader2.png')
		game.load.image('button_play', '/games/capitals/capitals_world/images/button_play.png')
        // load fonts
		var loadMe = game.add.text(-1000, 0, "..", {font:"9px extraBold", fill:"#000000"});
		var loadMe2 = game.add.text(-1000, 0, "..", {font:"9px bold", fill:"#000000"});
		var loadMe3 = game.add.text(-1000, 0, "..", {font:"9px semiBold", fill:"#000000"});
	},
	
	create: function() 
	{ 
		//game.stage.backgroundColor = '#33ccff';
		document.body.style.backgroundColor = '#33ccff';
        game.physics.startSystem(Phaser.Physics.ARCADE);
        
        game.stage.disableVisibilityChange = true; 
		
		// center the game
		game.scale.pageAlignHorizontally = true;
		game.scale.pageAlignVertically = true;
        game.scale.minWidth = 250;
        game.scale.minHeight = 400;
        game.scale.maxWidth = 1000;
        game.scale.maxHeight = 1600;
		game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
		
		// mobile
		if (!game.device.desktop) 
		{
			// only portrait mode
            this.scale.forceOrientation(false, true);
            this.scale.enterIncorrectOrientation.add(this.enterIncorrectOrientation, this);
            this.scale.leaveIncorrectOrientation.add(this.leaveIncorrectOrientation, this);
		} 
        
		game.scale.refresh();
		game.state.start('Loading');
	},
	
// manage device rotation
enterIncorrectOrientation: function () 
{
    game.scale.stopFullScreen();
	game.orientated = false;
	document.getElementById('orientation').style.display = 'block';
    game.paused = true;
},

leaveIncorrectOrientation: function () 
{
	game.orientated = true;
	document.getElementById('orientation').style.display = 'none';
    game.paused = false;
    game.scale.refresh(); 
}	
};