"use strict"

var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        })
    }

    create() {

        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;

        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");

        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");

       // camera
       camera = this.cameras.main;
       camera.zoom = 0.3;

        // min max zoom
        this.minZoom = 0.3;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.6;
        }
        else {
            this.maxZoom = 2.5;
        }

        // display countries in this scene
        this.displayAfrica(this);
       
        // get countries (sprites) array from the container
        this.countriesArray = this.africaContainer.getAll();

        // for each country (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {

            let country = this.countriesArray[i];


            /* enable drag to position countries
            country.setInteractive()
            this.input.setDraggable(country);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {

                gameObject.x = dragX;
                gameObject.y = dragY;
        
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });
            */



            // make countries sprites interactive
            country.setInteractive({ 
                useHandCursor: true,             
                pixelPerfect: true,
                alphaTolerance: 255
             });

             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over country
                country.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                        if (country.isSpritesheet === true) {
                            country.setFrame(1);
                        }
                        else {
                            country.alpha = 0.5;
                        }
                    }
                },this);

                country.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        if (country.isSpritesheet === true) {
                            country.setFrame(0);
                        }
                        else {
                            country.alpha = 1;
                        }
                    }
                },this);
            }

            country.on('pointerdown', () => {

                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });

            country.on('pointerup', () => {

                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);

                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    country.xPos = camera.x;
                    country.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false)
                    {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === country.name)
                        {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this country
                            country.disableInteractive();

                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }

                            // create the country label
                            this.showAfricaLabels(country);
    
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
    
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // drag
                else {
                    // console.log("don't tap, drag the map");
                }
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();

        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false)
            {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();

                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                var dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {

                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        var drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }

                }).on('pinch', dragScale => {
                    var scaleFactor = dragScale.scaleFactor;
                    
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                    
                }, this);

                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        //if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        //}

        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 65, color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 65, color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });

        // mouse over microstate sprite
        this.mouseOverMicro = this.add.image(0,0, 'mouseOverMicrostate');
        this.mouseOverMicro.setVisible(false);

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        
        // mouse wheel zoom in/out
        //if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                
                camera.zoom *= 0.9;
            }
        //}

        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.africaContainer.setSize(width, height);
        this.africaContainer.x = 0;
        this.africaContainer.y = 0; 
        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2, height/2);
        }
    }

    getQuestion()
    {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;
        this.questionsArray.shift();

        if (ui.questionText.text === countriesLabels.drCongo || ui.questionText.text === countriesLabels.car) {
            ui.questionText.setFontSize(24);
        }
        else {
            ui.questionText.setFontSize(32);
        }
        
        // tween
        this.tweens.add({
           targets: [ui.questionText],
           //scaleX: '-=.2',
           //angle: 10,
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;

        // play sound
        this.gameOverSound.play();

        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        ui.buttonSound.destroy();

        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {

        // tween camera
        if (camera.zoom > .3) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: .3,
                x: 0, 
                y: 0,
                duration: 2000,
                onComplete: () => {
                    
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }

        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: 0,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showAfricaLabels(country) {

            // update country name below
            if (country.name === countriesLabels.drCongo) {
                country.txt = this.add.text(country.x, country.y, labels.drCongoMulti, { fontFamily: "bold", fontSize: 38, color: '#000000' });
                country.txt.setOrigin(.5,.5);
                this.africaContainer.add(country.txt);
            }// update country name below
            else if (country.name === countriesLabels.car) {
                country.txt = this.add.text(country.x, country.y, labels.carMulti, { fontFamily: "bold", fontSize: 38, color: '#000000' });
                country.txt.setOrigin(.5,.5);
                this.africaContainer.add(country.txt);
            }
            else {
                country.txt = this.add.text(country.x, country.y, country.name, { fontFamily: "bold", fontSize: 38, color: '#000000' });
                country.txt.setOrigin(.5,.5);
                this.africaContainer.add(country.txt);
            }

            // position text
            if (country.labelX) {
                country.txt.x = country.labelX;
                country.txt.y = country.labelY;
            }

            // create a line if needed
            if (country.hasLine) {
                
                let line;
                if (country.name === countriesLabels.djibouti) {
                    line = this.add.image(country.lineX, country.lineY, "lineEswatini");
                    line.setOrigin(0,0);
                    line.scaleY = -1;
                }
                else if (country.name === countriesLabels.eswatini || country.name === countriesLabels.lesotho) {
                    line = this.add.image(country.lineX, country.lineY, "lineLesotho");
                    line.setOrigin(0,0);
                }
                else if (country.name === countriesLabels.senegal) {
                    line = this.add.image(country.lineX, country.lineY, "lineSenegal");
                    line.setOrigin(1,1);
                }
                else if (country.name === countriesLabels.rwanda || country.name === countriesLabels.burundi){
                    line = this.add.image(country.lineX, country.lineY, "lineRwanda");
                    line.setOrigin(0,0.5);
                    
                }
                else if (country.name === countriesLabels.liberia){
                    line = this.add.image(country.lineX, country.lineY, "lineLiberia");
                    line.setOrigin(1,0.5);
                }
                else if (country.name === countriesLabels.ivoryCoast){
                    line = this.add.image(country.lineX, country.lineY, "lineIvory");
                    line.setOrigin(1,0.5);
                }
                else if (country.name === countriesLabels.gambia || country.name === countriesLabels.guinea || country.name === countriesLabels.guineaBissau || country.name === countriesLabels.sierraLeone){
                    line = this.add.image(country.lineX, country.lineY, "lineGambia");
                    line.setOrigin(1,0.5);
                }
                else if (country.name === countriesLabels.ghana){
                    line = this.add.image(country.lineX, country.lineY, "lineGhana");
                    line.setOrigin(1,0);
                }
                else if (country.name === countriesLabels.benin){
                    line = this.add.image(country.lineX, country.lineY, "lineBenin");
                    line.setOrigin(1,0);
                }
                else if (country.name === countriesLabels.togo){
                    line = this.add.image(country.lineX, country.lineY, "lineTogo");
                    line.setOrigin(1,0);
                }
                else if (country.name === countriesLabels.saoTomeAndPrincipe){
                    line = this.add.image(country.lineX, country.lineY, "lineSaoTome");
                    line.setOrigin(1,0);
                }
                else if (country.name === countriesLabels.equatorialGuinea){
                    line = this.add.image(country.lineX, country.lineY, "lineEquatorial");
                    line.setOrigin(1,0);
                }
                else if (country.name === countriesLabels.gabon){
                    line = this.add.image(country.lineX, country.lineY, "lineEquatorial");
                    line.setOrigin(1,0);
                }
                else if (country.name === countriesLabels.congo){
                    line = this.add.image(country.lineX, country.lineY, "lineEquatorial");
                    line.setOrigin(1,0);
                }

                this.africaContainer.add(line);
            }
            
            // create white rectangles

            // gambia, guinea, sierra leone, liberia...
            if (country.hasLine && country.x < width/2) {
                
                country.rect = this.add.sprite(country.txt.x, country.txt.y, "rectangle");
                country.rect.displayWidth = country.txt.width + 2;
                country.rect.displayHeight = country.txt.height;
                // set different origin for these rectangles
                country.rect.setOrigin(1,0.5);
                country.txt.setOrigin(1,0.5);
                country.txt.x -= 1;
                this.africaContainer.add(country.rect);
            }
            else {
                // same rectangles for all other countries
                country.rect = this.add.sprite(country.txt.x, country.txt.y, "rectangle");
                country.rect.displayWidth = country.txt.width + 2;
                country.rect.displayHeight = country.txt.height;
                this.africaContainer.add(country.rect);
            }

            // bring to top text field
            this.africaContainer.bringToTop(country.txt);
    }
    
    displayAfrica(aScene) {
        // extra
        aScene.extraWesternSahara = aScene.add.image(width/2 - 802.5, height/2 - 688.5, "extraWesternSahara");
        // text western sahara
        aScene.txtWesternSahara = aScene.add.text(aScene.extraWesternSahara.x - 70, aScene.extraWesternSahara.y - 25, labels.westernSahara, { fontFamily: "bold", fontSize: 40, color: '#545454' });
        aScene.txtWesternSahara.setOrigin(1,0.5);

        // countries
        aScene.southSudan = aScene.add.image(width/2 + 346, height/2 - 182, "southSudan");
        aScene.comoros = aScene.add.image(width/2 + 742, height/2 + 438, "comoros");
        aScene.madagascar = aScene.add.image(width/2 + 802, height/2 + 642, "madagascar");
        aScene.mauritius = aScene.add.image(width/2 + 1152, height/2 + 552, "mauritius");
        aScene.seychelles = aScene.add.image(width/2 + 944, height/2 + 272, "seychelles");
        aScene.capeVerde = aScene.add.image(width/2 - 1112, height/2 - 450, "capeVerde");
        aScene.sudan = aScene.add.image(width/2 + 355, height/2 - 351, "sudan");
        aScene.ethiopia = aScene.add.image(width/2 + 640.5, height/2 - 222, "ethiopia");
        aScene.eritrea = aScene.add.image(width/2 + 615.5, height/2 - 408, "eritrea");
        aScene.djibouti = aScene.add.image(width/2 + 702, height/2 - 304, "djibouti");
        aScene.somalia = aScene.add.image(width/2 + 796, height/2 - 99, "somalia");
        aScene.kenya = aScene.add.image(width/2 + 572.5, height/2 + 62, "kenya");
        aScene.uganda = aScene.add.image(width/2 + 418, height/2 + 19, "uganda");
        aScene.burundi = aScene.add.image(width/2 + 352, height/2 + 166, "burundi");
        aScene.rwanda = aScene.add.image(width/2 + 352, height/2 + 121, "rwanda");
        aScene.tanzania = aScene.add.image(width/2 + 490.5, height/2 + 258, "tanzania");
        aScene.mozambique = aScene.add.image(width/2 + 500, height/2 + 639.5, "mozambique");
        aScene.zambia = aScene.add.image(width/2 + 293.5, height/2 + 467, "zambia");
        aScene.malawi = aScene.add.image(width/2 + 467, height/2 + 472, "malawi");
        aScene.zimbabwe = aScene.add.image(width/2 + 324, height/2 + 649.5, "zimbabwe");
        aScene.botswana = aScene.add.image(width/2 + 200, height/2 + 752, "botswana");
        aScene.southAfrica = aScene.add.image(width/2 + 196, height/2 + 943, "southAfrica");
        aScene.namibia = aScene.add.image(width/2 + 37, height/2 + 770.5, "namibia");
        aScene.eswatini = aScene.add.image(width/2 + 376.5, height/2 + 882.5, "eswatini");
        aScene.lesotho = aScene.add.image(width/2 + 287, height/2 + 977.5, "lesotho");
        aScene.angola = aScene.add.image(width/2 + 23, height/2 + 430, "angola");
        aScene.drCongo = aScene.add.image(width/2 + 130, height/2 + 185, "drCongo");
        aScene.congo = aScene.add.image(width/2 - 58.5, height/2 + 79, "congo");
        aScene.gabon = aScene.add.image(width/2 - 148.5, height/2 + 84, "gabon");
        aScene.car = aScene.add.image(width/2 + 107, height/2 - 146.5, "car");
        aScene.cameroon = aScene.add.image(width/2 - 126.5, height/2 - 168, "cameroon");
        aScene.chad = aScene.add.image(width/2 + 44, height/2 - 418, "chad");
        aScene.niger = aScene.add.image(width/2 - 245.5, height/2 - 484.5, "niger");
        aScene.nigeria = aScene.add.image(width/2 - 228.5, height/2 - 221, "nigeria");
        aScene.equatorialGuinea = aScene.add.image(width/2 - 194, height/2 - 13, "equatorialGuinea");
        aScene.saoTomeAndPrincipe = aScene.add.image(width/2 - 289, height/2 + 29, "saoTomeAndPrincipe");
        aScene.benin = aScene.add.image(width/2 - 402, height/2 - 229, "benin");
        aScene.ghana = aScene.add.image(width/2 - 495, height/2 - 187, "ghana");
        aScene.togo = aScene.add.image(width/2 - 443.5, height/2 - 207, "togo");
        aScene.burkinaFaso = aScene.add.image(width/2 - 506, height/2 - 318.5, "burkinaFaso");
        aScene.mali = aScene.add.image(width/2 - 571, height/2 - 483, "mali");
        aScene.algeria = aScene.add.image(width/2 - 411.5, height/2 - 807.5, "algeria");
        aScene.mauritania = aScene.add.image(width/2 - 753.5, height/2 - 590, "mauritania");
        aScene.senegal = aScene.add.image(width/2 - 856, height/2 - 388.5, "senegal");
        aScene.gambia = aScene.add.image(width/2 - 884, height/2 - 356, "gambia");
        aScene.guinea = aScene.add.image(width/2 - 772, height/2 - 246, "guinea");
        aScene.guineaBissau = aScene.add.image(width/2 - 881, height/2 - 301.5, "guineaBissau");
        aScene.sierraLeone = aScene.add.image(width/2 - 784.5, height/2 - 201, "sierraLeone");
        aScene.ivoryCoast = aScene.add.image(width/2 - 615, height/2 - 171.5, "ivoryCoast");
        aScene.liberia = aScene.add.image(width/2 - 721, height/2 - 139, "liberia");
        aScene.morocco = aScene.add.image(width/2 - 641, height/2 - 922.5, "morocco");
        aScene.tunisia = aScene.add.image(width/2 - 203, height/2 - 986, "tunisia");
        aScene.libya = aScene.add.image(width/2, height/2 - 755, "libya");
        aScene.egypt = aScene.add.image(width/2 + 345, height/2 - 769, "egypt");

        // show frame 2 on mouse over
        aScene.mauritius.isSpritesheet = true;
        aScene.capeVerde.isSpritesheet = true;
        aScene.saoTomeAndPrincipe.isSpritesheet = true;
        aScene.seychelles.isSpritesheet = true;
        aScene.comoros.isSpritesheet = true;

                // repositions some labels
		
		aScene.capeVerde.labelX = aScene.capeVerde.x - 50;
        aScene.capeVerde.labelY = aScene.capeVerde.y;		
		aScene.car.labelX = aScene.car.x;
        aScene.car.labelY = aScene.car.y - 40;
        aScene.ethiopia.labelX = aScene.ethiopia.x - 25;
        aScene.ethiopia.labelY = aScene.ethiopia.y + 20;
        aScene.zambia.labelX = aScene.zambia.x - 35;
        aScene.zambia.labelY = aScene.zambia.y + 30;
        aScene.southAfrica.labelX = aScene.southAfrica.x - 40;
        aScene.southAfrica.labelY = aScene.southAfrica.y + 95;
        aScene.namibia.labelX = aScene.namibia.x - 35;
        aScene.namibia.labelY = aScene.namibia.y - 60;
        aScene.nigeria.labelX = aScene.nigeria.x;
        aScene.nigeria.labelY = aScene.nigeria.y - 30;
        aScene.mozambique.labelX = aScene.mozambique.x + 25;
        aScene.mozambique.labelY = aScene.mozambique.y - 20;
        aScene.zimbabwe.labelX = aScene.zimbabwe.x + 10;
        aScene.zimbabwe.labelY = aScene.zimbabwe.y + 20;
        aScene.somalia.labelX = aScene.somalia.x + 60;
        aScene.somalia.labelY = aScene.somalia.y - 135;
        aScene.eritrea.labelX = aScene.eritrea.x;
        aScene.eritrea.labelY = aScene.eritrea.y - 15;
        aScene.cameroon.labelX = aScene.cameroon.x - 10;
        aScene.cameroon.labelY = aScene.cameroon.y + 60;
        aScene.mauritania.labelX = aScene.mauritania.x;
        aScene.mauritania.labelY = aScene.mauritania.y + 35;
        aScene.mali.labelX = aScene.mali.x + 40;
        aScene.mali.labelY = aScene.mali.y;
        aScene.sudan.labelX = aScene.sudan.x;
        aScene.sudan.labelY = aScene.sudan.y - 50;
		//southsudan
		aScene.southSudan.labelX = aScene.southSudan.x + 65;
        aScene.southSudan.labelY = aScene.southSudan.y + 60;
        aScene.drCongo.labelX = aScene.drCongo.x + 20;
        aScene.drCongo.labelY = aScene.drCongo.y - 20
        // lines and labels
        aScene.djibouti.labelX = aScene.djibouti.x + 130;
        aScene.djibouti.labelY = aScene.djibouti.y - 30;
        aScene.djibouti.hasLine = true;
        aScene.djibouti.lineX = aScene.djibouti.x;
        aScene.djibouti.lineY = aScene.djibouti.y;
        aScene.eswatini.labelX = aScene.eswatini.x + 150;
        aScene.eswatini.labelY = aScene.eswatini.y + 20;
        aScene.eswatini.hasLine = true;
        aScene.eswatini.lineX = aScene.eswatini.x;
        aScene.eswatini.lineY = aScene.eswatini.y;
        aScene.lesotho.labelX = aScene.lesotho.x + 170;
        aScene.lesotho.labelY = aScene.lesotho.y + 10;
        aScene.lesotho.hasLine = true;
        aScene.lesotho.lineX = aScene.lesotho.x;
        aScene.lesotho.lineY = aScene.lesotho.y - 10;
        aScene.rwanda.labelX = aScene.rwanda.x + 420;
        aScene.rwanda.labelY = aScene.rwanda.y + 15;
        aScene.rwanda.hasLine = true;
        aScene.rwanda.lineX = aScene.rwanda.x;
        aScene.rwanda.lineY = aScene.rwanda.y + 5;
        aScene.burundi.labelX = aScene.burundi.x + 420;
        aScene.burundi.labelY = aScene.burundi.y + 20;
        aScene.burundi.hasLine = true;
        aScene.burundi.lineX = aScene.burundi.x;
        aScene.burundi.lineY = aScene.burundi.y + 10;
        aScene.senegal.labelX = aScene.gambia.x - 140;
        aScene.senegal.labelY = aScene.gambia.y - 195;
        aScene.senegal.hasLine = true;
        aScene.senegal.lineX = aScene.senegal.x - 10;
        aScene.senegal.lineY = aScene.senegal.y - 10;

        aScene.gambia.labelX = aScene.gambia.x - 90;
        aScene.gambia.labelY = aScene.gambia.y;
        aScene.gambia.hasLine = true;
        aScene.gambia.lineX = aScene.gambia.x;
        aScene.gambia.lineY = aScene.gambia.y;
        aScene.guineaBissau.labelX = aScene.guineaBissau.x - 80;
        aScene.guineaBissau.labelY = aScene.guineaBissau.y - 1;
        aScene.guineaBissau.hasLine = true;
        aScene.guineaBissau.lineX = aScene.guineaBissau.x + 10;
        aScene.guineaBissau.lineY = aScene.guineaBissau.y;
        aScene.guinea.labelX = aScene.guinea.x - 110;
        aScene.guinea.labelY = aScene.guinea.y - 2;
        aScene.guinea.hasLine = true;
        aScene.guinea.lineX = aScene.guinea.x - 20;
        aScene.guinea.lineY = aScene.guinea.y - 20;
        aScene.sierraLeone.labelX = aScene.sierraLeone.x - 90;
        aScene.sierraLeone.labelY = aScene.sierraLeone.y + 20;
        aScene.sierraLeone.hasLine = true;
        aScene.sierraLeone.lineX = aScene.sierraLeone.x;
        aScene.sierraLeone.lineY = aScene.sierraLeone.y + 10;

        aScene.liberia.labelX = aScene.liberia.x - 40;
        aScene.liberia.labelY = aScene.liberia.y + 30;
        aScene.liberia.hasLine = true;
        aScene.liberia.lineX = aScene.liberia.x;
        aScene.liberia.lineY = aScene.liberia.y + 15;

        aScene.ivoryCoast.labelX = aScene.ivoryCoast.x - 40;
        aScene.ivoryCoast.labelY = aScene.ivoryCoast.y + 130;
        aScene.ivoryCoast.hasLine = true;
        aScene.ivoryCoast.lineX = aScene.ivoryCoast.x;
        aScene.ivoryCoast.lineY = aScene.ivoryCoast.y + 75;
        aScene.ghana.labelX = aScene.ghana.x - 75;
        aScene.ghana.labelY = aScene.ghana.y + 200;
        aScene.ghana.hasLine = true;
        aScene.ghana.lineX = aScene.ghana.x;
        aScene.ghana.lineY = aScene.ghana.y;
        aScene.togo.labelX = aScene.togo.x - 55;
        aScene.togo.labelY = aScene.togo.y + 275;
        aScene.togo.hasLine = true;
        aScene.togo.lineX = aScene.togo.x + 10;
        aScene.togo.lineY = aScene.togo.y + 30;
        aScene.benin.labelX = aScene.benin.x - 55;
        aScene.benin.labelY = aScene.benin.y + 355;
        aScene.benin.hasLine = true;
        aScene.benin.lineX = aScene.benin.x;
        aScene.benin.lineY = aScene.benin.y + 30;
        aScene.saoTomeAndPrincipe.labelX = aScene.saoTomeAndPrincipe.x - 107;
        aScene.saoTomeAndPrincipe.labelY = aScene.saoTomeAndPrincipe.y + 170;
        aScene.saoTomeAndPrincipe.hasLine = true;
        aScene.saoTomeAndPrincipe.lineX = aScene.saoTomeAndPrincipe.x - 17;
        aScene.saoTomeAndPrincipe.lineY = aScene.saoTomeAndPrincipe.y + 15;
        aScene.equatorialGuinea.labelX = aScene.equatorialGuinea.x - 165;
        aScene.equatorialGuinea.labelY = aScene.equatorialGuinea.y + 300;
        aScene.equatorialGuinea.hasLine = true;
        aScene.equatorialGuinea.lineX = aScene.equatorialGuinea.x + 10;
        aScene.equatorialGuinea.lineY = aScene.equatorialGuinea.y + 15;

        aScene.gabon.labelX = aScene.gabon.x - 165;
        aScene.gabon.labelY = aScene.gabon.y + 290;
        aScene.gabon.hasLine = true;
        aScene.gabon.lineX = aScene.gabon.x + 10;
        aScene.gabon.lineY = aScene.gabon.y + 5;

        aScene.congo.labelX = aScene.congo.x - 175;
        aScene.congo.labelY = aScene.congo.y + 355;
        aScene.congo.hasLine = true;
        aScene.congo.lineX = aScene.congo.x + 10;
        aScene.congo.lineY = aScene.congo.y + 55;

        // names
        aScene.southSudan.name = countriesLabels.southSudan;
        aScene.comoros.name = countriesLabels.comoros;
        aScene.madagascar.name = countriesLabels.madagascar;
        aScene.mauritius.name = countriesLabels.mauritius;
        aScene.seychelles.name = countriesLabels.seychelles;
        aScene.capeVerde.name = countriesLabels.capeVerde;
        aScene.saoTomeAndPrincipe.name = countriesLabels.saoTomeAndPrincipe;

        aScene.algeria.name = countriesLabels.algeria;
        aScene.angola.name = countriesLabels.angola;
        aScene.benin.name = countriesLabels.benin;
        aScene.botswana.name = countriesLabels.botswana;
        aScene.burkinaFaso.name = countriesLabels.burkinaFaso;
        aScene.burundi.name = countriesLabels.burundi;
        aScene.cameroon.name = countriesLabels.cameroon;
        aScene.car.name = countriesLabels.car;
        aScene.chad.name = countriesLabels.chad;
        aScene.congo.name = countriesLabels.congo;
        aScene.djibouti.name = countriesLabels.djibouti;
        aScene.drCongo.name = countriesLabels.drCongo;
        aScene.egypt.name = countriesLabels.egypt;
        aScene.equatorialGuinea.name = countriesLabels.equatorialGuinea;
        aScene.eritrea.name = countriesLabels.eritrea;
        aScene.eswatini.name = countriesLabels.eswatini;
        aScene.ethiopia.name = countriesLabels.ethiopia;
        aScene.gabon.name = countriesLabels.gabon;
        aScene.gambia.name = countriesLabels.gambia;
        aScene.ghana.name = countriesLabels.ghana;
        aScene.guinea.name = countriesLabels.guinea;
        aScene.guineaBissau.name = countriesLabels.guineaBissau;
        aScene.ivoryCoast.name = countriesLabels.ivoryCoast;
        aScene.kenya.name = countriesLabels.kenya;
        aScene.lesotho.name = countriesLabels.lesotho;
        aScene.liberia.name = countriesLabels.liberia;
        aScene.libya.name = countriesLabels.libya;
        aScene.malawi.name = countriesLabels.malawi;
        aScene.mali.name = countriesLabels.mali;
        aScene.mauritania.name = countriesLabels.mauritania;
        aScene.morocco.name = countriesLabels.morocco;
        aScene.mozambique.name = countriesLabels.mozambique;
        aScene.namibia.name = countriesLabels.namibia;
        aScene.niger.name = countriesLabels.niger;
        aScene.nigeria.name = countriesLabels.nigeria;
        aScene.rwanda.name = countriesLabels.rwanda;
        aScene.senegal.name = countriesLabels.senegal;
        aScene.sierraLeone.name = countriesLabels.sierraLeone;
        aScene.somalia.name = countriesLabels.somalia;
        aScene.southAfrica.name = countriesLabels.southAfrica;
        aScene.sudan.name = countriesLabels.sudan;
        aScene.tanzania.name = countriesLabels.tanzania;
        aScene.togo.name = countriesLabels.togo;
        aScene.tunisia.name = countriesLabels.tunisia;
        aScene.uganda.name = countriesLabels.uganda;
        aScene.zambia.name = countriesLabels.zambia;
        aScene.zimbabwe.name = countriesLabels.zimbabwe;

        // create container and put countries into it
        aScene.africaContainer = aScene.add.container(0, 0, [aScene.comoros, aScene.madagascar, aScene.mauritius, aScene.seychelles, aScene.capeVerde, aScene.southSudan, aScene.ethiopia, aScene.eritrea, aScene.sudan, aScene.somalia, aScene.kenya, aScene.djibouti, aScene.tanzania, aScene.uganda, aScene.burundi, aScene.rwanda, aScene.mozambique, aScene.zambia, aScene.malawi, aScene.zimbabwe, aScene.southAfrica, aScene.namibia, aScene.botswana, aScene.lesotho, aScene.eswatini, aScene.drCongo, aScene.angola, aScene.car, aScene.gabon, aScene.congo, aScene.chad, aScene.niger, aScene.nigeria, aScene.cameroon, aScene.saoTomeAndPrincipe, aScene.equatorialGuinea, aScene.ghana, aScene.benin, aScene.togo, aScene.algeria, aScene.mali, aScene.burkinaFaso, aScene.mauritania, aScene.senegal, aScene.guinea, aScene.guineaBissau, aScene.gambia, aScene.sierraLeone, aScene.ivoryCoast, aScene.liberia, aScene.morocco, aScene.libya, aScene.tunisia, aScene.egypt]);
        
        aScene.africaContainer.setSize(width, height);
        aScene.africaContainer.x = 0;
        aScene.africaContainer.y = 0;     
     }
}
