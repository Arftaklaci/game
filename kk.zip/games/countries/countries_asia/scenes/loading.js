class Loading extends Phaser.Scene
{    
    constructor()
    {
        super({
            
            key   : 'loading',
            pack  : 
            {
                files : 
                [
                    // pre-preload these images
                    { type: 'image', key: 'preloader1', url: '/games/countries/countries_asia/img/preloader1.png' },
                    { type: 'image', key: 'preloader2', url: '/games/countries/countries_asia/img/preloader2.png' },
                    { type: 'image', key: 'btnPlay', url: '/games/countries/countries_asia/img/btnPlay.png' },
                ] 
            }
        })
    }
    
    setPreloadSprite (sprite) 
    {
		this.preloadSprite = { sprite: sprite, width: sprite.width, height: sprite.height }
		sprite.visible = true
		// set callback for loading progress updates
		this.load.on('progress', this.onProgress, this);
	}
	
	onProgress (value) {
		if (this.preloadSprite) {
			// calculate width based on value (0.0 .. 1.0)
            let w = Math.floor(this.preloadSprite.width * value);
			// set width of sprite			
			this.preloadSprite.sprite.frame.width = w;
            this.preloadSprite.sprite.frame.cutWidth = w;
			// update screen
            this.preloadSprite.sprite.frame.updateUVs();
            // adjust positions while loading
            this.setPositions();
		}
    }
    
    preload(){

        // load custom fonts (extra bold loaded in index.html)
        this.font1 = this.add.text(0, 0, 'custom font', {
            fontFamily: "regular", fontSize: 16, color: '#000000'
        });
        this.font1.setVisible(false);
        this.font3 = this.add.text(0, 0, 'custom font', {
            fontFamily: "semiBold", fontSize: 16, color: '#000000'
        });
        this.font3.setVisible(false);
        this.font2 = this.add.text(0, 0, 'custom font', {
            fontFamily: "bold", fontSize: 16, color: '#000000'
        });
        this.font2.setVisible(false);

        // init width and height
        width = this.cameras.main.width;
        height = this.cameras.main.height;

        // display loading bar
		this.preloader1 = this.add.sprite(width/2, height/2 + 140, "preloader1");
		this.preloader2 = this.add.sprite(width/2, height/2 + 140, "preloader2");
        this.setPreloadSprite(this.preloader2);
        // play button
        this.btnPlay = this.add.image(width/2, height/2 + 140, "btnPlay");
        this.btnPlay.setVisible(false);

        // display text
        this.txtWebsite = this.add.text(width/2, height/2 - 150, labels.website, { fontFamily: "extraBold", fontSize: 60, color: '#000000' });
        this.txtTitle = this.add.text(width/2, height/2 - 80, labels.title, { fontFamily: "extraBold", fontSize: 55, color: '#FFFFFF' });
        this.txtTitle.setOrigin(0.5, 0.5);
        this.txtWebsite.setOrigin(0.5, 0.5);
        
        // plugins
        this.url = '/games/countries/countries_asia/plugins/pinchplugin.min.js';
        this.load.plugin('rexpinchplugin', this.url, true);
        this.url2 = '/games/countries/countries_asia/plugins/mousewheelplugin.min.js';
        this.load.plugin('rexmousewheeltoupdownplugin', this.url2, true);
        this.url3 = '/games/countries/countries_asia/plugins/rexscrollerplugin.min.js';
        this.load.plugin('rexscrollerplugin', this.url3, true);

        // animation
        this.load.spritesheet('butterfly', '/games/countries/countries_asia/img/butterfly.png', { frameWidth: 233, frameHeight: 374 });
        
        // asia countries
        this.load.image('extraEgypt', '/games/countries/countries_asia/img/extraEgypt.png');
        this.load.image('extraKashmir', '/games/countries/countries_asia/img/extraKashmir.png');
        this.load.image('extraNewGuinea', '/games/countries/countries_asia/img/extraNewGuinea.png');
        this.load.image('afghanistan', '/games/countries/countries_asia/img/afghanistan.png');
        this.load.image('armenia', '/games/countries/countries_asia/img/armenia.png');
        this.load.image('azerbaijan', '/games/countries/countries_asia/img/azerbaijan.png');
        this.load.image('bahrain', '/games/countries/countries_asia/img/bahrain.png');
        this.load.image('bangladesh', '/games/countries/countries_asia/img/bangladesh.png');
        this.load.image('bhutan', '/games/countries/countries_asia/img/bhutan.png');
        this.load.image('brunei', '/games/countries/countries_asia/img/brunei.png');
        this.load.image('cambodia', '/games/countries/countries_asia/img/cambodia.png');
        this.load.image('china', '/games/countries/countries_asia/img/china.png');
        this.load.image('eastTimor', '/games/countries/countries_asia/img/eastTimor.png');
        this.load.image('georgia', '/games/countries/countries_asia/img/georgia.png');
        this.load.image('india', '/games/countries/countries_asia/img/india.png');
        this.load.image('indonesia', '/games/countries/countries_asia/img/indonesia.png');
        this.load.image('iran', '/games/countries/countries_asia/img/iran.png');
        this.load.image('iraq', '/games/countries/countries_asia/img/iraq.png');
        this.load.image('israel', '/games/countries/countries_asia/img/israel.png');
        this.load.image('japan', '/games/countries/countries_asia/img/japan.png');
        this.load.image('jordan', '/games/countries/countries_asia/img/jordan.png');
        this.load.image('kazakhstan', '/games/countries/countries_asia/img/kazakhstan.png');
        this.load.image('kuwait', '/games/countries/countries_asia/img/kuwait.png');
        this.load.image('kyrgyzstan', '/games/countries/countries_asia/img/kyrgyzstan.png');
        this.load.image('laos', '/games/countries/countries_asia/img/laos.png');
        this.load.image('lebanon', '/games/countries/countries_asia/img/lebanon.png');
        this.load.image('malaysia', '/games/countries/countries_asia/img/malaysia.png');
        this.load.image('maldives', '/games/countries/countries_asia/img/maldives.png');
        this.load.image('mongolia', '/games/countries/countries_asia/img/mongolia.png');
        this.load.image('myanmar', '/games/countries/countries_asia/img/myanmar.png');
        this.load.image('nepal', '/games/countries/countries_asia/img/nepal.png');
        this.load.image('northKorea', '/games/countries/countries_asia/img/northKorea.png');
        this.load.image('oman', '/games/countries/countries_asia/img/oman.png');
        this.load.image('pakistan', '/games/countries/countries_asia/img/pakistan.png');
        this.load.image('palestine', '/games/countries/countries_asia/img/palestine.png');
        this.load.image('philippines', '/games/countries/countries_asia/img/philippines.png');
        this.load.image('qatar', '/games/countries/countries_asia/img/qatar.png');
        this.load.image('russia', '/games/countries/countries_asia/img/russia.png');
        this.load.image('saudiArabia', '/games/countries/countries_asia/img/saudiArabia.png');
        this.load.image('southKorea', '/games/countries/countries_asia/img/southKorea.png');
        this.load.image('singapore', '/games/countries/countries_asia/img/singapore.png');
        this.load.image('sriLanka', '/games/countries/countries_asia/img/sriLanka.png');
        this.load.image('syria', '/games/countries/countries_asia/img/syria.png');
        this.load.image('taiwan', '/games/countries/countries_asia/img/taiwan.png');
        this.load.image('thailand', '/games/countries/countries_asia/img/thailand.png');
        this.load.image('tajikistan', '/games/countries/countries_asia/img/tajikistan.png');
        this.load.image('turkmenistan', '/games/countries/countries_asia/img/turkmenistan.png');
        this.load.image('turkey', '/games/countries/countries_asia/img/turkey.png');
        this.load.image('uae', '/games/countries/countries_asia/img/uae.png');
        this.load.image('uzbekistan', '/games/countries/countries_asia/img/uzbekistan.png');
        this.load.image('vietnam', '/games/countries/countries_asia/img/vietnam.png');
        this.load.image('yemen', '/games/countries/countries_asia/img/yemen.png');

        // buttons
        this.load.spritesheet('button', '/games/countries/countries_asia/img/button.png', {frameWidth: 420, frameHeight: 62});
        this.load.image('btnPlay', '/games/countries/countries_asia/img/btnPlay.png');
        this.load.image('buttonBack', '/games/countries/countries_asia/img/buttonBack.png');
        this.load.image('buttonBackBlack', '/games/countries/countries_asia/img/buttonBackBlack.png');
        this.load.image('buttonStart', '/games/countries/countries_asia/img/buttonStart.png');
        this.load.image('buttonMap', '/games/countries/countries_asia/img/buttonMap.png');
        this.load.image('buttonMapWhite', '/games/countries/countries_asia/img/buttonMapWhite.png');
        this.load.image('buttonOptions', '/games/countries/countries_asia/img/buttonOptions.png');
        this.load.spritesheet('buttonToggle', '/games/countries/countries_asia/img/buttonToggle.png', {frameWidth: 89, frameHeight: 52 });
        
        // images
		this.load.spritesheet('bgQuestion', '/games/countries/countries_asia/img/bgQuestion.png', { frameWidth: 500, frameHeight: 65 });
		this.load.image('bgWhite', '/games/countries/countries_asia/img/bgWhite.jpg');
		this.load.image('rectangle', '/games/countries/countries_asia/img/rectangle.jpg');
		this.load.image('map', '/games/countries/countries_asia/img/map.png');
		this.load.image('circle', '/games/countries/countries_asia/img/circle.png');
		this.load.image('circleRed', '/games/countries/countries_asia/img/circleRed.png');
		this.load.image('circleGreen', '/games/countries/countries_asia/img/circleGreen.png');
		this.load.image('circleYellow', '/games/countries/countries_asia/img/circleYellow.png');
		this.load.image('lineBrunei', '/games/countries/countries_asia/img/lineBrunei.png');
		this.load.image('lineArmenia', '/games/countries/countries_asia/img/lineArmenia.png');
		this.load.image('lineAzerbaijan', '/games/countries/countries_asia/img/lineAzerbaijan.png');
		this.load.image('lineQatar', '/games/countries/countries_asia/img/lineQatar.png');
		this.load.image('lineBahrain', '/games/countries/countries_asia/img/lineBahrain.png');
		this.load.image('lineIsrael', '/games/countries/countries_asia/img/lineIsrael.png');
		this.load.image('lineJordan', '/games/countries/countries_asia/img/lineJordan.png');
		this.load.image('lineLebanon', '/games/countries/countries_asia/img/lineLebanon.png');
		this.load.image('mouseOverMicrostate', '/games/countries/countries_asia/img/mouseOverMicrostate.png');
		this.load.image('underline', '/games/countries/countries_asia/img/underline.png');
        // sounds
		this.load.audio('wrongSound', ['/games/countries/countries_asia/audio/wrongSound.mp3', '/games/countries/countries_asia/audio/wrongSound.ogg']);
		this.load.audio('correctSound', ['/games/countries/countries_asia/audio/correctSound.mp3', '/games/countries/countries_asia/audio/correctSound.ogg']);
		this.load.audio('gameOverSound', ['/games/countries/countries_asia/audio/gameOverSound.mp3', '/games/countries/countries_asia/audio/gameOverSound.ogg']);
    }
    
    create() {    

        // play button
        this.btnPlay.setVisible(true);
        this.btnPlay.setInteractive({useHandCursor: true})
        this.btnPlay.on("pointerup", () => { 
            this.scene.start("menu");
        }, this);

        // remove preloader
        this.preloader1.destroy();
        this.preloader2.destroy();
        
        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on("resize", (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.preloader1.setPosition(width/2, height/2 + 170);
        this.preloader2.setPosition(width/2, height/2 + 170);
        this.btnPlay.setPosition(width/2, height/2 + 170);
        this.txtTitle.setPosition(width/2, height/2 - 80);
        this.txtWebsite.setPosition(width/2, height/2 - 150);
    }
}