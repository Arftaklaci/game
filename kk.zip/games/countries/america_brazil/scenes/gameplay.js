"use strict"
var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        });
    }
    
    create() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;
        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;
       camera.zoom = .5;
       camera.scrollY = -20;
        // min max zoom
        this.minZoom = .5;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.6;
        }
        else {
            this.maxZoom = 1.9;
        }
        // display countries in this scene
        this.displayMap(this);
        // get countries (sprites) array from the container
        this.countriesArray = this.mapContainer.getAll();
        // for each subject (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {
            /* development phase - enable drag to position countries
            this.countriesArray[i].setInteractive()
            this.input.setDraggable(this.countriesArray[i]);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {
                gameObject.x = dragX;
                gameObject.y = dragY;
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });
            */
            
            let subject = this.countriesArray[i];
            // make countries sprites interactive
            subject.setInteractive({ 
                useHandCursor: true,             
                pixelPerfect: true,
                alphaTolerance: 255
             });
             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over subject
                subject.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                       subject.setTintFill(0xFFFFFF);
                    }
                },this);
                subject.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        subject.clearTint();
                    }
                },this);
            }
            subject.on('pointerdown', () => {
                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });
            subject.on('pointerup', () => {
                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);
                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    subject.xPos = camera.x;
                    subject.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false) {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === subject.name) {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this subject
                            subject.disableInteractive();
                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }
                            // create the subject label
                            this.showLabels(subject);
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // else don't tap, drag the map
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();
        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false) {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();
                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip, ui.buttonSound],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                let dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {
                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        let drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }
                }).on('pinch', dragScale => {
                    let scaleFactor = dragScale.scaleFactor;
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                }, this);
                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }
        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2 + 100, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 70, align: "center", color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2 + 100, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 70, align: "center", color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });
        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                camera.zoom *= 0.9;
            }
        }
        // limit zoom
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.mapContainer.setSize(width, height);
        this.mapContainer.x = 0;
        this.mapContainer.y = 0;

        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2 + 100, height/2);
        }
    }

    getQuestion() {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;
        this.questionsArray.shift();

        if (ui.questionText.text === subjects.newfoundland) {
            ui.questionText.setFontSize(26);
        }
        else {
            ui.questionText.setFontSize(34);
        }

        // tween
        this.tweens.add({
           targets: [ui.questionText],
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;
        // play sound
        this.gameOverSound.play();
        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        ui.buttonSound.destroy();
        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {
        // tween camera
        if (camera.zoom > this.minZoom) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: this.minZoom,
                x: 0, 
                y: 0,
                duration: 1500,
                onComplete: () => {
                    
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }
        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: -20,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showLabels(subject) {
        // create white rectangle
        subject.rect = this.add.sprite(subject.x, subject.y, "rectangle");
        // subject name
        subject.txt = this.add.text(subject.x, subject.y, subject.name, { fontFamily: "bold", fontSize: 28, align: "center", color: '#000000' });
        subject.txt.setOrigin(.5,.5);
        // position text
        if (subject.labelX) {
            subject.txt.x = subject.labelX;
            subject.txt.y = subject.labelY;
            subject.rect.x = subject.labelX;
            subject.rect.y = subject.labelY;
        }
        subject.rect.displayWidth = subject.txt.width + 4;
        subject.rect.displayHeight = subject.txt.height + 2;

        if (subject.hasLine) {
            let line;
            if (subject.name === subjects.sergipe) {
                line = this.add.image(subject.lineX, subject.lineY, "texture", "sergipeLine.png").setOrigin(0,0);
            }
            else if (subject.name === subjects.federalDistrict) {
                line = this.add.image(subject.lineX, subject.lineY, "texture", "federalDistrictLine.png").setOrigin(0,0.5);
            }
            else if (subject.name === subjects.alagoas) {
                line = this.add.image(subject.lineX, subject.lineY, "texture", "alagoasLine.png").setOrigin(0,0);
            }
            else if (subject.name === subjects.pernambuco) {
                line = this.add.image(subject.lineX, subject.lineY, "texture", "pernambucoLine.png").setOrigin(0,0);
            }
            else if (subject.name === subjects.paraiba) {
                line = this.add.image(subject.lineX, subject.lineY, "texture", "paraibaLine.png").setOrigin(0,0.5);
            }
            else if (subject.name === subjects.rioGrandeDoNorte) {
                line = this.add.image(subject.lineX, subject.lineY, "texture", "rioGrandeDoNorteLine.png").setOrigin(0,0.5);
            }

            this.mapContainer.add(line);
        }
    }

    displayMap(aScene) {
        this.map = this.add.image(width/2, height/2, 'map');
        this.map.alpha = 0;

        // interactive sprites
        aScene.tocantins = aScene.add.sprite(width/2 + 230.5, height/2 - 189.5, "texture", "tocantins.png");
        aScene.maranhao = aScene.add.sprite(width/2 + 340, height/2 - 331, "texture", "maranhao.png");
        aScene.piaui = aScene.add.sprite(width/2 + 418.5, height/2 - 285.5, "texture", "piaui.png");
        aScene.bahia = aScene.add.sprite(width/2 + 463.5, height/2 - 30.5, "texture", "bahia.png");
        aScene.ceara = aScene.add.sprite(width/2 + 562, height/2 - 343.5, "texture", "ceara.png");
        aScene.para = aScene.add.sprite(width/2 + 71.5, height/2 - 408.5, "texture", "para.png");
        aScene.matoGrosso = aScene.add.sprite(width/2 - 57.5, height/2 - 59, "texture", "matoGrosso.png");
        aScene.goias = aScene.add.sprite(width/2 + 180, height/2 + 65.5, "texture", "goias.png");
        aScene.federalDistrict = aScene.add.sprite(width/2 + 246.5, height/2 + 59.5, "texture", "federalDistrict.png");
        aScene.minasGerais = aScene.add.sprite(width/2 + 334, height/2 + 166.5, "texture", "minasGerais.png");
        aScene.espiritoSanto = aScene.add.sprite(width/2 + 508, height/2 + 206, "texture", "espiritoSanto.png");
        aScene.saoPaulo = aScene.add.sprite(width/2 + 215.5, height/2 + 319, "texture", "saoPaulo.png");
        aScene.rioDeJaneiro = aScene.add.sprite(width/2 + 429, height/2 + 301, "texture", "rioDeJaneiro.png");
        aScene.matoGrossoDoSul = aScene.add.sprite(width/2 - 5.5, height/2 + 244.5, "texture", "matoGrossoDoSul.png");
        aScene.parana = aScene.add.sprite(width/2 + 115, height/2 + 398.5, "texture", "parana.png");
        aScene.santaCatarina = aScene.add.sprite(width/2 + 124, height/2 + 514, "texture", "santaCatarina.png");
        aScene.rioGrandeDoSul = aScene.add.sprite(width/2 + 27.5, height/2 + 620, "texture", "rioGrandeDoSul.png");
        aScene.amazonas = aScene.add.sprite(width/2 - 394, height/2 - 402, "texture", "amazonas.png");
        aScene.rondonia = aScene.add.sprite(width/2 - 332, height/2 - 131, "texture", "rondonia.png");
        aScene.acre = aScene.add.sprite(width/2 - 594.5, height/2 - 197, "texture", "acre.png");
        aScene.roraima = aScene.add.sprite(width/2 - 278, height/2 - 617.5, "texture", "roraima.png");
        aScene.amapa = aScene.add.sprite(width/2 + 75.5, height/2 - 609, "texture", "amapa.png");
        aScene.pernambuco = aScene.add.sprite(width/2 + 608.5, height/2 - 225.5, "texture", "pernambuco.png");
        aScene.paraiba = aScene.add.sprite(width/2 + 657.5, height/2 - 272, "texture", "paraiba.png");
        aScene.rioGrandeDoNorte = aScene.add.sprite(width/2 + 658, height/2 - 320, "texture", "rioGrandeDoNorte.png");
        aScene.alagoas = aScene.add.sprite(width/2 + 660, height/2 - 176, "texture", "alagoas.png");
        aScene.sergipe = aScene.add.sprite(width/2 + 637, height/2 - 141.5, "texture", "sergipe.png");

        // reposition labels
        aScene.tocantins.labelX = aScene.tocantins.x - 5;
        aScene.tocantins.labelY = aScene.tocantins.y + 40;
        aScene.roraima.labelX = aScene.roraima.x + 10;
        aScene.roraima.labelY = aScene.roraima.y - 45;
        aScene.amapa.labelX = aScene.amapa.x + 10;
        aScene.amapa.labelY = aScene.amapa.y - 20;
        aScene.maranhao.labelX = aScene.maranhao.x;
        aScene.maranhao.labelY = aScene.maranhao.y - 20;
        aScene.piaui.labelX = aScene.piaui.x + 10;
        aScene.piaui.labelY = aScene.piaui.y + 40;
        aScene.bahia.labelX = aScene.bahia.x;
        aScene.bahia.labelY = aScene.bahia.y - 25;
        aScene.matoGrossoDoSul.labelX = aScene.matoGrossoDoSul.x - 50;
        aScene.matoGrossoDoSul.labelY = aScene.matoGrossoDoSul.y;
        aScene.saoPaulo.labelX = aScene.saoPaulo.x - 20;
        aScene.saoPaulo.labelY = aScene.saoPaulo.y - 25;
        aScene.santaCatarina.labelX = aScene.santaCatarina.x + 20;
        aScene.santaCatarina.labelY = aScene.santaCatarina.y - 20;
        aScene.rioDeJaneiro.labelX = aScene.rioDeJaneiro.x + 100;
        aScene.rioDeJaneiro.labelY = aScene.rioDeJaneiro.y + 15;
        aScene.minasGerais.labelX = aScene.minasGerais.x + 40;
        aScene.minasGerais.labelY = aScene.minasGerais.y;
        aScene.espiritoSanto.labelX = aScene.espiritoSanto.x + 100;
        aScene.espiritoSanto.labelY = aScene.espiritoSanto.y;
        aScene.federalDistrict.labelX = aScene.federalDistrict.x + 480;
        aScene.federalDistrict.labelY = aScene.federalDistrict.y;

        aScene.rioGrandeDoNorte.labelX = aScene.rioGrandeDoNorte.x + 230;
        aScene.rioGrandeDoNorte.labelY = aScene.rioGrandeDoNorte.y;
        aScene.paraiba.labelX = aScene.paraiba.x + 150;
        aScene.paraiba.labelY = aScene.paraiba.y;
        aScene.pernambuco.labelX = aScene.pernambuco.x + 235;
        aScene.pernambuco.labelY = aScene.pernambuco.y;
        aScene.alagoas.labelX = aScene.alagoas.x + 120;
        aScene.alagoas.labelY = aScene.alagoas.y;
        aScene.sergipe.labelX = aScene.sergipe.x + 100;
        aScene.sergipe.labelY = aScene.sergipe.y + 15;

        // lines
        aScene.rioGrandeDoNorte.hasLine = true;
        aScene.paraiba.hasLine = true;
        aScene.pernambuco.hasLine = true;
        aScene.alagoas.hasLine = true;
        aScene.sergipe.hasLine = true;
        aScene.federalDistrict.hasLine = true;

        aScene.rioGrandeDoNorte.lineX = aScene.rioGrandeDoNorte.x + 20;
        aScene.rioGrandeDoNorte.lineY = aScene.rioGrandeDoNorte.y;
        aScene.paraiba.lineX = aScene.paraiba.x + 35;
        aScene.paraiba.lineY = aScene.paraiba.y;
        aScene.pernambuco.lineX = aScene.pernambuco.x + 80;
        aScene.pernambuco.lineY = aScene.pernambuco.y - 10;
        aScene.alagoas.lineX = aScene.alagoas.x;
        aScene.alagoas.lineY = aScene.alagoas.y - 13;
        aScene.sergipe.lineX = aScene.sergipe.x - 10;
        aScene.sergipe.lineY = aScene.sergipe.y - 10;
        aScene.federalDistrict.lineX = aScene.federalDistrict.x - 10;
        aScene.federalDistrict.lineY = aScene.federalDistrict.y;

        // names
        aScene.tocantins.name = subjects.tocantins;
        aScene.maranhao.name = subjects.maranhao;
        aScene.piaui.name = subjects.piaui;
        aScene.bahia.name = subjects.bahia;
        aScene.ceara.name = subjects.ceara;
        aScene.para.name = subjects.para;
        aScene.matoGrosso.name = subjects.matoGrosso;
        aScene.goias.name = subjects.goias;
        aScene.federalDistrict.name = subjects.federalDistrict;
        aScene.minasGerais.name = subjects.minasGerais;
        aScene.espiritoSanto.name = subjects.espiritoSanto;
        aScene.saoPaulo.name = subjects.saoPaulo;
        aScene.rioDeJaneiro.name = subjects.rioDeJaneiro;
        aScene.matoGrossoDoSul.name = subjects.matoGrossoDoSul;
        aScene.parana.name = subjects.parana;
        aScene.santaCatarina.name = subjects.santaCatarina;
        aScene.rioGrandeDoSul.name = subjects.rioGrandeDoSul;
        aScene.amazonas.name = subjects.amazonas;
        aScene.rondonia.name = subjects.rondonia;
        aScene.acre.name = subjects.acre;
        aScene.roraima.name = subjects.roraima;
        aScene.amapa.name = subjects.amapa;
        aScene.pernambuco.name = subjects.pernambuco;
        aScene.paraiba.name = subjects.paraiba;
        aScene.rioGrandeDoNorte.name = subjects.rioGrandeDoNorte;
        aScene.alagoas.name = subjects.alagoas;
        aScene.sergipe.name = subjects.sergipe;

        // create container and put countries into it
        aScene.mapContainer = aScene.add.container(0, 0, [ aScene.federalDistrict, aScene.matoGrossoDoSul, aScene.maranhao, aScene.piaui, aScene.bahia, aScene.ceara, aScene.tocantins, aScene.para, aScene.matoGrosso, aScene.goias,  aScene.minasGerais, aScene.espiritoSanto, aScene.saoPaulo, aScene.rioDeJaneiro, aScene.parana, aScene.santaCatarina,  aScene.amazonas, aScene.rondonia, aScene.acre, aScene.roraima, aScene.amapa, aScene.pernambuco, aScene.paraiba, aScene.rioGrandeDoNorte, aScene.alagoas, aScene.sergipe, aScene.rioGrandeDoSul ]);

        aScene.mapContainer.setSize(width, height);
        aScene.mapContainer.x = 0;
        aScene.mapContainer.y = 0;
     }
}