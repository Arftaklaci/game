var game = new Phaser.Game(500, 800, Phaser.Canvas, null, null, true)

game.global =
{
	orientated    : false,
    instructions  : true,
}

// edit below 
collator = "en"
website_url = "https://world-geography-games.com/europe.html";
website_label = "World Geography Games"
title_label = "Capitals of Europe"
title_oneline = "Capitals of Europe"
play_again_label = "Play again"
stop_label = "Stop"
score_label = "score: "
final_score = "Score"
next_label = "Next"
out_of_label = "out of"
play_label = "play"
options_label = "options"
select_atleast_label = "Select at least 5 capitals"
back_label = "back"
sound_label = "SOUND"
number_of_flags_label = "NUMBER OF CAPITALS"
flags_label = "CAPITALS"
select_label = "select"
library_label = "library"

northern_label = "Northern Europe"
western_label = "Western Europe"
central_and_eastern_label = "Central and Eastern Europe"
southern_label = "Southern Europe"
microstates_label = "Microstates"

countries = ["Netherlands", "Andorra", "Greece", "Serbia", "Germany", "Switzerland", "Slovakia", "Belgium", "Romania", "Hungary", "Moldova", "Denmark", "Ireland", "Finland", "Ukraine", "Portugal", "Slovenia", "United Kingdom", "Luxembourg", "Spain", "Belarus", "Monaco", "Russia", "Cyprus", "Norway", "France", "Montenegro", "Czech Republic", "Kosovo", "Iceland", "Latvia", "Italy", "San Marino", "Bosnia and Herzegovina", "North Macedonia", "Bulgaria", "Sweden", "Estonia", "Albania", "Liechtenstein", "Malta", "Vatican City", "Austria", "Lithuania", "Poland", "Croatia"]

capitals = ["Amsterdam", "Andorra la Vella", "Athens", "Belgrade", "Berlin", "Bern", "Bratislava", "Brussels", "Bucharest", "Budapest", "Chișinău", "Copenhagen", "Dublin", "Helsinki", "Kyiv", "Lisbon", "Ljubljana", "London", "Luxembourg City", "Madrid", "Minsk", "Monaco", "Moscow", "Nicosia", "Oslo", "Paris", "Podgorica", "Prague", "Priština", "Reykjavík", "Riga", "Rome", "San Marino", "Sarajevo", "Skopje", "Sofia", "Stockholm", "Tallinn", "Tirana", "Vaduz", "Valletta", "Vatican City", "Vienna", "Vilnius", "Warsaw", "Zagreb"]

// ** DO NOT EDIT BELOW!
// create new array, don't change the first one, order alphabetically
countries_alphabet = countries.slice().sort(Intl.Collator(collator).compare);

flags_used = 46;

// frames that will be used (frames represent images)
frames = [];
for (var f = 0; f < flags_used; f++)
{
    frames.push(f);
}

// always contains all frames, get random flags from this array
all_frames = frames.slice();

northern_europe = [11,13,24,29,30,36,37,43];
western_europe = [1,0,4,5,7,12,17,18,21,25,39,42];
central_and_eastern_europe = [3,6,8,9,10,14,16,20,22, 26,27,28,33,34,35,45,44,38];
southern_europe = [2,15,19,23,31,32,40,41];
microstates = [1,21,32,39,41];

// toggle buttons used for regions, frame 0 or 1
northern_btn = 0;
southern_btn = 0;
central_btn = 0;
western_btn = 0;
microstates_btn = 0;

// toggle buttons used for countries, frame 0 or 1
toggle_button_frames = [];

for (var i = 0; i < frames.length; i++) {
    // by default all buttons are on (frame 0)
    toggle_button_frames.push(0);
}

// sound toggle button
sound_frame = 0;
// selecting regions or countries in options (back button depends on this)
selecting_regions = true;

// all capitals
have_lookalikes = [];
for (let i = 0; i < 46; i++) {
    have_lookalikes.push(i);
}

// capitals from the same region
lookalikes = [
[4,7,18],[19,41],[38,34],[33,45,26],[42,5],[30,25],[27,44],[25,0],[35,10,9],[27,6],[14,8],[24,36],[17],[24,26],[44,22],[19,1],[9,45,42],[12],[0,7],[15],[44,30],[25,32],[20,14],[2,1],[36,13],[7,19],[33,3],[6,40],[26,38,34],[24,11],[43,37],[32,41],[31,21],[45,16],[28,38],[2,34],[13,24],[13,30],[34,28],[5,42],[23,31],[40,31],[6,27],[20,30],[27,14],[33,16]
];
// game states
game.state.add('boot', bootState);
game.state.add("Loading", loading);
game.state.add("menu", menuState);
game.state.add("options", optionsState);
game.state.add("library", libraryState);
game.state.add("level1", state1);
game.state.start("boot");