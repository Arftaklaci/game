var loading =
{
	preload: function()
	{
        // circle
        var graphics = game.add.graphics(0, 0)
        graphics.beginFill(0xffffff, 1)
        graphics.drawCircle(game.width / 2, game.height / 2, 480)

		// preloader
		preloader1 = game.add.sprite(300, 530, 						'preloader1');
		preloader1.anchor.setTo(0, 0.5);
		preloader1.x = game.width / 2 - preloader1.width / 2;

		preloader2 = game.add.sprite(300, 530, 						'preloader2');
		preloader2.anchor.setTo(0, 0.5);
		preloader2.x = game.width / 2 - preloader2.width / 2;
		game.load.setPreloadSprite(preloader2);

        // website
        toporopa = game.add.text(game.width/2, 310, website_label, {font:"33px extraBold", fill:"#000000"});
        game_title = game.add.text(game.width/2, 375,title_oneline, {font:"35px extraBold", fill:"#0099ff"});

        game_title.anchor.setTo(0.5, 0.5);
        toporopa.anchor.setTo(0.5, 0.5);

		// load buttons
        game.load.image('button_back', '/games/capitals/capitals_europe/images/button_back.png')
        game.load.image('button_area', '/games/capitals/capitals_europe/images/button_area.png')
        game.load.image('double_tap', '/games/capitals/capitals_europe/images/double_tap.png')
        game.load.image('underline', '/games/capitals/capitals_europe/images/underline.png')

        // load spritesheets
        game.load.spritesheet('capitals', '/games/capitals/capitals_europe/images/capitals.png', 381, 216)
        game.load.spritesheet('capitals-small', '/games/capitals/capitals_europe/images/capitals-small.png', 120, 68)
        game.load.spritesheet('button_toggle', '/games/capitals/capitals_europe/images/button_toggle.png', 72, 38)

        game.load.image('bg', '/games/capitals/capitals_europe/images/bg.png')
        game.load.image('bg_top', '/games/capitals/capitals_europe/images/bg_top.png')
        game.load.image('bgEurope', '/games/capitals/capitals_europe/images/bgEurope.png')
        game.load.image('flag_counter', '/games/capitals/capitals_europe/images/flag_counter.png')
        game.load.image('flag_counter_bg', '/games/capitals/capitals_europe/images/flag_counter_bg.png')
        game.load.image('button_wrong', '/games/capitals/capitals_europe/images/button_wrong.png')
        game.load.image('button_next', '/games/capitals/capitals_europe/images/button_next.png')
        game.load.image('button_start', '/games/capitals/capitals_europe/images/button_start.png')
        game.load.image('button_options', '/games/capitals/capitals_europe/images/button_options.png')
        game.load.image('button_library', '/games/capitals/capitals_europe/images/button_library.png')
        game.load.spritesheet('button_capital', '/games/capitals/capitals_europe/images/button_capital.png', 420, 63)
        game.load.spritesheet('bikes', '/games/capitals/capitals_europe/images/bikes.png', 84, 55)

        game.load.image('button_invisible', '/games/capitals/capitals_europe/images/button_invisible.png')
        game.load.image('scroll_mobile', '/games/capitals/capitals_europe/images/scroll_mobile.png')
        game.load.image('scroll_desktop', '/games/capitals/capitals_europe/images/scroll_desktop.png')
        game.load.image('question', '/games/capitals/capitals_europe/images/question.png')

		// load audio
		game.load.audio('wrong_sound', '/games/capitals/capitals_europe/audio/wrong_sound.mp3');
		game.load.audio('correct_sound', '/games/capitals/capitals_europe/audio/correct_sound.mp3');
		game.load.audio('game_over_sound', '/games/capitals/capitals_europe/audio/game_over_sound.mp3');
},
  	create: function()
	{
  		// loading done
        game.add.tween(preloader1).to({alpha: 0}, 100, "Linear", true)
        tween_preloader = game.add.tween(preloader2).to({alpha: 0}, 100, "Linear", true)
        tween_preloader.onComplete.add(function(){

            preloader1.destroy()
            preloader2.destroy()

            // create play button
            button_play = game.add.button(game.width/2, 530, 'button_play', start_game, this)
            button_play.anchor.setTo(0.5,0.5)
            button_play.alpha = 0
            game.add.tween(button_play).to({alpha: 1}, 300, "Linear", true)
        })

        // directly to main menu
        game.state.start("menu")
	}
}

function start_game() {
	game.state.start("menu")
}