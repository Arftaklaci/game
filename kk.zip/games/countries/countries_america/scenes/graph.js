"use strict"

class Graph extends Phaser.Scene {
    constructor() {
        super({
            key: "graph"
        })
    }

    create() {

        width = this.cameras.main.width;
        height = this.cameras.main.height;

        // get user interface scene (static objects)
        let gameplay = this.scene.get("gameplay");
        gameplay.displayAmerica(this);

        // use delay to avoid lag when "map" button is clicked
        let timer = this.time.delayedCall(100, () => {
            // show labels
            this.showAmericaLabels();
        },this);

        // user interface
        this.ui = this.scene.get("graphUI");
        // launch user interface 
        this.scene.launch("graphUI");
        this.scene.moveAbove("graph", "graphUI");

       // camera
       camera = this.cameras.main;
       camera.zoom = 0.25;

        // min max zoom
        this.minZoom = 0.25;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 2;
        }
        else {
            this.maxZoom = 2.5;
        }

        // enable drag and pinch to zoom
        var dragScale = this.plugins.get('rexpinchplugin').add(this);
        // center the map on the start
        camera.scrollX = 150;

        dragScale.on('drag1', dragScale => {
                var drag1Vector = dragScale.drag1Vector;
                camera.scrollX -= drag1Vector.x / camera.zoom;
                camera.scrollY -= drag1Vector.y / camera.zoom;
        }).on('pinch', dragScale => {
            var scaleFactor = dragScale.scaleFactor;
            
            // camera zoom
            camera.zoom *= scaleFactor;
        }, this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);

            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
            //this.upKeyDown = cursorKeys.up.isDown;
            //this.downKeyDown = cursorKeys.down.isDown;
        }

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on("resize", (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }
    
    update() {
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop) {
            if (this.cursorKeys.up.isDown) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown) {
                
                camera.zoom *= 0.9;
            }
        }
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    showAmericaLabels(country) {

        // get countries (sprites) array from the container
        this.countriesArray = this.americaContainer.getAll();

        for (let i = 0; i < this.countriesArray.length; i++) {

            // name of the country
            let country = this.countriesArray[i];

            // update country name below
            country.txt = this.add.text(country.x, country.y, country.name, { fontFamily: "bold", fontSize: 32, color: '#000000' });
            country.txt.setOrigin(.5,.5);
            this.americaContainer.add(country.txt);
            
            // position text
            if (country.labelX) {
                country.txt.x = country.labelX;
                country.txt.y = country.labelY;
            }

            // create a line if needed
            if (country.hasLine) {
                
                let line;
                if (country.name === countriesLabels.elSalvador) {
                    line = this.add.image(country.lineX, country.lineY, "lineSalvador");
                    line.setOrigin(1,0);
                }
                else if (country.name === countriesLabels.dominicanRepublic) {
                    line = this.add.image(country.lineX, country.lineY, "lineSalvador");
                    line.setOrigin(1,0);
                    line.scaleX = -1;
                    line.scaleY = -1;
                }
                else if (country.name === countriesLabels.saintKittsAndNevis) {
                    line = this.add.image(country.lineX, country.lineY, "lineSaintKitts");
                    line.setOrigin(0,1);
                }
                else if (country.name === countriesLabels.antiguaAndBarbuda || country.name === countriesLabels.barbados) {
                    line = this.add.image(country.lineX, country.lineY, "lineAntigua");
                    line.setOrigin(0,0.5);
                }
                else if (country.name === countriesLabels.dominica || country.name === countriesLabels.saintLucia) {
                    line = this.add.image(country.lineX, country.lineY, "lineSaintLucia");
                    line.setOrigin(0,1);
                }
                else if (country.name === countriesLabels.saintVincent || country.name === countriesLabels.grenada) {
                    line = this.add.image(country.lineX, country.lineY, "lineGrenada");
                    line.setOrigin(0,0);
                }
                else if (country.name === countriesLabels.trinidadAndTobago) {
                    line = this.add.image(country.lineX, country.lineY, "lineSalvador");
                    line.setOrigin(1,0);
                    line.scaleX = -1;
                }

                this.americaContainer.add(line);
            }
            
            // create white rectangles

            // gambia, guinea, sierra leone, liberia...
            if (country.name === countriesLabels.elSalvador) {
                
                country.rect = this.add.sprite(country.txt.x, country.txt.y, "rectangle");
                country.rect.displayWidth = country.txt.width + 2;
                country.rect.displayHeight = country.txt.height;
                // set different origin for these rectangles
                country.rect.setOrigin(1,0.5);
                country.txt.setOrigin(1,0.5);
                country.txt.x -= 1;
                this.americaContainer.add(country.rect);
            }
            else if (country.hasLine) {
                country.rect = this.add.sprite(country.txt.x, country.txt.y, "rectangle");
                country.rect.displayWidth = country.txt.width + 2;
                country.rect.displayHeight = country.txt.height;
                // set different origin for these rectangles
                country.rect.setOrigin(0,0.5);
                country.txt.setOrigin(0,0.5);
                country.txt.x += 1;
                this.americaContainer.add(country.rect);
            }
            else {
                // same rectangles for all other countries
                country.rect = this.add.sprite(country.txt.x, country.txt.y, "rectangle");
                country.rect.displayWidth = country.txt.width + 2;
                country.rect.displayHeight = country.txt.height;
                this.americaContainer.add(country.rect);
            }

            // bring to top text field
            this.americaContainer.bringToTop(country.txt);
        }
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
    }
}
