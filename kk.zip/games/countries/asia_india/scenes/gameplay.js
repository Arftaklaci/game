"use strict"

var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        })
    }

    create() {

        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;

        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;
       camera.zoom = 0.25;

        // min max zoom
        this.minZoom = 0.2;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.5;
        }
        else {
            this.maxZoom = 2;
        }

        // display countries in this scene
        this.displayIndia(this);
       
        // get countries (sprites) array from the container
        this.countriesArray = this.indiaContainer.getAll();
        // for each country (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {

            let country = this.countriesArray[i];

            /* enable drag to position countries
            country.setInteractive()
            this.input.setDraggable(country);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {

                gameObject.x = dragX;
                gameObject.y = dragY;
        
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });
            */
            
            // make countries sprites interactive
            if (country.name === countriesLabels.okinawa) {
                country.setInteractive({           
                useHandCursor: true,             
                pixelPerfect: false,
                });
            }
            else {
                country.setInteractive({ 
                    useHandCursor: true,             
                    pixelPerfect: true,
                    alphaTolerance: 255
                    });
            }

             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over country
                country.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                        if (country.isSpritesheet === true) {
                            country.setFrame(1);
                        }
                        else {
                            country.setTintFill(0xFFFFFF);
                            //country.alpha = .5;
                        }
                    }
                },this);

                country.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        if (country.isSpritesheet === true) {
                            country.setFrame(0);
                        }
                        else {
                            country.clearTint();
                            //country.alpha = 1;
                        }
                    }
                },this);
            }

            country.on('pointerdown', () => {

                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });

            country.on('pointerup', () => {

                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);

                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    country.xPos = camera.x;
                    country.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false)
                    {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === country.name)
                        {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this country
                            country.disableInteractive();

                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }

                            // create the country label
                            this.showLabels(country);
    
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
    
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // drag
                else {
                    // console.log("don't tap, drag the map");
                }
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();

        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false)
            {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();

                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                var dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {

                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        var drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }

                }).on('pinch', dragScale => {
                    var scaleFactor = dragScale.scaleFactor;
                    
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                    
                }, this);

                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }

        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 70, color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 70, color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                
                camera.zoom *= 0.9;
            }
        }
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.indiaContainer.setSize(width, height);
        this.indiaContainer.x = 0;
        this.indiaContainer.y = 0; 
       // this.extraAsia.setPosition(this.chhattisgarh.x - 353.5, this.chhattisgarh.y - 51);
        this.extraSriLanka.setPosition(this.chhattisgarh.x - 168.5, this.chhattisgarh.y + 1514);
        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2, height/2);
        }
    }

    getQuestion()
    {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;

        // small font size for these labels
        if (ui.questionText.text === countriesLabels.andamanAndNicobarIslands) {
            ui.questionText.setFontSize(28);
        }
        else if (ui.questionText.text === countriesLabels.dadraAndNagarHaveli) {
            ui.questionText.setFontSize(19);
        }
        else {
            ui.questionText.setFontSize(33);
        }
        
        // tween
        this.tweens.add({
           targets: [ui.questionText],
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });

        // remove the previous question
        this.questionsArray.shift();
    }

    gameOver() {
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;

        // play sound
        this.gameOverSound.play();

        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();

        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {

        // tween camera
        if (camera.zoom > this.minZoom) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: this.minZoom,
                x: 0, 
                y: 0,
                duration: 1500,
                onComplete: () => {
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }

        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: 0,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showLabels(country) {

        // lines
        if (country.hasLine) {
            if (country.name === countriesLabels.dadraAndNagarHaveli) {
                let line = this.add.image(country.lineX, country.lineY, "lines", "lineDadraAndNagarHaveli.png");
                this.indiaContainer.add(line);
            }
            else if (country.name === countriesLabels.chandigarh) {
                let line = this.add.image(country.lineX, country.lineY, "lines", "lineChandigarh.png");
                this.indiaContainer.add(line);
            }
            else if (country.name === countriesLabels.puducherry) {
                let line = this.add.image(country.lineX, country.lineY, "lines", "linePuducherry.png");
                this.indiaContainer.add(line);
            }
            else if (country.name === countriesLabels.delhi) {
                let line = this.add.image(country.lineX, country.lineY, "lines", "lineDelhi.png");
                this.indiaContainer.add(line);
            }
        }

        // write country name
        country.txt = this.add.text(country.x, country.y, country.name, { fontFamily: "bold", fontSize: 38, align: "center", color: '#000000' });
        country.txt.setOrigin(.5,.5);
        this.indiaContainer.add(country.txt);

        if (country.name === countriesLabels.dadraAndNagarHaveli) {
            country.txt.setText(labels.dadraAndNagarHaveli2);
        }

        // position text
        if (country.labelX) {
            country.txt.x = country.labelX;
            country.txt.y = country.labelY;
        }
        
        // create white rectangles
        country.rect = this.add.sprite(country.txt.x, country.txt.y, "ui", "rectangle.jpg");
        country.rect.displayWidth = country.txt.width + 1;
        country.rect.displayHeight = country.txt.height;
        this.indiaContainer.add(country.rect);
        
        // bring to top text field
        this.indiaContainer.bringToTop(country.txt);
    }
    
    displayIndia(aScene) {
        // extra
       // aScene.extraAsia = aScene.add.image(0, 0, "extraAsia");
        aScene.extraSriLanka = aScene.add.image(0, 0, "atlas", "extraSriLanka.png");

        // provinces
        aScene.chhattisgarh = aScene.add.image(width/2 + 353.5, height/2 + 50.5, "chhattisgarh");
        aScene.uttarPradesh = aScene.add.image(width/2 + 204.5, height/2 - 663.5, "uttarPradesh");
        aScene.uttarakhand = aScene.add.image(width/2 + 46.5, height/2 - 1005, "atlas", "uttarakhand.png");
        aScene.himachalPradesh = aScene.add.image(width/2 - 151, height/2 - 1210.5, "atlas", "himachalPradesh.png");
        aScene.madhyaPradesh = aScene.add.image(width/2 - 66, height/2 - 303.7, "madhyaPradesh");
        aScene.rajasthan = aScene.add.image(width/2 - 513, height/2 - 619, "rajasthan");
        aScene.haryana = aScene.add.image(width/2 - 285, height/2 - 921, "atlas", "haryana.png");
        aScene.punjab = aScene.add.image(width/2 - 345.5, height/2 - 1124, "atlas", "punjab.png");
        aScene.jammuAndKashmir = aScene.add.image(width/2 - 336.8, height/2 - 1426, "atlas", "jammuAndKashmir.png");
        aScene.ladakh = aScene.add.image(width/2 - 127.3, height/2 - 1463, "atlas", "ladakh.png");
        aScene.delhi = aScene.add.image(width/2 - 180, height/2 - 842, "atlas", "delhi.png");
        aScene.chandigarh = aScene.add.image(width/2 - 212.3, height/2 - 1096, "atlas", "chandigarh.png");
        aScene.chandigarh = aScene.add.image(width/2 - 212.3, height/2 - 1096, "atlas", "chandigarh.png");
        aScene.chandigarh = aScene.add.image(width/2 - 212.3, height/2 - 1096, "atlas", "chandigarh.png");
        aScene.maharashtra = aScene.add.image(width/2 - 242, height/2 + 280, "maharashtra");
        aScene.gujarat = aScene.add.image(width/2 - 822, height/2 - 151, "gujarat");
        aScene.telangana = aScene.add.image(width/2 + 51.3, height/2 + 398.5, "atlas", "telangana.png");
        aScene.karnataka = aScene.add.image(width/2 - 323.5, height/2 + 732, "karnataka");
        aScene.andhraPradesh = aScene.add.image(width/2 + 182.5, height/2 + 633.5, "andhraPradesh");
        aScene.tamilNadu = aScene.add.image(width/2 - 98, height/2 + 1220, "tamilNadu");
        aScene.goa = aScene.add.image(width/2 - 581, height/2 + 675, "atlas", "goa.png");
        aScene.kerala = aScene.add.image(width/2 - 348, height/2 + 1247, "atlas", "kerala.png");
        aScene.lakshadweep = aScene.add.sprite(width/2 - 762, height/2 + 1254, "lakshadweep");
        aScene.andamanAndNicobarIslands = aScene.add.sprite(width/2 + 1628, height/2 + 1242, "andamanAndNicobarIslands");
        aScene.odisha = aScene.add.sprite(width/2 + 578, height/2 + 135.7, "atlas", "odisha.png");
        aScene.jharkhand = aScene.add.sprite(width/2 + 705.5, height/2 - 271.7, "atlas", "jharkhand.png");
        aScene.bihar = aScene.add.sprite(width/2 + 715.5, height/2 - 520.5, "atlas", "bihar.png");
        aScene.westBengal = aScene.add.sprite(width/2 + 939.5, height/2 - 365.5, "atlas", "westBengal.png");
        aScene.sikkim = aScene.add.sprite(width/2 + 979, height/2 - 739, "atlas", "sikkim.png");
        aScene.meghalaya = aScene.add.sprite(width/2 + 1290.5, height/2 - 525.5, "atlas", "meghalaya.png");
        aScene.tripura = aScene.add.sprite(width/2 + 1350.5, height/2 - 311, "atlas", "tripura.png");
        aScene.assam = aScene.add.sprite(width/2 + 1435, height/2 - 607, "atlas", "assam.png");
        aScene.mizoram = aScene.add.sprite(width/2 + 1468, height/2 - 270.5, "atlas", "mizoram.png");
        aScene.manipur = aScene.add.sprite(width/2 + 1560.5, height/2 - 459, "atlas", "manipur.png");
        aScene.nagaland = aScene.add.sprite(width/2 + 1595, height/2 - 610.5, "atlas", "nagaland.png");
        aScene.arunachalPradesh = aScene.add.sprite(width/2 + 1595, height/2 - 847, "atlas", "arunachalPradesh.png");
        aScene.puducherry = aScene.add.sprite(width/2 - 27.5, height/2 + 872.5, "puducherry");
        aScene.dadraAndNagarHaveli = aScene.add.sprite(width/2 - 766.5, height/2 + 71.5, "dadraAndNagarHaveli");

        // repositions these labels
        aScene.jammuAndKashmir.labelX = aScene.jammuAndKashmir.x - 90;
        aScene.jammuAndKashmir.labelY = aScene.jammuAndKashmir.y;
        aScene.punjab.labelX = aScene.punjab.x - 10;
        aScene.punjab.labelY = aScene.punjab.y + 30;
        aScene.karnataka.labelX = aScene.karnataka.x - 70;
        aScene.karnataka.labelY = aScene.karnataka.y + 40;
        aScene.himachalPradesh.labelX = aScene.himachalPradesh.x + 70;
        aScene.himachalPradesh.labelY = aScene.himachalPradesh.y - 15;
        aScene.maharashtra.labelX = aScene.maharashtra.x - 90;
        aScene.maharashtra.labelY = aScene.maharashtra.y - 35;
        aScene.madhyaPradesh.labelX = aScene.madhyaPradesh.x;
        aScene.madhyaPradesh.labelY = aScene.madhyaPradesh.y + 40;
        aScene.chhattisgarh.labelX = aScene.chhattisgarh.x - 15;
        aScene.chhattisgarh.labelY = aScene.chhattisgarh.y - 90;
        aScene.jharkhand.labelX = aScene.jharkhand.x - 35;
        aScene.jharkhand.labelY = aScene.jharkhand.y - 20;
        aScene.westBengal.labelX = aScene.westBengal.x - 30;
        aScene.westBengal.labelY = aScene.westBengal.y + 145;
        aScene.manipur.labelX = aScene.manipur.x + 40;
        aScene.manipur.labelY = aScene.manipur.y;
        aScene.nagaland.labelX = aScene.nagaland.x + 100;
        aScene.nagaland.labelY = aScene.nagaland.y;
        aScene.assam.labelX = aScene.assam.x - 20;
        aScene.assam.labelY = aScene.assam.y - 15;
        aScene.tripura.labelX = aScene.tripura.x - 30;
        aScene.tripura.labelY = aScene.tripura.y;
        aScene.mizoram.labelX = aScene.mizoram.x + 20;
        aScene.mizoram.labelY = aScene.mizoram.y + 10;
        aScene.arunachalPradesh.labelX = aScene.arunachalPradesh.x + 20;
        aScene.arunachalPradesh.labelY = aScene.arunachalPradesh.y - 40;
        aScene.delhi.labelX = aScene.delhi.x - 600;
        aScene.delhi.labelY = aScene.delhi.y - 60;
        aScene.chandigarh.labelX = aScene.chandigarh.x - 335;
        aScene.chandigarh.labelY = aScene.chandigarh.y - 130;
        aScene.dadraAndNagarHaveli.labelX = aScene.dadraAndNagarHaveli.x - 90;
        aScene.dadraAndNagarHaveli.labelY = aScene.dadraAndNagarHaveli.y + 165;
        aScene.puducherry.labelX = aScene.puducherry.x + 460;
        aScene.puducherry.labelY = aScene.puducherry.y + 60;

        // lines
        aScene.delhi.hasLine = true;
        aScene.delhi.lineX = aScene.delhi.x - 307;
        aScene.delhi.lineY = aScene.delhi.y - 30;
        aScene.chandigarh.hasLine = true;
        aScene.chandigarh.lineX = aScene.chandigarh.x - 135;
        aScene.chandigarh.lineY = aScene.chandigarh.y - 80;
        aScene.puducherry.hasLine = true;
        aScene.puducherry.lineX = aScene.puducherry.x + 20;
        aScene.puducherry.lineY = aScene.puducherry.y + 20;
        aScene.dadraAndNagarHaveli.hasLine = true;
        aScene.dadraAndNagarHaveli.lineX = aScene.dadraAndNagarHaveli.x - 20;
        aScene.dadraAndNagarHaveli.lineY = aScene.dadraAndNagarHaveli.y + 65;

        // names
        aScene.chhattisgarh.name = countriesLabels.chhattisgarh;
        aScene.uttarPradesh.name = countriesLabels.uttarPradesh;
        aScene.uttarakhand.name = countriesLabels.uttarakhand;
        aScene.himachalPradesh.name = countriesLabels.himachalPradesh;
        aScene.madhyaPradesh.name = countriesLabels.madhyaPradesh;
        aScene.rajasthan.name = countriesLabels.rajasthan;
        aScene.haryana.name = countriesLabels.haryana;
        aScene.punjab.name = countriesLabels.punjab;
        aScene.jammuAndKashmir.name = countriesLabels.jammuAndKashmir;
        aScene.ladakh.name = countriesLabels.ladakh;
        aScene.delhi.name = countriesLabels.delhi;
        aScene.chandigarh.name = countriesLabels.chandigarh;
        aScene.maharashtra.name = countriesLabels.maharashtra;
        aScene.gujarat.name = countriesLabels.gujarat;
        aScene.telangana.name = countriesLabels.telangana;
        aScene.karnataka.name = countriesLabels.karnataka;
        aScene.kerala.name = countriesLabels.kerala;
        aScene.andhraPradesh.name = countriesLabels.andhraPradesh;
        aScene.goa.name = countriesLabels.goa;
        aScene.tamilNadu.name = countriesLabels.tamilNadu;
        aScene.puducherry.name = countriesLabels.puducherry;
        aScene.lakshadweep.name = countriesLabels.lakshadweep;
        aScene.andamanAndNicobarIslands.name = countriesLabels.andamanAndNicobarIslands;
        aScene.odisha.name = countriesLabels.odisha;
        aScene.bihar.name = countriesLabels.bihar;
        aScene.westBengal.name = countriesLabels.westBengal;
        aScene.jharkhand.name = countriesLabels.jharkhand;
        aScene.sikkim.name = countriesLabels.sikkim;
        aScene.meghalaya.name = countriesLabels.meghalaya;
        aScene.assam.name = countriesLabels.assam;
        aScene.tripura.name = countriesLabels.tripura;
        aScene.arunachalPradesh.name = countriesLabels.arunachalPradesh;
        aScene.nagaland.name = countriesLabels.nagaland;
        aScene.manipur.name = countriesLabels.manipur;
        aScene.mizoram.name = countriesLabels.mizoram;
        aScene.dadraAndNagarHaveli.name = countriesLabels.dadraAndNagarHaveli;


        // create container and put countries into it
        aScene.indiaContainer = aScene.add.container(0, 0, [ aScene.chhattisgarh, aScene.uttarPradesh, aScene.uttarakhand, aScene.himachalPradesh, aScene.madhyaPradesh, aScene.rajasthan, aScene.punjab, aScene.haryana, aScene.jammuAndKashmir, aScene.ladakh, aScene.chandigarh, aScene.delhi, aScene.maharashtra, aScene.gujarat, aScene.karnataka, aScene.telangana, aScene.kerala, aScene.andhraPradesh, aScene.tamilNadu, aScene.goa, aScene.lakshadweep, aScene.andamanAndNicobarIslands, aScene.odisha, aScene.jharkhand, aScene.westBengal, aScene.bihar, aScene.sikkim, aScene.assam, aScene.tripura, aScene.meghalaya, aScene.arunachalPradesh, aScene.nagaland, aScene.manipur, aScene.mizoram, aScene.puducherry, aScene.dadraAndNagarHaveli ]);
        
        aScene.indiaContainer.setSize(width, height);
        aScene.indiaContainer.x = 0;
        aScene.indiaContainer.y = 0;   
        
        // position extra sprites
        //aScene.extraAsia.setPosition(aScene.chhattisgarh.x - 353.5, aScene.chhattisgarh.y - 51);
        aScene.extraSriLanka.setPosition(aScene.chhattisgarh.x - 168.5, aScene.chhattisgarh.y + 1514);
     }
}
