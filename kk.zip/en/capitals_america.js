var game = new Phaser.Game(500, 800, Phaser.Canvas, null, null, true)

game.global = 
{
	orientated    : false,
    instructions  : true,
}

// edit below 
collator = "en"
website_url = "https://world-geography-games.com/americas.html"  // stop button
website_label = "World Geography Games"
title_label = "Capitals of America"
play_again_label = "Play again"
stop_label = "Stop"
score_label = "score: "
final_score = "Score"
next_label = "Next"
out_of_label = "out of"
play_label = "play"
options_label = "options"
select_atleast_label = "Select at least 5 capitals"
back_label = "back"
sound_label = "SOUND"
number_of_capitals_label = "NUMBER OF CAPITALS"
capitals_label = "CAPITALS"
select_label = "select"
library_label = "library"

northernLabel = "Canada, US & Mexico"
centralLabel = "Central America"
southLabel = "South America"
caribbeanLabel = "Caribbean"

countries = ["Paraguay", "Saint Kitts and Nevis", "Belize", "Colombia", "Brazil", "Barbados", "Argentina", "Venezuela", "Saint Lucia", "Guyana", "Guatemala", "Cuba", "Jamaica", "St. Vincent and the Grenadines", "Peru", "Nicaragua", "Mexico", "Uruguay", "Bahamas", "Canada", "Panama", "Suriname", "Haiti", "Trinidad and Tobago", "Ecuador", "Dominica", "Antigua and Barbuda", "Costa Rica", "El Salvador", "Chile", "Dominican Republic", "Grenada", "Bolivia", "Honduras", "United States"];

capitals = ["Asunción", "Basseterre", "Belmopan", "Bogotá", "Brasília", "Bridgetown", "Buenos Aires", "Caracas", "Castries", "Georgetown", "Guatemala City", "Havana", "Kingston", "Kingstown", "Lima", "Managua", "Mexico City", "Montevideo", "Nassau", "Ottawa", "Panama City", "Paramaribo", "Port-au-Prince", "Port of Spain", "Quito", "Roseau", "Saint John's", "San José", "San Salvador", "Santiago", "Santo Domingo", "Saint George's", "Sucre", "Tegucigalpa", "Washington, D.C."];

// ** DO NOT EDIT BELOW!
// create new array, order alphabetically
countriesAlphabet = countries.slice().sort(Intl.Collator(collator).compare);

var capitalsUsed = 35;

// frames that will be used (frames represent images)
frames = [];
for (let f = 0; f < capitalsUsed; f++) {
    frames.push(f);
}

// always contains all frames, get random capitals from this array
allFrames = frames.slice();

canadaUsMexico = [34,19,16]; // canada us mexico
centralAmerica = [2,27,28,33,10,15,20]; 
southAmerica = [4,6,29,32,24,3,0,9,21,14,17,7]; 
caribbean = [26,18,5,11,25,30,31,22,13,12,1,8,23];

// toggle buttons - regions, frame 0 or 1
northernBtn = 0; 
southBtn = 0; 
centralBtn = 0; 
caribbeanBtn = 0; 

// toggle buttons used for countries, frame 0 or 1
toggleButtonFrames = [];

for (let i = 0; i < frames.length; i++) {
    // by default all buttons are on (frame 0)
    toggleButtonFrames.push(0);
}

// sound toggle button
soundFrame = 0;
// select regions or countries in options (back button depends on this)
selectingRegions = true;

// all capitals
haveLookalikes = [];
for (let i = 0; i < capitalsUsed; i++) {
    haveLookalikes.push(i);
}

// capitals from the same region
lookalikes = [
[4,6],[26,18],[27],[4,29],[3,32],[11,25],[24,0],[9],[30],[21],[28],[31,22],[13,1],[8,23],[17,7],[10],[34],[4,6],
[26,5],[34],[15],[29,32],[18,11],[25,30],[3,0],[30,31],[12,13],[20],[33],[9,21],[1,25],[23,8],[14,17],[10],[16,19]
];

// game states
game.state.add('boot', bootState);
game.state.add("Loading", loading);
game.state.add("menu", menuState);
game.state.add("options", optionsState);
game.state.add("library", libraryState);
game.state.add("level1", state1);
game.state.start("boot");