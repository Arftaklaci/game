"use strict"

var width, height, resize;

// edit below
var webUrl = "https://world-geography-games.com/americas.html";

var labels =
{
    website         : "World Geography Games",
    title           : "The Caribbean: Countries and Territories",
    titleTwo        : "Caribbean:\n Countries",
    play            : "play",
    map             : "map",
    tapStart        : "Tap on the map to start",
    clickStart      : "Click on the map to start\nUse mouse wheel to zoom",
    incorrect       : "Incorrect. Try again!",
    score           : "Score: ",
    attempts        : "Attempts: ",
    attemptsEnd     : "Attempts",
    back            : "back",
    map             : "map",
    playAgain       : "Play Again",
    stop            : "Stop",
    skip            : "Skip",
    skipped         : "Skipped",
    countries       : "Countries",
    FRtext          : "FR: Overseas department or collectivy of France",
    UKtext          : "UK : British overseas territory",
    USAtext         : "USA: Territory or commonwealth of the United States of America",
    NLtext          : "NL: Kingdom of the Netherlands or special municipality of the Netherlands",
    
    caymanIslandsT        : "Cayman Islands (UK)",
    turksAndCaicosT       : "Turks and Caicos\n  Islands (UK)",
    usVirginIslandsT      : "United States\nVirgin Islands\n  (USA)",
    britishVirginIslandsT : "British Virgin\n Islands (UK)",
    puertoRicoT           : "Puerto Rico\n(USA)",
    sabaT                 : "Saba (NL)",
    sintEustatiusT        : "Sint Eustatius (NL)",
    montserratT           : "Montserrat (UK)",
    arubaT                : "Aruba (NL)",
    curacaoT              : "Curaçao (NL)",
    bonaireT              : "Bonaire (NL)",
    anguillaT             : "Anguilla (UK)",
    saintMartinT          : "Saint Martin (FR)",
    sintMaartenT          : "Sint Maarten (NL)",
    saintBarthelemyT      : "Saint Barthélemy (FR)",
    guadeloupeT           : "Guadeloupe (FR)",
    martiniqueT           : "Martinique (FR)",
    dominicanRepublicT    : "Dominican\nRepublic",
    saintVincentT         : "Saint Vincent and \n  the Grenadines"
}

var countriesLabels = {
  bahamas             : "Bahamas",
  cuba                : "Cuba",
  caymanIslands       : "Cayman Islands",
  jamaica             : "Jamaica",
  haiti               : "Haiti",
  dominicanRepublic   : "Dominican Republic",
  turksAndCaicos      : "Turks and Caicos Islands",
  usVirginIslands     : "United States Virgin Islands",
  britishVirginIslands: "British Virgin Islands",
  puertoRico          : "Puerto Rico",
  saba                : "Saba",
  sintEustatius       : "Sint Eustatius",
  saintKittsAndNevis  : "Saint Kitts and Nevis",
  montserrat          : "Montserrat",
  aruba               : "Aruba",
  curacao             : "Curaçao",
  bonaire             : "Bonaire",
  anguilla            : "Anguilla",
  saintMartin         : "Saint Martin",
  sintMaarten         : "Sint Maarten",
  saintBarthelemy     : "Saint Barthélemy",
  antiguaAndBarbuda   : "Antigua and Barbuda",
  guadeloupe          : "Guadeloupe",
  dominica            : "Dominica",
  martinique          : "Martinique",
  saintLucia          : "Saint Lucia",
  barbados            : "Barbados",
  saintVincent        : "Saint Vincent and the Grenadines",
  grenada             : "Grenada",
  trinidadAndTobago   : "Trinidad and Tobago"
}

// don't edit below

// sound button is on by default
var soundButtonFrame = 0;
// number of attempts
var attempts = +0;
// number of skipped countries
var skips = +0;
// by default all countries are included
var questionsArray = Object.values(countriesLabels);

function tweenObj(aScene, obj, fromN, toN) {
  obj.alpha = fromN;

  aScene.tweens.add({
      targets: [obj],
      alpha: { value: toN },
      ease: 'Linear',
      duration: 400,
      onComplete: () => {
          
      }
  });
}

// resize
const DEFAULT_WIDTH = 1280
const DEFAULT_HEIGHT = 720
const MAX_WIDTH = DEFAULT_WIDTH * 1.5
const MAX_HEIGHT = DEFAULT_HEIGHT * 1.5
let SCALE_MODE = 'SMOOTH'

const config = {
    type: Phaser.AUTO,
    parent: 'geo-game',
    backgroundColor : 0x34C5EB,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,

    scale: 
    {
        mode: Phaser.Scale.NONE,
        parent: "geo-game",
    },
    scene: [Loading, Menu, UserInterface, GraphUI, Gameplay, Graph]
}

window.addEventListener('load', () => {
    const game = new Phaser.Game(config)
  
    const resize = () => {
      const w = window.innerWidth
      const h = window.innerHeight
  
      let width = DEFAULT_WIDTH
      let height = DEFAULT_HEIGHT
      let maxWidth = MAX_WIDTH
      let maxHeight = MAX_HEIGHT
      let scaleMode = SCALE_MODE
  
      let scale = Math.min(w / width, h / height)
      let newWidth = Math.min(w / scale, maxWidth)
      let newHeight = Math.min(h / scale, maxHeight)
  
      let defaultRatio = DEFAULT_WIDTH / DEFAULT_HEIGHT
      let maxRatioWidth = MAX_WIDTH / DEFAULT_HEIGHT
      let maxRatioHeight = DEFAULT_WIDTH / MAX_HEIGHT
  
      // smooth scaling
      let smooth = 1
      if (scaleMode === 'SMOOTH') {
        const maxSmoothScale = 1.15
        const normalize = (value, min, max) => {
          return (value - min) / (max - min)
        }
        if (width / height < w / h) {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioWidth) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        } else {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioHeight) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        }
      }

      // resize the game
      game.scale.resize(newWidth * smooth, newHeight * smooth)
      // scale the width and height of the css
      game.canvas.style.width = newWidth * scale + 'px'
      game.canvas.style.height = newHeight * scale + 'px'
      // center the game with css margin
      game.canvas.style.marginTop = `${(h - newHeight * scale) / 2}px`
      game.canvas.style.marginLeft = `${(w - newWidth * scale) / 2}px`
    }

    window.addEventListener('resize', event => {
      resize()
    })
  
    resize()
  })
