"use strict"

class Graph extends Phaser.Scene {
    constructor() {
        super({
            key: "graph"
        })
    }

    create() {

        width = this.cameras.main.width;
        height = this.cameras.main.height;

        // gameplay scene
        let gameplay = this.scene.get("gameplay");
        gameplay.displayMexico(this);

        // show labels
        this.showMexicoLabels();

        // user interface
        this.ui = this.scene.get("graphUI");
        // launch user interface 
        this.scene.launch("graphUI");
        this.scene.moveAbove("graph", "graphUI");

       // camera
       camera = this.cameras.main;

        // min zoom
        this.minZoom = 0.6;
        camera.zoom = 0.6;

        // max zoom
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.6;
        }
        else {
            this.maxZoom = 2;
        }

        // enable drag and pinch to zoom
        var dragScale = this.plugins.get('rexpinchplugin').add(this);
        dragScale.on('drag1', dragScale => {
                var drag1Vector = dragScale.drag1Vector;
                camera.scrollX -= drag1Vector.x / camera.zoom;
                camera.scrollY -= drag1Vector.y / camera.zoom;
        }).on('pinch', dragScale => {
            var scaleFactor = dragScale.scaleFactor;
            
            // camera zoom
            camera.zoom *= scaleFactor;
        }, this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);

            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
            //this.upKeyDown = cursorKeys.up.isDown;
            //this.downKeyDown = cursorKeys.down.isDown;
        }

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on("resize", (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }
    
    update() {
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop) {
            if (this.cursorKeys.up.isDown) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown) {
                
                camera.zoom *= 0.9;
            }
        }
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    showMexicoLabels(country) {

        // get countries (sprites) array from the container
        this.countriesArray = this.mexicoContainer.getAll();

        for (let i = 0; i < this.countriesArray.length; i++) {

            let country = this.countriesArray[i];
            country.txt = this.add.text(country.x, country.y, country.name, { fontFamily: "bold", fontSize: 17, color: '#000000' });
            country.txt.setOrigin(.5,.5);
            this.mexicoContainer.add(country.txt);
            // position text
            if (country.labelX) {
                country.txt.x = country.labelX;
                country.txt.y = country.labelY;
            }

            // create a line if needed
            if (country.hasLine) {
                if (country.name === countriesLabels.queretaro || country.name === countriesLabels.tlaxcala) {
                    let line = this.add.image(country.lineX, country.lineY, "line");
                    line.setOrigin(0,0.5);
                    this.mexicoContainer.add(line);
                }
                else if (country.name === countriesLabels.colima) {
                    let line = this.add.image(country.lineX, country.lineY, "lineColima");
                    line.setOrigin(1,0);
                    this.mexicoContainer.add(line);
                }
                else if (country.name === countriesLabels.morelos) {
                    let line = this.add.image(country.lineX, country.lineY, "lineMorelos");
                    line.setOrigin(1,0);
                     this.mexicoContainer.add(line);
                }
                else if (country.name === countriesLabels.aguascalientes) {
                    let line = this.add.image(country.lineX, country.lineY, "lineAguascalientes");
                    line.setOrigin(1,0);
                     this.mexicoContainer.add(line);
                }
                else if (country.name === countriesLabels.mexicoCity) {
                    let line = this.add.image(country.lineX, country.lineY, "lineMexicoCity");
                    line.setOrigin(1,0);
                    this.mexicoContainer.add(line);
                }
            }
            
            // create white rectangle
            country.rect = this.add.sprite(country.txt.x, country.txt.y, "rectangle");
            country.rect.displayWidth = country.txt.width + 2;
            country.rect.displayHeight = country.txt.height;
            this.mexicoContainer.add(country.rect);

            // bring to top text field
            this.mexicoContainer.bringToTop(country.txt);
        }
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.mexicoContainer.setSize(width, height);
        this.mexicoContainer.x = 0;
        this.mexicoContainer.y = 0;
    }
}
