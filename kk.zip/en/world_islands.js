"use strict"
var width, height, resize;
var webUrl = "https://world-geography-games.com/world.html";

var labels = 
{
    website         : "World Geography Games",
    title           : "Islands",
    titleTwo        : "Islands",
    play            : "play",
    options         : "options",
    map             : "map",
    sound           : "SOUND",
    photos          : "PHOTOS",
    tapStart        : "Tap on the map to start",
    clickStart      : "Click on the map to start",
    incorrect       : "Incorrect. Try again!",
    score           : "Score: ",
    attempts        : "Attempts: ",
    attemptsEnd     : "Attempts",
    points          : "Points",
    back            : "back",
    playAgain       : "Play Again",
    stop            : "Stop",
    skip            : "Skip",
    skipped         : "Skipped",
}

// the order of labels below is important!
var credits = {
  credit1   : "Photo: NASA 2013 (Public Domain)",
  credit2   : "Photo: Muhammad Haris 2016 (CC-BY-SA)",
  credit3   : "Photo: Amanderson2 2018 (CC-BY)",
  credit4   : "Photo: Berit Watkin 2014 (CC-BY)",
  credit5   : "Photo: Amanderson2 2019 (CC-BY)",
  credit6   : "Photo: Jason Boldero 2015 (CC-BY)",
  credit7   : "Photo: Ray Swi-hymn 2019 (CC-BY-SA)",
  credit8   : "Photo: Sanshiro Kubota 2019 (CC-BY)",
  credit9   : "Photo: Yoga Karta 2015 (CC-BY-NC)",
  credit10  : "Photo: ISS Expedition 58 crew 2019 (Public Domain)",
  credit11  : "Photo: Pavel Kirillov 2019 (CC-BY-SA)",
  credit12  : "Photo: Timothy Neesam 2018 (CC-BY-ND)",
  credit13  : "Photo: Douglas O'Brien 2018 (CC-BY-SA)",
  credit14  : "Photo: Brian Tibbets 2009 (Public Domain)",
  credit15  : "Photo: Simone Bosotti 2017 (CC-BY-SA)",
  credit16  : "Photo: Andrea Schaffer 2014 (CC-BY)",
  credit17  : "Photo: Rehman Abubakr 2018 (CC-BY-SA)",
  credit18  : "Photo: Faizal Abdul Aziz/CIFOR 2018 (CC-BY-NC-SA)",
  credit19  : "Photo: Thomas Williams 2018 (CC-BY)",
  credit20  : "Photo: Andrew Shiva 2016 (CC-BY-SA)"
}
var creditsArray = Object.values(credits);

var subjects = {
  baffinIsland:     "Baffin Island",
  borneo:           "Borneo",
  cuba:             "Cuba",
  greatBritain:     "Great Britain",
  greenland:        "Greenland",
  hispaniola:       "Hispaniola",
  honshu:           "Honshu",
  iceland:          "Iceland",
  java:             "Java",
  luzon:          	"Luzon",
  madagascar:       "Madagascar",
  newFoundland:  	"Newfoundland",
  newGuinea:        "New Guinea",
  sakhalin:         "Sakhalin",
  sicily:           "Sicily",
  southIsland:      "South Island",
  sriLanka:         "Sri Lanka",
  sumatra:          "Sumatra",
  tasmania:         "Tasmania",
  tierraDelFuego:   "Tierra del Fuego"
}


var countriesNames = ["Canada", "Southeast Asia", "Caribbean", "British Isles", "North America", "Caribbean", "Japan", "North Atlantic", "Indonesia", "Philippines", "Indian Ocean", "Canada", "Melanesia", "Russia", "Mediterranean Sea", "New Zealand", "Indian Ocean", "Indonesia", "Australia", "South America"];

var infoText = [
"Area: 507.451 km²", 
"Belongs to: Brunei, Indonesia and Malaysia.\nArea: 743,330 km²", 
"Area: 109.884 km²", 
"Belongs to: United Kingdom\nArea: 229.979 km²", 
"Belongs to: Denmark\nArea: 2.166.086 km²", 
"Belongs to: Dominican Republic and Haiti\nArea: 76.480 km²", 
"Area: 230.500 km²", 
"Area:103.000 km²", 
"Area: 132.000 km²", 
"Area: 104.688 km²", 
"Area: 587.295 km²", 
"Area: 111.390 km²", 
"Belongs to: Indonesia and Papua New Guinea\nArea: 786.000 km² ", 
"Area: 76.400 km²", 
"Belongs to: Italy\nArea: 25.710 km²", 
"Area: 150.718 km²", 
"Area: 65.610 km²", 
"Area: 470.000 km²", 
"Area: 68.401 km²", 
"Belongs to: Argentina and Chile\nArea: 47,992 km²"];
// don't edit below

// sound is on by default
var soundButtonFrame = 0;
// show photos by default
var showPhotos = true;
var photosButtonFrame = 0;
// number of attempts
var attempts = +0;
// number of skipped countries
var skips = +0;
// make array
var questionsArray = Object.values(subjects);
var questionsArrayStatic = Object.values(subjects);

// resize
const DEFAULT_WIDTH = 1280
const DEFAULT_HEIGHT = 720
const MAX_WIDTH = DEFAULT_WIDTH * 1.5
const MAX_HEIGHT = DEFAULT_HEIGHT * 1.5
let SCALE_MODE = 'SMOOTH'

const config = {
    type: Phaser.AUTO,
    parent: 'geo-game',
    backgroundColor : 0x34C5EB,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,

    scale: 
    {
        mode: Phaser.Scale.NONE,
        parent: "geo-game",
    },
    scene: [Loading, Menu, Options, UserInterface, GraphUI, Gameplay, Graph]
}

window.addEventListener('load', () => {
    const game = new Phaser.Game(config)
  
    resize = () => {
      const w = window.innerWidth
      const h = window.innerHeight
  
      let width = DEFAULT_WIDTH
      let height = DEFAULT_HEIGHT
      let maxWidth = MAX_WIDTH
      let maxHeight = MAX_HEIGHT
      let scaleMode = SCALE_MODE
  
      let scale = Math.min(w / width, h / height)
      let newWidth = Math.min(w / scale, maxWidth)
      let newHeight = Math.min(h / scale, maxHeight)
  
      let defaultRatio = DEFAULT_WIDTH / DEFAULT_HEIGHT
      let maxRatioWidth = MAX_WIDTH / DEFAULT_HEIGHT
      let maxRatioHeight = DEFAULT_WIDTH / MAX_HEIGHT
  
      // smooth scaling
      let smooth = 1
      if (scaleMode === 'SMOOTH') {
        const maxSmoothScale = 1.15
        const normalize = (value, min, max) => {
          return (value - min) / (max - min)
        }
        if (width / height < w / h) {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioWidth) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        } else {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioHeight) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        }
      }

      // resize the game
      game.scale.resize(newWidth * smooth, newHeight * smooth)
      // scale the width and height of the css
      game.canvas.style.width = newWidth * scale + 'px'
      game.canvas.style.height = newHeight * scale + 'px'
      // center the game with css margin
      game.canvas.style.marginTop = `${(h - newHeight * scale) / 2}px`
      game.canvas.style.marginLeft = `${(w - newWidth * scale) / 2}px`
    }

    window.addEventListener('resize', event => {
      resize()
    })
  
    resize()
  })
