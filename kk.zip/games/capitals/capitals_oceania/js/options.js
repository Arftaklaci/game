var mouseIsDown = false;
var distX = 0;

function mouseDown() {
    //set the mouseIsDown to true
    mouseIsDown = true;
    startX = game.input.y;
}
function mouseUp() {
    mouseIsDown = false;
}

var optionsState = {
    create: function () {

        mouseWheelScroll();

        game.input.onUp.add(mouseUp, this);
        game.input.onDown.add(mouseDown, this);

        // bg rectangle
        bg = game.add.image(0, 0, 'bg');

        // oceania group
        oceaniaGroup = game.add.group();

        txtOceania = game.add.text(50, 110, oceaniaLabel.toLocaleUpperCase(), {font:"26px bold", fill:"#0099ff"});

        // add all capitals to array and reorder items alphabetically
        array4 = [];

        oceania.forEach(function (fr) {
            array4.push(capitals[fr]);
        }, this)

        array4 = array4.sort(Intl.Collator(collator).compare);

        yPos = 380;
        array4.forEach(function (country) {

            // write text
            writeText(30, yPos, country, oceaniaGroup);
            // get index
            let index = capitals.indexOf(country);
            // create a button for each country
            addButton(W - 120, yPos - 5, index, toggleCapitals, oceaniaGroup);
            yPos += 50;
        }, this);

        // rectangle on top, hide capitals
        bgTop = game.add.image(0, 0, 'bg_top');
        bgTop.height = 370;

        // text options
        textOptions = game.add.text(W - 40, 22, options_label, {font:"36px extraBold", fill:"#0099ff"});

        textOptions.anchor.setTo(1, 0);
        buttonOptions = game.add.button(W - 55 - textOptions.width, 18, 'button_options');
        buttonOptions.anchor.setTo(1, 0);
        buttonOptions.scale.x = .8;
        buttonOptions.scale.y = .8;

        // button back
        buttonBackSmall = game.add.button(20, 21, 'button_back')

        textBack = game.add.text(55, 23, back_label, {font:"26px bold", fill:"#000000"});
        buttonBackClickable = game.add.button(10, 20, 'button_invisible', goBack);
        buttonBackClickable.width = 60 + textBack.width;
        buttonBackClickable.height = 40;

        // ** BASIC OPTIONS(sound, number of capitals, regions)
        regionsGroup = game.add.group();

        selectAtleast = game.add.text(W/2, 273, select_atleast_label, {font:"24px bold", fill:"#f80007"}, regionsGroup);
        selectAtleast.visible = false;
        selectAtleast.anchor.setTo(0.5, 0);

        // number of capitals
        textNumberOfCapitals = game.add.text(20, 230, number_of_capitals_label, {font:"27px bold", fill:"#0099ff"}, regionsGroup);

        numberOfCapitals = game.add.text(W-105, 225, capitalsUsed, {font:"36px bold", fill:"#000000"}, regionsGroup);
        // capitals
        textCapitals = game.add.text(20, 320, capitals_label, {font:"27px bold", fill:"#0099ff"}, regionsGroup);
        // sound
        text_sound = game.add.text(20, 140, sound_label, {font:"27px bold", fill:"#0099ff"}, regionsGroup);
        button_sound = game.add.button(W - 120, 137, 'button_toggle', toggleSound, this, null, null, null, null, regionsGroup);
        button_sound.frame = soundFrame;
        button_sound.anchor.setTo(0, 0);
    },

    update: function () {
        if (mouseIsDown === true && (oceaniaGroup.visible === true)) {
            //get the distance between the start and end point
            distX = Math.abs(game.input.y - startX);
            //if the distance is greater than 50 pixels
            if (distX > 50) {
                if (distX > 100) {
                    distX = 100
                }
                swipeDone();
            }
        }

        if (oceaniaGroup.y < -320) {
            oceaniaGroup.y = -320
        } 
        else if (oceaniaGroup.y > 0) {
            oceaniaGroup.y = 0
        }
    }
}

function swipeDone() {
    //get the ending point
    var endX = game.input.y;

    if (oceaniaGroup.visible === true) {
        if (endX < startX) {
            oceaniaGroup.y -= distX / 6
        } else {
            oceaniaGroup.y += distX / 6
        }
    }
}

function writeText(x_pos, yPos, this_text, this_group) {
    country_text = game.add.text(x_pos, yPos, this_text, {font:"24px bold", fill:"#000000"}, this_group);
}

function addButton(x_pos, yPos, number, callback, btn_group) {
    toggle_btn = game.add.button(x_pos, yPos, 'button_toggle', callback, this, null, null, null, null, btn_group)
    toggle_btn.number = number
    toggle_btn.frame = toggleButtonFrames[number]
}

function toggleCapitals(btn) {
    // remove this frame (map)
    if (btn.frame == 0) {
        for (let i = 0; i < frames.length; i++) {
            if (btn.number == frames[i]) {
                frames.splice(i, 1)
            }
        }
    } else // add this frame to the array
    {
        for (let i = 0; i < frames.length; i++) {
            if (frames.includes(btn.number) == false) {
                frames.push(btn.number)
            }
        }
        // make sure it runs at least once
        if (frames.length == 0) {
            if (frames.includes(btn.number) == false) {
                frames.push(btn.number)
            }
        }
    }

    // update capitals frames
    capitalsUsed = frames.length
    // update number of capitals
    numberOfCapitals.text = capitalsUsed.toString()
    // save toggle button frame (0 or 1)
    toggleButtonFrames[btn.number] = (toggleButtonFrames[btn.number] == 0) ? 1 : 0
    // switch frame of the current button
    btn.frame = (btn.frame == 0) ? 1 : 0
}

function goBack() {
    // go to menu
    if (frames.length >= 5) {
        game.state.start("menu")
    } 
    else {
        selectAtleast.visible = true;
    }
}
