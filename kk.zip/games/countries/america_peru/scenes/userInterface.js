"use strict"

class UserInterface extends Phaser.Scene {
    constructor() {
        super({
            key: "userInterface"
        })
    }

    create() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        // gameplay scene
        this.gameplay = this.scene.get("gameplay");
        this.gameCompleted = false;
       // question bg
       this.bgQuestion = this.add.image(width/2, 45, "bgQuestion");
       // question text
       this.questionText = this.add.text(width/2 + 15, 45, "", { fontFamily: "bold", fontSize: 34, color: "#000000" });
       this.questionText.setOrigin(0.5,0.5);

        // sound button
        this.buttonSound = this.add.sprite(20, height - 20, 'buttonSound').setInteractive({ useHandCursor: true });
        this.buttonSound.on("pointerdown", () => {
            // mute/unmute sounds
            this.sound.mute = !this.sound.mute;
            // switch button
            if (soundButtonFrame === 0) {
                this.buttonSound.setFrame(1);
                soundButtonFrame = 1;
            }
            else {
                this.buttonSound.setFrame(0);
                soundButtonFrame = 0;
            }
        });
        this.buttonSound.alpha = 0;
        this.buttonSound.setOrigin(0,1);
        // on/off image
        this.buttonSound.setFrame(soundButtonFrame);
       // button back
       this.buttonBack = this.add.image(50, 50, "buttonBack").setInteractive({ useHandCursor: true });
       this.buttonBack.on("pointerup", () => {
           this.scene.stop("gameplay");
           this.scene.start("menu");
       }, this);
       // txt incorrect
       this.txtIncorrect = this.add.text(width/2, height-20, labels.incorrect, { fontFamily: "bold", fontSize: 34, color: '#FFFFFF' });
       this.txtIncorrect.setOrigin(0.5,1);
       this.txtIncorrect.alpha = 0;
        // score
        this.txtScore = this.add.text(width/2 + 160, 75, labels.score + "0/" + String(questionsArray.length), { fontFamily: "bold", fontSize: 32, color: '#FFFFFF' });
        this.txtScore.setOrigin(.5,0);
        // reset attempts and skips
        attempts = 0;
        skips = 0;
        // attempts
        this.txtAttempts = this.add.text(width/2 - 160, 75, labels.attempts + String(attempts), { fontFamily: "bold", fontSize: 32, color: '#FFFFFF' });
        this.txtAttempts.setOrigin(.5,0);

        // skip button
        this.buttonSkip = this.add.text(width/2 + 260, 48, labels.skip, { fontFamily: "bold", fontSize: 32, color: '#FFFFFF' }).setInteractive({ useHandCursor: true });
        this.buttonSkip.on("pointerup", () => {
            skips++;
            // hide incorrect text
            this.txtIncorrect.alpha = 0;
            // get new question
            if (this.gameplay.questionsArray.length > 0) {
                this.gameplay.getQuestion();
                this.buttonSkip.setVisible(false);
                this.buttonSkip.y = -1000;
                this.skipTimer = this.time.delayedCall(900, () => {
                    this.buttonSkip.y = 48;
                    this.buttonSkip.setVisible(true);
                }, this);
            }
            else {
                this.gameplay.gameOver();
            }
        });
        this.buttonSkip.alpha = 0;
        this.buttonSkip.setOrigin(0,0.5);

        // hide user interface on start
        this.bgQuestion.alpha = 0;
        this.buttonBack.alpha = 0;
        this.txtScore.alpha = 0;
        this.txtAttempts.alpha = 0;

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on("resize", (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

    endScreen() {

        this.gameCompleted = true;

        // circle
        this.circle = this.add.image(width/2, height/2, 'circle');
        this.circle.scaleX = .9;
        this.circle.scaleY = .9;

         // button play again
         this.buttonPlayAgain = this.add.image(width/2, height/2 + 125, 'button').setInteractive({ useHandCursor: true });
         this.buttonPlayAgain.scaleX = .8;
         this.buttonPlayAgain.on("pointerup", () => {
             this.scene.stop("gameplay");
             this.scene.start("menu");
         });
         this.txtPlayAgain = this.add.text(width/2, height/2 + 125, labels.playAgain, { fontFamily: "bold", fontSize: 28, color: "#000000" });
         this.txtPlayAgain.setOrigin(0.5,0.5);
 
         // button stop
         this.buttonStop = this.add.image(width/2, height/2 + 210, 'button').setInteractive({ useHandCursor: true });
         this.buttonStop.scaleX = .8;
         this.buttonStop.on("pointerup", () => {
             location.assign(webUrl);
         });
         this.txtStop = this.add.text(width/2, height/2 + 210, labels.stop, { fontFamily: "bold", fontSize: 28, color: "#000000" });
         this.txtStop.setOrigin(0.5,0.5);
 
         // green circle and countries
         this.circleGreen = this.add.image(width/2 - 70, height/2 - 220, 'circleGreen');
         this.circleGreen.scaleX = 1.3;
         this.circleGreen.scaleY = 1.3;
         this.txtCountries = this.add.text(width/2, height/2 - 220, labels.countries, { fontFamily: "extraBold", fontSize: 32, color: '#000000' });
         this.txtCountries.setOrigin(0,.5);
         // number of countries
         this.correctAnswers = questionsArray.length - skips;        
         this.txtNumberOfCountries = this.add.text(this.circleGreen.x, this.circleGreen.y, String(this.correctAnswers), { fontFamily: "extraBold", fontSize: 58, color: '#000000' });
         this.txtNumberOfCountries.setOrigin(.5,.5);
         // circle yellow and attempts
         this.circleYellow = this.add.image(width/2 - 70, height/2 - 100, 'circleYellow');
         this.circleYellow.scaleX = 1.3;
         this.circleYellow.scaleY = 1.3;
         this.txtAttemptsEnd = this.add.text(width/2, this.circleYellow.y, labels.attemptsEnd, { fontFamily: "extraBold", fontSize: 32, color: '#000000' });
         this.txtAttemptsEnd.setOrigin(0,.5);
         // number of attempts
         this.txtNumberOfAttempts = this.add.text(this.circleYellow.x, this.circleYellow.y, String(attempts), { fontFamily: "extraBold", fontSize: 58, color: '#000000' });
         this.txtNumberOfAttempts.setOrigin(.5,.5);
         // red circle and skip
         this.circleRed = this.add.image(width/2 - 70, height/2 + 25, 'circleRed');
         this.circleRed.scaleX = 1.3;
         this.circleRed.scaleY = 1.3;
         this.txtSkip = this.add.text(width/2, height/2 + 25, labels.skipped, { fontFamily: "extraBold", fontSize: 32, color: '#000000' });
         this.txtSkip.setOrigin(0,.5);
         // number of skips
         this.txtNumSkip = this.add.text(this.circleRed.x, this.circleRed.y, String(skips), { fontFamily: "extraBold", fontSize: 58, color: '#000000' });
         this.txtNumSkip.setOrigin(.5,.5);
        // tween objects
        tweenObj(this, this.circle, 0, 1);
        tweenObj(this, this.buttonStop, 0, 1);
        tweenObj(this, this.buttonPlayAgain, 0, 1);
        tweenObj(this, this.txtStop, 0, 1);
        tweenObj(this, this.txtPlayAgain, 0, 1);
        tweenObj(this, this.txtAttemptsEnd, 0, 1);
        tweenObj(this, this.txtNumberOfAttempts, 0, 1);
        tweenObj(this, this.txtNumSkip, 0, 1);
        tweenObj(this, this.circleGreen, 0, 1);
        tweenObj(this, this.circleYellow, 0, 1);
        tweenObj(this, this.circleRed, 0, 1);
        tweenObj(this, this.txtNumberOfCountries, 0, 1);
        tweenObj(this, this.txtCountries, 0, 1);
        tweenObj(this, this.txtSkip, 0, 1);
        tweenObj(this, this.buttonSkip, 0, 1);

        // create two sprite
        this.armadillo1 = this.add.image(width+150, height-45, "armadillo1");
        this.anim = this.add.sprite(this.armadillo1.x-5, this.armadillo1.y-35, 'armadillo2');

        this.startAnimation();

        // animation config
        let animConfig = {
            key: "gettingUp",
            frames: this.anims.generateFrameNumbers("armadillo2", { frames: [ 0,1,2,3,4,5,6,7,8 ] }),
            frameRate: 12,
        };
        let animConfig2 = {
            key: "walking",
            frames: this.anims.generateFrameNumbers("armadillo2", { frames: [ 9,10,11,12,13,14,15,16,17,18,19,20 ] }),
            frameRate: 12,
            repeat: -1
        };
        this.anims.create(animConfig);
        this.anims.create(animConfig2);
    }

    startAnimation() {
        this.tweens.add({
            targets: this.armadillo1,
            ease: "Linear",
            x: "-=320",
            duration: 2400
        });
        this.tweens.add({
            targets: this.armadillo1,
            ease: "Linear",
            angle: -360,
            duration: 800,
            repeat: 2,
            onComplete: ()=> {
                // hide
                this.armadillo1.visible = false;
                this.anim.setPosition(this.armadillo1.x-5, this.armadillo1.y-35);
                // play new anim
                this.anim.anims.play("gettingUp");

                let timer = this.time.delayedCall(700, ()=> {
                    this.anim.anims.play("walking");
                    this.tweens.add({
                        targets: this.anim,
                        x: -400,
                        duration: 10500,
                        onComplete: () => {
                            // restart animation
                            this.armadillo1.visible = true;
                            this.armadillo1.setPosition(width+150, height-45);
                            this.anim.setPosition(this.armadillo1.x-5, this.armadillo1.y-35);

                            let timerRestart = this.time.delayedCall(3000, ()=> {
                                this.startAnimation();
                            });
                        }
                    });
                }); 
            }
        });
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
       // question bg
       this.bgQuestion.setPosition(width/2, 45, "bgQuestion");
       this.questionText.setPosition(width/2 + 15, 45);
       this.txtIncorrect.setPosition(width/2, height-20);
       this.txtScore.setPosition(width/2 + 160, 75);
       this.txtAttempts.setPosition(width/2 - 160, 75);
       this.buttonBack.setPosition(45, 40);
       this.buttonSkip.setPosition(width/2 + 260, 48);
       this.buttonSound.setPosition(20, height - 20);
       if (this.gameCompleted === true) {
            this.anim.setPosition(this.anim.x, height-10);
            this.circleGreen.setPosition(width/2 - 70, height/2 - 220);
            this.txtCountries.setPosition(width/2, height/2 - 220);
            this.txtNumberOfCountries.setPosition(this.circleGreen.x, this.circleGreen.y);
            this.txtStop.setPosition(width/2, height/2 + 210);
            this.buttonStop.setPosition(width/2, height/2 + 210);
            this.txtPlayAgain.setPosition(width/2, height/2 + 125);
            this.buttonPlayAgain.setPosition(width/2, height/2 + 125);
            this.circle.setPosition(width/2, height/2);
            this.circleYellow.setPosition(width/2 - 70, height/2 - 100);
            this.txtAttemptsEnd.setPosition(width/2, this.circleYellow.y);
            this.txtNumberOfAttempts.setPosition(this.circleYellow.x, this.circleYellow.y);
            this.circleRed.setPosition(width/2 - 70, height/2 + 25);
            this.txtSkip.setPosition(width/2, height/2 + 25);
            this.txtNumSkip.setPosition(this.circleRed.x, this.circleRed.y);
       }
    }
}