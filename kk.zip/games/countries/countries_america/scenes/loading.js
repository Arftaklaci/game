class Loading extends Phaser.Scene
{    
    constructor()
    {
        super({
            
            key   : 'loading',
            pack  : 
            {
                files : 
                [
                    // pre-preload these images
                    { type: 'image', key: 'preloader1', url: '/games/countries/countries_america/img/preloader1.png' },
                    { type: 'image', key: 'preloader2', url: '/games/countries/countries_america/img/preloader2.png' },
                    { type: 'image', key: 'btnPlay', url: '/games/countries/countries_america/img/btnPlay.png' },
                ] 
            }
        })
    }
    
    setPreloadSprite (sprite) 
    {
		this.preloadSprite = { sprite: sprite, width: sprite.width, height: sprite.height }
		sprite.visible = true
		// set callback for loading progress updates
		this.load.on('progress', this.onProgress, this);
	}
	
	onProgress (value) {
		if (this.preloadSprite) {
			// calculate width based on value (0.0 .. 1.0)
            let w = Math.floor(this.preloadSprite.width * value);
			// set width of sprite			
			this.preloadSprite.sprite.frame.width = w;
            this.preloadSprite.sprite.frame.cutWidth = w;
			// update screen
            this.preloadSprite.sprite.frame.updateUVs();
            // adjust positions while loading
            this.setPositions();
		}
    }
    
    preload(){

        // load custom fonts (extra bold loaded in index.html)
        this.font1 = this.add.text(0, 0, 'custom font', {
            fontFamily: "regular", fontSize: 16, color: '#000000'
        });
        this.font1.setVisible(false);
        this.font3 = this.add.text(0, 0, 'custom font', {
            fontFamily: "semiBold", fontSize: 16, color: '#000000'
        });
        this.font3.setVisible(false);
        this.font2 = this.add.text(0, 0, 'custom font', {
            fontFamily: "bold", fontSize: 16, color: '#000000'
        });
        this.font2.setVisible(false);

        // init width and height
        width = this.cameras.main.width;
        height = this.cameras.main.height;

        // display loading bar
		this.preloader1 = this.add.sprite(width/2, height/2 + 140, "preloader1");
		this.preloader2 = this.add.sprite(width/2, height/2 + 140, "preloader2");
        this.setPreloadSprite(this.preloader2);
        // play button
        this.btnPlay = this.add.image(width/2, height/2 + 140, "btnPlay");
        this.btnPlay.setVisible(false);

        // display text
        this.txtWebsite = this.add.text(width/2, height/2 - 150, labels.website, { fontFamily: "extraBold", fontSize: 60, color: '#000000' });
        this.txtTitle = this.add.text(width/2, height/2 - 80, labels.title, { fontFamily: "extraBold", fontSize: 55, color: '#FFFFFF' });
        this.txtTitle.setOrigin(0.5, 0.5);
        this.txtWebsite.setOrigin(0.5, 0.5);

        // animation
        this.load.spritesheet('bird', '/games/countries/countries_america/img/bird.png', { frameWidth: 366, frameHeight: 215 });
        
        // countries
        this.load.image('antiguaAndBarbuda', '/games/countries/countries_america/img/antiguaAndBarbuda.png');
        this.load.image('argentina', '/games/countries/countries_america/img/argentina.png');
        this.load.image('barbados', '/games/countries/countries_america/img/barbados.png');
        this.load.image('belize', '/games/countries/countries_america/img/belize.png');
        this.load.image('bolivia', '/games/countries/countries_america/img/bolivia.png');
        this.load.image('brazil', '/games/countries/countries_america/img/brazil.png');
        this.load.image('canada', '/games/countries/countries_america/img/canada.png');
        this.load.image('chile', '/games/countries/countries_america/img/chile.png');
        this.load.image('colombia', '/games/countries/countries_america/img/colombia.png');
        this.load.image('costaRica', '/games/countries/countries_america/img/costaRica.png');
        this.load.image('cuba', '/games/countries/countries_america/img/cuba.png');
        this.load.image('dominica', '/games/countries/countries_america/img/dominica.png');
        this.load.image('dominicanRepublic', '/games/countries/countries_america/img/dominicanRepublic.png');
        this.load.image('ecuador', '/games/countries/countries_america/img/ecuador.png');
        this.load.image('elSalvador', '/games/countries/countries_america/img/elSalvador.png');
        this.load.image('extraCaribbean', '/games/countries/countries_america/img/extraCaribbean.png');
        this.load.image('extraFalklands', '/games/countries/countries_america/img/extraFalklands.png');
        this.load.image('extraFrenchGuiana', '/games/countries/countries_america/img/extraFrenchGuiana.png');
        this.load.image('grenada', '/games/countries/countries_america/img/grenada.png');
        this.load.image('guatemala', '/games/countries/countries_america/img/guatemala.png');
        this.load.image('guyana', '/games/countries/countries_america/img/guyana.png');
        this.load.image('haiti', '/games/countries/countries_america/img/haiti.png');
        this.load.image('honduras', '/games/countries/countries_america/img/honduras.png');
        this.load.image('jamaica', '/games/countries/countries_america/img/jamaica.png');
        this.load.image('mexico', '/games/countries/countries_america/img/mexico.png');
        this.load.image('nicaragua', '/games/countries/countries_america/img/nicaragua.png');
        this.load.image('panama', '/games/countries/countries_america/img/panama.png');
        this.load.image('paraguay', '/games/countries/countries_america/img/paraguay.png');
        this.load.image('peru', '/games/countries/countries_america/img/peru.png');
        this.load.image('saintKittsAndNevis', '/games/countries/countries_america/img/saintKittsAndNevis.png');
        this.load.image('saintLucia', '/games/countries/countries_america/img/saintLucia.png');
        this.load.image('saintVincentAndGrenadines', '/games/countries/countries_america/img/saintVincentAndGrenadines.png');
        this.load.image('suriname', '/games/countries/countries_america/img/suriname.png');
        this.load.image('trinidadAndTobago', '/games/countries/countries_america/img/trinidadAndTobago.png');
        this.load.image('unitedStates', '/games/countries/countries_america/img/unitedStates.png');
        this.load.image('uruguay', '/games/countries/countries_america/img/uruguay.png');
        this.load.image('venezuela', '/games/countries/countries_america/img/venezuela.png');

        // spritesheets
        this.load.spritesheet('bahamas', '/games/countries/countries_america/img/bahamas.png', { frameWidth: 182, frameHeight: 208 });

        // buttons
        this.load.spritesheet('button', '/games/countries/countries_america/img/button.png', {frameWidth: 420, frameHeight: 62});
        this.load.image('btnPlay', '/games/countries/countries_america/img/btnPlay.png');
        this.load.image('buttonBack', '/games/countries/countries_america/img/buttonBack.png');
        this.load.image('buttonBackBlack', '/games/countries/countries_america/img/buttonBackBlack.png');
        this.load.image('buttonStart', '/games/countries/countries_america/img/buttonStart.png');
        this.load.image('buttonMap', '/games/countries/countries_america/img/buttonMap.png');
        this.load.image('buttonMapWhite', '/games/countries/countries_america/img/buttonMapWhite.png');
        this.load.image('buttonOptions', '/games/countries/countries_america/img/buttonOptions.png');
        this.load.spritesheet('buttonToggle', '/games/countries/countries_america/img/buttonToggle.png', {frameWidth: 89, frameHeight: 52 });
        
        // images
		this.load.spritesheet('bgQuestion', '/games/countries/countries_america/img/bgQuestion.png', { frameWidth: 500, frameHeight: 65 });
		this.load.image('bgWhite', '/games/countries/countries_america/img/bgWhite.jpg');
		this.load.image('rectangle', '/games/countries/countries_america/img/rectangle.jpg');
		this.load.image('map', '/games/countries/countries_america/img/map.png');
		this.load.image('circle', '/games/countries/countries_america/img/circle.png');
		this.load.image('circleRed', '/games/countries/countries_america/img/circleRed.png');
		this.load.image('circleGreen', '/games/countries/countries_america/img/circleGreen.png');
		this.load.image('circleYellow', '/games/countries/countries_america/img/circleYellow.png');
		this.load.image('lineAntigua', '/games/countries/countries_america/img/lineAntigua.png');
		this.load.image('lineGrenada', '/games/countries/countries_america/img/lineGrenada.png');
		this.load.image('lineSaintKitts', '/games/countries/countries_america/img/lineSaintKitts.png');
		this.load.image('lineSaintLucia', '/games/countries/countries_america/img/lineSaintLucia.png');
		this.load.image('lineSaintVincent', '/games/countries/countries_america/img/lineSaintVincent.png');
		this.load.image('lineSalvador', '/games/countries/countries_america/img/lineSalvador.png');
		this.load.image('mouseOverMicrostate', '/games/countries/countries_america/img/mouseOverMicrostate.png');
        this.load.image('underline', '/games/countries/countries_america/img/underline.png');

        // plugins
        this.url = '/games/countries/countries_america/plugins/pinchplugin.min.js';
        this.url2 = '/games/countries/countries_america/plugins/mousewheelplugin.min.js';
        this.url3 = '/games/countries/countries_america/plugins/rexscrollerplugin.min.js';

        this.load.plugin('rexpinchplugin', this.url, true);
        this.load.plugin('rexmousewheeltoupdownplugin', this.url2, true);
        this.load.plugin('rexscrollerplugin', this.url3, true);
        
        // sounds
		this.load.audio('wrongSound', ['/games/countries/countries_america/audio/wrongSound.mp3', '/games/countries/countries_america/audio/wrongSound.ogg']);
		this.load.audio('correctSound', ['/games/countries/countries_america/audio/correctSound.mp3', '/games/countries/countries_america/audio/correctSound.ogg']);
		this.load.audio('gameOverSound', ['/games/countries/countries_america/audio/gameOverSound.mp3', '/games/countries/countries_america/audio/gameOverSound.ogg']);
    }
    
    create() {    

        // play button
        this.btnPlay.setVisible(true);
        this.btnPlay.setInteractive({useHandCursor: true})
        this.btnPlay.on("pointerup", () => { 
            this.scene.start("menu");
        }, this);

        // remove preloader
        this.preloader1.destroy();
        this.preloader2.destroy();
        
        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on("resize", (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.preloader1.setPosition(width/2, height/2 + 170);
        this.preloader2.setPosition(width/2, height/2 + 170);
        this.btnPlay.setPosition(width/2, height/2 + 170);
        this.txtTitle.setPosition(width/2, height/2 - 80);
        this.txtWebsite.setPosition(width/2, height/2 - 150);
    }
}