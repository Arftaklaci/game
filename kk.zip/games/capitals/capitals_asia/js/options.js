var mouseIsDown = false;
var distX = 0;

function mouseDown() {
    //set the mouseIsDown to true
    mouseIsDown = true;
    startX = game.input.y;
}

function mouseUp() {
    mouseIsDown = false;
}

var optionsState = {
    create: function () {

        mouseWheelScroll();

        game.input.onUp.add(mouseUp, this);
        game.input.onDown.add(mouseDown, this);

        // bg rectangle
        bg = game.add.image(0, 0, 'bg');

        // *** SELECT ANY COUNTRY IN ANY REGION

        // capitals in western asia
        westernGroup = game.add.group();
        westernGroup.visible = false;

        // eastern group
        easternGroup = game.add.group();
        easternGroup.visible = false;

        // rectangle on top, hide capitals
        bgTop = game.add.image(0, 0, 'bg_top');
        bgTop.height = 150;

        // eastern
        //texteastAsia = game.add.bitmapText(50, 110, 'os-blue-bold', easternLabel.toLocaleUpperCase(), 26);
        texteastAsia = game.add.text(50, 110, easternLabel.toLocaleUpperCase(), {font:"26px bold", fill:"#0099ff"});
        texteastAsia.visible = false;

        // add all capitals to array and reorder items alphabetically
        array4 = [];

        eastAsia.forEach(function (fr) {
            array4.push(capitals[fr]);
        }, this)

        array4 = array4.sort(Intl.Collator(collator).compare);

        yPos = 170
        array4.forEach(function (country) {

            // write text
            writeText(50, yPos, country, easternGroup);

            // get index
            let index = capitals.indexOf(country);

            // create a button for each country
            addButton(W - 120, yPos - 5, index, toggleCapitals, easternGroup);

            yPos += 50;
        }, this)
       
        // western
        //txtWesternGroup = game.add.bitmapText(50, 110, 'os-blue-bold', westernLabel.toLocaleUpperCase(), 26);
        txtWesternGroup = game.add.text(50, 110, westernLabel.toLocaleUpperCase(), {font:"26px bold", fill:"#0099ff"});
        txtWesternGroup.visible = false;

        // add all capitals to array and reorder items alphabetically
        array2 = [];

        westernAsia.forEach(function (fr) {
            array2.push(capitals[fr]);
        }, this);

        array2 = array2.sort(Intl.Collator(collator).compare);

        yPos = 170;
        array2.forEach(function (country) {

            // write text
            writeText(50, yPos, country, westernGroup);

            // get index
            let index = capitals.indexOf(country);

            // create a button for each country
            addButton(W - 120, yPos - 5, index, toggleCapitals, westernGroup);

            yPos += 50
        }, this);

        // central group
        centralGroup = game.add.group();
        centralGroup.visible = false;

        if (game.global.instructions === true) {
            if (game.device.desktop) {
                scroll_instruction = game.add.sprite(250, 400, 'scroll_desktop');
            } else {
                scroll_instruction = game.add.sprite(250, 400, 'scroll_mobile');
            }
            centralGroup.add(scroll_instruction);
        }

        //txtCentral = game.add.bitmapText(50, 110, 'os-blue-bold', centralLabel.toLocaleUpperCase(), 25, centralGroup);
        text_central_and_eastern = game.add.text(50, 110, centralLabel.toLocaleUpperCase(), {font:"25px bold", fill:"#0099ff"}, centralGroup);

        // add all capitals to array and reorder items alphabetically
        array1 = [];

        centralAndNorthernAsia.forEach(function (f) {
            array1.push(capitals[f]);
        }, this);

        array1 = array1.sort(Intl.Collator(collator).compare);

        var yPos = 170;
        array1.forEach(function (country) {

            // write text
            writeText(50, yPos, country, centralGroup);

            // get index
            let index = capitals.indexOf(country);

            // create a button for each country
            addButton(W - 120, yPos - 5, index, toggleCapitals, centralGroup);

            yPos += 50
        }, this)

        // south east
        southEastGroup = game.add.group();
        southEastGroup.visible = false;

        //textSouthEast = game.add.bitmapText(50, 110, 'os-blue-bold', southEastLabel.toLocaleUpperCase(), 26, southEastGroup)
        textSouthEast = game.add.text(50, 110, southEastLabel.toLocaleUpperCase(), {font:"26px bold", fill:"#0099ff"}, southEastGroup);

        // add all capitals to array and reorder items alphabetically
        array3 = [];

        southEastAsia.forEach(function (fr) {
            array3.push(capitals[fr]);
        }, this)

        array3 = array3.sort(Intl.Collator(collator).compare);

        yPos = 170;
        array3.forEach(function (country) {

            // write text
            writeText(50, yPos, country, southEastGroup);

            // get index
            let index = capitals.indexOf(country);

            // create a button for each country
            addButton(W - 120, yPos - 5, index, toggleCapitals, southEastGroup);

            yPos += 50;
        }, this);

        // south
        southGroup = game.add.group()
        southGroup.visible = false

        //txtSouth = game.add.bitmapText(50, 110, 'os-blue-bold', southernLabel.toLocaleUpperCase(), 26, southGroup)
        txtSouth = game.add.text(50, 110, southernLabel.toLocaleUpperCase(), {font:"26px bold", fill:"#0099ff"}, southGroup);

        // add all capitals to array and reorder items alphabetically
        array5 = []

        southAsia.forEach(function (f) {
            array5.push(capitals[f])
        }, this)

        array5 = array5.sort(Intl.Collator(collator).compare);

        yPos = 170
        array5.forEach(function (country) {

            // write text
            writeText(50, yPos, country, southGroup)

            // get index
            let index = capitals.indexOf(country)

            // create a button for each country
            addButton(W - 120, yPos - 5, index, toggleCapitals, southGroup)

            yPos += 50
        }, this)

        // text options
        //textOptions = game.add.bitmapText(W - 40, 22, 'os-blue-extra-bold', options_label, 36)
        textOptions = game.add.text(W - 40, 22, options_label, {font:"36px extraBold", fill:"#0099ff"});

        textOptions.anchor.setTo(1, 0)
        buttonOptions = game.add.button(W - 55 - textOptions.width, 18, 'button_options')
        buttonOptions.anchor.setTo(1, 0)
        buttonOptions.scale.x = .8
        buttonOptions.scale.y = .8

        // button back
        buttonBackSmall = game.add.button(20, 21, 'button_back')
        //textBack = game.add.bitmapText(55, 23, 'open_sans_bold', back_label, 26)
        textBack = game.add.text(55, 23, back_label, {font:"26px bold", fill:"#000000"});
        buttonBackClickable = game.add.button(10, 20, 'button_invisible', goBack)
        buttonBackClickable.width = 60 + textBack.width
        buttonBackClickable.height = 40

        // ** BASIC OPTIONS(sound, number of capitals, regions)
        regionsGroup = game.add.group()

        //selectAtleast = game.add.bitmapText(W / 2, 670, 'os_red_bold', select_atleast_label, 24, regionsGroup)
        selectAtleast = game.add.text(W/2, 670, select_atleast_label, {font:"24px bold", fill:"#f80007"}, regionsGroup);
        selectAtleast.visible = false
        selectAtleast.anchor.setTo(0.5, 0)

        // number of capitals
        //textNumberOfCapitals = game.add.bitmapText(20, 240, 'os-blue-bold', number_of_capitals_label, 27, regionsGroup)
        textNumberOfCapitals = game.add.text(20, 240, number_of_capitals_label, {font:"27px bold", fill:"#0099ff"}, regionsGroup);

        //numberOfCapitals = game.add.bitmapText(350, 235, 'open_sans_bold', capitalsUsed, 36, regionsGroup)
        numberOfCapitals = game.add.text(350, 235, capitalsUsed, {font:"36px bold", fill:"#000000"}, regionsGroup);

        // capitals
        //textCapitals = game.add.bitmapText(20, 340, 'os-blue-bold', capitals_label, 27, regionsGroup)
        textCapitals = game.add.text(20, 340, capitals_label, {font:"27px bold", fill:"#0099ff"}, regionsGroup);

        // regions text
        //southEastTxt = game.add.bitmapText(20, 395, 'open_sans_bold', southEastLabel, 21, regionsGroup)
        southEastTxt = game.add.text(20, 395, southEastLabel, {font:"21px bold", fill:"#000000"}, regionsGroup);
        //southernTxt = game.add.bitmapText(20, 445, 'open_sans_bold', southernLabel, 21, regionsGroup)
        southernTxt = game.add.text(20, 445, southernLabel, {font:"21px bold", fill:"#000000"}, regionsGroup);
        //centralTxt = game.add.bitmapText(20, 495, 'open_sans_bold', centralLabel, 21, regionsGroup)
        centralTxt = game.add.text(20, 495, centralLabel, {font:"21px bold", fill:"#000000"}, regionsGroup);
        //westernTxt = game.add.bitmapText(20, 545, 'open_sans_bold', westernLabel, 21, regionsGroup)
        westernTxt = game.add.text(20, 545, westernLabel, {font:"21px bold", fill:"#000000"}, regionsGroup);
        //easternTxt = game.add.bitmapText(20, 595, 'open_sans_bold', easternLabel, 21, regionsGroup)
        easternTxt = game.add.text(20, 595, easternLabel, {font:"21px bold", fill:"#000000"}, regionsGroup);

        // select links
        //select_south = game.add.bitmapText(W - 20, 395, 'open_sans_bold', select_label, 20, regionsGroup)
        select_south = game.add.text(W-20, 395, select_label, {font:"20px bold", fill:"#000000"}, regionsGroup);
        //select_southern = game.add.bitmapText(W - 20, 445, 'open_sans_bold', select_label, 20, regionsGroup)
        select_southern = game.add.text(W-20, 445, select_label, {font:"20px bold", fill:"#000000"}, regionsGroup);
        //select_central_and_eastern = game.add.bitmapText(W - 20, 495, 'open_sans_bold', select_label, 20, regionsGroup)
        select_central_and_eastern = game.add.text(W-20, 495, select_label, {font:"20px bold", fill:"#000000"}, regionsGroup);
        //select_western = game.add.bitmapText(W - 20, 545, 'open_sans_bold', select_label, 20, regionsGroup)
        select_western = game.add.text(W-20, 545, select_label, {font:"20px bold", fill:"#000000"}, regionsGroup);
        //select_east = game.add.bitmapText(W - 20, 595, 'open_sans_bold', select_label, 20, regionsGroup)
        select_east = game.add.text(W - 20, 595, select_label, {font:"20px bold", fill:"#000000"}, regionsGroup);

        select_south.anchor.setTo(1, 0)
        select_southern.anchor.setTo(1, 0)
        select_central_and_eastern.anchor.setTo(1, 0)
        select_western.anchor.setTo(1, 0)
        select_east.anchor.setTo(1, 0)

        // underlines
        underline1 = regionsGroup.create(select_south.x - select_south.width, select_south.y + 19, 'underline')
        underline1.width = select_south.width

        underline2 = regionsGroup.create(select_southern.x - select_southern.width, select_southern.y + 19, 'underline')
        underline2.width = select_southern.width

        underline3 = regionsGroup.create(select_central_and_eastern.x - select_central_and_eastern.width, select_central_and_eastern.y + 19, 'underline')
        underline3.width = select_central_and_eastern.width

        underline4 = regionsGroup.create(select_western.x - select_western.width, select_western.y + 19, 'underline')
        underline4.width = select_western.width

        underline5 = regionsGroup.create(select_east.x - select_east.width, select_east.y + 19, 'underline')
        underline5.width = select_east.width

        // invisible clickable buttons (over select texts)
        btnSelectSouthEast = game.add.button(select_south.x + 10, select_south.y - 8, 'button_invisible', selectClicked, this)
        btnSelectSouthEast.width = 20 + select_south.width
        btnSelectSouthEast.height = 40

        btnSelectSouthern = game.add.button(select_southern.x + 10, select_southern.y - 8, 'button_invisible', selectClicked, this)
        btnSelectSouthern.width = 20 + select_southern.width
        btnSelectSouthern.height = 40

        btnSelectCentral = game.add.button(select_central_and_eastern.x + 10, select_central_and_eastern.y - 8, 'button_invisible', selectClicked, this)
        btnSelectCentral.width = 20 + select_central_and_eastern.width
        btnSelectCentral.height = 40

        btnSelectWestern = game.add.button(select_western.x + 10, select_western.y - 8, 'button_invisible', selectClicked, this)
        btnSelectWestern.width = 20 + select_western.width
        btnSelectWestern.height = 40

        btnSelectEastern = game.add.button(select_east.x + 10, select_east.y - 8, 'button_invisible', selectClicked, this)
        btnSelectEastern.width = 20 + select_east.width
        btnSelectEastern.height = 40

        btnSelectSouthEast.anchor.setTo(1, 0)
        btnSelectSouthern.anchor.setTo(1, 0)
        btnSelectCentral.anchor.setTo(1, 0)
        btnSelectWestern.anchor.setTo(1, 0)
        btnSelectEastern.anchor.setTo(1, 0)

        regionsGroup.add(btnSelectSouthEast)
        regionsGroup.add(btnSelectSouthern)
        regionsGroup.add(btnSelectWestern)
        regionsGroup.add(btnSelectCentral)
        regionsGroup.add(btnSelectEastern)

        select_south.anchor.setTo(1, 0)
        select_southern.anchor.setTo(1, 0)
        select_central_and_eastern.anchor.setTo(1, 0)
        select_western.anchor.setTo(1, 0)
        select_east.anchor.setTo(1, 0)

        // toggle buttons for regions
        toggleSouthEast = game.add.button(W - 35 - select_south.width, 390, 'button_toggle', toggleRegions, this, null, null, null, null, regionsGroup);
        toggleSouthEast.frame = southEastBtn;
        toggleSouth = game.add.button(W - 35 - select_south.width, 440, 'button_toggle', toggleRegions, this, null, null, null, null, regionsGroup);
        toggleSouth.frame = southernBtn;
        toggleCentral = game.add.button(W - 35 - select_south.width, 490, 'button_toggle', toggleRegions, this, null, null, null, null, regionsGroup);
        toggleCentral.frame = centralBtn;
        toggleWestern = game.add.button(W - 35 - select_south.width, 540, 'button_toggle', toggleRegions, this, null, null, null, null, regionsGroup);
        toggleWestern.frame = westernBtn;
        toggleEast = game.add.button(W - 35 - select_south.width, 590, 'button_toggle', toggleRegions, this, null, null, null, null, regionsGroup);
        toggleEast.frame = eastBtn;

        toggleSouthEast.anchor.setTo(1, 0);
        toggleSouth.anchor.setTo(1, 0);
        toggleCentral.anchor.setTo(1, 0);
        toggleWestern.anchor.setTo(1, 0);
        toggleEast.anchor.setTo(1, 0);

        // sound
        //text_sound = game.add.bitmapText(20, 140, 'os-blue-bold', sound_label, 27, regionsGroup);
        text_sound = game.add.text(20, 140, sound_label, {font:"27px bold", fill:"#0099ff"}, regionsGroup);

        button_sound = game.add.button(W - 35 - select_south.width, 137, 'button_toggle', toggleSound, this, null, null, null, null, regionsGroup);
        button_sound.frame = soundFrame;
        button_sound.anchor.setTo(1, 0);
    },

    update: function () {
        if (mouseIsDown === true && (easternGroup.visible === true ||     westernGroup.visible === true)) {
            //get the distance between the start and end point
            distX = Math.abs(game.input.y - startX);
            //if the distance is greater than 50 pixels
            if (distX > 50) {
                if (distX > 100) {
                    distX = 100
                }
                swipeDone();
            }
        }

        if (westernGroup.y < -320) {
            westernGroup.y = -320
        } 
        else if (westernGroup.y > 0) {
            westernGroup.y = 0
        }
    }
}

function swipeDone() {
    //get the ending point
    var endX = game.input.y;

    if (westernGroup.visible === true) {
        if (endX < startX) {
            westernGroup.y -= distX / 6
        } else {
            westernGroup.y += distX / 6
        }
    }
}

function writeText(x_pos, yPos, this_text, this_group) {
    //country_text = game.add.bitmapText(x_pos, yPos, 'open_sans_bold', this_text, 24, this_group)
    country_text = game.add.text(x_pos, yPos, this_text, {font:"24px bold", fill:"#000000"}, this_group);
}

function addButton(x_pos, yPos, number, callback, btn_group) {
    toggle_btn = game.add.button(x_pos, yPos, 'button_toggle', callback, this, null, null, null, null, btn_group)
    toggle_btn.number = number
    toggle_btn.frame = toggleButtonFrames[number]
}

function selectClicked(btn) {

    // hide sound button, number of capitals, select at least text...
    regionsGroup.visible = false
    selectingRegions = false
    selectAtleast.visible = false

    if (btn === btnSelectSouthEast) {
        southEastGroup.visible = true

        // switch each single button in this group
        southEastGroup.forEach(function (toggle_btn) {
            if (toggle_btn.number != null) {
                toggle_btn.frame = toggleButtonFrames[toggle_btn.number]
            }
        }, this)
    } else if (btn === btnSelectSouthern) {
        southGroup.visible = true
        // switch each single button in this group
        southGroup.forEach(function (toggle_btn) {
            if (toggle_btn.number != null) {
                toggle_btn.frame = toggleButtonFrames[toggle_btn.number]
            }
        }, this)
    } else if (btn === btnSelectCentral) {
        centralGroup.visible = true
        // switch each single button in this group
        centralGroup.forEach(function (toggle_btn) {
            if (toggle_btn.number != null) {
                toggle_btn.frame = toggleButtonFrames[toggle_btn.number]
            }
        }, this)

        // scroll instructions
        if (!game.device.desktop && game.global.instructions === true) {
            tween = game.add.tween(scroll_instruction).to({
                y: 300
            }, 700, "Linear", true, 0, 1, true)
            tween.onComplete.add(function () {
                scroll_instruction.visible = false
            }, this)

            game.global.instructions = false
        }
    } else if (btn === btnSelectWestern) {
        westernGroup.visible = true
        // show this text
        txtWesternGroup.visible = true;

        // switch each single button in this group
        westernGroup.forEach(function (toggle_btn) {
            if (toggle_btn.number != null) {
                toggle_btn.frame = toggleButtonFrames[toggle_btn.number]
            }
        }, this)
    } else if (btn === btnSelectEastern) {
        easternGroup.visible = true;
        // show this text
        texteastAsia.visible = true;

        // switch each single button in this group
        easternGroup.forEach(function (toggle_btn) {
            if (toggle_btn.number != null) {
                toggle_btn.frame = toggleButtonFrames[toggle_btn.number]
            }
        }, this)
    }
}

function toggleCapitals(btn) {
    // remove this frame (map)
    if (btn.frame == 0) {
        for (let i = 0; i < frames.length; i++) {
            if (btn.number == frames[i]) {
                frames.splice(i, 1)
            }
        }
    } else // add this frame to the array
    {
        for (let i = 0; i < frames.length; i++) {
            if (frames.includes(btn.number) == false) {
                frames.push(btn.number)
            }
        }
        // make sure it runs at least once
        if (frames.length == 0) {
            if (frames.includes(btn.number) == false) {
                frames.push(btn.number)
            }
        }
    }

    // update capitals frames
    capitalsUsed = frames.length

    // update number of capitals
    numberOfCapitals.text = capitalsUsed.toString()

    // save toggle button frame (0 or 1)
    toggleButtonFrames[btn.number] = (toggleButtonFrames[btn.number] == 0) ? 1 : 0

    // switch frame of the current button
    btn.frame = (btn.frame == 0) ? 1 : 0
}

function toggleRegions(btn) {
    if (btn == toggleSouthEast) {
        // save toggle buttonframe
        southEastBtn = (southEastBtn == 0) ? 1 : 0

        // exclude frames (capitals)
        if (btn.frame == 0) {
            for (let j = 0; j < southEastAsia.length; j++) {
                for (let i = 0; i < frames.length; i++) {
                    if (frames[i] === southEastAsia[j]) {
                        // toggle buttons off
                        toggleButtonFrames[frames[i]] = 1

                        // remove these frames
                        frames.splice(i, 1);
                    }
                }
            }
        } else // include frames (capitals)
        {
            for (let j = 0; j < southEastAsia.length; j++) {
                if (frames.includes(southEastAsia[j]) == false) {
                    // toggle buttons on
                    toggleButtonFrames[southEastAsia[j]] = 0

                    // add these frames
                    frames.push(southEastAsia[j])
                }
            }
        }
    } else if (btn == toggleCentral) {

        centralBtn = (centralBtn === 0) ? 1 : 0

        // exclude
        if (btn.frame === 0) {
            for (let j = 0; j < centralAndNorthernAsia.length; j++) {
                for (let i = 0; i < frames.length; i++) {
                    if (frames[i] === centralAndNorthernAsia[j]) {

                        // toggle buttons off
                        toggleButtonFrames[frames[i]] = 1
                        frames.splice(i, 1);
                    }
                }
            }
        } else // include
        {
            for (let j = 0; j < centralAndNorthernAsia.length; j++) {
                if (frames.includes(centralAndNorthernAsia[j]) == false) {
                    // toggle buttons on
                    toggleButtonFrames[centralAndNorthernAsia[j]] = 0

                    frames.push(centralAndNorthernAsia[j])
                }
            }
        }
    } else if (btn == toggleSouth) {
        southernBtn = (southernBtn === 0) ? 1 : 0

        // exclude
        if (btn.frame == 0) {
            for (let j = 0; j < southAsia.length; j++) {
                for (let i = 0; i < frames.length; i++) {
                    if (frames[i] === southAsia[j]) {
                        // toggle buttons off
                        toggleButtonFrames[frames[i]] = 1

                        // remove these frames
                        frames.splice(i, 1);
                    }
                }
            }
        } else // include
        {
            for (let j = 0; j < southAsia.length; j++) {
                if (frames.includes(southAsia[j]) == false) {
                    // toggle buttons on
                    toggleButtonFrames[southAsia[j]] = 0

                    // add these frames
                    frames.push(southAsia[j])
                }
            }
        }
    } else if (btn == toggleWestern) {
        westernBtn = (westernBtn == 0) ? 1 : 0

        // exclude
        if (btn.frame == 0) {

            for (let j = 0; j < westernAsia.length; j++) {
                for (let i = 0; i < frames.length; i++) {
                    if (frames[i] === westernAsia[j]) {
                        toggleButtonFrames[frames[i]] = 1

                        frames.splice(i, 1);
                    }
                }
            }
        } else // include
        {
            for (j = 0; j < westernAsia.length; j++) {
                if (frames.includes(westernAsia[j]) == false) {
                    // toggle buttons on
                    toggleButtonFrames[westernAsia[j]] = 0

                    // add these frames
                    frames.push(westernAsia[j])
                }
            }
        }
    } else if (btn == toggleEast) {
        eastBtn = (eastBtn == 0) ? 1 : 0

        // exclude
        if (btn.frame == 0) {
            for (let j = 0; j < eastAsia.length; j++) {
                for (let i = 0; i < frames.length; i++) {
                    if (frames[i] === eastAsia[j]) {
                        toggleButtonFrames[frames[i]] = 1
                        frames.splice(i, 1);
                    }
                }
            }
        } else // include
        {
            for (let j = 0; j < eastAsia.length; j++) {
                if (frames.includes(eastAsia[j]) == false) {
                    // toggle buttons on
                    toggleButtonFrames[eastAsia[j]] = 0

                    // add these frames
                    frames.push(eastAsia[j])
                }
            }
        }
    }

    // IMPORTANT switch button's frame
    btn.frame = (btn.frame == 0) ? 1 : 0;
    // update capitals frames
    capitalsUsed = frames.length;
    // update number of capitals
    numberOfCapitals.text = capitalsUsed.toString();
}

function goBack() {
    // go to menu
    if (selectingRegions == true) {
        if (frames.length >= 5) {
            game.state.start("menu")
        } 
        else {
            selectAtleast.visible = true;
        }
    } 
    else // go to basic options
    {
        regionsGroup.visible = true;
        selectingRegions = true;
        southEastGroup.visible = false;
        southGroup.visible = false;
        westernGroup.visible = false;
        centralGroup.visible = false;
        easternGroup.visible = false;

        // hide text
        txtWesternGroup.visible = false;
        texteastAsia.visible = false;
    }
}
