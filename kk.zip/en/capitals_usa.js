var game = new Phaser.Game(500, 800, Phaser.Canvas, null, null, true)

game.global = 
{
	orientated    : false,
    instructions  : true,
}

// edit below 
collator = "en"
website_url = "https://world-geography-games.com/americas.html";
website_label = "World Geography Games"
title_label = "US States Capitals"
title_oneline = "US States Capitals"
play_again_label = "Play again"
stop_label = "Stop"
score_label = "score: "
final_score = "Score"
next_label = "Next"
out_of_label = "out of"
play_label = "play"
options_label = "options"
select_atleast_label = "Select at least 5 capitals"
back_label = "back"
sound_label = "SOUND"
number_of_capitals_label = "NUMBER OF CAPITALS"
capitals_label = "CAPITALS"
select_label = "select"
library_label = "library"

northernLabel = "Northeast"
westernLabel = "West"
midwestLabel = "Midwest"
southLabel = "South"

countries = ["New York", "Maryland", "Georgia", "Maine", "Texas", "Louisiana", "North Dakota", "Idaho", "Massachusetts", "Nevada", "West Virginia", "Wyoming", "South Carolina", "Ohio", "New Hampshire", "Colorado", "Iowa", "Delaware", "Kentucky", "Pennsylvania", "Connecticut", "Montana", "Hawaii", "Indiana", "Mississippi", "Missouri", "Alaska", "Michigan", "Nebraska", "Arkansas", "Wisconsin", "Alabama", "Vermont", "Tennessee", "Oklahoma", "Washington", "Arizona", "South Dakota", "Rhode Island", "North Carolina", "Virginia", "California", "Minnesota", "Oregon", "Utah", "New Mexico", "Illinois", "Florida", "Kansas", "New Jersey"];

capitals = ["Albany", "Annapolis", "Atlanta", "Augusta", "Austin", "Baton Rouge", "Bismarck", "Boise ", "Boston", "Carson City", "Charleston ", "Cheyenne ", "Columbia", "Columbus", "Concord", "Denver", "Des Moines", "Dover", "Frankfort", "Harrisburg", "Hartford", "Helena", "Honolulu", "Indianapolis", "Jackson", "Jefferson City", "Juneau", "Lansing", "Lincoln", "Little Rock", "Madison", "Montgomery", "Montpelier", "Nashville", "Oklahoma City", "Olympia", "Phoenix", "Pierre", "Providence", "Raleigh", "Richmond", "Sacramento", "Saint Paul", "Salem", "Salt Lake City", "Santa Fe", "Springfield",  "Tallahassee", "Topeka", "Trenton"];

// ** DO NOT EDIT BELOW!
// create new array, order alphabetically
countriesAlphabet = countries.slice().sort(Intl.Collator(collator).compare);

var capitalsUsed = 50;

// frames that will be used (frames represent images)
frames = [];
for (let f = 0; f < capitalsUsed; f++) {
    frames.push(f);
}

// always contains all frames, get random capitals from this array
allFrames = frames.slice();

northeast = [20,3,8,14,0,49,19,38,32];
west = [26,36,41,15,22,7,21,9,45,43,44,35,11];
midwest = [16,46,23,27,48,42,28,25,6,13,37,30]; 
south = [31,29,17,47,2,18,1,5,24,39,12,34,4,33,40,10];

// toggle buttons used for regions, frame 0 or 1
northernBtn = 0;
midwestBtn = 0;
westernBtn = 0;
southBtn = 0;

// toggle buttons used for countries, frame 0 or 1
toggleButtonFrames = [];

for (let i = 0; i < frames.length; i++) {
    // by default all buttons are on (frame 0)
    toggleButtonFrames.push(0);
}

// sound toggle button
soundFrame = 0;
// selecting regions or countries in options (back button depends on this)
selectingRegions = true;

// all capitals
haveLookalikes = [];
for (let i = 0; i < capitalsUsed; i++) {
    haveLookalikes.push(i);
}

// capitals from the same region
lookalikes = [
[20],[31,29],[17,47],[8,14],[2],[18],[16,46],[26],[0,49],[36],[1],[15],[5,24],[48],[19,38],[9],[25,6],[12],[39],[32,20],[3,8],[43],[44],[30,37],[4],[48],[11],[16],[46],[40],[23,27],[2,1],[3,14],[5,24],[10],[22],[7,9],[16,42],[32,0],[4,33],[10],[11,35],[6],[35,21],[9],[21],[13,30],[40],[46],[3,20]
];

// game states
game.state.add('boot', bootState);
game.state.add("Loading", loading);
game.state.add("menu", menuState);
game.state.add("options", optionsState);
game.state.add("library", libraryState);
game.state.add("level1", state1);
game.state.start("boot");