"use strict"
var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        });
    }
    
    create() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;
        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;

        // min max zoom
        if (this.sys.game.device.os.desktop) {
            this.minZoom = .75;  
            this.maxZoom = 1.6;
            camera.zoom = .75;
        }
        else {
            this.minZoom = .75;  
            this.maxZoom = 1.8;
            camera.zoom = .75;
        }

        // display countries in this scene
        this.displayMap(this);
        // get countries (sprites) array from the container
        this.countriesArray = this.mapContainer.getAll();
        // for each subject (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {
            /* development phase 
            this.countriesArray[i].setInteractive()
            this.input.setDraggable(this.countriesArray[i]);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {
                gameObject.x = dragX;
                gameObject.y = dragY;
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });
            */
            
            let subject = this.countriesArray[i];

            //interactive
             if (subject.name === subjects.cityOfLondon) {
                subject.setInteractive({ 
                    useHandCursor: true,             
                 });
             }
             else {
                subject.setInteractive({ 
                    useHandCursor: true,             
                    pixelPerfect: true,
                    alphaTolerance: 255
                 });
             }

             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over subject
                subject.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                       subject.setTintFill(0xFFFFFF);
                    }
                },this);
                subject.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        subject.clearTint();
                    }
                },this);
            }
            subject.on('pointerdown', () => {
                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });
            subject.on('pointerup', () => {
                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);
                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    subject.xPos = camera.x;
                    subject.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false) {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === subject.name) {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this subject
                            subject.disableInteractive();
                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }
                            // create the subject label
                            this.showLabels(subject);
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // else don't tap, drag the map
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();
        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false) {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();
                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip, ui.buttonSound],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                let dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {
                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        let drag1Vector = dragScale.drag1Vector;
                        //camera.scrollX -= drag1Vector.x / camera.zoom;
                        //camera.scrollY -= drag1Vector.y / camera.zoom;
                    }
                }).on('pinch', dragScale => {
                    let scaleFactor = dragScale.scaleFactor;
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                }, this);
                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }
        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 50, align: "center", color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 50, align: "center", color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });
        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                camera.zoom *= 0.9;
            }
        }
        // limit zoom
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.mapContainer.setSize(width, height);
        this.mapContainer.x = 0;
        this.mapContainer.y = 0;

        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2, height/2);
        }
    }

    getQuestion() {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;
        this.questionsArray.shift();

        // tween
        this.tweens.add({
           targets: [ui.questionText],
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;
        // play sound
        this.gameOverSound.play();
        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        ui.buttonSound.destroy();
        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {
        // tween camera
        if (camera.zoom > this.minZoom) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: this.minZoom,
                x: 0, 
                y: 0,
                duration: 1500,
                onComplete: () => {
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }
        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: 0,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showLabels(subject) {
        // rectangle
        subject.rect = this.add.sprite(subject.x, subject.y, "rectangle");
        // subject name
        subject.txt = this.add.text(subject.x, subject.y, subject.name, { fontFamily: "bold", fontSize: 22, align: "center", color: '#000000' });
        subject.txt.setOrigin(.5,.5);
        
        // position text
        if (subject.labelX) {
            subject.txt.x = subject.labelX;
            subject.txt.y = subject.labelY;
            subject.rect.x = subject.labelX;
            subject.rect.y = subject.labelY;
        }
        subject.rect.displayWidth = subject.txt.width + 4;
        subject.rect.displayHeight = subject.txt.height + 2;

        if (subject.hasLine) {
            let line;
            if (subject.name === subjects.alBahah) {
                line = this.add.image(subject.x+10, subject.y-60, "texture", "al-bahahLine.png").setOrigin(0,0);
            }
            this.mapContainer.add(line);
        }
    }

    displayMap(aScene) {
        this.map = this.add.image(width/2, height/2, "map");
        this.map.alpha = .3;
        
        // emirates
        aScene.riyadh = aScene.add.sprite(width/2 - 8.5, height/2 + 45.3, "texture", "riyadh.png");
        aScene.alQassim = aScene.add.sprite(width/2 - 89.6, height/2 - 106, "texture", "al-qassim.png");
        aScene.easternProvince = aScene.add.sprite(width/2 + 225.7, height/2 + 9.8, "texture", "easternProvince.png");
        aScene.najran = aScene.add.sprite(width/2 + 126, height/2 + 306.5, "texture", "najran.png");
        aScene.hail = aScene.add.sprite(width/2 - 154, height/2 - 144, "texture", "hail.png");
        aScene.alJawf = aScene.add.sprite(width/2 - 256, height/2 - 293.2, "texture", "al-jawf.png");
        aScene.northernBorders = aScene.add.sprite(width/2 - 151.2, height/2 - 298.4, "texture", "northernBorders.png");
        aScene.mecca = aScene.add.sprite(width/2 - 177.5, height/2 + 156.2, "texture", "mecca.png");
        aScene.medina = aScene.add.sprite(width/2 - 262, height/2 - 40.7, "texture", "medina.png");
        aScene.tabuk = aScene.add.sprite(width/2 - 358.4, height/2 - 153, "texture", "tabuk.png");

        aScene.asir = aScene.add.sprite(width/2 - 99.6, height/2 + 259.5, "texture", "asir.png");
        aScene.alBahah = aScene.add.sprite(width/2 - 165, height/2 + 205.5, "texture", "al-bahah.png");
        aScene.jazan = aScene.add.sprite(width/2 - 121.8, height/2 + 358.2, "texture", "jazan.png");

        // position labels
        aScene.alQassim.labelX = aScene.alQassim.x + 8;
        aScene.alQassim.labelY = aScene.alQassim.y + 25;
        aScene.alBahah.labelX = aScene.alBahah.x - 100;
        aScene.alBahah.labelY = aScene.alBahah.y + 55;
        aScene.mecca.labelX = aScene.mecca.x;
        aScene.mecca.labelY = aScene.mecca.y - 25;
        aScene.medina.labelX = aScene.medina.x + 20;
        aScene.medina.labelY = aScene.medina.y + 25;
        aScene.najran.labelX = aScene.najran.x - 60;
        aScene.najran.labelY = aScene.najran.y - 5;
        aScene.tabuk.labelX = aScene.tabuk.x;
        aScene.tabuk.labelY = aScene.tabuk.y - 50;
        aScene.northernBorders.labelX = aScene.northernBorders.x;
        aScene.northernBorders.labelY = aScene.northernBorders.y - 60;
        aScene.easternProvince.labelX = aScene.easternProvince.x + 50;
        aScene.easternProvince.labelY = aScene.easternProvince.y + 125;

        aScene.alBahah.hasLine = true;

        // names
        aScene.riyadh.name = subjects.riyadh;
        aScene.alQassim.name = subjects.alQassim;
        aScene.easternProvince.name = subjects.easternProvince;
        aScene.najran.name = subjects.najran;
        aScene.hail.name = subjects.hail;
        aScene.alJawf.name = subjects.alJawf;
        aScene.northernBorders.name = subjects.northernBorders;
        aScene.mecca.name = subjects.mecca;
        aScene.medina.name = subjects.medina;
        aScene.tabuk.name = subjects.tabuk;
        aScene.asir.name = subjects.asir;
        aScene.alBahah.name = subjects.alBahah;
        aScene.jazan.name = subjects.jazan;

        // create container 
        aScene.mapContainer = aScene.add.container(0, 0, [aScene.riyadh, aScene.alQassim, aScene.easternProvince, aScene.najran, aScene.hail, aScene.alJawf, aScene.northernBorders, aScene.mecca, aScene.medina, aScene.tabuk, aScene.asir, aScene.alBahah, aScene.jazan]);

        aScene.mapContainer.setSize(width, height);
        aScene.mapContainer.x = 0;
        aScene.mapContainer.y = 0;
     }
}