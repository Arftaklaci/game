"use strict"

class Menu extends Phaser.Scene {
    constructor() {
        super({
            key: "menu"
        })
    }

    create() {

        width = this.cameras.main.width;
        height = this.cameras.main.height;
        // gameplay scene
        this.map = this.add.image(width/2, height/2-50, "map");
        this.map.setScale(1.2,1.2);
        // circle
        this.circle = this.add.image(width/2, height/2, "circle");
        this.circle.scaleX = .85;
        this.circle.scaleY = .85;
        // title
        this.txtTitle = this.add.text(width/2, height/2 - 160, labels.titleTwo, {fontFamily: "extraBold", fontSize: 55, align: "center", color: "0x000000"});
        this.txtTitle.setOrigin(0.5,0.5);
       // buttons
       this.buttonPlay = this.add.image(width/2 - 50, height/2 + 20, 'buttonStart').setInteractive({useHandCursor: true});
       this.buttonPlay.on("pointerup", () => {
           this.scene.start("gameplay");
       }, this);
       this.buttonMap = this.add.image(width/2 - 50, height/2 + 120, 'buttonMap').setInteractive({useHandCursor: true});
       this.buttonMap.on("pointerup", () => {
           this.scene.start("graph");
       }, this);

       // button text
       this.txtPlay = this.add.text(width/2, height/2 - 14, labels.play, {fontFamily: "bold", fontSize: 40, color: "0x000000"}).setInteractive({useHandCursor: true});
       this.txtPlay.on("pointerup", () => {
           this.scene.start("gameplay");
       }, this);
       this.txtPlay.setOrigin(0,0.5);

       this.txtMap = this.add.text(width/2, height/2 + 198, labels.map, {fontFamily: "bold", fontSize: 40, color: "0x000000"}).setInteractive({useHandCursor: true});
       this.txtMap.on("pointerup", () => {
           this.scene.start("graph");
       }, this);
       this.txtMap.setOrigin(0,0.5);

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on("resize", (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;

        this.circle.setPosition(width/2, height/2);
        this.txtTitle.setPosition(width/2, height/2 - 160);
        this.buttonPlay.setPosition(width/2 - 60, height/2 + 12);
        this.buttonMap.setPosition(width/2 - 60, height/2 + 150);
        this.txtPlay.setPosition(width/2 + 10, height/2 + 10);
        this.txtMap.setPosition(width/2 + 10, height/2 + 148);
        this.map.setPosition(width/2, height/2);
    }
}
