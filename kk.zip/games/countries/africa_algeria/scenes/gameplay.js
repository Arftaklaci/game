"use strict"

var ui, camera, startTime, endTime, startX, startY, endX, endY;

class Gameplay extends Phaser.Scene {
    constructor() {
        super({
            key: 'gameplay'
        })
    }

    create() {

        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.score = +0;
        this.gameStarted = false;
        this.gameCompleted = false;
        this.canTap = false;
        this.canZoom = true;

        // get user interface scene (static objects)
        ui = this.scene.get("userInterface");
        // launch user interface 
        this.scene.launch("userInterface");
        this.scene.moveAbove("gameplay", "userInterface");
        // sounds
        this.wrongSound = this.sound.add("wrongSound");
        this.correctSound = this.sound.add("correctSound");
        this.gameOverSound = this.sound.add("gameOverSound");
       // camera
       camera = this.cameras.main;
       camera.scrollY = -40;

        // min max zoom
        this.minZoom = 0.5;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.8;
            camera.zoom = 0.5;
        }
        else {
            this.maxZoom = 2;
            camera.zoom = 0.5;
        }

        // display countries in this scene
        this.displayStates(this);
       
        // get countries (sprites) array from the container
        this.countriesArray = this.statesContainer.getAll();
        // for each country (sprite)
        for (let i = 0; i < this.countriesArray.length; i++) {

            let country = this.countriesArray[i];

            /* development phase
            country.setInteractive()
            this.input.setDraggable(country);
            this.input.on('drag', function (pointer, gameObject, dragX, dragY) {

                gameObject.x = dragX;
                gameObject.y = dragY;
        
            });
            this.input.on('dragend', function (pointer, gameObject) {
                console.log("endX: " + (gameObject.x - width/2))
                console.log("endY: " + (gameObject.y - height/2))
            });
            */

            // make countries sprites interactive
            country.setInteractive({ 
                useHandCursor: true,             
                pixelPerfect: true,
                alphaTolerance: 255
             });

             // mouse over
            if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
                // mouse over country
                country.on("pointerover", (pointer) => {
                    if (this.gameStarted === true) {
                        if (country.isSpritesheet === true) {
                            country.setFrame(1);
                        }
                        else {
                            country.setTintFill(0xFFFFFF);
                        }
                    }
                },this);

                country.on("pointerout", () => {
                    if (this.gameStarted === true) {
                        if (country.isSpritesheet === true) {
                            country.setFrame(0);
                        }
                        else {
                            country.clearTint();
                        }
                    }
                },this);
            }

            country.on('pointerdown', () => {

                // start x, y positions and current time
                startX = round(camera.scrollX, 1);
                startY = round(camera.scrollY, 1);
                startTime = round(this.time.now, 1);
            });

            country.on('pointerup', () => {

                endX = round(camera.scrollX, 1);
                endY = round(camera.scrollY, 1);
                endTime = round(this.time.now, 1);

                // click
                if (endTime - startTime < 254 && 
                    (endX + 4 >= startX && endX - 4 <= startX) &&
                    endY + 4 >= startY && endY - 4 <= startY) {
                    country.xPos = camera.x;
                    country.yPos = camera.y;

                    if (this.canTap === true && this.gameCompleted === false)
                    {
                        // increase attempts
                        attempts++;
                        ui.txtAttempts.text = labels.attempts + String(attempts);
                        // correct
                        if (ui.questionText.text === country.name)
                        {
                            // increase the score
                            this.score ++;
                            ui.txtScore.text = labels.score + String(this.score) + "/" + String(questionsArray.length);
                            this.correctSound.play();
                            // disable this country
                            country.disableInteractive();

                            // hide incorrect
                            if (ui.txtIncorrect.alpha === 1) {
                                tweenObj(this, ui.txtIncorrect, 1, 0);
                            }

                            // create the country label
                            this.showLabels(country);
    
                            // get new question
                            if (this.questionsArray.length > 0) {
                                this.getQuestion();
                            }
                            else {
                                this.gameOver();
                            }
                        }
                        else {
                            // wrong
                            tweenObj(this, ui.txtIncorrect, 0, 1);
                            this.wrongSound.play();
                        }
    
                        // you can tap after 600 ms again
                        this.canTap = false;
                        setTimeout(() => {
                            this.canTap = true;
                        }, 600);
                    }
                }
                // drag
                else {
                    // console.log("don't tap, drag the map");
                }
            });
        }
		
        // shuffle array defined in game.js
        shuffle(questionsArray);
        // clone questionsArray
        this.questionsArray = questionsArray.slice();

        // click anywhere to start          
        this.input.on('pointerup', () => {

            if (this.gameStarted === false)
            {
                // hide click to start text
                this.gameStarted = true;
                this.txtStart.destroy();

                // show ui
                this.tweens.add({
                    targets: [ui.bgQuestion, ui.buttonBack, ui.txtAttempts, ui.txtScore, ui.buttonSkip],
                    ease: "Linear",
                    alpha: 1,
                    duration: 600,
                 });

                setTimeout(() => {
                    this.canTap = true;
                }, 1000);

                // enable drag and pinch to zoom
                var dragScale = this.plugins.get('rexpinchplugin').add(this);
                dragScale.on('drag1', dragScale => {

                    // drag if game is not completed
                    if (this.gameCompleted === false) {
                        var drag1Vector = dragScale.drag1Vector;
                        camera.scrollX -= drag1Vector.x / camera.zoom;
                        camera.scrollY -= drag1Vector.y / camera.zoom;
                    }

                }).on('pinch', dragScale => {
                    var scaleFactor = dragScale.scaleFactor;
                    
                    // camera zoom
                    if (this.canZoom === true) {
                        if (this.gameCompleted === false) {
                            camera.zoom *= scaleFactor;
                        }
                    }
                    
                }, this);

                // show the first question
                this.getQuestion();
            }
        },this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);
            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
        }

        // tap on the map
        if (this.sys.game.device.os.desktop) {
            this.txtStart = this.add.text(width/2, height/2, labels.clickStart, { fontFamily: "bold", fontSize: 65, color: '#FFFFFF' });
        }
        else{
            this.txtStart = this.add.text(width/2, height/2, labels.tapStart, { fontFamily: "bold", fontSize: 65, color: '#FFFFFF' });
        }
        this.txtStart.setOrigin(0.5,0.5);

        // tween click to start text
        this.tweens.add({
            targets: [this.txtStart],
            ease: "Linear",
            alpha: 0,
            duration: 400,
            repeat: -1,
            yoyo: true,
         });

        // mouse over microstate sprite
        this.mouseOverMicro = this.add.image(0,0, 'mouseOverMicrostate');
        this.mouseOverMicro.setVisible(false);

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on('resize', (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }

	update(){
        
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop && this.gameCompleted === false) {
            if (this.cursorKeys.up.isDown && this.canZoom === true) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown && this.canZoom === true) {
                
                camera.zoom *= 0.9;
            }
        }
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.statesContainer.setSize(width, height);
        this.statesContainer.x = 0;
        this.statesContainer.y = 0; 
        if (this.txtStart != null) {
            this.txtStart.setPosition(width/2, height/2);
        }
    }

    getQuestion() {
        this.question = this.questionsArray[0];
        this.correctAnswer = this.questionsArray[0];
        ui.questionText.text = this.question;
        // tween
        this.tweens.add({
           targets: [ui.questionText],
           //scaleX: '-=.2',
           //angle: 10,
           ease: 'Power1',
           alpha: 0.2,
           duration: 200,
           repeat: 1,
           yoyo: true,
        });

        // remove the previous question
        this.questionsArray.shift();
    }

    gameOver() {
        ui.bgQuestion.setFrame(1);
        ui.questionText.x -= 20;
        ui.questionText.text = "Completed!";
        this.gameCompleted = true;

        // play sound
        this.gameOverSound.play();

        // remove score, attempts and back button
        ui.buttonBack.destroy();
        ui.bgQuestion.destroy();
        ui.questionText.destroy();
        ui.txtScore.destroy();
        ui.txtAttempts.destroy();
        ui.buttonSkip.destroy();
        ui.buttonSound.destroy();

        // show animation at the end
        this.showAnimation();
    }

    showAnimation() {

        // tween camera
        if (camera.zoom > this.minZoom) {
            this.canZoom = false;
            this.tweens.add({
                targets: [camera],
                callbackScope: this,
                ease: 'Linear',
                zoom: this.minZoom,
                x: 0, 
                y: 0,
                duration: 2000,
                onComplete: () => {
                    
                    this.canZoom = true;
                    // show end screen
                    ui.endScreen();
                },
            });
        }
        else {
            // show end screen
            ui.endScreen();
        }

        this.tweens.add({
            targets: [camera],
            scrollX: 0,
            scrollY: -40,
            ease: 'Linear',
            duration: 2000,
        });
    }

    showLabels(country) {
        if (country.name === countriesLabels.boumerdes) {
            let line = this.add.image(country.x-7, country.y+5, "texture", "lineBoumerdes.png");
            line.setOrigin(.5,1);
            this.statesContainer.add(line);
        }
        else if (country.name === countriesLabels.bejaia) {
            let line = this.add.image(country.x, country.y-8, "texture", "lineBoumerdes.png");
            line.setOrigin(.5,1);
            this.statesContainer.add(line);
        }

        // write country name
        country.txt = this.add.text(country.x, country.y, country.name, { fontFamily: "bold", fontSize: 24, align: "center", color: '#000000' });
        country.txt.setOrigin(.5,.5);
        this.statesContainer.add(country.txt);

        // small font size
        if (country.y < height/2 - 400) {
            country.txt.setFontSize(12);
        }
        else if (country.y < height/2 - 250) {
            country.txt.setFontSize(16);
        }

        if (country.labelX != null) {
            country.txt.x = country.labelX;
            country.txt.y = country.labelY;
        }
        
        // rectangles 
        country.rect = this.add.sprite(country.txt.x, country.txt.y, "rectangle");
        country.rect.displayWidth = country.txt.width;
        country.rect.displayHeight = country.txt.height - 2;
        this.statesContainer.add(country.rect);

        // bring to top text field
        this.statesContainer.bringToTop(country.txt);
    }
    
    displayStates(aScene) {
        // map
        aScene.map = aScene.add.image(width/2, height/2, 'map');
        aScene.map.alpha = .6;

        // states
        aScene.inSalah = aScene.add.image(width/2 + 95.5, height/2 + 68.5, 'texture', 'inSalah.png');
        aScene.adrar = aScene.add.image(width/2 - 236, height/2 + 118, 'texture', 'adrar.png');
        aScene.tindouf = aScene.add.image(width/2 - 485, height/2 + 30.5, 'texture', 'tindouf.png');
        aScene.illizi = aScene.add.image(width/2 + 385, height/2 + 13, 'texture', 'illizi.png');
        aScene.tamanrasset = aScene.add.image(width/2 + 264.5, height/2 + 301, 'texture', 'tamanrasset.png');
        aScene.bordjBajiMokhtar = aScene.add.image(width/2 - 192.5, height/2 + 388.5, 'texture', 'bordjBajiMokhtar.png');
        aScene.inGuezzam = aScene.add.image(width/2 + 198, height/2 + 553.5, 'texture', 'inGuezzam.png');
        aScene.djanet = aScene.add.image(width/2 + 485, height/2 + 274, 'texture', 'djanet.png');

        aScene.timimoun = aScene.add.image(width/2 - 78, height/2 - 129, 'texture', 'timinoun.png');
        aScene.elMenia = aScene.add.image(width/2 + 81, height/2 - 178, 'texture', 'elMenia.png');
        aScene.ouargla = aScene.add.image(width/2 + 270.5, height/2 - 201.5, 'texture', 'ouargla.png');
        aScene.bechar = aScene.add.image(width/2 - 216, height/2 - 230, 'texture', 'bechar.png');
        aScene.beniAbbes = aScene.add.image(width/2 - 272, height/2 - 67.5, 'texture', 'beniAbbes.png');

        aScene.elBayadh = aScene.add.image(width/2 - 52.5, height/2 - 311.5, 'texture', 'elBayadh.png');
        aScene.naama = aScene.add.image(width/2 - 156, height/2 - 359.5, 'texture', 'naama.png');
        aScene.laghouat = aScene.add.image(width/2 + 64.5, height/2 - 394, 'texture', 'laghouat.png');
        aScene.ghardaia = aScene.add.image(width/2 + 108.5, height/2 - 300.5, 'texture', 'ghardaia.png');
        aScene.djelfa = aScene.add.image(width/2 + 102, height/2 - 438.5, 'texture', 'djelfa.png');
        aScene.medea = aScene.add.image(width/2 + 60.5, height/2 - 554, 'texture', 'medea.png');
        aScene.blida = aScene.add.image(width/2 + 61.5, height/2 - 591, 'texture', 'blida.png');
        aScene.algiers = aScene.add.image(width/2 + 72.5, height/2 - 606, 'texture', 'algiers.png');
        aScene.ainDefla = aScene.add.image(width/2 + 13.5, height/2 - 566.5, 'texture', 'ainDefla.png');
        aScene.tipaza = aScene.add.image(width/2 + 23, height/2 - 593.5, 'texture', 'tipaza.png');
        aScene.tissemsilt = aScene.add.image(width/2 - 2.5, height/2 - 539.5, 'texture', 'tissemsilt.png');
        aScene.tiaret = aScene.add.image(width/2 - 15.5, height/2 - 476, 'texture', 'tiaret.png');
        aScene.chlef = aScene.add.image(width/2 - 37, height/2 - 569.5, 'texture', 'chlef.png');
        aScene.relizane = aScene.add.image(width/2 - 58.5, height/2 - 543.5, 'texture', 'relizane.png');
        aScene.mascara = aScene.add.image(width/2 - 97, height/2 - 513, 'texture', 'mascara.png');
        aScene.saida = aScene.add.image(width/2 - 91.5, height/2 - 466, 'texture', 'saida.png');
        aScene.mostaganem = aScene.add.image(width/2 - 88.5, height/2 - 556, 'texture', 'mostaganem.png');
        aScene.oran = aScene.add.image(width/2 - 142, height/2 - 530, 'texture', 'oran.png');
        aScene.sidiBelAbbes = aScene.add.image(width/2 - 141.5, height/2 - 462.5, 'texture', 'sidiBelAbbes.png');
        aScene.ainTemouchent = aScene.add.image(width/2 - 172, height/2 - 511.5, 'texture', 'ainTemouchent.png');
        aScene.tlemcen = aScene.add.image(width/2 - 196.5, height/2 - 462, 'texture', 'tlemcen.png');
        aScene.msila = aScene.add.image(width/2 + 147, height/2 - 495, 'texture', 'msila.png');
        aScene.bouira = aScene.add.image(width/2 + 116, height/2 - 573, 'texture', 'bouira.png');
        aScene.boumerdes = aScene.add.image(width/2 + 104, height/2 - 609, 'texture', 'boumerdes.png');
        aScene.ouledDjellal = aScene.add.image(width/2 + 173, height/2 - 423, 'texture', 'ouledDjellal.png');
        aScene.bordjBouArreridj = aScene.add.image(width/2 + 162.5, height/2 - 564.5, 'texture', 'bordjBouArreridj.png');
        aScene.bejaia = aScene.add.image(width/2 + 178, height/2 - 597.5, 'texture', 'bejaia.png');
        aScene.tiziOuzou = aScene.add.image(width/2 + 136, height/2 - 606, 'texture', 'tiziOuzou.png');
        aScene.setif = aScene.add.image(width/2 + 205, height/2 - 566.5, 'texture', 'setif.png');
        aScene.batna = aScene.add.image(width/2 + 230, height/2 - 513.5, 'texture', 'batna.png');
        aScene.biskra = aScene.add.image(width/2 + 236, height/2 - 473.5, 'texture', 'biskra.png');
        aScene.ElMGhair = aScene.add.image(width/2 + 228, height/2 - 413.5, 'texture', 'ElMGhair.png');
        aScene.elOued = aScene.add.image(width/2 + 341.5, height/2 - 363, 'texture', 'elOued.png');
        aScene.touggourt = aScene.add.image(width/2 + 279.5, height/2 - 345.5, 'texture', 'touggourt.png');
        aScene.jijel = aScene.add.image(width/2 + 239, height/2 - 611.5, 'texture', 'jijel.png');
        aScene.oumElBouaghi = aScene.add.image(width/2 + 303, height/2 - 550, 'texture', 'oumElBouaghi.png');
        aScene.mila = aScene.add.image(width/2 + 249.5, height/2 - 579.5, 'texture', 'mila.png');
        aScene.khenchela = aScene.add.image(width/2 + 304, height/2 - 484.5, 'texture', 'khenchela.png');
        aScene.constantine = aScene.add.image(width/2 + 280.5, height/2 - 588, 'texture', 'constantine.png');
        aScene.skikda = aScene.add.image(width/2 + 287.5, height/2 - 616, 'texture', 'skikda.png');
        aScene.guelma = aScene.add.image(width/2 + 325, height/2 - 589, 'texture', 'guelma.png');
        aScene.annaba = aScene.add.image(width/2 + 329.5, height/2 - 625, 'texture', 'annaba.png');
        aScene.elTaref = aScene.add.image(width/2 + 365, height/2 - 614, 'texture', 'elTaref.png');
        aScene.soukAhras = aScene.add.image(width/2 + 348, height/2 - 575.5, 'texture', 'soukAhras.png');
        aScene.tebessa = aScene.add.image(width/2 + 353, height/2 - 503, 'texture', 'tebessa.png');

        // position
        aScene.adrar.labelX = aScene.adrar.x + 40;
        aScene.adrar.labelY = aScene.adrar.y - 10;
        aScene.beniAbbes.labelX = aScene.beniAbbes.x - 5;
        aScene.beniAbbes.labelY = aScene.beniAbbes.y - 25;
        aScene.tamanrasset.labelX = aScene.tamanrasset.x - 65;
        aScene.tamanrasset.labelY = aScene.tamanrasset.y;
        aScene.inGuezzam.labelX = aScene.inGuezzam.x - 10;
        aScene.inGuezzam.labelY = aScene.inGuezzam.y + 30;
        aScene.timimoun.labelX = aScene.timimoun.x + 15;
        aScene.timimoun.labelY = aScene.timimoun.y + 15;
        aScene.elMenia.labelX = aScene.elMenia.x - 10;
        aScene.elMenia.labelY = aScene.elMenia.y;
        aScene.bordjBajiMokhtar.labelX = aScene.bordjBajiMokhtar.x;
        aScene.bordjBajiMokhtar.labelY = aScene.bordjBajiMokhtar.y - 20;
        aScene.laghouat.labelX = aScene.laghouat.x - 15;
        aScene.laghouat.labelY = aScene.laghouat.y + 10;
        aScene.medea.labelX = aScene.medea.x + 8;
        aScene.medea.labelY = aScene.medea.y - 5;
        aScene.tipaza.labelX = aScene.tipaza.x - 5;
        aScene.tipaza.labelY = aScene.tipaza.y - 5;
        aScene.algiers.labelX = aScene.algiers.x - 5;
        aScene.algiers.labelY = aScene.algiers.y - 8;
        aScene.djelfa.labelX = aScene.djelfa.x - 25;
        aScene.djelfa.labelY = aScene.djelfa.y - 15;
        aScene.relizane.labelX = aScene.relizane.x - 3;
        aScene.relizane.labelY = aScene.relizane.y;
        aScene.chlef.labelX = aScene.chlef.x + 2;
        aScene.chlef.labelY = aScene.chlef.y - 2;
        aScene.ainTemouchent.labelX = aScene.ainTemouchent.x - 40;
        aScene.ainTemouchent.labelY = aScene.ainTemouchent.y;
        aScene.tlemcen.labelX = aScene.tlemcen.x;
        aScene.tlemcen.labelY = aScene.tlemcen.y - 15;
        aScene.saida.labelX = aScene.saida.x;
        aScene.saida.labelY = aScene.saida.y - 10;
        aScene.sidiBelAbbes.labelX = aScene.sidiBelAbbes.x;
        aScene.sidiBelAbbes.labelY = aScene.sidiBelAbbes.y + 5;
        aScene.chlef.labelX = aScene.chlef.x;
        aScene.chlef.labelY = aScene.chlef.y - 10;
        aScene.oran.labelX = aScene.oran.x - 3;
        aScene.oran.labelY = aScene.oran.y - 10;
        aScene.mostaganem.labelX = aScene.mostaganem.x - 25;
        aScene.mostaganem.labelY = aScene.mostaganem.y - 8;
        aScene.msila.labelX = aScene.msila.x - 5;
        aScene.msila.labelY = aScene.msila.y - 15;
        aScene.boumerdes.labelX = aScene.boumerdes.x - 10;
        aScene.boumerdes.labelY = aScene.boumerdes.y - 30;
        aScene.bejaia.labelX = aScene.bejaia.x;
        aScene.bejaia.labelY = aScene.bejaia.y - 40;
        aScene.tiziOuzou.labelX = aScene.tiziOuzou.x;
        aScene.tiziOuzou.labelY = aScene.tiziOuzou.y + 5;
        aScene.bordjBouArreridj.labelX = aScene.bordjBouArreridj.x;
        aScene.bordjBouArreridj.labelY = aScene.bordjBouArreridj.y + 7;
        aScene.bouira.labelX = aScene.bouira.x + 5;
        aScene.bouira.labelY = aScene.bouira.y - 5;
        aScene.setif.labelX = aScene.setif.x + 10;
        aScene.setif.labelY = aScene.setif.y - 10;
        aScene.batna.labelX = aScene.batna.x + 5;
        aScene.batna.labelY = aScene.batna.y - 5;
        aScene.ouledDjellal.labelX = aScene.ouledDjellal.x;
        aScene.ouledDjellal.labelY = aScene.ouledDjellal.y - 10;
        aScene.touggourt.labelX = aScene.touggourt.x - 15;
        aScene.touggourt.labelY = aScene.touggourt.y;
        aScene.elOued.labelX = aScene.elOued.x - 15;
        aScene.elOued.labelY = aScene.elOued.y - 10;
        aScene.tebessa.labelX = aScene.tebessa.x + 10;
        aScene.tebessa.labelY = aScene.tebessa.y;
        aScene.soukAhras.labelX = aScene.soukAhras.x + 25;
        aScene.soukAhras.labelY = aScene.soukAhras.y;
        aScene.jijel.labelX = aScene.jijel.x - 5;
        aScene.jijel.labelY = aScene.jijel.y - 5;
        aScene.annaba.labelX = aScene.annaba.x;
        aScene.annaba.labelY = aScene.annaba.y - 10;
        aScene.elTaref.labelX = aScene.elTaref.x + 10;
        aScene.elTaref.labelY = aScene.elTaref.y - 5;
        
        aScene.guelma.labelX = aScene.guelma.x;
        aScene.guelma.labelY = aScene.guelma.y - 8;
        aScene.mila.labelX = aScene.mila.x - 5;
        aScene.mila.labelY = aScene.mila.y - 15;
        aScene.constantine.labelX = aScene.constantine.x;
        aScene.constantine.labelY = aScene.constantine.y + 8;

        // names
        aScene.inSalah.name = countriesLabels.inSalah;
        aScene.adrar.name = countriesLabels.adrar;
        aScene.tindouf.name = countriesLabels.tindouf;
        aScene.illizi.name = countriesLabels.illizi;
        aScene.tamanrasset.name = countriesLabels.tamanrasset;
        aScene.bordjBajiMokhtar.name = countriesLabels.bordjBajiMokhtar;
        aScene.inGuezzam.name = countriesLabels.inGuezzam;
        aScene.djanet.name = countriesLabels.djanet;
        aScene.timimoun.name = countriesLabels.timimoun;
        aScene.elMenia.name = countriesLabels.elMenia;
        aScene.ouargla.name = countriesLabels.ouargla;
        aScene.bechar.name = countriesLabels.bechar;
        aScene.beniAbbes.name = countriesLabels.beniAbbes;
        aScene.elBayadh.name = countriesLabels.elBayadh;
        aScene.naama.name = countriesLabels.naama;
        aScene.laghouat.name = countriesLabels.laghouat;
        aScene.ghardaia.name = countriesLabels.ghardaia;
        aScene.djelfa.name = countriesLabels.djelfa;
        aScene.medea.name = countriesLabels.medea;
        aScene.blida.name = countriesLabels.blida;
        aScene.algiers.name = countriesLabels.algiers;
        aScene.ainDefla.name = countriesLabels.ainDefla;
        aScene.tipaza.name = countriesLabels.tipaza;
        aScene.tissemsilt.name = countriesLabels.tissemsilt;
        aScene.tiaret.name = countriesLabels.tiaret;
        aScene.chlef.name = countriesLabels.chlef;
        aScene.relizane.name = countriesLabels.relizane;
        aScene.mascara.name = countriesLabels.mascara;
        aScene.saida.name = countriesLabels.saida;
        aScene.mostaganem.name = countriesLabels.mostaganem;
        aScene.oran.name = countriesLabels.oran;
        aScene.sidiBelAbbes.name = countriesLabels.sidiBelAbbes;
        aScene.ainTemouchent.name = countriesLabels.ainTemouchent;
        aScene.tlemcen.name = countriesLabels.tlemcen;
        aScene.msila.name = countriesLabels.msila;
        aScene.bouira.name = countriesLabels.bouira;
        aScene.boumerdes.name = countriesLabels.boumerdes;
        aScene.ouledDjellal.name = countriesLabels.ouledDjellal;
        aScene.bordjBouArreridj.name = countriesLabels.bordjBouArreridj;
        aScene.bejaia.name = countriesLabels.bejaia;
        aScene.tiziOuzou.name = countriesLabels.tiziOuzou;
        aScene.setif.name = countriesLabels.setif;
        aScene.batna.name = countriesLabels.batna;
        aScene.biskra.name = countriesLabels.biskra;
        aScene.ElMGhair.name = countriesLabels.ElMGhair;
        aScene.elOued.name = countriesLabels.elOued;
        aScene.touggourt.name = countriesLabels.touggourt;
        aScene.jijel.name = countriesLabels.jijel;
        aScene.oumElBouaghi.name = countriesLabels.oumElBouaghi;
        aScene.mila.name = countriesLabels.mila;
        aScene.khenchela.name = countriesLabels.khenchela;
        aScene.constantine.name = countriesLabels.constantine;
        aScene.skikda.name = countriesLabels.skikda;
        aScene.guelma.name = countriesLabels.guelma;
        aScene.annaba.name = countriesLabels.annaba;
        aScene.elTaref.name = countriesLabels.elTaref;
        aScene.soukAhras.name = countriesLabels.soukAhras;
        aScene.tebessa.name = countriesLabels.tebessa;

        // create container and put countries into it
        aScene.statesContainer = aScene.add.container(0, 0, [aScene.inSalah, aScene.adrar, aScene.tindouf, aScene.illizi, aScene.tamanrasset, aScene.bordjBajiMokhtar, aScene.inGuezzam, aScene.djanet, aScene.timimoun, aScene.elMenia, aScene.ouargla, aScene.bechar, aScene.beniAbbes, aScene.elBayadh, aScene.naama, aScene.laghouat, aScene.ghardaia, aScene.djelfa, aScene.medea, aScene.blida, aScene.algiers, aScene.ainDefla, aScene.tipaza, aScene.tissemsilt, aScene.tiaret, aScene.chlef, aScene.relizane, aScene.saida, aScene.mascara, aScene.mostaganem, aScene.oran, aScene.sidiBelAbbes, aScene.ainTemouchent, aScene.tlemcen, aScene.msila, aScene.bouira, aScene.boumerdes, aScene.ouledDjellal, aScene.bordjBouArreridj, aScene.bejaia, aScene.tiziOuzou, aScene.setif, aScene.batna, aScene.biskra, aScene.ElMGhair, aScene.elOued, aScene.touggourt, aScene.jijel, aScene.oumElBouaghi, aScene.mila, aScene.khenchela, aScene.constantine, aScene.guelma, aScene.skikda, aScene.annaba, aScene.elTaref, aScene.soukAhras, aScene.tebessa]);

        aScene.statesContainer.setSize(width, height);
        aScene.statesContainer.x = 0;
        aScene.statesContainer.y = 0;     
     }
}
