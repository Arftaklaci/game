"use strict"
var width, height, resize;
var webUrl = "https://world-geography-games.com/world.html";

var labels = 
{
    website         : "World Geography Games",
    title           : "Volcanoes",
    titleTwo        : "Volcanoes",
    play            : "play",
    options         : "options",
    map             : "map",
    sound           : "SOUND",
    photos          : "PHOTOS",
    tapStart        : "Tap on the map to start",
    clickStart      : "Click on the map to start",
    incorrect       : "Incorrect. Try again!",
    score           : "Score: ",
    attempts        : "Attempts: ",
    attemptsEnd     : "Attempts",
    points          : "Points",
    back            : "back",
    playAgain       : "Play Again",
    stop            : "Stop",
    skip            : "Skip",
    skipped         : "Skipped",
}

// the order of labels is important!
var credits = {
  credit1   : "Photo - Stephan Harmer 2016 (CC-BY-NC)",
  credit2   : "Photo - Hansueli Krapf 2006 (CC-BY-SA)",
  credit3   : "Photo - ESA/A.Gerst 2018 (CC-BY-SA)",
  credit4   : "Photo - Kuhnmi 2014 (CC-BY)",
  credit5   : "Photo - Thomas Jundt 2019 (CC-BY-NC)",
  credit6   : "Photo - Catherine Poh Huay Tan 2019 (CC-BY)",
  credit7   : "Photo - Maddalena Monge 2016 (CC-BY-NC)",
  credit8   : "Photo - MONUSCO/Neil Wetmore 2014 (CC-BY-SA)",
  credit9   : "Photo - Sophie Quebriac 2013  (CC-BY-NC-SA)",
  credit10  : "Photo - Yabang Pinoy 2011 (CC-BY)",
  credit11  : "Photo - Jeff Hollet 2018 (Public Domain)",
  credit12  : "Photo - R.Halfpaap 2016 (CC-BY-SA)",
  credit13  : "Photo - Edgar Jiménez 2007 (CC-BY-SA)",
  credit14  : "Photo - Artyom Tadzhibaev/Copernicus Sentinel-2 2020 (CC-BY)",
  credit15  : "Photo - x768 2017  (CC-BY-SA)",
  credit16  : "Photo - Fernando Reyes Palencia 2008 (CC-BY-SA)",
  credit17  : "Photo - José Luis Sánchez de la Rosa 2018 (CC-BY-NC-SA)",
  credit18  : "Photo - ISS Crew 2013 (Public Domain)",
  credit19  : "Photo - Sarah and Iain 2007 (CC-BY)",
  credit20  : "Photo - White Island - Gérard 2013 (CC-BY-SA)",
}
var creditsArray = Object.values(credits);

var subjects = {
  cotopaxi:            "Cotopaxi",
  hekla:               "Hekla",
  krakatoa:            "Krakatoa",
  koryaksky:           "Koryaksky",
  maunaLoa:            "Mauna Loa",
  mountEtna:           "Mount Etna",
  mountMerapi:         "Mount Merapi",
  mountNyiragongo:     "Mount Nyiragongo",
  mountPelee:          "Mount Pelée",
  mountPinatubo:       "Mount Pinatubo",
  mountRainier:        "Mount Rainier",
  mountVesuvius:       "Mount Vesuvius",
  nevadoDelRuiz:       "Nevado del Ruiz",
  popocatepetl:        "Popocatépetl",
  sakurajima:          "Sakurajima",
  santaMaria:          "Santa María",
  teide:          	   "Teide",
  ulawun:              "Ulawun",
  villarica:           "Villarrica",
  whakaariWhiteIsland: "Whakaari / White Island",
}

var countriesNames = ["Ecuador", "Iceland", "Indonesia", "Russia", "Hawai", "Italy", "Indonesia",
 "DR Congo", "Martinique", "Philippines", "USA", "Italy", "Colombia", "Mexico", 
 "Japan", "Guatemala", "Canary Islands", "Papua New Guinea", "Chile", "New Zealand", ];

var infoText = [
"Last eruption: 2016", 
"Last eruption: 2000", 
"Last eruption: 2020", 
"Last eruption: 2009", 
"Last eruption: 1984", 
"Last eruption: 2020", 
"Last eruption: 2020", 
"Last eruption: 2020", 
"Last eruption: 1932", 
"Last eruption: 1993", 
"Last eruption: 1450", 
"Last eruption: 1944", 
"Last eruption: 2020", 
"Last eruption: 2020", 
"Last eruption: 2020", 
"Last eruption: 2020", 
"Last eruption: 1909", 
"Last eruption: 2019", 
"Last eruption: 2020", 
"Last eruption: 2019"];

// don't edit below

// sound is on by default
var soundButtonFrame = 0;
// show photos by default
var showPhotos = true;
var photosButtonFrame = 0;
// number of attempts
var attempts = +0;
// number of skipped countries
var skips = +0;
// make array
var questionsArray = Object.values(subjects);
var questionsArrayStatic = [...questionsArray];

// resize
const DEFAULT_WIDTH = 1280
const DEFAULT_HEIGHT = 720
const MAX_WIDTH = DEFAULT_WIDTH * 1.5
const MAX_HEIGHT = DEFAULT_HEIGHT * 1.5
let SCALE_MODE = 'SMOOTH'

const config = {
    type: Phaser.AUTO,
    parent: 'geo-game',
    backgroundColor : 0x34C5EB,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,

    scale: 
    {
        mode: Phaser.Scale.NONE,
        parent: "geo-game",
    },
    scene: [Loading, Menu, Options, UserInterface, GraphUI, Gameplay, Graph]
}

window.addEventListener('load', () => {
    const game = new Phaser.Game(config)
  
    resize = () => {
      const w = window.innerWidth
      const h = window.innerHeight
  
      let width = DEFAULT_WIDTH
      let height = DEFAULT_HEIGHT
      let maxWidth = MAX_WIDTH
      let maxHeight = MAX_HEIGHT
      let scaleMode = SCALE_MODE
  
      let scale = Math.min(w / width, h / height)
      let newWidth = Math.min(w / scale, maxWidth)
      let newHeight = Math.min(h / scale, maxHeight)
  
      let defaultRatio = DEFAULT_WIDTH / DEFAULT_HEIGHT
      let maxRatioWidth = MAX_WIDTH / DEFAULT_HEIGHT
      let maxRatioHeight = DEFAULT_WIDTH / MAX_HEIGHT
  
      // smooth scaling
      let smooth = 1
      if (scaleMode === 'SMOOTH') {
        const maxSmoothScale = 1.15
        const normalize = (value, min, max) => {
          return (value - min) / (max - min)
        }
        if (width / height < w / h) {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioWidth) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        } else {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioHeight) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        }
      }

      // resize the game
      game.scale.resize(newWidth * smooth, newHeight * smooth)
      // scale the width and height of the css
      game.canvas.style.width = newWidth * scale + 'px'
      game.canvas.style.height = newHeight * scale + 'px'
      // center the game with css margin
      game.canvas.style.marginTop = `${(h - newHeight * scale) / 2}px`
      game.canvas.style.marginLeft = `${(w - newWidth * scale) / 2}px`
    }

    window.addEventListener('resize', event => {
      resize()
    })
  
    resize()
  })
