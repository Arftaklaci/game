"use strict"

class Graph extends Phaser.Scene {
    constructor() {
        super({
            key: "graph"
        })
    }

    create() {

        width = this.cameras.main.width;
        height = this.cameras.main.height;

        // gameplay scene
        let gameplay = this.scene.get("gameplay");
        gameplay.displayCaribbean(this);
        // show labels
        this.showLabels();
        // user interface
        this.ui = this.scene.get("graphUI");
        // launch user interface 
        this.scene.launch("graphUI");
        this.scene.moveAbove("graph", "graphUI");
       // camera
       camera = this.cameras.main;
        // min zoom
        this.minZoom = 0.65;
        camera.zoom = 0.65;
        // max zoom
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.7;
        }
        else {
            this.maxZoom = 2.1;
        }

        // enable drag and pinch to zoom
        var dragScale = this.plugins.get('rexpinchplugin').add(this);
        dragScale.on('drag1', dragScale => {
                var drag1Vector = dragScale.drag1Vector;
                camera.scrollX -= drag1Vector.x / camera.zoom;
                camera.scrollY -= drag1Vector.y / camera.zoom;
        }).on('pinch', dragScale => {
            var scaleFactor = dragScale.scaleFactor;
            
            // camera zoom
            camera.zoom *= scaleFactor;
        }, this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);

            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
            //this.upKeyDown = cursorKeys.up.isDown;
            //this.downKeyDown = cursorKeys.down.isDown;
        }

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on("resize", (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }
    
    update() {
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop) {
            if (this.cursorKeys.up.isDown) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown) {
                
                camera.zoom *= 0.9;
            }
        }
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    showLabels(country) {

        // get countries (sprites) array from the container
        this.countriesArray = this.caribbeanContainer.getAll();

        for (let i = 0; i < this.countriesArray.length; i++) {

            let country = this.countriesArray[i];
            // create white lines
            if (country.name === countriesLabels.aruba) {
                let line = this.add.image(country.lineX, country.lineY, "lineAruba");
                line.setOrigin(0.5,0.5);
                this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.bonaire) {
                let line = this.add.image(country.lineX, country.lineY, "lineBonaire");
                line.setOrigin(0,0.5);
                this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.curacao) {
                let line = this.add.image(country.lineX, country.lineY, "lineCuracao");
                line.setOrigin(.5,.5);
                    this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.trinidadAndTobago) {
                let line = this.add.image(country.lineX, country.lineY, "lineTrinidadAndTobago");
                line.setOrigin(0,0.5);
                    this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.turksAndCaicos) {
                let line = this.add.image(country.lineX, country.lineY, "lineTurksAndCaicosIslands");
                line.setOrigin(0,0.5);
                    this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.usVirginIslands) {
                let line = this.add.image(country.lineX, country.lineY, "lineUnitedStatesVirginIslands");
                line.setOrigin(0.5,1);
                    this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.britishVirginIslands) {
                let line = this.add.image(country.lineX, country.lineY, "lineBritishVirginIslands");
                    line.setOrigin(0.5,0.5);
                    this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.puertoRico) {
                let line = this.add.image(country.lineX, country.lineY, "linePuertoRico");
                    line.setOrigin(0.5,1);
                    this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.grenada || country.name === countriesLabels.saintVincent) {
                let line = this.add.image(country.lineX, country.lineY, "lineGrenada");
                line.setOrigin(0,0.5);
                this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.barbados) {
                let line = this.add.image(country.lineX, country.lineY, "lineAruba");
                line.setOrigin(0,0.5);
                this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.saba) {
                let line = this.add.image(country.lineX, country.lineY, "lineSaba");
                line.setOrigin(1,0.5);
                this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.sintEustatius ||country.name === countriesLabels.saintKittsAndNevis || country.name === countriesLabels.montserrat) {
                let line = this.add.image(country.lineX, country.lineY, "lineMontserrat");
                line.setOrigin(1,0.5);
                this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.saintMartin ||country.name === countriesLabels.sintMaarten) {
                let line = this.add.image(country.lineX, country.lineY, "lineSaintMartin");
                line.setOrigin(0,0.5);
                this.caribbeanContainer.add(line);
            }
            else if (country.name === countriesLabels.saintLucia || country.name === countriesLabels.martinique || country.name === countriesLabels.dominica || country.name === countriesLabels.guadeloupe || country.name === countriesLabels.saintBarthelemy || country.name === countriesLabels.antiguaAndBarbuda) {
                let line = this.add.image(country.lineX, country.lineY, "lineGuadeloupe");
                    line.setOrigin(0,0.5);
                    this.caribbeanContainer.add(line);
            }

            // text
            country.txt = this.add.text(country.x, country.y, country.name, { fontFamily: "bold", fontSize: 24, align: "center", color: '#000000' });
            country.txt.setOrigin(.5,.5);
            this.caribbeanContainer.add(country.txt);

            // different labels for these territories (UK, NL, FR, USA)
            if (country.name === countriesLabels.anguilla) {
                country.txt.setText(labels.anguillaT);
            }
            else if (country.name === countriesLabels.saintMartin) {
                country.txt.setText(labels.saintMartinT);
            }
            else if (country.name === countriesLabels.sintMaarten) {
                country.txt.setText(labels.sintMaartenT);
            }
            else if (country.name === countriesLabels.saintBarthelemy) {
                country.txt.setText(labels.saintBarthelemyT);
            }
            else if (country.name === countriesLabels.guadeloupe) {
                country.txt.setText(labels.guadeloupeT);
            }
            else if (country.name === countriesLabels.martinique) {
                country.txt.setText(labels.martiniqueT);
            }
            else if (country.name === countriesLabels.britishVirginIslands) {
                country.txt.setText(labels.britishVirginIslandsT);
            }
            else if (country.name === countriesLabels.puertoRico) {
                country.txt.setText(labels.puertoRicoT);
            }
            else if (country.name === countriesLabels.usVirginIslands) {
                country.txt.setText(labels.usVirginIslandsT);
            }
            else if (country.name === countriesLabels.turksAndCaicos) {
                country.txt.setText(labels.turksAndCaicosT);
            }
            else if (country.name === countriesLabels.caymanIslands) {
                country.txt.setText(labels.caymanIslandsT);
            }
            else if (country.name === countriesLabels.aruba) {
                country.txt.setText(labels.arubaT);
            }
            else if (country.name === countriesLabels.curacao) {
                country.txt.setText(labels.curacaoT);
            }
            else if (country.name === countriesLabels.bonaire) {
                country.txt.setText(labels.bonaireT);
            }

            // position text
            if (country.labelX) {
                country.txt.x = country.labelX;
                country.txt.y = country.labelY;
            }
            // create white rectangle
            country.rect = this.add.sprite(country.txt.x, country.txt.y, "rectangle");
            country.rect.displayWidth = country.txt.width + 2;
            country.rect.displayHeight = country.txt.height;
            this.caribbeanContainer.add(country.rect);
            // set different origin for these rectangles
            if (country.name === countriesLabels.aruba ||country.name === countriesLabels.saba ||country.name === countriesLabels.sintEustatius ||country.name === countriesLabels.saintKittsAndNevis || country.name === countriesLabels.montserrat) {
                country.rect.setOrigin(1,0.5);
                country.txt.setOrigin(1,0.5);
                country.txt.x -= 1;
            }
            else if (country.name === countriesLabels.bonaire || country.name === countriesLabels.trinidadAndTobago || country.name === countriesLabels.turksAndCaicos || country.name === countriesLabels.britishVirginIslands || country.name === countriesLabels.grenada || country.name === countriesLabels.saintVincent || country.name === countriesLabels.barbados || country.name === countriesLabels.saintLucia || country.name === countriesLabels.martinique || country.name === countriesLabels.dominica || country.name === countriesLabels.guadeloupe || country.name === countriesLabels.saintBarthelemy || country.name === countriesLabels.antiguaAndBarbuda || country.name === countriesLabels.saintMartin || country.name === countriesLabels.sintMaarten) {
                country.rect.setOrigin(0,0.5);
                country.txt.setOrigin(0,0.5);
                country.txt.x += 1;
            }
            // bring to top text field
            this.caribbeanContainer.bringToTop(country.txt);
        }

        // territories text
        this.txtFR = this.add.text(-300, height/2 + 180, labels.FRtext, { fontFamily: "semiBold", fontSize: 23, color: '#000000' });
        this.txtFR.setOrigin(0,.5);
        this.caribbeanContainer.add(this.txtFR);
        this.txtNL = this.add.text(-300, height/2 + 225, labels.NLtext, { fontFamily: "semiBold", fontSize: 23, color: '#000000' });
        this.txtNL.setOrigin(0,.5);
        this.caribbeanContainer.add(this.txtNL);
        this.txtUSA = this.add.text(-300, height/2 + 270, labels.USAtext, { fontFamily: "semiBold", fontSize: 23, color: '#000000' });
        this.txtUSA.setOrigin(0,.5);
        this.caribbeanContainer.add(this.txtUSA);
        this.txtUK = this.add.text(-300, height/2 + 315, labels.UKtext, { fontFamily: "semiBold", fontSize: 23, color: '#000000' });
        this.txtUK.setOrigin(0,.5);
        this.caribbeanContainer.add(this.txtUK);
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.caribbeanContainer.setSize(width, height);
        this.caribbeanContainer.x = 0;
        this.caribbeanContainer.y = 0;
    }
}
