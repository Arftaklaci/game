"use strict"

var width, height, resize;

// edit below
var collator = "en";
var webUrl = "https://world-geography-games.com/australia.html";

var labels =
{
    website         : "World Geography Games",
    title           : "Countries of Australia and Oceania",
    titleTwo        : "Countries \n Oceania",
    play            : "play",
    options         : "options",
    map             : "map",
    tapStart        : "Tap on the map to start",
    clickStart      : "Click on the map to start\nUse mouse wheel to zoom",
    incorrect       : "Incorrect. Try again!",
    score           : "Score: ",
    attempts        : "Attempts: ",
    attemptsEnd     : "Attempts",
    skip            : "Skip",
    skipped         : "Skipped",
    countries       : "Countries",
    sound           : "SOUND",
    numOfCountries  : "Number of Countries",
    region1         : "Northern Europe",
    region2         : "Central and Eastern Europe",
    region3         : "Southern Europe",
    region4         : "Western Europe",
    region5         : "Microstates",
    select          : "select",
    selectAtleast   : "Please select at least 5 countries",
    back            : "back",
    map             : "map",
    playAgain       : "Play Again",
    stop            : "Stop",
    southeastAsia   : "Southeast Asia"
}

var countriesLabels = {

    australia       : "Australia",
    fiji            : "Fiji",
    kiribati        : "Kiribati",
    marshallIslands : "Marshall Islands",
    micronesia      : "Micronesia",
    nauru           : "Nauru",
    newZealand      : "New Zealand",
    palau           : "Palau",
    papuaNewGuinea  : "Papua New Guinea",
    solomonIslands  : "Solomon Islands",
    samoa           : "Samoa",
    tonga           : "Tonga",
    tuvalu          : "Tuvalu",
    vanuatu         : "Vanuatu"
}

// don't edit below

// number of attempts
var attempts = +0;
// number of skipped countries
var skips = +0;

// by default all countries are included
var questionsArray = Object.values(countriesLabels);
// calling entries will put key-value pairs to the array
// Object.entries(countriesLabels);

//questionsArray.length = 20;
//var numberOfCountries = questionsArray.length;

// countries options
var region1Array = questionsArray.slice(0);

// central and eastern
var region2Array = ["Albania", "Belarus", "Bosnia and Herzegovina", "Bulgaria", "Croatia", "Czech Republic", "Hungary", "Kosovo", "Moldova", "Montenegro", "North Macedonia", "Poland", "Slovenia", "Serbia", "Slovakia", "Romania", "Russia", "Ukraine"];
// southern
var region3Array = ["Cyprus", "Greece", "Italy", "Malta", "Portugal", "Spain", "San Marino", "Vatican City"];
// western
var region4Array = ["Andorra", "Austria", "Belgium", "France", "Germany", "Ireland", "Monaco", "Luxembourg", "Liechtenstein", "Netherlands", "Switzerland", "United Kingdom"];
// microstates
var region5Array = ["Liechtenstein", "Andorra", "Vatican City", "San Marino", "Monaco"];

// always contains all countries
const questionsArrayStatic = questionsArray.slice();

// toggle buttons, by default they are green (frame 0)
var btnRegion1Frame = 0;
var btnRegion2Frame = 0;
var btnRegion3Frame = 0;
var btnRegion4Frame = 0;
var btnRegion5Frame = 0;
var soundButtonFrame = 0;

var toggleButtonsFrames = [];
for (let x = 0; x < questionsArrayStatic.length; x++) {
  toggleButtonsFrames.push(+0);
}

// if true you can toggle regions, else you toggle countries on options
var regionsVisible = true;

function tweenObj(aScene, obj, fromN, toN) {
  obj.alpha = fromN;

  aScene.tweens.add({
      targets: [obj],
      alpha: { value: toN },
      ease: 'Linear',
      duration: 400,
      onComplete: () => {
          
      }
  });
}

// resize
const DEFAULT_WIDTH = 1280
const DEFAULT_HEIGHT = 720
const MAX_WIDTH = DEFAULT_WIDTH * 1.5
const MAX_HEIGHT = DEFAULT_HEIGHT * 1.5
let SCALE_MODE = 'SMOOTH'

const config = {
    type: Phaser.AUTO,
    parent: 'geo-game',
    backgroundColor : 0x34C5EB,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,

    scale: 
    {
        mode: Phaser.Scale.NONE,
        parent: "geo-game",
    },
    scene: [Loading, Menu, UserInterface, GraphUI, Gameplay, Options, Graph]
}

window.addEventListener('load', () => {
    const game = new Phaser.Game(config)
  
    const resize = () => {
      const w = window.innerWidth
      const h = window.innerHeight
  
      let width = DEFAULT_WIDTH
      let height = DEFAULT_HEIGHT
      let maxWidth = MAX_WIDTH
      let maxHeight = MAX_HEIGHT
      let scaleMode = SCALE_MODE
  
      let scale = Math.min(w / width, h / height)
      let newWidth = Math.min(w / scale, maxWidth)
      let newHeight = Math.min(h / scale, maxHeight)
  
      let defaultRatio = DEFAULT_WIDTH / DEFAULT_HEIGHT
      let maxRatioWidth = MAX_WIDTH / DEFAULT_HEIGHT
      let maxRatioHeight = DEFAULT_WIDTH / MAX_HEIGHT
  
      // smooth scaling
      let smooth = 1
      if (scaleMode === 'SMOOTH') {
        const maxSmoothScale = 1.15
        const normalize = (value, min, max) => {
          return (value - min) / (max - min)
        }
        if (width / height < w / h) {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioWidth) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        } else {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioHeight) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        }
      }

      // resize the game
      game.scale.resize(newWidth * smooth, newHeight * smooth)
      // scale the width and height of the css
      game.canvas.style.width = newWidth * scale + 'px'
      game.canvas.style.height = newHeight * scale + 'px'
      // center the game with css margin
      game.canvas.style.marginTop = `${(h - newHeight * scale) / 2}px`
      game.canvas.style.marginLeft = `${(w - newWidth * scale) / 2}px`
    }

    window.addEventListener('resize', event => {
      resize()
    })
  
    resize()
  })
