"use strict"

var width, height, resize;

// edit below
var collator = "en";
var webUrl = "https://world-geography-games.com/world.html";

var labels =
{
    website         : "World Geography Games",
    title           : "Countries: World",
    titleTwo        : "Countries \n   World",
    play            : "play",
    options         : "options",
    map             : "map",
    tapStart        : "Tap on the map to start",
    clickStart      : "Click on the map to start\nUse mouse wheel to zoom",
    incorrect       : "Incorrect. Try again!",
    score           : "Score: ",
    attempts        : "Attempts: ",
    skipped         : "Skipped",
    skip            : "Skip",
    attemptsEnd     : "Attempts",
    countries       : "Countries",
    sound           : "SOUND",
    select          : "select",
    selectAtleast   : "Short of countries, please change options",
    back            : "back",
    map             : "map",
    playAgain       : "Play Again",
    stop            : "Stop",
    carMulti        : " Central African \n     Republic",
    drCongoMulti    : " Democratic Republic \n     of the Congo",
    numOfCountries  : "Number of Countries",
    
    region1         : "Africa",
    region2         : "Asia",
    region3         : "North America",
    region6         : "South America",
    region4         : "Europe",
    region5         : "Oceania",
}

var countriesLabels = {

    // africa
    botswana          : "Botswana",
    eswatini          : "Eswatini",
    lesotho           : "Lesotho",
    southAfrica       : "South Africa",
    algeria           : "Algeria",
    egypt             : "Egypt",
    libya             : "Libya",
    morocco           : "Morocco",
    sudan             : "Sudan",
    tunisia           : "Tunisia",
    angola            : "Angola",
    cameroon          : "Cameroon",
    car               : "Central African Republic",
    chad              : "Chad",
    drCongo           : "Democratic Republic of the Congo",
    equatorialGuinea  : "Equatorial Guinea",
    gabon             : "Gabon",
    congo             : "Republic of the Congo",
    saoTomeAndPrincipe: "São Tomé und Príncipe",
    benin             : "Benin",
    burkinaFaso       : "Burkina Faso",
    capeVerde         : "Cape Verde",
    gambia            : "Gambia",
    ghana             : "Ghana",
    guinea            : "Guinea",
    guineaBissau      : "Guinea-Bissau",
    ivoryCoast        : "Ivory Coast",
    liberia           : "Liberia",
    mali              : "Mali",
    mauritania        : "Mauritania",
    niger             : "Niger",
    nigeria           : "Nigeria",
    senegal           : "Senegal",
    sierraLeone       : "Sierra Leone",
    togo              : "Togo",
    burundi           : "Burundi",
    comoros           : "Comoros",
    djibouti          : "Djibouti",
    eritrea           : "Eritrea",
    ethiopia          : "Ethiopia",
    kenya             : "Kenya",
    madagascar        : "Madagascar",
    malawi            : "Malawi",
    mauritius         : "Mauritius",
    mozambique        : "Mozambique",
    namibia           : "Namibia",
    rwanda            : "Rwanda",
    seychelles        : "Seychelles",
    somalia           : "Somalia",
    southSudan        : "South Sudan",
    tanzania          : "Tanzania",
    uganda            : "Uganda",
    zambia            : "Zambia",
    zimbabwe          : "Zimbabwe",
    // asia
    armenia           : "Armenia",
    azerbaijan        : "Azerbaijan",
    bahrain           : "Bahrain",
    georgia           : "Georgia",
    iran              : "Iran",
    iraq              : "Iraq",
    israel            : "Israel",
    jordan            : "Jordan",
    kuwait            : "Kuwait",
    lebanon           : "Lebanon",
    oman              : "Oman",
    palestine         : "Palestine",
    qatar             : "Qatar",
    saudiArabia       : "Saudi Arabia",
    syria             : "Syria",
    turkey            : "Turkey",
    uae               : "United Arab Emirates",
    yemen             : "Yemen",
    china             : "China",
    japan             : "Japan",
    mongolia          : "Mongolia",
    northKorea        : "North Korea",
    southKorea        : "South Korea",
    taiwan            : "Taiwan",
    kazakhstan        : "Kazakhstan",
    kyrgyzstan        : "Kyrgyzstan",
    russia            : "Russia",
    tajikistan        : "Tajikistan",
    turkmenistan      : "Turkmenistan",
    uzbekistan        : "Uzbekistan",
    afghanistan       : "Afghanistan",
    bangladesh        : "Bangladesh",
    bhutan            : "Bhutan",
    india             : "India",
    maldives          : "Maldives",
    nepal             : "Nepal",
    pakistan          : "Pakistan",
    sriLanka          : "Sri Lanka",
    brunei            : "Brunei",
    cambodia          : "Cambodia",
    eastTimor         : "East Timor",
    indonesia         : "Indonesia",
    laos              : "Laos",
    malaysia          : "Malaysia",
    myanmar           : "Myanmar", 
    philippines       : "Philippines",
    singapore         : "Singapore",
    thailand          : "Thailand",
    vietnam           : "Vietnam",
    // oceania
    australia       : "Australia",
    fiji            : "Fiji",
    kiribati        : "Kiribati",
    marshallIslands : "Marshall Islands",
    micronesia      : "Micronesia",
    nauru           : "Nauru",
    newZealand      : "New Zealand",
    palau           : "Palau",
    papuaNewGuinea  : "Papua New Guinea",
    solomonIslands  : "Solomon Islands",
    samoa           : "Samoa",
    tonga           : "Tonga",
    tuvalu          : "Tuvalu",
    vanuatu         : "Vanuatu",
    // europe
    finland             : "Finland",
    sweden              : "Sweden",
    norway              : "Norway",
    iceland             : "Iceland",
    latvia              : "Latvia",
    lithuania           : "Lithuania",
    estonia             : "Estonia",
    denmark             : "Denmark",
    albania             : "Albania",
    bosnia              : "Bosnia and Herzegovina",
    serbia              : "Serbia",
    croatia             : "Croatia",
    kosovo              : "Kosovo",
    montenegro          : "Montenegro",
    poland              : "Poland",
    northMacedonia      : "North Macedonia",
    bulgaria            : "Bulgaria",
    moldova             : "Moldova",
    romania             : "Romania",
    belarus             : "Belarus",
    hungary             : "Hungary",
    ukraine             : "Ukraine",
    sanMarino           : "San Marino",
    vaticanCity         : "Vatican City",
    malta               : "Malta",
    greece              : "Greece",
    italy               : "Italy",
    cyprus              : "Cyprus",
    spain               : "Spain",
    portugal            : "Portugal",
    andorra             : "Andorra",
    liechtenstein       : "Liechtenstein",
    monaco              : "Monaco",
    austria             : "Austria",
    france              : "France",
    germany             : "Germany",
    belgium             : "Belgium",
    ireland             : "Ireland",
    luxembourg          : "Luxembourg",
    netherlands         : "Netherlands",
    slovenia            : "Slovenia",
    slovakia            : "Slovakia",
    czechRepublic       : "Czechia",
    switzerland         : "Switzerland",
    unitedKingdom       : "United Kingdom",
    russia              : "Russia",
    // america
    canada             : "Canada",
    mexico             : "Mexico",
    unitedStates       : "United States",
    antiguaAndBarbuda  : "Antigua and Barbuda",
    bahamas            : "Bahamas",
    barbados           : "Barbados",
    cuba               : "Cuba",
    dominica           : "Dominica",
    dominicanRepublic  : "Dominican Republic",
    grenada            : "Grenada",
    haiti              : "Haiti",
    jamaica            : "Jamaica",
    saintKittsAndNevis : "Saint Kitts and Nevis",
    saintLucia         : "Saint Lucia",
    saintVincent       : "Saint Vincent and the Grenadines",
    trinidadAndTobago  : "Trinidad and Tobago",
    belize             : "Belize",
    elSalvador         : "El Salvador",
    costaRica          : "Costa Rica",
    guatemala          : "Guatemala",
    honduras           : "Honduras",
    nicaragua          : "Nicaragua",
    panama             : "Panama",
    argentina          : "Argentina",
    bolivia            : "Bolivia",
    brazil             : "Brazil",
    chile              : "Chile",
    colombia           : "Colombia",
    ecuador            : "Ecuador",
    guyana             : "Guyana",
    paraguay           : "Paraguay",
    peru               : "Peru",
    suriname           : "Suriname",
    uruguay            : "Uruguay",
    venezuela          : "Venezuela"
}

// don't edit below

// number of attempts
var attempts = +0;
// skip
var skips = +0;
// radio buttons, by default 25 countries are selected
var countriesSelected = 25;
// this array contains the questions (countries names)
var questionsArray = Object.values(countriesLabels);
// always contains all countries
const questionsArrayStatic = questionsArray.slice();
// this array contains countries from all selected continents
// it is updated when a toggle button is clicked
// elements from this array are pushed to questionsArray after shuffling, the number of elements depends on radio buttons
var countriesFromAllContinent = questionsArray.slice();

// africa
var region1Array = [];
for (let x = 0; x < 54; x++) {
  region1Array.push(questionsArray[x]);
}
// asia
var region2Array = [];
for (let x = 54; x < 103; x++) {
  region2Array.push(questionsArray[x]);
}
// europe
var region4Array = [];
for (let x = 117; x < 162; x++) {
  region4Array.push(questionsArray[x]);
}

// oceania
var region5Array = [];
for (let x = 103; x < 117; x++) {
  region5Array.push(questionsArray[x]);
}
// north america
var region3Array = [];
for (let x = 162; x < 185; x++) {
  region3Array.push(questionsArray[x]);
}
// south america
var region6Array = [];
for (let x = 185; x < 197; x++) {
  region6Array.push(questionsArray[x]);
}

// toggle buttons, by default they are green (frame 0)
var btnRegion1Frame = 0;
var btnRegion2Frame = 0;
var btnRegion3Frame = 0;
var btnRegion4Frame = 0;
var btnRegion5Frame = 0;
var btnRegion6Frame = 0;
var soundButtonFrame = 0;

var toggleButtonsFrames = [];
for (let x = 0; x < questionsArrayStatic.length; x++) {
  toggleButtonsFrames.push(+0);
}

// by default only 25 random countries are selected
shuffle(questionsArray);
questionsArray.length = countriesSelected;

// if true you can toggle regions, else you toggle countries on options
var regionsVisible = true;

function tweenObj(aScene, obj, fromN, toN) {
  obj.alpha = fromN;

  aScene.tweens.add({
      targets: [obj],
      alpha: { value: toN },
      ease: 'Linear',
      duration: 400,
  });
}

// resize
const DEFAULT_WIDTH = 1280
const DEFAULT_HEIGHT = 720
const MAX_WIDTH = DEFAULT_WIDTH * 1.5
const MAX_HEIGHT = DEFAULT_HEIGHT * 1.5
let SCALE_MODE = 'SMOOTH'

const config = {
    type: Phaser.AUTO,
    parent: 'geo-game',
    backgroundColor : 0x34C5EB,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,

    scale: 
    {
        mode: Phaser.Scale.NONE,
        parent: "geo-game",
    },
    scene: [Loading, Menu, UserInterface, GraphUI, Gameplay, Options, Graph]
}

window.addEventListener('load', () => {
    const game = new Phaser.Game(config)
  
    const resize = () => {
      const w = window.innerWidth
      const h = window.innerHeight
  
      let width = DEFAULT_WIDTH
      let height = DEFAULT_HEIGHT
      let maxWidth = MAX_WIDTH
      let maxHeight = MAX_HEIGHT
      let scaleMode = SCALE_MODE
  
      let scale = Math.min(w / width, h / height)
      let newWidth = Math.min(w / scale, maxWidth)
      let newHeight = Math.min(h / scale, maxHeight)
  
      let defaultRatio = DEFAULT_WIDTH / DEFAULT_HEIGHT
      let maxRatioWidth = MAX_WIDTH / DEFAULT_HEIGHT
      let maxRatioHeight = DEFAULT_WIDTH / MAX_HEIGHT
  
      // smooth scaling
      let smooth = 1
      if (scaleMode === 'SMOOTH') {
        const maxSmoothScale = 1.15
        const normalize = (value, min, max) => {
          return (value - min) / (max - min)
        }
        if (width / height < w / h) {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioWidth) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        } else {
          smooth =
            -normalize(newWidth / newHeight, defaultRatio, maxRatioHeight) /
              (1 / (maxSmoothScale - 1)) +
            maxSmoothScale
        }
      }

      // resize the game
      game.scale.resize(newWidth * smooth, newHeight * smooth)
      // scale the width and height of the css
      game.canvas.style.width = newWidth * scale + 'px'
      game.canvas.style.height = newHeight * scale + 'px'
      // center the game with css margin
      game.canvas.style.marginTop = `${(h - newHeight * scale) / 2}px`
      game.canvas.style.marginLeft = `${(w - newWidth * scale) / 2}px`
    }

    window.addEventListener('resize', event => {
      resize()
    })
  
    resize()
  })
