"use strict"

class Graph extends Phaser.Scene {
    constructor() {
        super({
            key: "graph"
        })
    }

    create() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        // gameplay scene
        let gameplay = this.scene.get("gameplay");
        gameplay.displayMap(this);
        
        // show labels
        this.showLabels();
        // user interface
        this.ui = this.scene.get("graphUI");
        // launch user interface 
        this.scene.launch("graphUI");
        this.scene.moveAbove("graph", "graphUI");
       // camera
       camera = this.cameras.main;
       camera.zoom = 1;
       camera.scrollY = -20;
        // min max zoom
        this.minZoom = 1;        
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.6;
        }
        else {
            this.maxZoom = 1.9;
        }
        // enable drag and pinch to zoom
        var dragScale = this.plugins.get('rexpinchplugin').add(this);
        dragScale.on('drag1', dragScale => {
                var drag1Vector = dragScale.drag1Vector;
                camera.scrollX -= drag1Vector.x / camera.zoom;
                camera.scrollY -= drag1Vector.y / camera.zoom;
        }).on('pinch', dragScale => {
            var scaleFactor = dragScale.scaleFactor;
            
            // camera zoom
            camera.zoom *= scaleFactor;
        }, this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);

            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
            //this.upKeyDown = cursorKeys.up.isDown;
            //this.downKeyDown = cursorKeys.down.isDown;
        }

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on("resize", (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }
    
    update() {
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop) {
            if (this.cursorKeys.up.isDown) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown) {
                
                camera.zoom *= 0.9;
            }
        }
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    showLabels(subject) {
        
        this.subjectsArray = this.mapContainer.getAll();

        for (let i = 0; i < this.subjectsArray.length; i++) {
            let subject = this.subjectsArray[i];

            // create white rectangle
            subject.rect = this.add.image(subject.x, subject.y, "rectangle");
            // write text
            subject.txt = this.add.text(subject.x, subject.y, subject.name, { fontFamily: "bold", fontSize: 22, align: "center", color: '#000000' });
            subject.txt.setOrigin(.5,.5);
            // position text
            if (subject.labelX) {
                subject.txt.x = subject.labelX;
                subject.txt.y = subject.labelY;
                subject.rect.x = subject.labelX;
                subject.rect.y = subject.labelY;
            }
            // rectangle width/height
            subject.rect.displayWidth = subject.txt.width + 4;
            subject.rect.displayHeight = subject.txt.height;

            if (subject.hasLine) {
                let line;
                if (subject.name === subjects.blekingeLan) {
                    line = this.add.image(subject.lineX, subject.lineY, "texture", "lineBlekingeLan.png").setOrigin(0,0);
                }
                else if (subject.name === subjects.kronobergsLan) {
                    line = this.add.image(subject.lineX, subject.lineY, "texture", "lineKronobergsLan.png").setOrigin(0,0.5);
                }
                else if (subject.name === subjects.kalmarLan) {
                    line = this.add.image(subject.lineX, subject.lineY, "texture", "lineKalmarLan.png").setOrigin(0,0);
                }
                else if (subject.name === subjects.gotlandsLan) {
                    line = this.add.image(subject.lineX, subject.lineY, "texture", "gotlandsLan-line.png").setOrigin(0,0);
                }
                else if (subject.name === subjects.ostergotlandsLan) {
                    line = this.add.image(subject.lineX, subject.lineY, "texture", "lineOstergotlandsLan.png").setOrigin(0,0.5);
                }
                else if (subject.name === subjects.sodermanlandsLan) {
                    line = this.add.image(subject.lineX, subject.lineY, "texture", "lineSodermanlandsLan.png").setOrigin(0,0.5);
                }
                else if (subject.name === subjects.stockholmsLan) {
                    line = this.add.image(subject.lineX, subject.lineY, "texture", "lineStockholmsLan.png").setOrigin(0,0);
                }
                else if (subject.name === subjects.vastmanlandsLan) {
                    line = this.add.image(subject.lineX, subject.lineY, "texture", "lineVastmanlandsLan.png").setOrigin(0,0.5);
                }
                else if (subject.name === subjects.uppsalaLan) {
                    line = this.add.image(subject.lineX, subject.lineY, "texture", "lineUppslaLan.png").setOrigin(0,1);
                }
                else if (subject.name === subjects.orebroLan) {
                    line = this.add.image(subject.lineX, subject.lineY, "texture", "lineOrebroLan.png").setOrigin(1,0.5);
                }
                else if (subject.name === subjects.jonkopingsLan) {
                    line = this.add.image(subject.lineX, subject.lineY, "texture", "lineJonkopingsLan.png").setOrigin(1,0.5);
                }

                this.mapContainer.add(line);
            }
        }
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.mapContainer.setSize(width, height);
        this.mapContainer.x = 0;
        this.mapContainer.y = 0;
    }
}
