"use strict"

class Graph extends Phaser.Scene {
    constructor() {
        super({
            key: "graph"
        })
    }

    create() {

        width = this.cameras.main.width;
        height = this.cameras.main.height;

        // gameplay scene
        let gameplay = this.scene.get("gameplay");
        gameplay.displayCanada(this);

        // show labels
        this.showLabels();

        // user interface
        this.ui = this.scene.get("graphUI");
        // launch user interface 
        this.scene.launch("graphUI");
        this.scene.moveAbove("graph", "graphUI");

       // camera
       camera = this.cameras.main;

        // min zoom
        this.minZoom = 1;    
        camera.zoom = this.minZoom;
            
        if (this.sys.game.device.os.desktop) {
            this.maxZoom = 1.8;
        }
        else {
            this.maxZoom = 2.1;
        }

        // enable drag and pinch to zoom
        var dragScale = this.plugins.get('rexpinchplugin').add(this);
        dragScale.on('drag1', dragScale => {
                var drag1Vector = dragScale.drag1Vector;
                camera.scrollX -= drag1Vector.x / camera.zoom;
                camera.scrollY -= drag1Vector.y / camera.zoom;
        }).on('pinch', dragScale => {
            var scaleFactor = dragScale.scaleFactor;
            
            // camera zoom
            camera.zoom *= scaleFactor;
        }, this);

        // mouse wheel
        if (this.sys.game.device.os.desktop) {
            var mouseWheelToUpDown = this.plugins.get('rexmousewheeltoupdownplugin').add(this);

            this.cursorKeys = mouseWheelToUpDown.createCursorKeys();
            //this.upKeyDown = cursorKeys.up.isDown;
            //this.downKeyDown = cursorKeys.down.isDown;
        }

        // resize
        const resize = () => {
            this.setPositions();
        }
        this.scale.on("resize", (gameSize, baseSize, displaySize, resolution) => {
            if (this.scene.isActive()) {
                this.cameras.resize(gameSize.width, gameSize.height);
                resize();
            }
        })
        resize();
    }
    
    update() {
        // mouse wheel zoom in/out
        if (this.sys.game.device.os.desktop) {
            if (this.cursorKeys.up.isDown) {
                camera.zoom *= 1.1;
            } else if (this.cursorKeys.down.isDown) {
                
                camera.zoom *= 0.9;
            }
        }
        camera.setZoom(Phaser.Math.Clamp(camera.zoom, this.minZoom, this.maxZoom));
    }

    showLabels(country) {

        // get countries (sprites) array from the container
        this.countriesArray = this.canadaContainer.getAll();

        for (let i = 0; i < this.countriesArray.length; i++) {
            
            let country = this.countriesArray[i];

            if (country.name === countriesLabels.princeEdwardIsland) {
                let line = this.add.image(country.lineX, country.lineY, "linePrinceEdward");
                line.setOrigin(0,0.5);
                this.canadaContainer.add(line);
            }
            else if (country.name === countriesLabels.novaScotia) {
                let line = this.add.image(country.lineX, country.lineY, "lineNovaScotia");
                line.setOrigin(0,0.5);
                this.canadaContainer.add(line);
            }
            else if (country.name === countriesLabels.newBrunswick) {
                let line = this.add.image(country.lineX, country.lineY, "lineNewBrunswick");
                line.setOrigin(.5,.5);
                this.canadaContainer.add(line);
            }

            country.txt = this.add.text(country.x, country.y, country.name, { fontFamily: "bold", fontSize: 14, color: '#000000' });
            country.txt.setOrigin(.5,.5);
            this.canadaContainer.add(country.txt);
            // position text
            if (country.labelX) {
                country.txt.x = country.labelX;
                country.txt.y = country.labelY;
            }

            // create white rectangle
            country.rect = this.add.sprite(country.txt.x, country.txt.y, "rectangle");
            country.rect.displayWidth = country.txt.width + 4;
            country.rect.displayHeight = country.txt.height;
            this.canadaContainer.add(country.rect);

            // set different origin for certain text and rectangles
            if (country.name === countriesLabels.princeEdwardIsland || country.name === countriesLabels.novaScotia) {
                country.rect.setOrigin(0, 0.5);
                country.txt.setOrigin(0, 0.5);
                country.txt.x += 2;
            }
            // bring to top text field
            this.canadaContainer.bringToTop(country.txt);
        }
    }

    setPositions() {
        width = this.cameras.main.width;
        height = this.cameras.main.height;
        this.canadaContainer.setSize(width, height);
        this.canadaContainer.x = 0;
        this.canadaContainer.y = 0;
    }
}
