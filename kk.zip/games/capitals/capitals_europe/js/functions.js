function stop_game() {
	window.location.href = website_url;
}

function mouseWheelScroll() {
    // mouse wheel on desktop
    if (game.global.instructions == true)
    {
        if (game.device.desktop) {
            mouseWheel = game.input.mouseWheel;
            mouseWheel.callback = scrollIt;

            scroll_instruction = game.add.sprite(400, 400, 'scroll_desktop');
        }
        else
        {
            scroll_instruction = game.add.sprite(370, 400, 'scroll_mobile');
            tween = game.add.tween(scroll_instruction).to({y: 300}, 500, "Linear", true, 0, 2, true);
            tween.onComplete.add(function(){
                scroll_instruction.visible = false;
            },this);
        }
        
        game.global.instructions = false;
    }
}

function scrollIt(event)
{
    var cState = game.state.getCurrentState().key;
    
    if (cState === "library") {
        if (mouseWheel.delta == 1 && flags_group.y < 100){
            flags_group.y += 50
        }
        else if (mouseWheel.delta == -1 && flags_group.y > -2000){
            flags_group.y -= 50
        }
    }
    else if (cState === "options" && central_and_eastern_group.visible === true) {
        if (central_and_eastern_group.visible) {

            if (mouseWheel.delta == 1 && central_and_eastern_group.y < 0) {
                central_and_eastern_group.y += 50
            } else if (mouseWheel.delta == -1 && central_and_eastern_group.y > -320) {
                central_and_eastern_group.y -= 50
            }
        }
    }
    
    if (scroll_instruction.visible)
    {
        scroll_instruction.visible = false
    }
}

function go_to_menu() {
    /* show large background on mobile
    if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent))
    {
        var img = document.getElementById("flags-bg").style.display = 'block';
    } */
    game.state.start("menu")
}

function shuffle(a) {
    for (let i = a.length - 1; i > 0; i--) 
    {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

function go_fullscreen() {
    if (game.scale.isFullScreen)
    {
        game.scale.stopFullScreen()
    }
    else
    {
        game.scale.startFullScreen(false, false)
    }
}

function toggle_sound() {
	game.sound.mute = ! game.sound.mute;
	button_sound.frame = game.sound.mute ? 1 : 0;
    
    // save sound frame
    sound_frame = button_sound.frame
}

function tween_object(this_object)
{
    game.add.tween(this_object).to({alpha: 1}, 600, "Linear", true)
}